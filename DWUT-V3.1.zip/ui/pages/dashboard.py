"""
ui/pages/dashboard.py — fully responsive, no fixed widths, no layout jank.

Layout rules:
  - StatCards use equal-weight grid columns so they always fill available width
  - Detail cards (sys/net/mem) use proportional weights: 2 / 1 / 1
  - All padx/pady use relative values so the page scales smoothly
  - No pack_propagate(False) on resizable containers
  - GPU name label placed correctly AFTER the cards
  - Single persistent background worker — never recreated on page switch
"""

from __future__ import annotations

import threading
from typing import Optional

import customtkinter as ctk

from app.config import config
from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from modules.system.info import (
    DashboardSnapshot,
    SystemHealthScore,
    compute_health_score,
    get_dashboard_snapshot,
    gpu_detection_status,
    gpu_packages_missing,
    install_gpu_packages,
)
from ui.theme import TOKENS, get_font, card_style
from ui.widgets.tooltip import InfoBadge, attach_tooltip

_log = get_logger(__name__)


# ── Stat Card ─────────────────────────────────────────────────────────────────

class StatCard(ctk.CTkFrame):
    """
    Responsive metric card.  Uses grid weight so cards share width equally.
    Does NOT use pack_propagate(False) — it grows with the window.
    """

    def __init__(self, parent, title: str, unit: str = "",
                 color: str = "", tooltip: str = "") -> None:
        super().__init__(
            parent,
            fg_color=TOKENS["bg_card"],
            corner_radius=8,
            border_width=1,
            border_color=TOKENS["border"],
        )
        self._unit   = unit
        self._accent = color or TOKENS["accent"]

        # Title row
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.pack(pady=(10, 2), padx=10)
        ctk.CTkLabel(
            hdr, text=title,
            font=get_font(11), text_color=TOKENS["text_secondary"],
        ).pack(side="left")
        if tooltip:
            InfoBadge(hdr, tooltip).pack(side="left", padx=3)

        # Big value
        self._val_label = ctk.CTkLabel(
            self, text="—",
            font=get_font(24, "bold"), text_color=self._accent,
        )
        self._val_label.pack(padx=10)

        # Progress bar
        self._bar = ctk.CTkProgressBar(
            self, height=3,
            fg_color=TOKENS["bg_input"],
            progress_color=self._accent,
            corner_radius=2,
        )
        self._bar.set(0)
        self._bar.pack(fill="x", padx=12, pady=(4, 10))

    def update_value(self, value: Optional[float], pct: Optional[float] = None) -> None:
        """Update in-place — no widget recreation."""
        if value is None:
            self._val_label.configure(text="N/A", text_color=TOKENS["text_disabled"])
            self._bar.set(0)
        else:
            self._val_label.configure(
                text=f"{value:.0f}{self._unit}",
                text_color=self._accent,
            )
            if pct is not None:
                self._bar.set(max(0.0, min(1.0, pct / 100.0)))

    def set_text(self, text: str, color: Optional[str] = None) -> None:
        """Show an arbitrary string (e.g. 'Detected') without a unit."""
        self._val_label.configure(
            text=text,
            text_color=color or TOKENS["text_secondary"],
        )
        self._bar.set(0)


# ── Detail card helper ────────────────────────────────────────────────────────

def _detail_card(parent, title: str, tip: str = "") -> tuple[ctk.CTkFrame, dict]:
    """Return (card_frame, {key: label}) for a key/value info card."""
    f = ctk.CTkFrame(parent, **card_style())

    hdr = ctk.CTkFrame(f, fg_color="transparent")
    hdr.pack(fill="x", padx=12, pady=(10, 6))
    ctk.CTkLabel(
        hdr, text=title,
        font=get_font(13, "bold"), text_color=TOKENS["text_primary"],
    ).pack(side="left")
    if tip:
        InfoBadge(hdr, tip).pack(side="left", padx=5)

    return f, hdr


# ── Dashboard page ────────────────────────────────────────────────────────────

class DashboardPage:
    def __init__(self, parent: ctk.CTkFrame) -> None:
        self.frame = ctk.CTkFrame(parent, fg_color=TOKENS["bg_base"], corner_radius=0)
        self._visible = False
        self._stop_ev: Optional[threading.Event] = None
        self._sys_labels: dict[str, ctk.CTkLabel] = {}
        self._net_labels: dict[str, ctk.CTkLabel] = {}
        self._mem_labels: dict[str, ctk.CTkLabel] = {}

        self._build()
        bus.subscribe(Events.DASHBOARD_STATS, self._on_stats)

    # ── Build ──────────────────────────────────────────────────────────────

    def _build(self) -> None:
        P = 16   # base padding

        # ── Title row ─────────────────────────────────────────────────────
        title_bar = ctk.CTkFrame(self.frame, fg_color="transparent", height=48)
        title_bar.pack(fill="x", padx=P, pady=(P, 0))
        title_bar.pack_propagate(False)

        ctk.CTkLabel(
            title_bar, text="System Overview",
            font=get_font(18, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left", pady=10)

        self._health_badge = ctk.CTkLabel(
            title_bar, text="Health: —",
            font=get_font(12, "bold"), text_color=TOKENS["text_secondary"],
        )
        self._health_badge.pack(side="right", pady=10)

        # ── Stat cards — equal-weight grid ────────────────────────────────
        cards_outer = ctk.CTkFrame(self.frame, fg_color="transparent")
        cards_outer.pack(fill="x", padx=P, pady=(10, 8))

        # 5 columns, all equal weight → cards always share available width
        for col in range(5):
            cards_outer.columnconfigure(col, weight=1, uniform="statcard")

        self._cpu_card  = StatCard(cards_outer, "CPU",      "%",  TOKENS["accent"],
            "CPU utilisation across all logical cores.")
        self._ram_card  = StatCard(cards_outer, "RAM",      "%",  TOKENS["success"],
            "Physical memory in use as a percentage of total RAM.")
        self._disk_card = StatCard(cards_outer, "DISK",     "%",  TOKENS["warning"],
            "C: drive usage. High usage slows Windows significantly.")
        self._gpu_card  = StatCard(cards_outer, "GPU",      "%",  TOKENS["info"],
            "GPU core load, any vendor.\n\nUses NVML on NVIDIA, Windows' own "
            "GPU Engine counters otherwise (same source as Task Manager's "
            "GPU graph) — needs the 'wmi' package installed.")
        self._temp_card = StatCard(cards_outer, "GPU °C",   "°",  TOKENS["error"],
            "GPU temperature in Celsius.\nAvailable via pynvml (NVIDIA) or "
            "OpenHardwareMonitor.\nN/A is normal if neither is running — "
            "Windows has no vendor-agnostic temperature counter.")

        for col, card in enumerate((self._cpu_card, self._ram_card,
                                    self._disk_card, self._gpu_card, self._temp_card)):
            card.grid(row=0, column=col, sticky="nsew", padx=4, pady=2)

        # GPU name label below the cards, with a one-click installer for
        # the missing wmi/pynvml packages when that's why it's not detected
        gpu_row = ctk.CTkFrame(cards_outer, fg_color="transparent")
        gpu_row.grid(row=1, column=0, columnspan=5, sticky="e", padx=4, pady=(0, 2))

        self._gpu_install_btn = ctk.CTkButton(
            gpu_row, text="Install GPU Support", width=140, height=22,
            font=get_font(9), fg_color=TOKENS["accent_dim"], hover_color=TOKENS["accent"],
            command=self._install_gpu_packages,
        )
        # Hidden until we actually know packages are missing (see _on_stats)

        self._gpu_name_label = ctk.CTkLabel(
            gpu_row, text="",
            font=get_font(9), text_color=TOKENS["text_disabled"], anchor="e",
        )
        self._gpu_name_label.pack(side="right")

        # ── Detail cards — proportional grid ──────────────────────────────
        detail_outer = ctk.CTkFrame(self.frame, fg_color="transparent")
        detail_outer.pack(fill="x", padx=P, pady=(0, 8))
        detail_outer.columnconfigure(0, weight=3)   # System card wider
        detail_outer.columnconfigure(1, weight=2)   # Network
        detail_outer.columnconfigure(2, weight=2)   # Memory

        sys_card = self._build_sys_card(detail_outer)
        net_card = self._build_net_card(detail_outer)
        mem_card = self._build_mem_card(detail_outer)

        sys_card.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
        net_card.grid(row=0, column=1, sticky="nsew", padx=(0, 4))
        mem_card.grid(row=0, column=2, sticky="nsew")

        # ── Quick actions ──────────────────────────────────────────────────
        qa_card = ctk.CTkFrame(self.frame, **card_style())
        qa_card.pack(fill="x", padx=P, pady=(0, 8))

        qa_hdr = ctk.CTkFrame(qa_card, fg_color="transparent")
        qa_hdr.pack(fill="x", padx=12, pady=(10, 6))
        ctk.CTkLabel(qa_hdr, text="Quick Actions",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]
                     ).pack(side="left")

        qa_btns = ctk.CTkFrame(qa_card, fg_color="transparent")
        qa_btns.pack(fill="x", padx=12, pady=(0, 10))
        for col in range(5):
            qa_btns.columnconfigure(col, weight=1)

        quick = [
            ("Optimize & Repair",  "optimizer", "SFC, DISM, network reset, tool launchers"),
            ("Game Booster",       "gaming",    "Real process priority + power plan boost"),
            ("Debloat Windows",    "debloat",   "Remove bloatware, disable telemetry & Recall"),
            ("Proxy Center",       "proxy",     "Fetch, validate and export proxies"),
            ("Tools",              "tools",     "Registry cleaner, startup manager, disk cleanup"),
        ]
        for col, (label, page, tip) in enumerate(quick):
            b = ctk.CTkButton(
                qa_btns, text=label,
                fg_color=TOKENS["accent"], hover_color=TOKENS["accent_dim"],
                text_color=TOKENS["accent_text"], font=get_font(12),
                height=32, corner_radius=6,
                command=lambda p=page: bus.publish(Events.PAGE_CHANGE, p),
            )
            b.grid(row=0, column=col, sticky="ew", padx=3)
            attach_tooltip(b, tip)

        # ── Activity log ───────────────────────────────────────────────────

        # ── Internet Speed Test ────────────────────────────────────────────
        speed_card = ctk.CTkFrame(self.frame, **card_style())
        speed_card.pack(fill="x", padx=P, pady=(0, 8))

        speed_hdr = ctk.CTkFrame(speed_card, fg_color="transparent")
        speed_hdr.pack(fill="x", padx=12, pady=(10, 6))
        ctk.CTkLabel(speed_hdr, text="Internet Speed Test",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]
                     ).pack(side="left")
        InfoBadge(
            speed_hdr,
            "Measures real download and upload speed using Cloudflare's\n"
            "speed.cloudflare.com endpoint — no third-party service.\n\n"
            "Download: fetches a 10 MB payload, measures throughput.\n"
            "Upload: sends a 2 MB payload, measures throughput.\n"
            "Latency: raw TCP connect time to 1.1.1.1:443.",
        ).pack(side="left", padx=5)

        speed_body = ctk.CTkFrame(speed_card, fg_color="transparent")
        speed_body.pack(fill="x", padx=12, pady=(0, 12))

        self._speed_results: dict[str, ctk.CTkLabel] = {}
        metrics_row = ctk.CTkFrame(speed_body, fg_color="transparent")
        metrics_row.pack(side="left", fill="x", expand=True)

        for col, (key, label, color, tip) in enumerate([
            ("download", "Download", TOKENS["success"],
             "Download speed in Mbps (megabits per second)."),
            ("upload",   "Upload",   TOKENS["accent"],
             "Upload speed in Mbps (megabits per second)."),
            ("latency",  "Latency",  TOKENS["warning"],
             "Round-trip latency to Cloudflare 1.1.1.1:443 in milliseconds."),
        ]):
            box = ctk.CTkFrame(metrics_row, fg_color=TOKENS["bg_input"], corner_radius=6)
            box.pack(side="left", padx=(0, 8), ipadx=8, ipady=4)
            lbl_hdr = ctk.CTkFrame(box, fg_color="transparent")
            lbl_hdr.pack(pady=(4, 0))
            ctk.CTkLabel(lbl_hdr, text=label, font=get_font(10),
                         text_color=TOKENS["text_secondary"]).pack(side="left")
            InfoBadge(lbl_hdr, tip).pack(side="left", padx=2)
            val = ctk.CTkLabel(box, text="—", font=get_font(18, "bold"),
                               text_color=color)
            val.pack(padx=12, pady=(0, 4))
            self._speed_results[key] = val

        self._speed_progress = ctk.CTkProgressBar(
            speed_card,
            fg_color=TOKENS["bg_input"],
            progress_color=TOKENS["accent"],
            height=3, corner_radius=0,
        )
        self._speed_progress.set(0)

        btn_col = ctk.CTkFrame(speed_body, fg_color="transparent")
        btn_col.pack(side="right", padx=(8, 0))

        self._speed_btn = ctk.CTkButton(
            btn_col, text="Run Speed Test",
            fg_color=TOKENS["accent"], hover_color=TOKENS["accent_dim"],
            text_color=TOKENS["accent_text"],
            font=get_font(12), height=34, width=140, corner_radius=6,
            command=self._run_speed_test,
        )
        self._speed_btn.pack()

        self._speed_status = ctk.CTkLabel(
            btn_col, text="",
            font=get_font(9), text_color=TOKENS["text_disabled"],
        )
        self._speed_status.pack(pady=(4, 0))

        log_card = ctk.CTkFrame(self.frame, **card_style())
        log_card.pack(fill="both", expand=True, padx=P, pady=(0, P))

        log_hdr = ctk.CTkFrame(log_card, fg_color="transparent")
        log_hdr.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(log_hdr, text="Recent Activity",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]
                     ).pack(side="left")
        ctk.CTkButton(
            log_hdr, text="Clear",
            fg_color="transparent", hover_color=TOKENS["bg_hover"],
            text_color=TOKENS["text_disabled"], font=get_font(10),
            height=22, width=44, corner_radius=4,
            command=self._clear_log,
        ).pack(side="right")

        self._log_box = ctk.CTkTextbox(
            log_card,
            fg_color=TOKENS["bg_input"],
            text_color=TOKENS["text_secondary"],
            font=get_font(10, mono=True),
            corner_radius=4,
        )
        self._log_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self._log_box.configure(state="disabled")
        bus.subscribe(Events.LOG_LINE, self._on_log_line)

    def _build_sys_card(self, parent) -> ctk.CTkFrame:
        f = ctk.CTkFrame(parent, **card_style())
        hdr = ctk.CTkFrame(f, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(hdr, text="System",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]).pack(side="left")

        rows = [
            ("CPU",    "CPU model name"),
            ("OS",     "Windows build number"),
            ("Uptime", "Time since last restart — long uptimes lower the health score"),
            ("Host",   "Machine hostname"),
            ("Admin",  "Administrator rights — most DWUT features require this"),
            ("Reboot", "Whether Windows needs a restart to finish installing updates"),
        ]
        for key, tip in rows:
            row = ctk.CTkFrame(f, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=2)

            key_frame = ctk.CTkFrame(row, fg_color="transparent")
            key_frame.pack(side="left")
            ctk.CTkLabel(key_frame, text=f"{key}:",
                         font=get_font(11), text_color=TOKENS["text_secondary"],
                         width=54, anchor="w").pack(side="left")
            InfoBadge(key_frame, tip).pack(side="left", padx=2)

            val = ctk.CTkLabel(
                row, text="—",
                font=get_font(11), text_color=TOKENS["text_primary"],
                anchor="w",
            )
            val.pack(side="left", padx=6, fill="x", expand=True)
            self._sys_labels[key] = val

        ctk.CTkFrame(f, fg_color="transparent", height=6).pack()
        return f

    def _build_net_card(self, parent) -> ctk.CTkFrame:
        f = ctk.CTkFrame(parent, **card_style())
        hdr = ctk.CTkFrame(f, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(hdr, text="Network",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(hdr, "Live network send/receive rates and totals since boot.").pack(side="left", padx=5)

        rows = [
            ("Send Rate", "Current upload speed"),
            ("Recv Rate", "Current download speed"),
            ("Total Sent", "Total bytes sent since boot"),
            ("Total Recv", "Total bytes received since boot"),
        ]
        for key, tip in rows:
            row = ctk.CTkFrame(f, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=2)
            key_f = ctk.CTkFrame(row, fg_color="transparent")
            key_f.pack(side="left")
            ctk.CTkLabel(key_f, text=f"{key}:", font=get_font(11),
                         text_color=TOKENS["text_secondary"], width=74, anchor="w").pack(side="left")
            InfoBadge(key_f, tip).pack(side="left", padx=2)
            val = ctk.CTkLabel(row, text="—", font=get_font(11),
                               text_color=TOKENS["text_primary"], anchor="w")
            val.pack(side="left", padx=6, fill="x", expand=True)
            self._net_labels[key] = val

        ctk.CTkFrame(f, fg_color="transparent", height=6).pack()
        return f

    def _build_mem_card(self, parent) -> ctk.CTkFrame:
        f = ctk.CTkFrame(parent, **card_style())
        hdr = ctk.CTkFrame(f, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(hdr, text="Memory",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(hdr, "Physical RAM usage breakdown.").pack(side="left", padx=5)

        rows = [
            ("Used",  "RAM currently in use"),
            ("Free",  "RAM available for new processes"),
            ("Total", "Total physical RAM installed"),
            ("Usage", "Percentage of RAM in use"),
        ]
        for key, tip in rows:
            row = ctk.CTkFrame(f, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=2)
            key_f = ctk.CTkFrame(row, fg_color="transparent")
            key_f.pack(side="left")
            ctk.CTkLabel(key_f, text=f"{key}:", font=get_font(11),
                         text_color=TOKENS["text_secondary"], width=46, anchor="w").pack(side="left")
            InfoBadge(key_f, tip).pack(side="left", padx=2)
            val = ctk.CTkLabel(row, text="—", font=get_font(11),
                               text_color=TOKENS["text_primary"], anchor="w")
            val.pack(side="left", padx=6, fill="x", expand=True)
            self._mem_labels[key] = val

        ctk.CTkFrame(f, fg_color="transparent", height=6).pack()
        return f

    # ── Lifecycle ──────────────────────────────────────────────────────────


    def _run_speed_test(self, initial: bool = False) -> None:
        """
        Accurate multi-stream speed test.

        WHY SINGLE STREAM IS WRONG FOR FAST CONNECTIONS
        ────────────────────────────────────────────────
        A 600 Mbps connection can saturate a single TCP stream in about 13 ms
        round-trip, but a single HTTP request with Python's requests library
        adds overhead (GIL, chunked-read loop, TLS) that caps throughput at
        ~100–200 Mbps regardless of actual link speed.

        The fix: run PARALLEL streams simultaneously, sum their throughput,
        and take the peak 1-second window.  This is exactly what fast.com,
        speed.cloudflare.com, and nperf do.

        IMPLEMENTATION
        ──────────────
        Download: 8 parallel HTTPS streams × 100 MB each from
                  speed.cloudflare.com/__down?bytes=104857600
                  We read for 10 seconds, measure bytes received per second
                  across all streams, and take the average of the top 3
                  1-second windows.

        Upload:   4 parallel streams × 20 MB each to __up, same timing.

        Latency:  10 raw TCP round-trips to 1.1.1.1:443, take p10 (best).

        All runs on the worker thread pool — zero UI blocking.
        """
        import socket, time, threading
        import requests

        if not initial:
            try:
                self._speed_btn.configure(state="disabled", text="Running…")
                self._speed_progress.set(0)
                self._speed_progress.pack(fill="x", padx=12, pady=(0, 6))
                self._speed_status.configure(text="Measuring latency…")
            except Exception:
                pass
            for key in ("download", "upload", "latency"):
                try:
                    self._speed_results[key].configure(text="…")
                except Exception:
                    pass

        def _ui(fn):
            """Marshal fn() to the UI thread safely."""
            try:
                self.frame.after(0, fn)
            except Exception:
                pass

        def _progress(val: float, status: str) -> None:
            _ui(lambda: (
                self._speed_progress.set(val),
                self._speed_status.configure(text=status),
            ))

        # ── Shared byte counter for parallel streams ────────────────────
        class _Counter:
            __slots__ = ("lock", "buckets", "t0")
            def __init__(self, t0: float):
                self.lock    = threading.Lock()
                self.buckets: dict[int, int] = {}   # second_index → bytes
                self.t0 = t0

            def add(self, n_bytes: int) -> None:
                sec = int(time.monotonic() - self.t0)
                with self.lock:
                    self.buckets[sec] = self.buckets.get(sec, 0) + n_bytes

            def peak_mbps(self, top_n: int = 3) -> float:
                """Average of the top-N 1-second buckets → Mbps."""
                with self.lock:
                    vals = sorted(self.buckets.values(), reverse=True)
                if not vals:
                    return 0.0
                top = vals[:top_n]
                return (sum(top) / len(top)) * 8 / 1_000_000

        # Headers that match what speed.cloudflare.com's own UI sends —
        # without these Cloudflare returns 403 for the /__down endpoint.
        _CF_HEADERS = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/124.0.0.0 Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://speed.cloudflare.com/",
            "Origin": "https://speed.cloudflare.com",
        }

        def _dl_stream(counter: _Counter, dur: float) -> None:
            """One download stream — reads until dur seconds elapsed."""
            try:
                sess = requests.Session()
                # 100 MB payload — more than enough for any 10-second window
                resp = sess.get(
                    "https://speed.cloudflare.com/__down?bytes=104857600",
                    stream=True, timeout=dur + 5,
                    headers=_CF_HEADERS,
                )
                resp.raise_for_status()
                deadline = counter.t0 + dur
                for chunk in resp.iter_content(chunk_size=131072):
                    if chunk:
                        counter.add(len(chunk))
                    if time.monotonic() >= deadline:
                        break
            except Exception:
                pass

        def _ul_stream(counter: _Counter, dur: float) -> None:
            """One upload stream — POSTs until dur seconds elapsed."""
            try:
                # Generator that yields chunks for the duration AND counts bytes
                chunk = b"\x00" * 131072   # 128 KB chunks
                deadline = counter.t0 + dur

                def _gen():
                    while time.monotonic() < deadline:
                        counter.add(len(chunk))   # count before sending
                        yield chunk

                ul_headers = dict(_CF_HEADERS)
                ul_headers["Content-Type"] = "application/octet-stream"

                sess = requests.Session()
                sess.post(
                    "https://speed.cloudflare.com/__up",
                    data=_gen(),
                    headers=ul_headers,
                    timeout=dur + 5,
                )
            except Exception:
                pass

        def _do_test() -> dict:
            results: dict = {}

            # 1. Latency — 10 TCP round-trips, take p10 (best ~= bufferbloat-free)
            try:
                samples = []
                for _ in range(10):
                    t0 = time.monotonic()
                    s = socket.create_connection(("1.1.1.1", 443), timeout=3)
                    samples.append((time.monotonic() - t0) * 1000)
                    s.close()
                samples.sort()
                results["latency"] = samples[0]   # p10 of 10 = best
                results["latency_avg"] = sum(samples) / len(samples)
            except Exception as exc:
                results["latency"] = None

            _progress(0.15, "Measuring download… (8 parallel streams)")

            # 2. Download — 8 parallel streams for 10 seconds
            DL_STREAMS = 8
            DL_DUR     = 10.0
            dl_t0      = time.monotonic()
            dl_counter = _Counter(dl_t0)

            dl_threads = [
                threading.Thread(target=_dl_stream, args=(dl_counter, DL_DUR), daemon=True)
                for _ in range(DL_STREAMS)
            ]
            for t in dl_threads: t.start()

            # Update progress while download runs
            while any(t.is_alive() for t in dl_threads):
                elapsed = time.monotonic() - dl_t0
                frac = min(elapsed / DL_DUR, 1.0)
                current_mbps = dl_counter.peak_mbps(1)
                _progress(0.15 + frac * 0.50,
                          f"Download… {current_mbps:.0f} Mbps ({int(elapsed)}s / {int(DL_DUR)}s)")
                time.sleep(0.4)

            results["download"] = dl_counter.peak_mbps(3)

            _progress(0.65, "Measuring upload… (4 parallel streams)")

            # 3. Upload — 4 parallel streams for 8 seconds
            UL_STREAMS = 4
            UL_DUR     = 8.0
            ul_t0      = time.monotonic()
            ul_counter = _Counter(ul_t0)

            ul_threads = [
                threading.Thread(target=_ul_stream, args=(ul_counter, UL_DUR), daemon=True)
                for _ in range(UL_STREAMS)
            ]
            for t in ul_threads: t.start()

            while any(t.is_alive() for t in ul_threads):
                elapsed = time.monotonic() - ul_t0
                frac = min(elapsed / UL_DUR, 1.0)
                current_mbps = ul_counter.peak_mbps(1)
                _progress(0.65 + frac * 0.30,
                          f"Upload… {current_mbps:.0f} Mbps ({int(elapsed)}s / {int(UL_DUR)}s)")
                time.sleep(0.4)

            results["upload"] = ul_counter.peak_mbps(3)

            _progress(1.0, "Done.")
            return results

        def _on_done(results: dict) -> None:
            try:
                lat = results.get("latency")
                dl  = results.get("download")
                ul  = results.get("upload")

                self._speed_results["latency"].configure(
                    text=f"{lat:.0f} ms" if lat is not None else "err"
                )
                self._speed_results["download"].configure(
                    text=f"{dl:.0f} Mbps" if dl is not None else "err"
                )
                self._speed_results["upload"].configure(
                    text=f"{ul:.0f} Mbps" if ul is not None else "err"
                )
                self._speed_btn.configure(state="normal", text="Run Speed Test")
                self.frame.after(2000, lambda: (
                    self._speed_progress.set(0),
                    self._speed_progress.pack_forget(),
                ))
            except Exception:
                pass

        worker.submit(
            _do_test,
            on_done=lambda r: self.frame.after(0, _on_done, r),
            on_error=lambda e: self.frame.after(0, lambda: (
                self._speed_btn.configure(state="normal", text="Run Speed Test"),
                self._speed_status.configure(text=f"Error: {e}"),
            )),
        )

    def on_show(self) -> None:
        self._visible = True
        if self._stop_ev is None:
            interval = config.dashboard_refresh_ms / 1000.0
            self._stop_ev = worker.submit_periodic(self._do_refresh, interval)

        # Auto-run speed test on first visit so results are ready immediately.
        # Runs entirely on the worker thread — zero UI blocking.
        if not getattr(self, "_speed_test_started", False):
            self._speed_test_started = True
            # Small delay so the dashboard renders fully before the test begins
            self.frame.after(800, self._run_speed_test)

    def on_hide(self) -> None:
        self._visible = False

    def _do_refresh(self) -> None:
        if not self._visible:
            return
        snap = get_dashboard_snapshot()
        bus.publish(Events.DASHBOARD_STATS, snap)

    # ── Update callbacks ───────────────────────────────────────────────────

    def _on_stats(self, snap: DashboardSnapshot) -> None:
        if not self._visible:
            return
        health = compute_health_score(snap)
        self._update_cards(snap)
        self._update_sys(snap)
        self._update_net(snap)
        self._update_mem(snap)
        self._update_health(health)

    def _update_cards(self, snap: DashboardSnapshot) -> None:
        self._cpu_card.update_value(snap.cpu_pct, snap.cpu_pct)
        self._ram_card.update_value(snap.ram_pct, snap.ram_pct)
        self._disk_card.update_value(snap.disk_pct, snap.disk_pct)

        if snap.gpu:
            src_map = {"nvml": "NVML", "ohm": "OHM", "perfcounter": "GPU Engine", "wmi_name": "WMI"}
            src_label = src_map.get(snap.gpu.source, "")
            self._gpu_name_label.configure(
                text=f"{snap.gpu.name}  [{src_label}]" if src_label else snap.gpu.name
            )
            if snap.gpu.usage_pct is not None:
                self._gpu_card.update_value(snap.gpu.usage_pct, snap.gpu.usage_pct)
            else:
                self._gpu_card.set_text("Detected", TOKENS["text_secondary"])

            if snap.gpu.temp_c is not None:
                self._temp_card.update_value(snap.gpu.temp_c)
            else:
                self._temp_card.update_value(None)

            if self._gpu_install_btn.winfo_ismapped():
                self._gpu_install_btn.pack_forget()
        else:
            self._gpu_card.update_value(None)
            self._temp_card.update_value(None)
            self._gpu_name_label.configure(text=f"GPU: not detected — {gpu_detection_status()}")

            if gpu_packages_missing():
                if not self._gpu_install_btn.winfo_ismapped():
                    self._gpu_install_btn.pack(side="right", padx=(0, 8))
            elif self._gpu_install_btn.winfo_ismapped():
                self._gpu_install_btn.pack_forget()

    def _install_gpu_packages(self) -> None:
        self._gpu_install_btn.configure(state="disabled", text="Installing…")

        def _on_done(result: tuple[bool, str]) -> None:
            ok, msg = result
            self._gpu_install_btn.configure(state="normal", text="Install GPU Support")
            from tkinter import messagebox
            if ok:
                messagebox.showinfo("GPU Support", msg, parent=self.frame.winfo_toplevel())
            else:
                messagebox.showerror(
                    "Install Failed",
                    f"Couldn't install GPU packages:\n\n{msg}",
                    parent=self.frame.winfo_toplevel(),
                )

        worker.submit(install_gpu_packages,
                       on_done=lambda r: self.frame.after(0, _on_done, r))

    def _update_sys(self, snap: DashboardSnapshot) -> None:
        def _uptime(td) -> str:
            s = int(td.total_seconds())
            d, r = divmod(s, 86400)
            h, r2 = divmod(r, 3600)
            m = r2 // 60
            return f"{d}d {h}h {m}m" if d else f"{h}h {m}m"

        self._sys_labels["CPU"].configure(text=snap.cpu_name)
        self._sys_labels["OS"].configure(text=snap.windows_version)
        self._sys_labels["Uptime"].configure(text=_uptime(snap.uptime))
        self._sys_labels["Host"].configure(text=snap.hostname)
        self._sys_labels["Admin"].configure(
            text="Yes" if snap.is_admin else "No — restart as admin",
            text_color=TOKENS["success"] if snap.is_admin else TOKENS["warning"],
        )
        self._sys_labels["Reboot"].configure(
            text="Restart pending" if snap.pending_reboot else "None",
            text_color=TOKENS["warning"] if snap.pending_reboot else TOKENS["success"],
        )

    def _update_net(self, snap: DashboardSnapshot) -> None:
        def _rate(v: Optional[float]) -> str:
            if v is None: return "—"
            if v > 1024:  return f"{v/1024:.1f} MB/s"
            return f"{v:.0f} KB/s"

        def _total(b: int) -> str:
            for u in ("B", "KB", "MB", "GB", "TB"):
                if b < 1024: return f"{b:.1f} {u}"
                b //= 1024
            return f"{b:.1f} PB"

        n = snap.net
        self._net_labels["Send Rate"].configure(text=_rate(n.send_rate_kbps))
        self._net_labels["Recv Rate"].configure(text=_rate(n.recv_rate_kbps))
        self._net_labels["Total Sent"].configure(text=_total(n.bytes_sent))
        self._net_labels["Total Recv"].configure(text=_total(n.bytes_recv))

    def _update_mem(self, snap: DashboardSnapshot) -> None:
        free = snap.ram_total_gb - snap.ram_used_gb
        self._mem_labels["Used"].configure(text=f"{snap.ram_used_gb:.1f} GB")
        self._mem_labels["Free"].configure(text=f"{free:.1f} GB")
        self._mem_labels["Total"].configure(text=f"{snap.ram_total_gb:.1f} GB")
        self._mem_labels["Usage"].configure(text=f"{snap.ram_pct:.1f}%")

    def _update_health(self, health: SystemHealthScore) -> None:
        colors = {
            "Excellent": TOKENS["success"],
            "Good":      TOKENS["accent"],
            "Fair":      TOKENS["warning"],
            "Poor":      TOKENS["error"],
        }
        self._health_badge.configure(
            text=f"Health: {health.total}%  —  {health.label}",
            text_color=colors.get(health.label, TOKENS["text_secondary"]),
        )

    def _on_log_line(self, record) -> None:
        if not self._visible:
            return
        ts   = record.timestamp.strftime("%H:%M:%S")
        line = f"[{ts}]  {record.level:<7}  {record.message}\n"
        self._log_box.configure(state="normal")
        self._log_box.insert("end", line)
        self._log_count = getattr(self, "_log_count", 0) + 1
        if self._log_count > 150:
            self._log_box.delete("1.0", "10.0")
            self._log_count -= 9
        self._log_box.see("end")
        self._log_box.configure(state="disabled")

    def _clear_log(self) -> None:
        self._log_box.configure(state="normal")
        self._log_box.delete("1.0", "end")
        self._log_count = 0
        self._log_box.configure(state="disabled")

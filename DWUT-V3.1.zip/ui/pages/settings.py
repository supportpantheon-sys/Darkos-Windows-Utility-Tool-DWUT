"""
ui/pages/settings.py — Settings

Sections:
  Appearance   — 12-theme picker with live preview swatches
  Dashboard    — refresh interval, GPU toggle

  Safety       — restore point, confirm, restore-on-close
  About        — version, open logs, open backups
"""

from __future__ import annotations

import subprocess

import colorsys
import math
import tkinter as tk

import customtkinter as ctk

from app.config import LOGS_DIR, BACKUPS_DIR, config
from core.events import Events, bus
from core.logger import get_logger
from ui.widgets.smooth_scroll import SmoothScrollFrame
from ui.theme import (
    TOKENS, all_theme_names, apply_theme, current_theme,
    display_name, button_style, card_style, get_font,
    set_typography,
)
from ui.widgets.tooltip import InfoBadge, attach_tooltip

_log = get_logger(__name__)
_VERSION = "1.0.0-dev"


class _ColorPickerDialog:
    """
    Full HSV color picker dialog:
      - Hue ring (full 360° spectrum)
      - Saturation/Value square
      - Live preview swatch
      - Hex entry with live update
      - Recent colour history (last 8 picks)
    """
    _recent: list[str] = []   # class-level, persisted across opens
    _RING_OUTER = 140
    _RING_INNER = 104
    _SQ_SIZE    = 96

    def __init__(self, parent, initial_color: str, on_select):
        self._on_select = on_select
        self._h, self._s, self._v = 0.0, 1.0, 1.0

        # Parse initial colour
        try:
            r, g, b = self._hex_to_rgb(initial_color)
            self._h, self._s, self._v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        except Exception:
            pass

        self._dragging: str | None = None  # 'ring' | 'sq'

        # Window
        root = parent.winfo_toplevel()
        self._win = tk.Toplevel(root)
        self._win.title("Pick Colour")
        self._win.resizable(False, False)
        self._win.configure(bg="#1a1a2e")
        self._win.transient(root)
        self._win.grab_set()

        # Centre on parent
        self._win.update_idletasks()
        px, py = root.winfo_rootx(), root.winfo_rooty()
        pw, ph = root.winfo_width(), root.winfo_height()
        w, h = 340, 460
        x = px + (pw - w) // 2
        y = py + (ph - h) // 2
        self._win.geometry(f"{w}x{h}+{x}+{y}")

        self._build()
        self._redraw_all()

    # ── Build UI ──────────────────────────────────────────────────────────

    def _build(self):
        BG  = "#1a1a2e"
        BG2 = "#16213e"
        ACC = TOKENS.get("accent", "#7c3aed")
        TXT = "#e0e0e0"
        BDR = "#2d2d4e"

        outer = tk.Frame(self._win, bg=BG, padx=16, pady=16)
        outer.pack(fill="both", expand=True)

        # ── Canvas (ring + square) ────────────────────────────────────────
        D = self._RING_OUTER * 2 + 4
        self._cv = tk.Canvas(outer, width=D, height=D,
                             bg=BG, highlightthickness=0)
        self._cv.pack(pady=(0, 10))

        self._cv.bind("<ButtonPress-1>",   self._on_press)
        self._cv.bind("<B1-Motion>",       self._on_drag)
        self._cv.bind("<ButtonRelease-1>", self._on_release)

        # ── Preview swatch + hex entry row ────────────────────────────────
        row = tk.Frame(outer, bg=BG)
        row.pack(fill="x", pady=(0, 8))

        self._swatch = tk.Label(row, bg=self._current_hex(), width=4,
                                relief="flat", bd=0)
        self._swatch.pack(side="left", ipady=14, padx=(0, 10))

        self._hex_var = tk.StringVar(value=self._current_hex())
        hex_entry = tk.Entry(
            row, textvariable=self._hex_var,
            bg=BG2, fg=TXT, insertbackground=TXT,
            relief="flat", font=("Segoe UI Variable", 12),
            bd=4, width=10,
        )
        hex_entry.pack(side="left", ipady=4)
        self._hex_var.trace_add("write", self._on_hex_input)

        # ── Recent colours ────────────────────────────────────────────────
        rec_lbl = tk.Label(outer, text="Recent", bg=BG, fg="#666680",
                           font=("Segoe UI Variable", 9))
        rec_lbl.pack(anchor="w")

        self._rec_frame = tk.Frame(outer, bg=BG)
        self._rec_frame.pack(fill="x", pady=(2, 8))
        self._rebuild_recent_swatches()

        # ── Buttons ───────────────────────────────────────────────────────
        btn_row = tk.Frame(outer, bg=BG)
        btn_row.pack(fill="x")

        for text, cmd, fg_bg in [
            ("Select",  self._select,  ("#ffffff", ACC)),
            ("Cancel",  self._cancel,  (TXT,       BG2)),
        ]:
            tk.Button(
                btn_row, text=text, command=cmd,
                bg=fg_bg[1], fg=fg_bg[0], activebackground=fg_bg[1],
                relief="flat", font=("Segoe UI Variable", 11, "bold"),
                padx=18, pady=6, cursor="hand2",
            ).pack(side="left", padx=(0, 8))

    # ── Drawing ───────────────────────────────────────────────────────────

    def _redraw_all(self):
        self._cv.delete("all")
        cx = cy = self._RING_OUTER + 2
        self._draw_ring(cx, cy)
        self._draw_square(cx, cy)
        self._draw_ring_cursor(cx, cy)
        self._draw_sq_cursor(cx, cy)
        self._sync_hex_and_swatch()

    def _draw_ring(self, cx, cy):
        """Draw a hue ring with 360 coloured arc segments."""
        outer = self._RING_OUTER
        inner = self._RING_INNER
        for i in range(360):
            a1 = math.radians(i - 1)
            a2 = math.radians(i + 1)
            r, g, b = colorsys.hsv_to_rgb(i / 360, 1.0, 1.0)
            col = "#%02x%02x%02x" % (int(r*255), int(g*255), int(b*255))
            # Draw as overlapping arcs; tk arc is chunky so we use small polygons
            cos1, sin1 = math.cos(a1), math.sin(a1)
            cos2, sin2 = math.cos(a2), math.sin(a2)
            pts = [
                cx + outer * cos1, cy - outer * sin1,
                cx + outer * cos2, cy - outer * sin2,
                cx + inner * cos2, cy - inner * sin2,
                cx + inner * cos1, cy - inner * sin1,
            ]
            self._cv.create_polygon(pts, fill=col, outline="")

    def _draw_square(self, cx, cy):
        """Draw the SV square for the current hue."""
        sq = self._SQ_SIZE
        x0, y0 = cx - sq//2, cy - sq//2
        # Draw as horizontal strips (value), each strip as sat gradient
        STEPS = 24
        step_h = sq / STEPS
        step_w = sq / STEPS
        for vi in range(STEPS):
            v = 1.0 - vi / (STEPS - 1)
            for si in range(STEPS):
                s = si / (STEPS - 1)
                r, g, b = colorsys.hsv_to_rgb(self._h, s, v)
                col = "#%02x%02x%02x" % (int(r*255), int(g*255), int(b*255))
                px0 = x0 + si * step_w
                py0 = y0 + vi * step_h
                self._cv.create_rectangle(
                    px0, py0,
                    px0 + step_w + 1, py0 + step_h + 1,
                    fill=col, outline="",
                )

    def _draw_ring_cursor(self, cx, cy):
        angle = math.radians(self._h * 360)
        mid_r = (self._RING_OUTER + self._RING_INNER) / 2
        mx = cx + mid_r * math.cos(angle)
        my = cy - mid_r * math.sin(angle)
        r = 7
        self._cv.create_oval(mx-r, my-r, mx+r, my+r,
                             outline="#ffffff", width=2, fill="")

    def _draw_sq_cursor(self, cx, cy):
        sq = self._SQ_SIZE
        x0, y0 = cx - sq//2, cy - sq//2
        mx = x0 + self._s * sq
        my = y0 + (1 - self._v) * sq
        r = 6
        self._cv.create_oval(mx-r, my-r, mx+r, my+r,
                             outline="#ffffff", width=2, fill="")
        self._cv.create_oval(mx-r+2, my-r+2, mx+r-2, my+r-2,
                             outline="#000000", width=1, fill="")

    # ── Interaction ───────────────────────────────────────────────────────

    def _on_press(self, e):
        cx = cy = self._RING_OUTER + 2
        dist = math.hypot(e.x - cx, e.y - cy)
        if self._RING_INNER < dist <= self._RING_OUTER:
            self._dragging = "ring"
            self._update_ring(e.x, e.y, cx, cy)
        elif dist <= self._SQ_SIZE // 2 * 1.42:
            sq = self._SQ_SIZE
            x0, y0 = cx - sq//2, cy - sq//2
            if x0 <= e.x <= x0+sq and y0 <= e.y <= y0+sq:
                self._dragging = "sq"
                self._update_sq(e.x, e.y, cx, cy)

    def _on_drag(self, e):
        cx = cy = self._RING_OUTER + 2
        if self._dragging == "ring":
            self._update_ring(e.x, e.y, cx, cy)
        elif self._dragging == "sq":
            self._update_sq(e.x, e.y, cx, cy)

    def _on_release(self, e):
        self._dragging = None

    def _update_ring(self, mx, my, cx, cy):
        angle = math.atan2(cy - my, mx - cx)
        self._h = angle / (2 * math.pi) % 1.0
        self._redraw_all()

    def _update_sq(self, mx, my, cx, cy):
        sq = self._SQ_SIZE
        x0, y0 = cx - sq//2, cy - sq//2
        self._s = max(0.0, min(1.0, (mx - x0) / sq))
        self._v = max(0.0, min(1.0, 1.0 - (my - y0) / sq))
        self._redraw_all()

    def _on_hex_input(self, *_):
        val = self._hex_var.get().strip().lstrip("#")
        if len(val) == 6:
            try:
                r, g, b = int(val[0:2],16), int(val[2:4],16), int(val[4:6],16)
                self._h, self._s, self._v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
                self._redraw_all()
            except Exception:
                pass

    def _sync_hex_and_swatch(self):
        hex_col = self._current_hex()
        # Update swatch
        try:
            self._swatch.configure(bg=hex_col)
        except Exception:
            pass
        # Update hex entry without triggering trace again
        current = self._hex_var.get()
        if current.lower() != hex_col.lower():
            self._hex_var.set(hex_col)

    # ── Helpers ───────────────────────────────────────────────────────────

    def _current_hex(self) -> str:
        r, g, b = colorsys.hsv_to_rgb(self._h, self._s, self._v)
        return "#%02x%02x%02x" % (int(r*255), int(g*255), int(b*255))

    @staticmethod
    def _hex_to_rgb(hex_str: str):
        h = hex_str.strip().lstrip("#")
        return int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)

    def _rebuild_recent_swatches(self):
        for w in self._rec_frame.winfo_children():
            w.destroy()
        for col in _ColorPickerDialog._recent[-8:]:
            c = col
            def _pick(color=c):
                try:
                    r, g, b = self._hex_to_rgb(color)
                    self._h, self._s, self._v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
                    self._redraw_all()
                except Exception:
                    pass
            tk.Label(
                self._rec_frame, bg=col, width=3, cursor="hand2",
                relief="flat", bd=1,
            ).pack(side="left", ipadx=2, ipady=10, padx=2)
            self._rec_frame.children[list(self._rec_frame.children)[-1]].bind(
                "<Button-1>", lambda e, f=_pick: f()
            )

    def _select(self):
        hex_col = self._current_hex()
        if hex_col not in _ColorPickerDialog._recent:
            _ColorPickerDialog._recent.append(hex_col)
        self._on_select(hex_col)
        self._win.destroy()

    def _cancel(self):
        self._win.destroy()


class SettingsPage:
    def __init__(self, parent: ctk.CTkFrame) -> None:
        self.frame = ctk.CTkFrame(parent, fg_color=TOKENS["bg_base"], corner_radius=0)
        self._int_vars:    dict[str, ctk.StringVar]  = {}
        self._combo_vars:  dict[str, ctk.StringVar]  = {}
        self._toggle_vars: dict[str, ctk.BooleanVar] = {}
        self._build()

    # ── Layout ─────────────────────────────────────────────────────────────

    def _build(self) -> None:
        title_row = ctk.CTkFrame(self.frame, fg_color="transparent", height=52)
        title_row.pack(fill="x", padx=20, pady=(14, 0))
        title_row.pack_propagate(False)

        ctk.CTkLabel(
            title_row, text="Settings",
            font=get_font(18, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left", pady=10)

        self._save_status = ctk.CTkLabel(
            title_row, text="",
            font=get_font(11), text_color=TOKENS["success"],
        )
        self._save_status.pack(side="right", pady=10)

        ctk.CTkFrame(self.frame, fg_color=TOKENS["border"], height=1).pack(fill="x", padx=20)

        scroll = SmoothScrollFrame(self.frame, fg_color="transparent", corner_radius=0)
        scroll.pack(fill="both", expand=True, padx=20, pady=(10, 0))

        self._build_appearance(scroll)
        self._build_typography(scroll)
        self._build_dashboard(scroll)
        self._build_safety(scroll)
        self._build_about(scroll)

        # Sticky save button
        save_bar = ctk.CTkFrame(self.frame, fg_color=TOKENS["bg_card"],
                                corner_radius=0, height=52, border_width=1,
                                border_color=TOKENS["border"])
        save_bar.pack(fill="x", side="bottom")
        save_bar.pack_propagate(False)

        ctk.CTkButton(
            save_bar, text="Save All Settings",
            **button_style("primary"), height=36, width=180,
            command=self._save,
        ).pack(side="right", padx=16, pady=8)

    # ── Appearance ─────────────────────────────────────────────────────────

    def _build_appearance(self, parent) -> None:
        card = ctk.CTkFrame(parent, **card_style())
        card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=14, pady=(12, 8))
        ctk.CTkLabel(hdr, text="Appearance", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(
            hdr,
            "Choose a colour theme for the entire application.\n\n"
            "Dark/Midnight/Obsidian/Abyss — distinct dark surface palettes\n"
            "Violet/Crimson/Ember/Emerald — dark base tinted toward the accent\n"
            "Nord/Dracula/Solarized       — popular programmer colour schemes\n"
            "High Contrast                — maximum readability\n"
            "Daylight/Paper               — light themes\n\n"
            "Applies instantly — the whole app redraws in the new theme.",
        ).pack(side="left", padx=6)

        # Theme grid — 4 columns of colour swatches
        themes = all_theme_names()
        COLS = 4
        current = current_theme()

        for row_idx in range(0, len(themes), COLS):
            row_frame = ctk.CTkFrame(card, fg_color="transparent")
            row_frame.pack(fill="x", padx=14, pady=3)

            for theme_key in themes[row_idx:row_idx + COLS]:
                self._add_theme_swatch(row_frame, theme_key, current)

        ctk.CTkLabel(
            card,
            text="Theme changes apply instantly. The preview swatch shows accent + background colours.",
            font=get_font(10), text_color=TOKENS["text_disabled"],
        ).pack(anchor="w", padx=14, pady=(4, 12))

    def _add_theme_swatch(self, parent, key: str, current_key: str) -> None:
        from ui.theme import _THEMES, _BASE

        # Resolve accent and bg for the preview swatch
        merged = {**_BASE, **_THEMES.get(key, {})}
        accent = merged.get("accent", _BASE["accent"])
        bg     = merged.get("bg_card", _BASE["bg_card"])

        is_current = key == current_key
        border_col = TOKENS["accent"] if is_current else TOKENS["border"]

        swatch_frame = ctk.CTkFrame(
            parent,
            fg_color=TOKENS["bg_input"],
            corner_radius=8,
            border_width=2,
            border_color=border_col,
            width=110, height=64,
        )
        swatch_frame.pack(side="left", padx=5, pady=2)
        swatch_frame.pack_propagate(False)

        # Colour preview strip at top
        preview = ctk.CTkFrame(swatch_frame, fg_color=bg, corner_radius=6, height=28)
        preview.pack(fill="x", padx=4, pady=(4, 2))
        preview.pack_propagate(False)

        accent_dot = ctk.CTkFrame(preview, fg_color=accent, corner_radius=4, width=24, height=16)
        accent_dot.pack(side="right", padx=4, pady=6)

        # Name + apply button
        name_row = ctk.CTkFrame(swatch_frame, fg_color="transparent")
        name_row.pack(fill="x", padx=4)

        ctk.CTkLabel(
            name_row, text=display_name(key),
            font=get_font(10, "bold" if is_current else "normal"),
            text_color=TOKENS["accent"] if is_current else TOKENS["text_secondary"],
            anchor="w",
        ).pack(side="left")

        if not is_current:
            def _apply(k=key):
                config.theme = k
                config.save()
                apply_theme(k)
                # MainWindow is subscribed to THEME_CHANGE and rebuilds the
                # whole UI tree against the new TOKENS — including recreating
                # this very settings page with the new "Active" swatch — so
                # nothing else needs to happen here.
                bus.publish(Events.THEME_CHANGE, k)

            btn = ctk.CTkButton(
                name_row, text="Use",
                fg_color="transparent",
                hover_color=TOKENS["bg_hover"],
                text_color=TOKENS["text_secondary"],
                font=get_font(9), height=18, width=28, corner_radius=4,
                command=_apply,
            )
            btn.pack(side="right")
        else:
            ctk.CTkLabel(
                name_row, text="Active",
                font=get_font(9), text_color=TOKENS["accent"],
            ).pack(side="right")

    # ── Typography ─────────────────────────────────────────────────────────

    _FONT_CHOICES = [
        "Segoe UI Variable", "Segoe UI", "Inter", "Roboto",
        "Arial", "Calibri", "Verdana", "Tahoma", "Consolas", "Courier New",
    ]
    _SCALE_CHOICES = {
        "Small (85%)":   0.85,
        "Normal (100%)": 1.0,
        "Large (110%)":  1.10,
        "Larger (120%)": 1.20,
    }

    def _build_typography(self, parent) -> None:
        from ui.theme import _FONT_FAMILY, _FONT_SCALE  # type: ignore
        card = ctk.CTkFrame(parent, **card_style())
        card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=14, pady=(12, 8))
        ctk.CTkLabel(hdr, text="Typography", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(
            hdr,
            "Customise the font, text size, and colour used across the whole app.\n\n"
            "Font      — changes the typeface for all labels and buttons\n"
            "Size      — scales all font sizes (85 % – 120 %)\n"
            "Colour    — overrides the primary text colour (picker or hex)\n\n"
            "Click Apply Typography to apply your changes instantly.",
        ).pack(side="left", padx=6)

        # ── Font family ─────────────────────────────────────────────────────
        self._add_labelled_row(
            card,
            label="Font family",
            tip="The typeface used throughout the app.\n\n"
                "Segoe UI Variable is the sharpest on Windows 11.\n"
                "Inter and Roboto are clean open-source alternatives.",
            widget=lambda parent: self._combo(
                parent, "ui_font", _FONT_FAMILY,
                self._FONT_CHOICES, width=190,
                on_change=lambda _: self._update_typo_preview(),
            ),
        )

        # ── Size scale ──────────────────────────────────────────────────────
        current_scale_label = next(
            (k for k, v in self._SCALE_CHOICES.items()
             if abs(v - _FONT_SCALE) < 0.01),
            "Normal (100%)",
        )
        self._add_labelled_row(
            card,
            label="Text size",
            tip="Scale all font sizes up or down.\n"
                "85% = compact  |  100% = default  |  110%/120% = accessibility.",
            widget=lambda parent: self._combo(
                parent, "_ui_font_scale_label", current_scale_label,
                list(self._SCALE_CHOICES.keys()), width=170,
                on_change=lambda _: self._update_typo_preview(),
            ),
        )

        # ── Colour picker row ────────────────────────────────────────────────
        self._typo_color_var = ctk.StringVar(
            value=config.ui_text_color or TOKENS["text_primary"]
        )

        color_row = ctk.CTkFrame(card, fg_color="transparent")
        color_row.pack(fill="x", padx=14, pady=(4, 2))

        lbl_col = ctk.CTkFrame(color_row, fg_color="transparent")
        lbl_col.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(lbl_col, text="Text colour", font=get_font(11),
                     text_color=TOKENS["text_secondary"], anchor="w").pack(side="left")
        InfoBadge(
            lbl_col,
            "Override the primary text colour for the whole app.\n\n"
            "Click the colour swatch to open the picker.\n"
            "You can also type a hex code directly (e.g. #FFD700).\n"
            "Leave blank or click Reset to use the theme default.",
        ).pack(side="left", padx=4)

        ctrl_col = ctk.CTkFrame(color_row, fg_color="transparent")
        ctrl_col.pack(side="right")

        # Hex entry
        self._typo_hex_entry = ctk.CTkEntry(
            ctrl_col,
            textvariable=self._typo_color_var,
            placeholder_text="#RRGGBB",
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"],
            width=100, height=30, corner_radius=4,
        )
        self._typo_hex_entry.pack(side="left", padx=(0, 6))

        # Colour swatch button (shows current colour, opens picker)
        self._typo_swatch = ctk.CTkButton(
            ctrl_col,
            text="",
            fg_color=self._typo_color_var.get() or TOKENS["text_primary"],
            hover_color=self._typo_color_var.get() or TOKENS["text_primary"],
            width=38, height=30, corner_radius=4,
            border_width=2, border_color=TOKENS["border"],
            command=self._open_color_picker,
        )
        self._typo_swatch.pack(side="left", padx=(0, 4))
        attach_tooltip(self._typo_swatch, "Click to open the full colour picker.")

        # Keep swatch synced when hex entry changes
        self._typo_color_var.trace_add("write", self._on_typo_color_changed)

        # ── Preview ─────────────────────────────────────────────────────────
        self._typo_preview = ctk.CTkLabel(
            card,
            text="Preview: The quick brown fox jumps over the lazy dog",
            font=get_font(12),
            text_color=self._typo_color_var.get() or TOKENS["text_primary"],
            anchor="w",
        )
        self._typo_preview.pack(anchor="w", padx=14, pady=(2, 6))

        # ── Buttons ─────────────────────────────────────────────────────────
        btn_row = ctk.CTkFrame(card, fg_color="transparent")
        btn_row.pack(fill="x", padx=14, pady=(2, 12))

        ctk.CTkButton(
            btn_row, text="Apply Typography",
            **button_style("primary"), height=32, width=160,
            command=self._apply_typography,
        ).pack(side="left")

        ctk.CTkButton(
            btn_row, text="Reset to Default",
            **button_style("ghost"), height=32, width=130,
            command=self._reset_typography,
        ).pack(side="left", padx=8)

        self._typo_status = ctk.CTkLabel(
            btn_row, text="",
            font=get_font(10), text_color=TOKENS["success"],
        )
        self._typo_status.pack(side="left", padx=4)

    def _on_typo_color_changed(self, *_) -> None:
        """Live-update the swatch and preview as the hex entry changes."""
        val = self._typo_color_var.get().strip()
        import re as _re
        is_valid = bool(_re.match(r"^#[0-9A-Fa-f]{6}$", val))
        try:
            color = val if is_valid else TOKENS["text_primary"]
            self._typo_swatch.configure(fg_color=color, hover_color=color)
            self._update_typo_preview()
        except Exception:
            pass

    def _update_typo_preview(self) -> None:
        try:
            font_var = self._combo_vars.get("ui_font")
            font_name = font_var.get() if font_var else "Segoe UI Variable"
            scale_var = self._combo_vars.get("_ui_font_scale_label")
            scale_label = scale_var.get() if scale_var else "Normal (100%)"
            scale = self._SCALE_CHOICES.get(scale_label, 1.0)
            color = self._typo_color_var.get().strip() or TOKENS["text_primary"]
            size = max(8, int(12 * scale))
            self._typo_preview.configure(
                font=(font_name, size),
                text_color=color,
            )
        except Exception:
            pass

    def _open_color_picker(self) -> None:
        """Open the HSV color picker popup dialog."""
        _ColorPickerDialog(
            parent=self.frame,
            initial_color=self._typo_color_var.get().strip() or TOKENS["text_primary"],
            on_select=lambda hex_color: self._typo_color_var.set(hex_color),
        )

    def _reset_typography(self) -> None:
        """Clear all typography overrides back to theme defaults."""
        config.ui_font        = "Segoe UI Variable"
        config.ui_font_scale  = 1.0
        config.ui_text_color  = ""
        config.save()
        self._typo_color_var.set(TOKENS["text_primary"])
        set_typography(font=None, scale=None, text_color=None)
        bus.publish(Events.THEME_CHANGE, current_theme())
        self._typo_status.configure(text="Reset to default", text_color=TOKENS["info"])
        self.frame.after(3000, lambda: (
            self._typo_status.configure(text="")
            if self._typo_status.winfo_exists() else None
        ))

    def _apply_typography(self) -> None:
        """Read typography fields, save to config, apply live."""
        font_var = self._combo_vars.get("ui_font")
        if font_var:
            config.ui_font = font_var.get()

        scale_var = self._combo_vars.get("_ui_font_scale_label")
        if scale_var:
            config.ui_font_scale = self._SCALE_CHOICES.get(scale_var.get(), 1.0)

        raw = self._typo_color_var.get().strip()
        if raw and not raw.startswith("#"):
            raw = "#" + raw
        import re as _re
        if raw and not _re.match(r"^#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?$", raw):
            self._typo_status.configure(
                text="Invalid hex colour — use #RRGGBB",
                text_color=TOKENS["error"],
            )
            return
        config.ui_text_color = raw
        config.save()

        set_typography(
            font=config.ui_font or None,
            scale=config.ui_font_scale if config.ui_font_scale != 1.0 else None,
            text_color=config.ui_text_color or None,
        )
        bus.publish(Events.THEME_CHANGE, current_theme())
        self._typo_status.configure(text="Applied!", text_color=TOKENS["success"])
        self.frame.after(3000, lambda: (
            self._typo_status.configure(text="")
            if self._typo_status.winfo_exists() else None
        ))

    # ── Dashboard ──────────────────────────────────────────────────────────

    def _build_dashboard(self, parent) -> None:
        card = ctk.CTkFrame(parent, **card_style())
        card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(card, text="Dashboard", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(anchor="w", padx=14, pady=(12, 6))

        self._add_labelled_row(
            card,
            label="Refresh interval (ms)",
            tip="How often the Dashboard updates CPU, RAM, Disk, and GPU stats.\n\n"
                "Lower = more responsive but uses slightly more CPU.\n"
                "Default is 2000ms (2 seconds). Minimum is 500ms.",
            widget=lambda parent: self._int_entry(parent, "dashboard_refresh_ms", config.dashboard_refresh_ms, width=100),
        )
        self._add_toggle_row(
            card,
            label="Show GPU stats",
            tip="Display GPU usage and temperature on the Dashboard.\n\n"
                "Requires OpenHardwareMonitor to be running. "
                "If OHM is not running, GPU cards will show 'N/A'.",
            attr="show_gpu_stats", current=config.show_gpu_stats,
        )
        ctk.CTkFrame(card, fg_color="transparent", height=6).pack()

    # ── Safety ─────────────────────────────────────────────────────────────

    def _build_safety(self, parent) -> None:
        card = ctk.CTkFrame(parent, **card_style())
        card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(card, text="Safety", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(anchor="w", padx=14, pady=(12, 6))

        self._add_toggle_row(
            card,
            "Auto-create restore point before destructive operations",
            "Automatically creates a Windows System Restore point before running Debloat, "
            "Feature changes, or Registry Cleaner.\n\n"
            "Strongly recommended. Allows rolling back if something goes wrong.\n"
            "Requires System Protection to be enabled on the C: drive.",
            "auto_restore_point", config.auto_restore_point,
        )
        self._add_toggle_row(
            card,
            "Confirm before destructive operations",
            "Show a confirmation dialog before deleting files, removing packages, "
            "or modifying the registry.\n\n"
            "Disable only if you are certain of what you are doing.",
            "confirm_destructive", config.confirm_destructive,
        )
        self._add_toggle_row(
            card,
            "Restore game boost settings when game closes",
            "When the Game Booster detects the game process has exited, "
            "automatically restore the original power plan, process priority, "
            "and registry settings.\n\n"
            "Keeps your system in its normal state when you are not gaming.",
            "restore_on_game_close", config.restore_on_game_close,
        )
        ctk.CTkFrame(card, fg_color="transparent", height=6).pack()

    # ── About ──────────────────────────────────────────────────────────────

    def _build_about(self, parent) -> None:
        card = ctk.CTkFrame(parent, **card_style())
        card.pack(fill="x", pady=(0, 20))

        ctk.CTkLabel(card, text="About DWUT", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(anchor="w", padx=14, pady=(12, 6))

        for line in [
            f"Version       {_VERSION}",
            f"Python        {__import__('sys').version.split()[0]}",
            "",
            "All operations use real Windows APIs — no simulated output, no fake numbers.",
            "Every destructive action creates a restore point or backup first.",
            "",
            "Built with CustomTkinter, psutil, pymem, requests, pywin32.",
        ]:
            ctk.CTkLabel(
                card, text=line,
                font=get_font(11 if line else 5),
                text_color=TOKENS["text_secondary"] if line else TOKENS["bg_card"],
                anchor="w",
            ).pack(anchor="w", padx=14, pady=1)

        btn_row = ctk.CTkFrame(card, fg_color="transparent")
        btn_row.pack(fill="x", padx=14, pady=12)

        for label, cmd, tip in [
            ("Open Logs Folder",    self._open_logs,    "Open the folder containing dwut.log and rotated log files."),
            ("Open Backups Folder", self._open_backups, "Open the folder containing .reg registry backups and debloat session JSON logs."),
            ("Check for Updates",   self._check_updates,"Check GitHub for a newer release of DWUT."),
        ]:
            b = ctk.CTkButton(btn_row, text=label, **button_style("ghost"), height=30, command=cmd)
            attach_tooltip(b, tip)
            b.pack(side="left", padx=(0, 8))

    # ── Widget factories ───────────────────────────────────────────────────

    def _add_labelled_row(self, card, label: str, tip: str, widget) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=4)

        hdr = ctk.CTkFrame(row, fg_color="transparent")
        hdr.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(hdr, text=label, font=get_font(11),
                     text_color=TOKENS["text_secondary"], anchor="w").pack(side="left")
        InfoBadge(hdr, tip).pack(side="left", padx=4)

        w = widget(row) if callable(widget) else widget
        w.pack(side="right")

    def _add_toggle_row(self, card, label: str, tip: str, attr: str, current: bool) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=4)

        hdr = ctk.CTkFrame(row, fg_color="transparent")
        hdr.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(hdr, text=label, font=get_font(11),
                     text_color=TOKENS["text_secondary"], anchor="w").pack(side="left")
        InfoBadge(hdr, tip).pack(side="left", padx=4)

        var = ctk.BooleanVar(value=current)
        self._toggle_vars[attr] = var
        ctk.CTkSwitch(
            row, text="", variable=var,
            fg_color=TOKENS["bg_input"],
            progress_color=TOKENS["accent"],
            button_color=TOKENS["accent"],
            width=44,
        ).pack(side="right")

    def _int_entry(self, parent, attr: str, value: int, width: int = 120) -> ctk.CTkEntry:
        var = ctk.StringVar(value=str(value))
        self._int_vars[attr] = var
        return ctk.CTkEntry(
            parent,
            textvariable=var,
            fg_color=TOKENS["bg_input"],
            border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"],
            width=width, height=28, corner_radius=4,
        )

    def _combo(self, parent, attr: str, value: str, choices: list[str], width: int = 180, on_change=None) -> ctk.CTkOptionMenu:
        var = ctk.StringVar(value=value)
        self._combo_vars[attr] = var
        return ctk.CTkOptionMenu(
            parent,
            values=choices, variable=var,
            fg_color=TOKENS["bg_input"],
            button_color=TOKENS["accent"],
            button_hover_color=TOKENS.get("accent_hover", TOKENS["accent"]),
            text_color=TOKENS["text_primary"],
            dropdown_fg_color=TOKENS["bg_card"],
            dropdown_text_color=TOKENS["text_primary"],
            dropdown_hover_color=TOKENS["bg_hover"],
            font=get_font(11),
            dropdown_font=get_font(11),
            width=width,
            height=28,
            corner_radius=4,
            command=lambda val: (on_change(val) if on_change else None),
        )

    # ── Save ───────────────────────────────────────────────────────────────

    def _save(self) -> None:
        for attr, var in self._int_vars.items():
            try:
                setattr(config, attr, int(var.get()))
            except ValueError:
                pass
        for attr, var in self._combo_vars.items():
            setattr(config, attr, var.get())
        for attr, var in self._toggle_vars.items():
            setattr(config, attr, var.get())

        config.save()
        self._save_status.configure(text="Saved")
        _log.info("Settings saved")
        self.frame.after(3000, lambda: self._save_status.configure(text=""))

    # ── Openers ────────────────────────────────────────────────────────────

    def _open_logs(self) -> None:
        try:
            subprocess.Popen(["explorer", str(LOGS_DIR)])
        except Exception as exc:
            _log.warning("Could not open logs: %s", exc)

    def _open_backups(self) -> None:
        try:
            subprocess.Popen(["explorer", str(BACKUPS_DIR)])
        except Exception as exc:
            _log.warning("Could not open backups: %s", exc)

    def _check_updates(self) -> None:
        try:
            subprocess.Popen(["start", "", "https://github.com"], shell=True)
        except Exception:
            pass

    def on_show(self) -> None:
        pass

    def on_hide(self) -> None:
        pass

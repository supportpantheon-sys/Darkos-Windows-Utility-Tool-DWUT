"""
ui/pages/cleaner.py

DWUT Cleaner — Tron-inspired malware removal, system repair, and optimization workflow.

Two execution tiers:
  1. Light Clean (Quick Maintenance · 3–5 Minutes):
     Creates restore point, clears temp junk & caches, runs fast component store cleanup,
     trims SSD, flushes DNS, and optimizes memory working sets. Zero third-party scan delays.
  2. Deep Clean (Full Tron Workflow · 30–60 Minutes):
     Full 7-phase deep repair, disinfection, Windows Update repair, and deep tuning.

STRICT SAFETY RULES:
  - NEVER touch Xbox services, Game Bar, GameDVR, or anything related to gaming.
  - NEVER touch Microsoft Store, UWP apps, Web Experience Pack, or Widgets.
  - NEVER touch Windows Media Player, WMPNetworkSvc, or DRM.
  - ALWAYS create a system restore point before Phase 0 begins.

OS ADAPTATION:
  - Automatically detects the user's OS on startup.
  - If running Windows 10: ALL Windows 11 options/buttons/steps are strictly hidden.
  - If running Windows 11: ALL Windows 10 options/buttons/steps are strictly hidden.
"""
from __future__ import annotations

import os
import platform
import sys
import threading
from typing import Callable

import customtkinter as ctk
import tkinter as tk

from modules.cleaner.registry import (
    ALL_PHASES, STEP_MAP, Step, LIGHT_CLEAN_STEPS,
)
from ui.theme import TOKENS, get_font, button_style, card_style
from ui.widgets.smooth_scroll import SmoothScrollFrame
from ui.widgets.tooltip import InfoBadge, attach_tooltip


# ── Colour constants ──────────────────────────────────────────────────────────
_C_PHASE_IDLE    = "#2d2d4e"
_C_PHASE_ACTIVE  = TOKENS.get("accent",  "#7c3aed")
_C_PHASE_DONE    = TOKENS.get("success", "#22c55e")
_C_STEP_OK       = TOKENS.get("success", "#22c55e")
_C_STEP_FAIL     = TOKENS.get("error",   "#ef4444")
_C_STEP_ACTIVE   = TOKENS.get("accent",  "#7c3aed")
_C_STEP_SKIP     = TOKENS.get("text_disabled", "#555575")


def detect_windows_info() -> tuple[int, str]:
    """Detect current Windows version (10 vs 11) and build string."""
    try:
        build = sys.getwindowsversion().build
        ver = 11 if build >= 22000 else 10
        ed = platform.win32_edition() if hasattr(platform, "win32_edition") else "Windows"
        return ver, f"Windows {ver} {ed} (Build {build})"
    except Exception:
        ver = 11 if "11" in platform.version() or "11" in platform.release() else 10
        return ver, f"Windows {ver}"


class CleanerPage:
    def __init__(self, parent: ctk.CTkFrame) -> None:
        self.frame = ctk.CTkFrame(parent, fg_color=TOKENS["bg_base"], corner_radius=0)
        self._engine      = None
        self._thread: threading.Thread | None = None
        self._running     = False
        self._paused      = False

        self._detected_ver, self._os_label = detect_windows_info()
        self._active_win_ver = self._detected_ver  # strictly default to detected OS

        self._step_rows:       dict[str, ctk.CTkFrame] = {}
        self._step_check_vars: dict[str, ctk.BooleanVar] = {}
        self._phase_dots:      dict[int, ctk.CTkLabel] = {}
        self._steps_cards:     dict[int, ctk.CTkFrame] = {}

        self._enabled_steps: set[str] = {
            s.id for p in ALL_PHASES for s in p.steps
            if (self._active_win_ver == 10 and s.win10 or self._active_win_ver == 11 and s.win11)
        }

        # Quick customization options
        self._quick_onedrive = ctk.BooleanVar(value=False)
        self._quick_cortana  = ctk.BooleanVar(value=False)
        self._quick_scanners = ctk.BooleanVar(value=True)
        self._quick_wd_temp  = ctk.BooleanVar(value=True)
        self._quick_power    = ctk.BooleanVar(value=True)
        self._dns_choice_var = ctk.StringVar(value="Keep Current")

        self._build()

    # ── Layout ────────────────────────────────────────────────────────────────

    def _build(self) -> None:
        # Title row
        title_row = ctk.CTkFrame(self.frame, fg_color="transparent", height=54)
        title_row.pack(fill="x", padx=20, pady=(12, 0))
        title_row.pack_propagate(False)

        left_title = ctk.CTkFrame(title_row, fg_color="transparent")
        left_title.pack(side="left", fill="y")

        ctk.CTkLabel(
            left_title, text="Cleaner",
            font=get_font(18, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            left_title,
            text=f"Detected: {self._os_label}",
            font=get_font(10, "bold"),
            text_color=TOKENS["accent"],
            fg_color=TOKENS["bg_card"],
            corner_radius=4,
            padx=8, pady=3,
        ).pack(side="left", padx=12)

        # Advanced mode toggle (top-right)
        adv_row = ctk.CTkFrame(title_row, fg_color="transparent")
        adv_row.pack(side="right", fill="y")
        ctk.CTkLabel(adv_row, text="Advanced Mode", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(
            adv_row,
            "Advanced Mode reveals all 7 phases and lets you toggle every single step individually.",
        ).pack(side="left", padx=4)

        self._adv_var = ctk.BooleanVar(value=False)
        ctk.CTkSwitch(
            adv_row, text="", variable=self._adv_var,
            fg_color=TOKENS["bg_input"], progress_color=TOKENS["accent"],
            button_color=TOKENS["accent"], width=42,
            command=self._on_advanced_toggle,
        ).pack(side="left", padx=6)

        # Divider
        ctk.CTkFrame(self.frame, fg_color=TOKENS["border"], height=1).pack(fill="x", padx=20)

        # Main scroll area
        self._scroll = SmoothScrollFrame(self.frame, fg_color="transparent", corner_radius=0)
        self._scroll.pack(fill="both", expand=True, padx=20, pady=10)

        self._build_safety_banner()
        self._build_clean_tiers()
        self._build_quick_customization()
        self._build_phase_bar()
        self._build_progress_card()
        self._build_log_card()
        self._build_phase_steps()

    # ── Safety Banner ─────────────────────────────────────────────────────────

    def _build_safety_banner(self) -> None:
        banner = ctk.CTkFrame(self._scroll, fg_color=TOKENS["bg_card"],
                              corner_radius=8, border_width=1, border_color=TOKENS["border"])
        banner.pack(fill="x", pady=(0, 12))

        inner = ctk.CTkFrame(banner, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=10)

        ctk.CTkLabel(
            inner,
            text="SAFETY GUARANTEED",
            font=get_font(11, "bold"), text_color=TOKENS["success"],
        ).pack(side="left")

        ctk.CTkLabel(
            inner,
            text="• System Restore Point created first  • Xbox & Gaming untouched  "
                 "• Microsoft Store untouched  • Windows Media Player untouched",
            font=get_font(10), text_color=TOKENS["text_secondary"],
        ).pack(side="left", padx=12)

    # ── Clean Tiers (Filtered strictly to detected OS) ─────────────────────────

    def _build_clean_tiers(self) -> None:
        ver = self._active_win_ver
        other_ver = 10 if ver == 11 else 11

        # ── 1. Light Clean Card ──────────────────────────────────────────────
        light_card = ctk.CTkFrame(self._scroll, **card_style())
        light_card.pack(fill="x", pady=(0, 12))

        l_hdr = ctk.CTkFrame(light_card, fg_color="transparent")
        l_hdr.pack(fill="x", padx=18, pady=(14, 6))

        ctk.CTkLabel(
            l_hdr, text=f"Windows {ver} Light Clean",
            font=get_font(14, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            l_hdr, text="RECOMMENDED · 3–5 MINS",
            font=get_font(9, "bold"), text_color=TOKENS["accent"],
            fg_color=TOKENS["bg_input"], corner_radius=3, padx=7, pady=2,
        ).pack(side="left", padx=10)

        InfoBadge(
            l_hdr,
            f"Windows {ver} Light Clean includes:\n"
            "  1. Automatic System Restore Point (C:)\n"
            "  2. Wipes user & system Temp, Prefetch, crash dumps, and logs\n"
            "  3. Clears Windows Update & Delivery Optimization caches\n"
            "  4. Clears DirectX shader caches and Explorer thumbnail DB\n"
            "  5. Cleans all browser caches (Chrome, Edge, Firefox, Brave, Opera)\n"
            "  6. Guided Malwarebytes quick threat scan with popup helper\n"
            "  7. Fast Component Store Cleanup (DISM /StartComponentCleanup)\n"
            "  8. Resets Microsoft Store cache (wsreset) without touching installed apps\n"
            "  9. Flushes DNS resolver cache and resets Winsock\n"
            " 10. Runs SSD TRIM (Restore write speeds) / HDD defrag\n"
            " 11. Trims memory working sets and standby caches\n"
            " 12. Empty Recycle Bin on all drives and generates session report\n\n"
            "Fast, high-impact maintenance with zero risk.",
        ).pack(side="left", padx=2)

        ctk.CTkLabel(
            light_card,
            text=f"High-impact, safe maintenance for Windows {ver}. Reclaims gigabytes of disk space, "
                 "optimizes RAM, runs a guided Malwarebytes check, and trims SSDs in just a few minutes.",
            font=get_font(11), text_color=TOKENS["text_secondary"], anchor="w",
        ).pack(anchor="w", padx=18, pady=(0, 12))

        btn_row_light = ctk.CTkFrame(light_card, fg_color="transparent")
        btn_row_light.pack(fill="x", padx=18, pady=(0, 16))

        self._start_light_btn = ctk.CTkButton(
            btn_row_light, text=f"Start Windows {ver} Light Clean ->",
            **button_style("primary"), height=36, width=280,
            command=lambda: self._start(win_ver=ver, is_light=True),
        )
        self._start_light_btn.pack(side="left")

        # ── 2. Deep Clean Card ──────────────────────────────────────────────
        deep_card = ctk.CTkFrame(self._scroll, **card_style())
        deep_card.pack(fill="x", pady=(0, 12))

        d_hdr = ctk.CTkFrame(deep_card, fg_color="transparent")
        d_hdr.pack(fill="x", padx=18, pady=(14, 6))

        ctk.CTkLabel(
            d_hdr, text=f"Windows {ver} Deep Clean",
            font=get_font(14, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            d_hdr, text="FULL TRON WORKFLOW · 30–60 MINS",
            font=get_font(9, "bold"), text_color=TOKENS["text_secondary"],
            fg_color=TOKENS["bg_input"], corner_radius=3, padx=7, pady=2,
        ).pack(side="left", padx=10)

        win11_extra = "\n  • Windows Recovery Environment (WinRE) integrity check" if ver == 11 else ""
        InfoBadge(
            d_hdr,
            f"Windows {ver} Deep Clean includes all 7 Tron workflow phases:\n"
            "  Phase 0: Process termination, restore point, registry backup, network backup\n"
            "  Phase 1: Deep temp file & cache cleanup\n"
            "  Phase 3: Battery of malware, adware & rootkit scanners (MBAM, KVRT, Sophos, ESET, etc.)\n"
            f"  Phase 4: Full system file & component repair (SFC /scannow, DISM /RestoreHealth, WMI, boot){win11_extra}\n"
            "  Phase 5: Patch updates & runtime repair (VC++, DirectX)\n"
            "  Phase 6: TCP stack, registry, and system performance optimizations\n"
            "  Phase 7: Service restoration, power plan restore, and detailed log report",
        ).pack(side="left", padx=2)

        ctk.CTkLabel(
            deep_card,
            text=f"Comprehensive Tron-inspired disinfection and deep system repair for Windows {ver}. "
                 "Recommended for heavily slowed or infected systems.",
            font=get_font(11), text_color=TOKENS["text_secondary"], anchor="w",
        ).pack(anchor="w", padx=18, pady=(0, 12))

        btn_row_deep = ctk.CTkFrame(deep_card, fg_color="transparent")
        btn_row_deep.pack(fill="x", padx=18, pady=(0, 16))

        self._start_deep_btn = ctk.CTkButton(
            btn_row_deep, text=f"Start Windows {ver} Deep Clean ->",
            **button_style("ghost"), height=36, width=280,
            command=lambda: self._start(win_ver=ver, is_light=False),
        )
        self._start_deep_btn.pack(side="left")

    # ── Quick Customization (No Advanced Mode Required) ───────────────────────

    def _build_quick_customization(self) -> None:
        card = ctk.CTkFrame(self._scroll, **card_style())
        card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=18, pady=(12, 6))

        ctk.CTkLabel(
            hdr, text="Quick Customization",
            font=get_font(13, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            hdr, text="Customize preferences directly without opening Advanced Mode",
            font=get_font(10), text_color=TOKENS["text_disabled"],
        ).pack(side="left", padx=10)

        grid = ctk.CTkFrame(card, fg_color="transparent")
        grid.pack(fill="x", padx=18, pady=(4, 12))

        # Row 1: OneDrive & Cortana (Cortana only visible on Win10)
        r1 = ctk.CTkFrame(grid, fg_color="transparent")
        r1.pack(fill="x", pady=2)

        self._make_checkbox_item(
            r1, label="Clean OneDrive cache & sync logs",
            tip="Removes temporary sync files and telemetry logs. User files remain intact.",
            var=self._quick_onedrive,
        ).pack(side="left", padx=(0, 24))

        if self._active_win_ver == 10:
            self._make_checkbox_item(
                r1, label="Clean Cortana query cache",
                tip="Removes legacy Cortana and Windows search cached temp files.",
                var=self._quick_cortana,
            ).pack(side="left")

        # Row 2: Defender temp disable & High Performance
        r2 = ctk.CTkFrame(grid, fg_color="transparent")
        r2.pack(fill="x", pady=2)

        self._make_checkbox_item(
            r2, label="Pause Defender during deep scans",
            tip="Temporarily disables real-time scanning so third-party tools can run faster. Automatically re-enabled in Wrap-up.",
            var=self._quick_wd_temp,
        ).pack(side="left", padx=(0, 24))

        self._make_checkbox_item(
            r2, label="Set High Performance power plan during clean",
            tip="Prevents CPU throttling and sleep during cleaning. Automatically restores Balanced in Wrap-up.",
            var=self._quick_power,
        ).pack(side="left")

        # Row 3: Scanners & DNS
        r3 = ctk.CTkFrame(grid, fg_color="transparent")
        r3.pack(fill="x", pady=2)

        self._make_checkbox_item(
            r3, label="Include third-party anti-malware scanners (Deep Clean)",
            tip="Runs Malwarebytes, KVRT, Sophos, ESET, and AdwCleaner during Phase 3 Disinfect.",
            var=self._quick_scanners,
        ).pack(side="left", padx=(0, 24))

        dns_box = ctk.CTkFrame(r3, fg_color="transparent")
        dns_box.pack(side="left")
        ctk.CTkLabel(dns_box, text="DNS Provider:", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left", padx=(0, 6))

        dns_menu = ctk.CTkOptionMenu(
            dns_box,
            values=["Keep Current", "1.1.1.1 (Cloudflare)", "8.8.8.8 (Google)", "9.9.9.9 (Quad9)"],
            variable=self._dns_choice_var,
            fg_color=TOKENS["bg_input"],
            button_color=TOKENS["accent"],
            text_color=TOKENS["text_primary"],
            dropdown_fg_color=TOKENS["bg_card"],
            dropdown_text_color=TOKENS["text_primary"],
            dropdown_hover_color=TOKENS["bg_hover"],
            font=get_font(10),
            dropdown_font=get_font(10),
            width=160, height=26, corner_radius=4,
        )
        dns_menu.pack(side="left")

    def _make_checkbox_item(self, parent, label: str, tip: str, var: ctk.BooleanVar) -> ctk.CTkFrame:
        f = ctk.CTkFrame(parent, fg_color="transparent")
        ck = ctk.CTkCheckBox(
            f, text="", variable=var, width=18,
            checkbox_width=16, checkbox_height=16,
            fg_color=TOKENS["accent"], hover_color=TOKENS["accent"],
        )
        ck.pack(side="left", padx=(0, 6))
        ctk.CTkLabel(f, text=label, font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(f, tip).pack(side="left", padx=4)
        return f

    # ── Phase Progress Bar ────────────────────────────────────────────────────

    def _build_phase_bar(self) -> None:
        self._phase_bar_card = ctk.CTkFrame(self._scroll, **card_style())
        self._phase_bar_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(
            self._phase_bar_card, text="Phase Progress",
            font=get_font(11, "bold"), text_color=TOKENS["text_secondary"],
        ).pack(anchor="w", padx=18, pady=(10, 6))

        dot_row = ctk.CTkFrame(self._phase_bar_card, fg_color="transparent")
        dot_row.pack(fill="x", padx=18, pady=(0, 12))

        for idx, phase in enumerate(ALL_PHASES):
            col = ctk.CTkFrame(dot_row, fg_color="transparent")
            col.pack(side="left", expand=True)

            dot = ctk.CTkLabel(col, text="*", font=get_font(18), text_color=_C_PHASE_IDLE)
            dot.pack()

            ctk.CTkLabel(
                col, text=f"P{phase.number}\n{phase.name}",
                font=get_font(9), text_color=TOKENS["text_disabled"],
                justify="center",
            ).pack()
            self._phase_dots[phase.number] = dot

    # ── Current step + progress card ──────────────────────────────────────────

    def _build_progress_card(self) -> None:
        card = ctk.CTkFrame(self._scroll, **card_style())
        card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=18, pady=(10, 4))

        ctk.CTkLabel(
            hdr, text="Status & Progress",
            font=get_font(11, "bold"), text_color=TOKENS["text_secondary"],
        ).pack(side="left")

        self._skip_btn = ctk.CTkButton(
            hdr, text="Skip Step", **button_style("ghost"), height=24, width=80,
            command=self._skip_step, state="disabled",
        )
        self._skip_btn.pack(side="right")

        self._step_label = ctk.CTkLabel(
            card, text="Ready to clean",
            font=get_font(12), text_color=TOKENS["text_primary"], anchor="w",
        )
        self._step_label.pack(anchor="w", padx=18, pady=(0, 4))

        self._progress = ctk.CTkProgressBar(
            card, progress_color=TOKENS["accent"], fg_color=TOKENS["bg_input"], height=6,
        )
        self._progress.set(0)
        self._progress.pack(fill="x", padx=18, pady=(0, 4))

        self._progress_lbl = ctk.CTkLabel(
            card, text="", font=get_font(10), text_color=TOKENS["text_disabled"], anchor="w",
        )
        self._progress_lbl.pack(anchor="w", padx=18, pady=(0, 10))

        # Control buttons
        ctrl = ctk.CTkFrame(card, fg_color="transparent")
        ctrl.pack(fill="x", padx=18, pady=(0, 12))

        self._pause_btn = ctk.CTkButton(
            ctrl, text="Pause", **button_style("ghost"), height=32, width=90,
            command=self._pause_resume, state="disabled",
        )
        self._pause_btn.pack(side="left", padx=(0, 8))

        self._cancel_btn = ctk.CTkButton(
            ctrl, text="Cancel", **button_style("danger"), height=32, width=90,
            command=self._cancel, state="disabled",
        )
        self._cancel_btn.pack(side="left")

        self._status_lbl = ctk.CTkLabel(
            ctrl, text="", font=get_font(10), text_color=TOKENS["text_secondary"],
        )
        self._status_lbl.pack(side="left", padx=12)

    # ── Live log ──────────────────────────────────────────────────────────────

    def _build_log_card(self) -> None:
        card = ctk.CTkFrame(self._scroll, **card_style())
        card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=18, pady=(10, 4))

        ctk.CTkLabel(
            hdr, text="Live Output Log",
            font=get_font(11, "bold"), text_color=TOKENS["text_secondary"],
        ).pack(side="left")

        for txt, cmd, tip in [
            ("Copy",  self._copy_log,  "Copy all log text to clipboard"),
            ("Save",  self._save_log,  "Save log to a .txt file"),
            ("Clear", self._clear_log, "Clear the log display"),
        ]:
            b = ctk.CTkButton(hdr, text=txt, **button_style("ghost"), height=24, width=54,
                              command=cmd)
            attach_tooltip(b, tip)
            b.pack(side="right", padx=2)

        log_container = ctk.CTkFrame(card, fg_color=TOKENS["bg_input"], corner_radius=6)
        log_container.pack(fill="x", padx=18, pady=(0, 12))

        self._log_text = tk.Text(
            log_container,
            bg=TOKENS["bg_input"], fg=TOKENS["text_secondary"],
            font=("Consolas", 10),
            relief="flat", bd=0,
            height=11, wrap="word",
            state="disabled",
            cursor="arrow",
        )
        scrollbar = tk.Scrollbar(log_container, command=self._log_text.yview)
        self._log_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self._log_text.pack(fill="x", padx=6, pady=6)

    # ── Per-phase step lists (Advanced Mode) ──────────────────────────────────

    def _build_phase_steps(self) -> None:
        self._adv_container = ctk.CTkFrame(self._scroll, fg_color="transparent")

        for phase in ALL_PHASES:
            card = ctk.CTkFrame(self._adv_container, **card_style())
            card.pack(fill="x", pady=(0, 8))
            self._steps_cards[phase.number] = card

            hdr = ctk.CTkFrame(card, fg_color="transparent")
            hdr.pack(fill="x", padx=18, pady=(10, 4))

            ctk.CTkLabel(
                hdr,
                text=f"Phase {phase.number} — {phase.name}",
                font=get_font(12, "bold"), text_color=TOKENS["text_primary"],
            ).pack(side="left")

            ctk.CTkLabel(
                hdr, text=phase.description,
                font=get_font(10), text_color=TOKENS["text_disabled"],
            ).pack(side="left", padx=10)

            steps_frame = ctk.CTkFrame(card, fg_color="transparent")
            steps_frame.pack(fill="x", padx=18, pady=(0, 10))

            for step in phase.steps:
                row = self._make_step_row(steps_frame, step)
                self._step_rows[step.id] = row

            card._steps_frame = steps_frame  # type: ignore[attr-defined]

        # Apply strict OS filtering on start
        self._apply_os_filtering(self._active_win_ver)

    def _apply_os_filtering(self, win_ver: int) -> None:
        """Strictly hide any options or steps from other Windows versions."""
        for phase in ALL_PHASES:
            card = self._steps_cards.get(phase.number)
            if not card or not hasattr(card, "_steps_frame"):
                continue

            for step in phase.steps:
                row = self._step_rows.get(step.id)
                if not row:
                    continue

                is_supported = (win_ver == 10 and step.win10) or (win_ver == 11 and step.win11)
                if is_supported:
                    row.pack(fill="x", pady=2)
                else:
                    row.pack_forget()

    def _make_step_row(self, parent, step: Step) -> ctk.CTkFrame:
        row = ctk.CTkFrame(parent, fg_color="transparent")

        # Status dot
        dot = ctk.CTkLabel(row, text="-", font=get_font(12),
                           text_color=_C_STEP_SKIP, width=20)
        dot.pack(side="left")
        row._dot = dot  # type: ignore[attr-defined]

        # Enable/disable checkbox
        is_restore = (step.id == "restore_point")
        var = ctk.BooleanVar(value=True if is_restore else (step.id in self._enabled_steps))
        self._step_check_vars[step.id] = var

        ck = ctk.CTkCheckBox(
            row, text="", variable=var, width=20,
            checkbox_width=16, checkbox_height=16,
            fg_color=TOKENS["accent"], hover_color=TOKENS["accent"],
            command=lambda sid=step.id, v=var: self._toggle_step(sid, v.get()),
            state="disabled" if is_restore else "normal",
        )
        ck.pack(side="left", padx=4)

        lbl_text = step.label + (" (Mandatory Rollback Point)" if is_restore else "")
        ctk.CTkLabel(
            row, text=lbl_text, font=get_font(10),
            text_color=TOKENS["text_primary"] if is_restore else TOKENS["text_secondary"],
            anchor="w",
        ).pack(side="left")

        if not step.auto:
            ctk.CTkLabel(
                row, text="manual", font=get_font(9),
                text_color=TOKENS["warning"], fg_color=TOKENS["bg_input"],
                corner_radius=3, width=46,
            ).pack(side="left", padx=6)

        return row

    # ── Advanced mode ─────────────────────────────────────────────────────────

    def _prewarm_adv(self) -> None:
        pass

    def _on_advanced_toggle(self) -> None:
        adv = self._adv_var.get()
        if not adv:
            self._adv_container.pack_forget()
            return

        def _deferred_pack():
            self._adv_container.pack(fill="x", pady=(0, 8))
            try:
                self._scroll.bind_children()
            except Exception:
                pass

        self.frame.after(10, _deferred_pack)

    def _toggle_step(self, step_id: str, enabled: bool) -> None:
        if step_id == "restore_point":
            return  # non-skippable
        if enabled:
            self._enabled_steps.add(step_id)
        else:
            self._enabled_steps.discard(step_id)

    # ── Engine start / control ────────────────────────────────────────────────

    def _start(self, win_ver: int, is_light: bool = False) -> None:
        if self._running:
            return

        self._active_win_ver = win_ver
        self._apply_os_filtering(win_ver)
        self._reset_ui()
        self._running = True

        if is_light:
            active_steps = set(LIGHT_CLEAN_STEPS)
        else:
            active_steps = set(self._enabled_steps)

        # Restore point is ALWAYS guaranteed
        active_steps.add("restore_point")

        # Apply quick customization overrides
        if self._quick_onedrive.get():
            active_steps.add("opt_onedrive")
        else:
            active_steps.discard("opt_onedrive")

        if self._quick_cortana.get() and win_ver == 10:
            active_steps.add("opt_cortana")
        else:
            active_steps.discard("opt_cortana")

        if not self._quick_scanners.get():
            for s in ALL_PHASES[2].steps:  # Phase 3 Disinfect
                active_steps.discard(s.id)

        if not self._quick_wd_temp.get():
            active_steps.discard("dis_wd")

        if not self._quick_power.get():
            active_steps.discard("power_high")
            active_steps.discard("opt_power")

        # Strictly purge steps that belong to the other OS
        for p in ALL_PHASES:
            for s in p.steps:
                if (win_ver == 10 and not s.win10) or (win_ver == 11 and not s.win11):
                    active_steps.discard(s.id)

        from modules.cleaner.engine import CleanerEngine
        self._engine = CleanerEngine(
            win_version    = win_ver,
            on_log         = self._on_log,
            on_step_start  = self._on_step_start,
            on_step_done   = self._on_step_done,
            on_phase_start = self._on_phase_start,
            on_phase_done  = self._on_phase_done,
            on_done        = self._on_done,
            on_manual_step = self._show_manual_step_dialog,
        )
        self._engine.configure(active_steps)

        self._thread = threading.Thread(target=self._engine.run, daemon=True)
        self._thread.start()

        mode_name = "Light Clean" if is_light else "Deep Clean"
        self._pause_btn.configure(state="normal")
        self._cancel_btn.configure(state="normal")
        self._skip_btn.configure(state="normal")
        self._status_lbl.configure(text=f"Running Windows {win_ver} {mode_name}…")

    def _pause_resume(self) -> None:
        self._paused = not self._paused
        self._pause_btn.configure(text="Resume" if self._paused else "Pause")

    def _cancel(self) -> None:
        if self._engine:
            self._engine.cancel()
        self._status_lbl.configure(text="Cancelling…")

    def _skip_step(self) -> None:
        pass

    # ── Engine callbacks (called from background thread) ──────────────────────

    def _on_log(self, msg: str) -> None:
        self.frame.after(0, lambda: self._append_log(msg))

    def _on_step_start(self, step_id: str, label: str) -> None:
        def _ui():
            self._step_label.configure(text=f"Running: {label}")
            row = self._step_rows.get(step_id)
            if row and hasattr(row, "_dot"):
                row._dot.configure(text=">", text_color=_C_STEP_ACTIVE)
        self.frame.after(0, _ui)

    def _on_step_done(self, step_id: str, success: bool) -> None:
        def _ui():
            row = self._step_rows.get(step_id)
            if row and hasattr(row, "_dot"):
                row._dot.configure(
                    text="+" if success else "x",
                    text_color=_C_STEP_OK if success else _C_STEP_FAIL,
                )
            if self._engine:
                total = len(self._engine._enabled_steps)
                done = sum(1 for sid in self._engine._enabled_steps
                           if hasattr(self._step_rows.get(sid, object()), "_dot")
                           and self._step_rows[sid]._dot.cget("text") in ("+", "x"))
                frac = done / max(total, 1)
                self._progress.set(frac)
                self._progress_lbl.configure(text=f"{done} / {total} steps  ({int(frac*100)}%)")
        self.frame.after(0, _ui)

    def _on_phase_start(self, num: int, name: str) -> None:
        def _ui():
            dot = self._phase_dots.get(num)
            if dot:
                dot.configure(text_color=_C_PHASE_ACTIVE)
            self._append_log(f"\n{'='*50}\nPHASE {num}: {name.upper()}\n{'='*50}")
        self.frame.after(0, _ui)

    def _on_phase_done(self, num: int) -> None:
        def _ui():
            dot = self._phase_dots.get(num)
            if dot:
                dot.configure(text_color=_C_PHASE_DONE)
        self.frame.after(0, _ui)

    def _on_done(self, completed: bool) -> None:
        def _ui():
            self._running = False
            self._pause_btn.configure(state="disabled")
            self._cancel_btn.configure(state="disabled")
            self._skip_btn.configure(state="disabled")
            if completed:
                self._step_label.configure(text="Cleaning complete!")
                self._status_lbl.configure(text="All tasks finished successfully.")
                self._progress.set(1.0)
            else:
                self._step_label.configure(text="Cancelled or stopped.")
                self._status_lbl.configure(text="")
        self.frame.after(0, _ui)

    # ── Log helpers ───────────────────────────────────────────────────────────

    def _append_log(self, msg: str) -> None:
        self._log_text.configure(state="normal")
        self._log_text.insert("end", msg + "\n")
        self._log_text.see("end")
        self._log_text.configure(state="disabled")

    def _copy_log(self) -> None:
        txt = self._log_text.get("1.0", "end")
        self.frame.clipboard_clear()
        self.frame.clipboard_append(txt)

    def _save_log(self) -> None:
        from tkinter import filedialog
        from datetime import datetime
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            initialfile=f"dwut_clean_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._log_text.get("1.0", "end"))

    def _clear_log(self) -> None:
        self._log_text.configure(state="normal")
        self._log_text.delete("1.0", "end")
        self._log_text.configure(state="disabled")

    # ── Manual steps dialog ───────────────────────────────────────────────────

    def _show_manual_step_dialog(self, step: Step) -> bool:
        result: list[bool] = [True]
        done_event = threading.Event()

        def _show():
            _ManualStepDialog(
                parent=self.frame,
                step=step,
                on_continue=lambda: (result.__setitem__(0, True),  done_event.set()),
                on_skip    =lambda: (result.__setitem__(0, True),  done_event.set()),
                on_cancel  =lambda: (result.__setitem__(0, False), done_event.set()),
            )

        self.frame.after(0, _show)
        done_event.wait(timeout=3600)
        return result[0]

    # ── UI reset ──────────────────────────────────────────────────────────────

    def _reset_ui(self) -> None:
        for dot in self._phase_dots.values():
            dot.configure(text_color=_C_PHASE_IDLE)
        for row in self._step_rows.values():
            if hasattr(row, "_dot"):
                row._dot.configure(text="-", text_color=_C_STEP_SKIP)
        self._progress.set(0)
        self._progress_lbl.configure(text="")
        self._step_label.configure(text="Starting...")
        self._clear_log()

    def on_show(self) -> None:
        pass

    def on_hide(self) -> None:
        pass


# ── Manual Step Dialog ────────────────────────────────────────────────────────

class _ManualStepDialog:
    """
    Sequential guided dialog for AV tools that need manual interaction.

    Design:
    - Launches the tool in the background.
    - Shows step-by-step instructions with a large "I'm Done" button.
    - When the user clicks "I'm Done" the engine moves on and the NEXT tool's
      dialog opens automatically — one at a time, no waiting on process exit.
    - Skip This Tool skips without running it.
    - Cancel All stops the whole clean.
    """

    _INSTRUCTIONS: dict[str, list[str]] = {
        "malwarebytes": [
            "Malwarebytes has opened in a new window.",
            "1. Click 'Scan' on the Malwarebytes dashboard.",
            "2. Wait for the scan to complete (usually 2–5 minutes).",
            "3. If threats are found, click 'Quarantine'.",
            "4. When finished, click  I'm Done  below — DWUT will move to the next tool.",
        ],
        "hitmanpro": [
            "HitmanPro has opened in a new window.",
            "1. Click 'Next' to accept the EULA.",
            "2. Select 'Scan the computer'.",
            "3. Wait for the scan to complete.",
            "4. Click 'Next', then 'Free 30-day trial' if prompted.",
            "5. Click 'Delete' to remove any threats found.",
            "6. When finished, click  I'm Done  below.",
        ],
        "eset": [
            "ESET Online Scanner has opened.",
            "1. Accept the Terms of Use.",
            "2. Click 'Get started'.",
            "3. Choose 'Full Scan' and enable 'Remove found threats'.",
            "4. Wait for the scan to complete.",
            "5. Click 'Finish', then click  I'm Done  below.",
        ],
        "npe": [
            "Norton Power Eraser has launched.",
            "1. Click 'Scan for Risks'.",
            "2. Review the results.",
            "3. Click 'Fix' to remove any threats found.",
            "4. When finished, click  I'm Done  below.",
        ],
        "gmer": [
            "GMER is scanning for advanced rootkits.",
            "1. GMER auto-scans on startup — wait for it to finish.",
            "2. If anything appears in RED, click 'Disable' or 'Delete'.",
            "3. Click 'Save' to save the log.",
            "WARNING: Do not click anything else in GMER unless you know what it is.",
            "When finished, click  I'm Done  below.",
        ],
        "aswmbr": [
            "aswMBR (Avast MBR Scanner) has opened.",
            "1. Click 'Scan'.",
            "2. If threats are found, click 'Fix MBR'.",
            "3. When finished, click  I'm Done  below.",
        ],
        "frst": [
            "Farbar Recovery Scan Tool (FRST) has opened.",
            "1. Click 'Scan' — this creates FRST.txt and Addition.txt.",
            "2. These logs help diagnose persistent infections.",
            "3. When the scan is complete, click  I'm Done  below.",
        ],
        "otl": [
            "OTL (OldTimer ListIt) has opened.",
            "1. Click 'Run Scan'.",
            "2. Wait for OTL.txt and Extras.txt to be created.",
            "3. When finished, click  I'm Done  below.",
        ],
    }

    # Default instructions for any tool without specific guidance
    _DEFAULT_INSTRUCTIONS = [
        "{label} has been launched in a new window.",
        "Please complete the scan or operation in that window.",
        "When you are done, click  I'm Done  below.",
        "DWUT will automatically move to the next step.",
    ]

    def __init__(
        self, parent,
        step: Step,
        on_continue: Callable,
        on_skip:     Callable,
        on_cancel:   Callable,
    ):
        root = parent.winfo_toplevel()
        self._win = tk.Toplevel(root)
        self._win.title(f"Manual Step — {step.label}")
        self._win.configure(bg=TOKENS["bg_card"])
        self._win.transient(root)
        self._win.grab_set()
        self._win.resizable(False, False)
        self._win.protocol("WM_DELETE_WINDOW", lambda: None)  # prevent accidental close

        w, h = 520, 400
        px, py = root.winfo_rootx(), root.winfo_rooty()
        pw, ph = root.winfo_width(), root.winfo_height()
        self._win.geometry(f"{w}x{h}+{px+(pw-w)//2}+{py+(ph-h)//2}")

        self._on_continue = on_continue
        self._on_skip     = on_skip
        self._on_cancel   = on_cancel
        self._done_event  = threading.Event()

        self._build(step, on_continue, on_skip, on_cancel)
        try:
            self._win.bell()
        except Exception:
            pass
        self._win.lift()
        self._win.focus_force()
        self._launch(step)

    def _build(self, step: Step, on_continue: Callable, on_skip: Callable, on_cancel: Callable) -> None:
        outer = tk.Frame(self._win, bg=TOKENS["bg_card"], padx=22, pady=18)
        outer.pack(fill="both", expand=True)

        # Header row
        hdr = tk.Frame(outer, bg=TOKENS["bg_card"])
        hdr.pack(fill="x", pady=(0, 8))

        tk.Label(
            hdr, text="Manual Step Required",
            bg=TOKENS["bg_card"], fg=TOKENS["warning"],
            font=("Segoe UI Variable", 13, "bold"),
        ).pack(side="left")

        tk.Label(
            outer, text=step.label,
            bg=TOKENS["bg_card"], fg=TOKENS["text_primary"],
            font=("Segoe UI Variable", 12, "bold"),
        ).pack(anchor="w", pady=(0, 12))

        # Instructions
        instructions = self._INSTRUCTIONS.get(step.id) or [
            line.replace("{label}", step.label)
            for line in self._DEFAULT_INSTRUCTIONS
        ]

        inst_frame = tk.Frame(
            outer, bg=TOKENS["bg_input"],
            bd=0, relief="flat",
            padx=14, pady=10,
        )
        inst_frame.pack(fill="x", pady=(0, 14))

        for line in instructions:
            is_warn = line.startswith("WARNING")
            tk.Label(
                inst_frame, text=line,
                bg=TOKENS["bg_input"],
                fg=TOKENS["warning"] if is_warn else TOKENS["text_secondary"],
                font=("Segoe UI Variable", 10),
                anchor="w", justify="left", wraplength=460,
            ).pack(anchor="w", pady=2)

        # Status note
        self._status_note = tk.Label(
            outer,
            text="Launching tool…",
            bg=TOKENS["bg_card"], fg=TOKENS["text_disabled"],
            font=("Segoe UI Variable", 9),
        )
        self._status_note.pack(anchor="w", pady=(0, 10))

        # Buttons
        btn_row = tk.Frame(outer, bg=TOKENS["bg_card"])
        btn_row.pack(fill="x", side="bottom")

        # "I'm Done" — the primary action, disabled until tool has launched
        self._done_btn = tk.Button(
            btn_row,
            text="I'm Done  →  Next Step",
            command=self._user_done,
            bg=TOKENS["accent"], fg="#ffffff",
            activebackground=TOKENS["accent"],
            relief="flat",
            font=("Segoe UI Variable", 11, "bold"),
            padx=18, pady=8,
            state="disabled",
        )
        self._done_btn.pack(side="left", padx=(0, 10))

        tk.Button(
            btn_row,
            text="Skip This Tool",
            command=self._user_skip,
            bg=TOKENS["bg_input"], fg=TOKENS["text_primary"],
            activebackground=TOKENS["bg_hover"],
            relief="flat",
            font=("Segoe UI Variable", 10),
            padx=10, pady=8,
        ).pack(side="left", padx=(0, 8))

        tk.Button(
            btn_row,
            text="Cancel All",
            command=self._user_cancel,
            bg=TOKENS["error"], fg="#ffffff",
            activebackground=TOKENS["error"],
            relief="flat",
            font=("Segoe UI Variable", 10),
            padx=10, pady=8,
        ).pack(side="left")

    def _enable_done_btn(self) -> None:
        """Called from main thread once the tool has been launched."""
        try:
            self._status_note.configure(text="Tool is running — complete the scan, then click I'm Done.")
            self._done_btn.configure(state="normal")
        except Exception:
            pass

    def _user_done(self) -> None:
        """User clicked 'I'm Done' — advance to next step."""
        self._done_event.set()
        self._on_continue()
        try:
            self._win.destroy()
        except Exception:
            pass

    def _user_skip(self) -> None:
        """User chose to skip this tool."""
        self._done_event.set()
        self._on_skip()
        try:
            self._win.destroy()
        except Exception:
            pass

    def _user_cancel(self) -> None:
        """User cancelled the entire clean."""
        self._done_event.set()
        self._on_cancel()
        try:
            self._win.destroy()
        except Exception:
            pass

    def _launch(self, step: Step) -> None:
        """Download and launch the tool, then enable the I'm Done button."""
        from modules.cleaner.downloader import download
        import subprocess, os
        from pathlib import Path

        def _get_mbam_installed() -> Path | None:
            for cand in [
                Path(os.environ.get("ProgramFiles",      "C:\\Program Files")) / "Malwarebytes" / "Anti-Malware" / "mbam.exe",
                Path(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")) / "Malwarebytes" / "Anti-Malware" / "mbam.exe",
            ]:
                if cand.exists():
                    return cand
            return None

        def _run():
            path: Path | None = None
            if step.id == "malwarebytes":
                path = _get_mbam_installed()

            if not path:
                try:
                    self._win.after(0, lambda: self._status_note.configure(
                        text="Downloading tool — please wait…"))
                except Exception:
                    pass
                path = download(step.id, on_log=lambda m: None)

            if not path:
                # Could not download — auto-skip and signal done
                try:
                    self._win.after(0, lambda: self._status_note.configure(
                        text="Download failed — skipping this tool."))
                    self._win.after(1500, self._user_skip)
                except Exception:
                    self._user_skip()
                return

            # Launch the tool (non-blocking — don't wait for it to close)
            try:
                subprocess.Popen([str(path)])
            except Exception as exc:
                try:
                    self._win.after(0, lambda: self._status_note.configure(
                        text=f"Could not launch tool: {exc}"))
                except Exception:
                    pass

            # Enable the I'm Done button on the main thread
            try:
                self._win.after(0, self._enable_done_btn)
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True).start()

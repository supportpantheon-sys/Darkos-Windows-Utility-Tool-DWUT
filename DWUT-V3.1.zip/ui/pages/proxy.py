"""
ui/pages/proxy.py  — Proxy Center

Tabs:
  Generator   — fetch from sources with region/protocol/anonymity filters
  Checker     — 9-stage validation pipeline with live streaming table
  Configure   — chain builder placeholder + output format / export settings
  History     — past fetch/check session summary

No emojis anywhere. Every filter has an (i) badge explaining what it does.
"""

from __future__ import annotations

import threading

import customtkinter as ctk

from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from modules.proxy.sources import ProxyRecord, fetch_all_sources
from modules.proxy.checker import CheckResult, check_all
from ui.widgets.smooth_scroll import SmoothScrollFrame
from ui.widgets.tab_overlay import TabOverlayMixin
from ui.theme import TOKENS, get_font, card_style, button_style
from ui.widgets.scrolled_table import ScrolledTable
from ui.widgets.tooltip import InfoBadge, attach_tooltip

_log = get_logger(__name__)

_PROTOCOLS  = ["any", "http", "socks4", "socks5"]
_ANONYMITY  = ["any", "elite", "anonymous", "transparent"]
_MAX_PING   = ["any", "50ms", "75ms", "100ms"]   # checker hard-rejects >100ms
_REGIONS    = [
    "Any", "Canada", "United States", "United Kingdom",
    "Germany", "France", "Netherlands", "Switzerland",
    "Japan", "South Korea", "Australia", "Singapore",
    "Brazil", "India", "Russia",
]

_PING_MAP = {"any": 9999, "50ms": 50, "75ms": 75, "100ms": 100}

_EXPORT_FORMATS = [
    "ip:port",
    "protocol://ip:port",
    "ip:port:protocol",
    "Proxifier (*.ppx)",
    "ProxyCap",
    "Shadowsocks JSON",
    "Windows system proxy command",
]

_CHAIN_ROUTING = ["Strict (fail if any hop fails)", "Fail closed", "Automatic"]


class ProxyPage(TabOverlayMixin):
    def __init__(self, parent: ctk.CTkFrame) -> None:
        self.frame = ctk.CTkFrame(parent, fg_color=TOKENS["bg_base"], corner_radius=0)
        self._raw_proxies: list[ProxyRecord] = []
        self._results: list[CheckResult] = []
        self._chain_nodes: list[str] = []  # list of proxy addresses in the chain
        self._stop_event: threading.Event | None = None  # set while a check is running
        self._check_running: bool = False
        self._live_stats: dict[str, int] = {}
        self._live_results: list = []   # accumulated CheckResults for the in-progress/last check — lets filters re-render without re-checking
        self._build()
        self._subscribe()

    # ── Top-level layout ───────────────────────────────────────────────────

    def _build(self) -> None:
        # Title + status row
        title_row = ctk.CTkFrame(self.frame, fg_color="transparent", height=52)
        title_row.pack(fill="x", padx=20, pady=(14, 0))
        title_row.pack_propagate(False)

        ctk.CTkLabel(
            title_row, text="Proxy Center",
            font=get_font(18, "bold"), text_color=TOKENS["text_primary"],
        ).pack(side="left", pady=10)

        self._status_label = ctk.CTkLabel(
            title_row, text="",
            font=get_font(11), text_color=TOKENS["text_secondary"],
        )
        self._status_label.pack(side="right", pady=10)

        # Tab bar
        tabs = ["Generator", "Checker", "Configure", "History"]
        self._tab_frames: dict[str, ctk.CTkFrame] = {}
        self._tab_btns:   dict[str, ctk.CTkButton] = {}

        tab_bar = ctk.CTkFrame(self.frame, fg_color="transparent")
        tab_bar.pack(fill="x", padx=20)

        for tab in tabs:
            btn = ctk.CTkButton(
                tab_bar, text=tab,
                fg_color="transparent", hover_color=TOKENS["bg_hover"],
                text_color=TOKENS["text_secondary"],
                font=get_font(12), height=30, corner_radius=4,
                command=lambda t=tab: self._switch_tab(t),
            )
            btn.pack(side="left", padx=2)
            self._tab_btns[tab] = btn

        ctk.CTkFrame(self.frame, fg_color=TOKENS["border"], height=1).pack(fill="x", padx=20)

        # Shared progress strip
        self._progress_bar = ctk.CTkProgressBar(
            self.frame, fg_color=TOKENS["bg_input"],
            progress_color=TOKENS["accent"], height=2, corner_radius=0,
        )
        self._progress_bar.set(0)
        self._progress_bar.pack(fill="x")

        self._content = ctk.CTkFrame(self.frame, fg_color="transparent")
        self._content.pack(fill="both", expand=True, padx=20, pady=(8, 16))
        self._init_tab_overlay(self._content)

        # Tabs build lazily — only the first-shown tab is constructed now;
        # the rest build on first switch (same fix as OptimizerPage).
        self._tab_builders = {
            "Generator": self._build_generator_tab,
            "Checker":   self._build_checker_tab,
            "Configure": self._build_configure_tab,
            "History":   self._build_history_tab,
        }
        self._built_tabs: set[str] = set()
        self._history_data: list[tuple] = []   # (kind, ts, total, excellent, good, fair) — survives History tab not being built yet

        self._initial_switch_tab("Generator", self._do_switch_tab)
        # Prewarm remaining tabs in the background so switching to them is 100% instantaneous.
        # Only prewarm tabs that actually exist in _tab_builders to avoid spurious exceptions.
        self.frame.after(120, lambda: self._prewarm_tabs(["Checker", "Configure", "History"]))

    def _prewarm_tabs(self, tabs: list[str]) -> None:
        if not tabs:
            return
        next_tab = tabs[0]
        remaining = tabs[1:]
        if next_tab in self._tab_builders and next_tab not in self._built_tabs:
            try:
                self._tab_builders[next_tab]()
                self._built_tabs.add(next_tab)
                frm = self._tab_frames.get(next_tab)
                if frm is not None and hasattr(frm, "bind_children"):
                    frm.bind_children()
            except Exception as exc:
                _log.debug("Prewarm tab '%s' failed: %s", next_tab, exc)
        if remaining:
            self.frame.after(60, lambda: self._prewarm_tabs(remaining))

    def _switch_tab(self, tab: str) -> None:
        self._switch_tab_with_overlay(tab, self._do_switch_tab, self._built_tabs)

    def _do_switch_tab(self, tab: str) -> None:
        first_build = tab not in self._built_tabs
        if first_build:
            self._tab_builders[tab]()
            self._built_tabs.add(tab)
            frm = self._tab_frames.get(tab)
            if frm is not None and hasattr(frm, "bind_children"):
                frm.bind_children()
        for name, frame in self._tab_frames.items():
            frame.pack_forget()
        for name, btn in self._tab_btns.items():
            active = name == tab
            btn.configure(
                text_color=TOKENS["accent"] if active else TOKENS["text_secondary"],
                fg_color=TOKENS["sidebar_active"] if active else "transparent",
            )
        self._tab_frames[tab].pack(fill="both", expand=True)

    # ── Generator tab ──────────────────────────────────────────────────────

    def _build_generator_tab(self) -> None:
        f = ctk.CTkFrame(self._content, fg_color="transparent")
        self._tab_frames["Generator"] = f

        # Filter card
        filters = ctk.CTkFrame(f, **card_style())
        filters.pack(fill="x", pady=(0, 8))

        ctk.CTkLabel(
            filters, text="Source Filters",
            font=get_font(12, "bold"), text_color=TOKENS["text_primary"],
        ).pack(anchor="w", padx=14, pady=(10, 6))

        row = ctk.CTkFrame(filters, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=(0, 10))

        # Protocol filter
        self._add_filter_group(
            row,
            "Protocol",
            "tip_proto",
            "The proxy protocol to fetch.\n\n"
            "HTTP — basic web proxies\n"
            "SOCKS4 — faster, no auth support\n"
            "SOCKS5 — best: UDP support + authentication\n"
            "'any' fetches all three types.",
            _PROTOCOLS,
            ctk.StringVar(value="any"),
        )

        # Region filter
        self._add_filter_group(
            row,
            "Region",
            "tip_region",
            "Filter proxies by country of their exit IP.\n\n"
            "Applied during the Check phase — the Generator fetches all regions "
            "and the region filter is used when checking to discard proxies "
            "whose geo-IP does not match your selection.",
            _REGIONS,
            ctk.StringVar(value="Any"),
            width=140,
        )

        # Anonymity filter
        self._add_filter_group(
            row,
            "Min Anonymity",
            "tip_anon",
            "The minimum anonymity level to accept.\n\n"
            "Elite       — no identifying headers forwarded to destination\n"
            "Anonymous — some headers stripped but Via/Proxy-Connection present\n"
            "Transparent — your real IP is forwarded (not private)\n\n"
            "'Elite' is recommended for privacy. 'any' accepts all.",
            _ANONYMITY,
            ctk.StringVar(value="any"),
        )

        # Action buttons
        actions = ctk.CTkFrame(row, fg_color="transparent")
        actions.pack(side="left", padx=(20, 0))

        self._fetch_btn = ctk.CTkButton(
            actions, text="Fetch Proxies",
            **button_style("primary"), height=34,
            command=self._fetch_proxies,
        )
        self._fetch_btn.pack(pady=(0, 4))

        self._gen_count_label = ctk.CTkLabel(
            actions, text="",
            font=get_font(10), text_color=TOKENS["text_secondary"],
        )
        self._gen_count_label.pack()

        attach_tooltip(
            self._fetch_btn,
            "Downloads proxy lists from 22 public sources in parallel.\n"
            "Deduplicates by IP:port:protocol.\n"
            "Takes 5–15 seconds depending on connection speed."
        )

        # Raw list
        self._raw_box = ctk.CTkTextbox(
            f,
            fg_color=TOKENS["bg_card"],
            text_color=TOKENS["text_secondary"],
            font=get_font(10, mono=True),
            corner_radius=6,
        )
        self._raw_box.pack(fill="both", expand=True, pady=(4, 0))
        self._raw_box.configure(state="disabled")

    def _add_filter_group(
        self, parent, label: str, tip_key: str, tip_text: str,
        choices: list[str], var: ctk.StringVar, width: int = 110,
    ) -> None:
        grp = ctk.CTkFrame(parent, fg_color="transparent")
        grp.pack(side="left", padx=(0, 16))

        hdr = ctk.CTkFrame(grp, fg_color="transparent")
        hdr.pack(anchor="w")

        ctk.CTkLabel(
            hdr, text=label, font=get_font(11),
            text_color=TOKENS["text_secondary"],
        ).pack(side="left")

        InfoBadge(hdr, tip_text).pack(side="left", padx=(4, 0))

        ctk.CTkComboBox(
            grp, values=choices, variable=var,
            fg_color=TOKENS["bg_input"],
            border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"],
            width=width,
        ).pack(pady=(4, 0))

        # store var for later use
        setattr(self, f"_var_{tip_key}", var)

    # ── Checker tab ────────────────────────────────────────────────────────

    def _build_checker_tab(self) -> None:
        f = ctk.CTkFrame(self._content, fg_color="transparent")
        self._tab_frames["Checker"] = f

        # Controls
        ctrl = ctk.CTkFrame(f, **card_style())
        ctrl.pack(fill="x", pady=(0, 8))

        ctrl_row = ctk.CTkFrame(ctrl, fg_color="transparent")
        ctrl_row.pack(fill="x", padx=14, pady=10)

        # Max ping filter
        ping_grp = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        ping_grp.pack(side="left", padx=(0, 16))

        hdr = ctk.CTkFrame(ping_grp, fg_color="transparent")
        hdr.pack(anchor="w")
        ctk.CTkLabel(hdr, text="Max Latency", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(
            hdr,
            "Maximum acceptable round-trip latency.\n\n"
            "Measured as the time to complete a TCP connection to the proxy port.\n"
            "Proxies slower than this threshold are marked 'rejected'.",
        ).pack(side="left", padx=4)

        self._ping_var = ctk.StringVar(value="any")
        ctk.CTkComboBox(
            ping_grp, values=list(_PING_MAP.keys()), variable=self._ping_var,
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=100,
        ).pack(pady=(4, 0))

        # Custom latency — overrides the preset above if filled in
        custom_grp = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        custom_grp.pack(side="left", padx=(0, 16))

        hdr_custom = ctk.CTkFrame(custom_grp, fg_color="transparent")
        hdr_custom.pack(anchor="w")
        ctk.CTkLabel(hdr_custom, text="Custom Latency (ms)", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(
            hdr_custom,
            "Type an exact max latency in milliseconds — overrides the preset "
            "dropdown when filled in. Leave blank to use the preset instead.",
        ).pack(side="left", padx=4)

        self._custom_latency_var = ctk.StringVar(value="")
        ctk.CTkEntry(
            custom_grp, textvariable=self._custom_latency_var,
            placeholder_text="e.g. 800",
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=100, height=28, corner_radius=4,
        ).pack(pady=(4, 0))

        # Region filter (Checker tab — filters by geolocated exit country)
        region_grp = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        region_grp.pack(side="left", padx=(0, 16))
        hdr_reg = ctk.CTkFrame(region_grp, fg_color="transparent")
        hdr_reg.pack(anchor="w")
        ctk.CTkLabel(hdr_reg, text="Region (Checker)", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(hdr_reg,
            "Keep only proxies whose geolocated exit IP is in this country.\n\n"
            "Applied after the geolocation stage — proxies resolving to the\n"
            "wrong country are rejected.  'Any' = no region restriction.",
        ).pack(side="left", padx=4)
        self._checker_region_var = ctk.StringVar(value="Any")
        ctk.CTkComboBox(
            region_grp, values=_REGIONS, variable=self._checker_region_var,
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=130,
        ).pack(pady=(4, 0))

        # Workers
        workers_grp = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        workers_grp.pack(side="left", padx=(0, 16))

        hdr2 = ctk.CTkFrame(workers_grp, fg_color="transparent")
        hdr2.pack(anchor="w")
        ctk.CTkLabel(hdr2, text="Workers", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        InfoBadge(
            hdr2,
            "Number of proxies checked simultaneously.\n\n"
            "Higher = faster but uses more CPU, RAM, and network sockets.\n"
            "50 is a safe default. Capped at 150 — much higher risks running "
            "out of network resources on some systems. Reduce if you see "
            "high CPU usage or the check behaving oddly.",
        ).pack(side="left", padx=4)

        self._workers_var = ctk.StringVar(value="50")
        ctk.CTkEntry(
            workers_grp, textvariable=self._workers_var,
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=70, height=28, corner_radius=4,
        ).pack(pady=(4, 0))

        # Buttons
        btns = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        btns.pack(side="left", padx=(0, 0))

        self._check_btn = ctk.CTkButton(
            btns, text="Check All",
            **button_style("primary"), height=34,
            command=self._check_proxies,
        )
        attach_tooltip(
            self._check_btn,
            "Runs each proxy through a 9-stage validation pipeline:\n\n"
            "1. Parse — extract IP, port, protocol\n"
            "2. TCP connect — raw socket, measure latency\n"
            "3. Protocol handshake — verify proxy speaks its protocol\n"
            "4. Exit IP test — route through proxy to api.ipify.org\n"
            "5. Transparent check — reject if exit IP matches your real IP\n"
            "6. Geolocation — look up country, ISP, ASN of exit IP\n"
            "7. Anonymity test — check for identifying headers via httpbin\n"
            "8. Pool analysis — detect shared/datacenter infrastructure\n"
            "9. Score 0-100 — classify as Excellent/Good/Fair/Rejected"
        )
        self._check_btn.pack(pady=(0, 4))

        _stop_style = button_style("ghost")
        _stop_style["text_color"] = TOKENS["error"]
        self._stop_btn = ctk.CTkButton(
            btns, text="Stop",
            **_stop_style, height=28, state="disabled",
            command=self._stop_check,
        )
        attach_tooltip(
            self._stop_btn,
            "Forcefully stops the current check.\n\n"
            "No new proxies are started. Anything already mid-check finishes "
            "quietly in the background and is discarded — results collected "
            "so far are kept."
        )
        self._stop_btn.pack()

        _export_btn = ctk.CTkButton(
            btns, text="Export Working",
            **button_style("ghost"), height=28,
            command=self._export_working,
        )
        _export_btn.pack()
        attach_tooltip(
            _export_btn,
            "Export all working proxies (Excellent + Good + Fair) to a .txt file.\n\n"
            "Each line is in the format:  protocol://ip:port\n"
            "You can choose the file path in the save dialog."
        )

        _import_btn = ctk.CTkButton(
            btns, text="Import List",
            **button_style("ghost"), height=28,
            command=self._import_proxy_list,
        )
        _import_btn.pack()
        attach_tooltip(
            _import_btn,
            "Paste in your own proxy list to add it to the current pool.\n\n"
            "Accepted formats:\n"
            "  ip:port\n"
            "  ip:port:protocol\n"
            "  protocol://ip:port\n\n"
            "Duplicates are skipped automatically.  Use Check All to validate them."
        )

        # Hide dead/rejected toggle — the checker has to actually check a
        # dead proxy to know it's dead, but there's no reason to clutter
        # the table with thousands of rows nobody's going to use. On by
        # default; results are always in self._live_results/self._results
        # underneath regardless, so stats and export are unaffected.
        hide_grp = ctk.CTkFrame(ctrl_row, fg_color="transparent")
        hide_grp.pack(side="left", padx=(16, 0))
        self._hide_dead_var = ctk.BooleanVar(value=True)
        _hide_cb = ctk.CTkCheckBox(
            hide_grp, text="Hide Dead/Rejected", variable=self._hide_dead_var,
            font=get_font(11), text_color=TOKENS["text_secondary"],
            fg_color=TOKENS["accent"], hover_color=TOKENS["accent_dim"],
            border_color=TOKENS["border"], width=18, height=18,
            command=self._reapply_table_filter,
        )
        _hide_cb.pack(anchor="w")
        attach_tooltip(
            _hide_cb,
            "When checked, proxies that failed all check stages are hidden from\n"
            "the results table to reduce clutter.\n\n"
            "Dead proxies are still counted in the stats bar and included in\n"
            "the full results — only the table view is filtered.\n\n"
            "Uncheck to see every proxy including dead ones."
        )

        # Stats strip
        self._stats_row = ctk.CTkFrame(ctrl, fg_color="transparent")
        self._stats_row.pack(fill="x", padx=14, pady=(0, 10))

        _stat_tips = {
            "total":     "Total number of proxies checked in this session.",
            "excellent": "Score 65+. Verified YouTube streaming + sub-75ms latency + high anonymity.",
            "youtube":   "Verified 100% working on YouTube and Google (HTTP 204 received).",
            "good":      "Score 50–64. Full HTTPS browsing verified, solid performance.",
            "fair":      "Score 30–49. Working HTTPS browsing, higher latency or fallback.",
            "rejected":  "Failed TCP, HTTPS CONNECT, or browse test. Not usable.",
            "elite":     "Anonymous AND sends no identifying headers (X-Forwarded-For etc.).",
        }
        self._stat_labels: dict[str, ctk.CTkLabel] = {}
        for key, label, color in [
            ("total",     "Total: 0",       TOKENS["text_primary"]),
            ("excellent", "Excellent: 0",   TOKENS["success"]),
            ("youtube",   "YouTube: 0",     "#FF4444"),
            ("good",      "Good: 0",        TOKENS["accent"]),
            ("fair",      "Fair: 0",        TOKENS["warning"]),
            ("rejected",  "Rejected: 0",    TOKENS["error"]),
            ("elite",     "Elite anon: 0",  TOKENS["info"]),
        ]:
            lbl = ctk.CTkLabel(
                self._stats_row, text=label,
                font=get_font(11, "bold"), text_color=color,
            )
            lbl.pack(side="left", padx=8)
            self._stat_labels[key] = lbl
            if key in _stat_tips:
                attach_tooltip(lbl, _stat_tips[key])

        # ── Connect to Best / active proxy bar ───────────────────────────
        connect_bar = ctk.CTkFrame(f, **card_style())
        connect_bar.pack(fill="x", pady=(0, 6))

        cb_row = ctk.CTkFrame(connect_bar, fg_color="transparent")
        cb_row.pack(fill="x", padx=14, pady=8)

        self._connect_best_btn = ctk.CTkButton(
            cb_row, text="Connect to Best",
            fg_color=TOKENS["success"], hover_color=TOKENS["accent_dim"],
            text_color="#000000",
            font=get_font(12, "bold"), height=32, width=150, corner_radius=6,
            command=self._connect_to_best,
        )
        self._connect_best_btn.pack(side="left")
        attach_tooltip(
            self._connect_best_btn,
            "Sets the Windows system proxy to the highest-scoring verified proxy\n"
            "(YouTube-verified and Excellent tier preferred, then Good).\n\n"
            "This changes the system-wide HTTP/HTTPS proxy in Windows Settings →\n"
            "Network → Proxy, so every app that respects system proxy settings\n"
            "(Chrome, Edge, curl, etc.) will route through it.\n\n"
            "Run a check first — the button does nothing with no results."
        )

        self._disconnect_btn = ctk.CTkButton(
            cb_row, text="Disconnect",
            **button_style("ghost"), height=32, width=100,
            command=self._disconnect_proxy,
        )
        self._disconnect_btn.pack(side="left", padx=(8, 0))
        attach_tooltip(
            self._disconnect_btn,
            "Disables the Windows system proxy, restoring direct internet access."
        )

        self._active_proxy_lbl = ctk.CTkLabel(
            cb_row, text="No proxy active",
            font=get_font(11), text_color=TOKENS["text_disabled"],
        )
        self._active_proxy_lbl.pack(side="left", padx=(14, 0))

        # Refresh active proxy label on load
        self.frame.after(200, self._refresh_active_proxy_label)

        # ── Table (hint label below) ──────────────────────────────────────
        hint = ctk.CTkLabel(
            f, text="Click any working row to enable that proxy  |  Right-click to copy  |  YT OK = YouTube verified",
            font=get_font(9), text_color=TOKENS["text_disabled"],
        )
        hint.pack(anchor="w", padx=4, pady=(0, 2))

        # Table — fast canvas-based, no widget creation per row
        _cols = [
            ("IP : Port",   146),
            ("Protocol",     62),
            ("HTTPS",        58),
            ("Country",      84),
            ("Latency",      58),
            ("Anonymity",    78),
            ("Score",        44),
            ("Status",       70),
        ]
        self._table = ScrolledTable(f, columns=_cols)
        self._table.pack(fill="both", expand=True)
        self._table.on_row_click = self._on_table_row_click

    # ── Configure tab ────────────────────────────────────────────────

    def _build_configure_tab(self) -> None:
        f = SmoothScrollFrame(self._content, fg_color="transparent", corner_radius=0)
        self._tab_frames["Configure"] = f

        # ── Chain Builder ───────────────────────────────────────────
        chain_card = ctk.CTkFrame(f, **card_style())
        chain_card.pack(fill="x", pady=(0, 12))

        hdr = ctk.CTkFrame(chain_card, fg_color="transparent")
        hdr.pack(fill="x", padx=14, pady=(12, 4))
        ctk.CTkLabel(hdr, text="Proxy Chain Builder", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(
            hdr,
            "Routes traffic through multiple proxies in sequence.\n\n"
            "Example: You → US → DE → NL → Target\n\n"
            "Only Good/Excellent proxies from the Checker can be added.",
        ).pack(side="left", padx=6)
        self._chain_status_label = ctk.CTkLabel(
            hdr, text="No chain",
            font=get_font(10, "bold"), text_color=TOKENS["text_disabled"],
        )
        self._chain_status_label.pack(side="right", padx=4)

        list_outer = ctk.CTkFrame(chain_card, fg_color=TOKENS["bg_input"], corner_radius=6)
        list_outer.pack(fill="x", padx=14, pady=(0, 6))
        self._chain_scroll = SmoothScrollFrame(
            list_outer, fg_color="transparent", corner_radius=0, height=190,
        )
        self._chain_scroll.pack(fill="x", padx=2, pady=2)
        self._chain_empty_lbl = ctk.CTkLabel(
            self._chain_scroll,
            text="No proxies in chain.  Add below or Import from Checker.",
            font=get_font(10), text_color=TOKENS["text_disabled"],
        )
        self._chain_empty_lbl.pack(pady=20)

        btn_row = ctk.CTkFrame(chain_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=14, pady=(0, 6))
        for label, cmd, variant, tip in [
            ("+ Add Best Proxy",      self._chain_add_node,           "ghost",
             "Add the highest-scoring checked proxy not already in the chain."),
            ("Import from Checker",   self._chain_import_from_checker, "ghost",
             "Fill chain with best proxies from Checker results (max 8 hops)."),
            ("Clear",                 self._chain_clear,             "ghost",
             "Remove all nodes."),
            ("Test Chain",            self._chain_test,              "primary",
             "Route a live request through the chain. Failing hops auto-removed."),
            ("Export",                self._chain_export,            "ghost",
             "Copy the chain to clipboard."),
        ]:
            b = ctk.CTkButton(btn_row, text=label, **button_style(variant),
                              height=30, command=cmd)
            attach_tooltip(b, tip)
            b.pack(side="left", padx=(0, 4))

        self._chain_test_label = ctk.CTkLabel(
            chain_card, text="",
            font=get_font(10), text_color=TOKENS["text_secondary"],
        )
        self._chain_test_label.pack(anchor="w", padx=14, pady=(0, 4))

        opt_card = ctk.CTkFrame(chain_card, fg_color=TOKENS["bg_input"], corner_radius=6)
        opt_card.pack(fill="x", padx=14, pady=(0, 12))

        routing_row = ctk.CTkFrame(opt_card, fg_color="transparent")
        routing_row.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(routing_row, text="Routing:", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        self._routing_var = ctk.StringVar(value=_CHAIN_ROUTING[0])
        ctk.CTkComboBox(
            routing_row, values=_CHAIN_ROUTING, variable=self._routing_var,
            fg_color=TOKENS["bg_card"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=240,
        ).pack(side="left", padx=10)

        dns_row = ctk.CTkFrame(opt_card, fg_color="transparent")
        dns_row.pack(fill="x", padx=12, pady=(0, 8))
        ctk.CTkLabel(dns_row, text="DNS through proxy:", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")
        self._dns_proxy_var = ctk.BooleanVar(value=True)
        ctk.CTkSwitch(
            dns_row, text="", variable=self._dns_proxy_var,
            fg_color=TOKENS["bg_card"], progress_color=TOKENS["accent"],
            button_color=TOKENS["accent"], width=40,
        ).pack(side="left", padx=10)

        # ── Export Format ─────────────────────────────────────────────────
        export_card = ctk.CTkFrame(f, **card_style())
        export_card.pack(fill="x", pady=(0, 12))

        hdr4 = ctk.CTkFrame(export_card, fg_color="transparent")
        hdr4.pack(fill="x", padx=14, pady=(12, 6))
        ctk.CTkLabel(hdr4, text="Export Format", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(
            hdr4,
            "Choose the format for exporting your checked proxy list.\n\n"
            "ip:port is the simplest and works with most tools.\n"
            "Proxifier and ProxyCap formats can be imported directly into those apps.\n"
            "Shadowsocks JSON is used by shadowsocks-ng / Clash / v2ray."
        ).pack(side="left", padx=6)

        fmt_row = ctk.CTkFrame(export_card, fg_color="transparent")
        fmt_row.pack(fill="x", padx=14, pady=(0, 10))

        ctk.CTkLabel(fmt_row, text="Format:", font=get_font(11),
                     text_color=TOKENS["text_secondary"]).pack(side="left")

        self._export_fmt_var = ctk.StringVar(value=_EXPORT_FORMATS[0])
        ctk.CTkComboBox(
            fmt_row, values=_EXPORT_FORMATS, variable=self._export_fmt_var,
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"], width=240,
        ).pack(side="left", padx=8)

        _export_list_btn = ctk.CTkButton(
            fmt_row, text="Export List",
            **button_style("primary"), height=30,
            command=self._export_working,
        )
        _export_list_btn.pack(side="left", padx=8)
        attach_tooltip(
            _export_list_btn,
            "Export all working proxies in the selected format to a .txt file.\n\n"
            "You must run Check All before exporting — exporting before checking\n"
            "will produce an empty file since no proxies have been validated yet."
        )

        # ── Checker Settings ──────────────────────────────────────────────
        check_card = ctk.CTkFrame(f, **card_style())
        check_card.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(check_card, text="Checker Settings",
                     font=get_font(13, "bold"), text_color=TOKENS["text_primary"]
                     ).pack(anchor="w", padx=14, pady=(12, 6))

        settings = [
            ("Verify exit IP through proxy",    "check_exit_ip",
             "Route a request through the proxy to confirm the exit IP differs from yours.\n"
             "Detects transparent proxies. Adds ~2s per proxy to check time."),
            ("Test anonymity headers",          "check_anon_headers",
             "Send a request to httpbin.org/headers through the proxy and check if "
             "identifying headers (X-Forwarded-For, Via, etc.) are present.\n"
             "Adds ~3s per proxy but is the only reliable way to detect elite vs anonymous."),
            ("Detect pooled/datacenter proxies","check_pool",
             "Flag proxies on known datacenter ASNs (AWS, Azure, Hetzner, OVH, etc.).\n"
             "These are often blocked by sites that detect hosting provider IPs."),
            ("Multi-request pool detection",    "check_multi_req",
             "Send 3 requests through the same proxy and compare exit IPs.\n"
             "If they differ, the proxy is confirmed to use a shared pool.\n"
             "Adds ~5s per proxy but is the most reliable pool detection method."),
        ]

        self._checker_setting_vars: dict[str, ctk.BooleanVar] = {}

        for label, key, tip in settings:
            row = ctk.CTkFrame(check_card, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=3)

            hdr_r = ctk.CTkFrame(row, fg_color="transparent")
            hdr_r.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(hdr_r, text=label, font=get_font(11),
                         text_color=TOKENS["text_secondary"], anchor="w").pack(side="left")
            InfoBadge(hdr_r, tip).pack(side="left", padx=4)

            var = ctk.BooleanVar(value=True)
            self._checker_setting_vars[key] = var
            ctk.CTkSwitch(
                row, text="", variable=var,
                fg_color=TOKENS["bg_input"], progress_color=TOKENS["accent"],
                button_color=TOKENS["accent"], width=40,
            ).pack(side="right")

        ctk.CTkFrame(check_card, fg_color="transparent", height=8).pack()

        # ── Proxy Defaults (migrated from Settings) ────────────────────────
        # These are the same controls that live in Settings → Proxy Defaults.
        # They are surfaced here too so you don't need to leave the Proxy page
        # to tweak workers / timeout / protocol / anonymity defaults.
        # Changes save to config immediately (same object both pages share).
        defaults_card = ctk.CTkFrame(f, **card_style())
        defaults_card.pack(fill="x", pady=(0, 12))

        dh = ctk.CTkFrame(defaults_card, fg_color="transparent")
        dh.pack(fill="x", padx=14, pady=(12, 4))
        ctk.CTkLabel(dh, text="Proxy Defaults", font=get_font(13, "bold"),
                     text_color=TOKENS["text_primary"]).pack(side="left")
        InfoBadge(
            dh,
            "These defaults are also editable in Settings → Proxy Defaults.\n\n"
            "Changes take effect immediately for new check/fetch operations.",
        ).pack(side="left", padx=6)

        from app.config import config as _cfg

        def _defaults_row(label: str, tip: str, make_widget) -> None:
            """
            Build one labelled row inside defaults_card.

            make_widget(row_frame) → widget
            The widget is created WITH the row as its parent so pack geometry
            is correct.  Creating the widget before the row (with defaults_card
            as parent) caused the overlap seen in the screenshot.
            """
            row = ctk.CTkFrame(defaults_card, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=4)
            lbl_f = ctk.CTkFrame(row, fg_color="transparent")
            lbl_f.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(lbl_f, text=label, font=get_font(11),
                         text_color=TOKENS["text_secondary"]).pack(side="left")
            InfoBadge(lbl_f, tip).pack(side="left", padx=4)
            w = make_widget(row)
            w.pack(side="right")

        # Workers
        self._cfg_workers_var = ctk.StringVar(value=str(_cfg.proxy_max_workers))
        def _on_workers_change(*_):
            try:
                v = int(self._cfg_workers_var.get())
                if 1 <= v <= 500:
                    _cfg.proxy_max_workers = v
                    _cfg.save()
            except ValueError:
                pass
        self._cfg_workers_var.trace_add("write", _on_workers_change)
        _defaults_row(
            "Max concurrent workers",
            "How many proxies are checked simultaneously.\n\n"
            "Higher = faster but heavier on CPU/RAM.\n50 is a good balance.",
            lambda row: ctk.CTkEntry(
                row, textvariable=self._cfg_workers_var,
                fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
                text_color=TOKENS["text_primary"], width=72, justify="right",
            ),
        )

        # Timeout
        self._cfg_timeout_var = ctk.StringVar(value=str(_cfg.proxy_timeout_s))
        def _on_timeout_change(*_):
            try:
                v = int(self._cfg_timeout_var.get())
                if 1 <= v <= 120:
                    _cfg.proxy_timeout_s = v
                    _cfg.save()
            except ValueError:
                pass
        self._cfg_timeout_var.trace_add("write", _on_timeout_change)
        _defaults_row(
            "Check timeout (seconds)",
            "Max wait per proxy during a check.\n\n"
            "Lower = faster but may reject slow working proxies.\nDefault: 10s.",
            lambda row: ctk.CTkEntry(
                row, textvariable=self._cfg_timeout_var,
                fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
                text_color=TOKENS["text_primary"], width=72, justify="right",
            ),
        )

        # Anonymity filter
        self._cfg_anon_var = ctk.StringVar(value=_cfg.proxy_default_anonymity)
        _defaults_row(
            "Default anonymity filter",
            "Pre-selected anonymity level in the Checker.\n\n"
            "Elite = no identifying headers (most private)\n"
            "Anonymous = some headers stripped\nAny = all levels accepted.",
            lambda row: ctk.CTkComboBox(
                row, values=["any", "elite", "anonymous"],
                variable=self._cfg_anon_var,
                fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
                text_color=TOKENS["text_primary"], width=140,
                command=lambda v: (setattr(_cfg, "proxy_default_anonymity", v), _cfg.save()),
            ),
        )

        # Protocol default
        self._cfg_proto_var = ctk.StringVar(value=_cfg.proxy_default_protocol)
        _defaults_row(
            "Default protocol",
            "Pre-selected protocol filter in the Generator and Checker.\n\n"
            "SOCKS5 is the most capable.  'any' fetches all three types.",
            lambda row: ctk.CTkComboBox(
                row, values=["any", "http", "socks4", "socks5"],
                variable=self._cfg_proto_var,
                fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
                text_color=TOKENS["text_primary"], width=140,
                command=lambda v: (setattr(_cfg, "proxy_default_protocol", v), _cfg.save()),
            ),
        )

        ctk.CTkFrame(defaults_card, fg_color="transparent", height=6).pack()
        f.bind_children()

    # ── History tab ────────────────────────────────────────────────────────

    def _build_history_tab(self) -> None:
        f = ctk.CTkFrame(self._content, fg_color="transparent")
        self._tab_frames["History"] = f

        ctk.CTkLabel(
            f, text="Session History",
            font=get_font(14, "bold"), text_color=TOKENS["text_primary"],
        ).pack(anchor="w", pady=(0, 10))

        self._history_scroll = SmoothScrollFrame(
            f, fg_color=TOKENS["bg_card"], corner_radius=6
        )
        self._history_scroll.pack(fill="both", expand=True)

        # Render any entries that arrived before this tab was ever built —
        # tabs are now lazy (only built on first visit), but a fetch/check
        # can finish before the user has ever clicked into History.
        if self._history_data:
            for kind, ts, total, excellent, good, fair in self._history_data:
                self._render_history_row(kind, ts, total, excellent, good, fair)
        else:
            empty_label = ctk.CTkLabel(
                self._history_scroll,
                text="No sessions yet. Fetch and check proxies to see history here.",
                font=get_font(11), text_color=TOKENS["text_disabled"],
            )
            empty_label.pack(pady=30)
            empty_label._is_empty_state = True

    # ── Proxy connect / enable ─────────────────────────────────────────────

    def _refresh_active_proxy_label(self) -> None:
        """Update the 'active proxy' label from the current system setting."""
        try:
            from modules.proxy.connect import get_active_proxy
            current = get_active_proxy()
            if current:
                self._active_proxy_lbl.configure(
                    text=f"Active: {current}",
                    text_color=TOKENS["success"],
                )
            else:
                self._active_proxy_lbl.configure(
                    text="No proxy active",
                    text_color=TOKENS["text_disabled"],
                )
        except Exception:
            pass

    def _connect_to_best(self) -> None:
        """Enable the highest-scoring working proxy as the system proxy."""
        from modules.proxy.connect import enable_proxy
        best = None
        for tier in ("excellent", "good", "fair"):
            candidates = [r for r in self._results if r.tier == tier]
            if candidates:
                # Prioritize youtube_ok first, then highest score, then lowest latency
                candidates.sort(key=lambda r: (not getattr(r, "youtube_ok", False), -r.score, r.tcp_latency_ms or 9999))
                best = candidates[0]
                break

        if best is None:
            self._status_label.configure(
                text="No working proxies — run Check All first."
            )
            return

        def _do():
            return enable_proxy(best.proxy.ip, best.proxy.port, best.proxy.protocol)

        def _done(result):
            ok, msg = result
            self._status_label.configure(text=msg)
            self._refresh_active_proxy_label()

        worker.submit(
            _do,
            on_done=lambda r: self.frame.after(0, _done, r),
            on_error=lambda e: self.frame.after(0, lambda: self._status_label.configure(
                text=f"Connect failed: {e}"
            )),
        )

    def _disconnect_proxy(self) -> None:
        """Clear the Windows system proxy."""
        from modules.proxy.connect import disable_proxy

        def _do():
            return disable_proxy()

        def _done(result):
            ok, msg = result
            self._status_label.configure(text=msg)
            self._refresh_active_proxy_label()

        worker.submit(
            _do,
            on_done=lambda r: self.frame.after(0, _done, r),
            on_error=lambda e: self.frame.after(0, lambda: self._status_label.configure(
                text=f"Disconnect failed: {e}"
            )),
        )

    def _on_table_row_click(self, row_idx: int, cells: list, tag: str, event) -> None:
        """
        Left-click on a result row.

        Working proxies (excellent/good/fair) → show a tiny action popup with
        Enable (set as system proxy) and Copy options.
        Dead/rejected proxies → show Copy only.
        """
        import tkinter as tk

        # Parse proxy address from first cell: "ip:port"
        addr = cells[0] if cells else ""
        status = cells[-1].lower() if cells else ""
        is_working = tag in ("excellent", "good", "fair")

        # Build popup menu
        menu = tk.Menu(self.frame, tearoff=0,
                       bg=TOKENS["bg_card"], fg=TOKENS["text_primary"],
                       activebackground=TOKENS["accent"],
                       activeforeground=TOKENS["accent_text"],
                       relief="flat", bd=0)

        if is_working and addr:
            parts = addr.rsplit(":", 1)
            if len(parts) == 2:
                ip, port_str = parts
                try:
                    port = int(port_str)
                    # Determine protocol from _live_results
                    proto = "http"
                    for r in self._live_results:
                        if r.proxy.ip == ip and r.proxy.port == port:
                            proto = r.proxy.protocol
                            break

                    def _enable_this():
                        from modules.proxy.connect import enable_proxy

                        def _do():
                            return enable_proxy(ip, port, proto)

                        def _done(result):
                            ok, msg = result
                            self._status_label.configure(text=msg)
                            self._refresh_active_proxy_label()

                        worker.submit(
                            _do,
                            on_done=lambda r: self.frame.after(0, _done, r),
                            on_error=lambda e: self.frame.after(
                                0, lambda: self._status_label.configure(
                                    text=f"Enable failed: {e}"
                                )
                            ),
                        )

                    menu.add_command(label=f"Enable  {addr}  ({proto.upper()})",
                                     command=_enable_this,
                                     font=get_font(11, "bold"))
                    menu.add_separator()
                except ValueError:
                    pass

        if addr:
            menu.add_command(
                label="Copy  ip:port",
                command=lambda: (
                    self.frame.clipboard_clear(),
                    self.frame.clipboard_append(addr),
                ),
                font=get_font(11),
            )
            menu.add_command(
                label="Copy all columns",
                command=lambda: (
                    self.frame.clipboard_clear(),
                    self.frame.clipboard_append("  |  ".join(cells)),
                ),
                font=get_font(11),
            )

        if menu.index("end") is not None:
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()

    # ── EventBus subscriptions ─────────────────────────────────────────────

    def _subscribe(self) -> None:
        bus.subscribe(Events.PROXY_FETCH_PROGRESS, self._on_fetch_progress)
        bus.subscribe(Events.PROXY_FETCH_DONE,     self._on_fetch_done)
        bus.subscribe(Events.PROXY_CHECK_PROGRESS, self._on_check_progress)
        bus.subscribe(Events.PROXY_CHECK_DONE,     self._on_check_done)
        bus.subscribe(Events.PROXY_RESULT_BATCH,   self._on_proxy_result_batch)

    def _widget_alive(self) -> bool:
        """Return True only when the page frame is still part of a live Tk window.

        This guards every event-bus callback against the case where the user
        switches away from the Proxy page (or closes the app) while a
        background fetch/check thread is still running.  Calling .configure()
        on a destroyed widget raises RuntimeError from a non-main thread which
        triggers the 'Variable.__del__ / main thread is not in main loop' crash
        seen in the logs.
        """
        try:
            return bool(self.frame.winfo_exists())
        except Exception:
            return False

    def _on_fetch_progress(self, data: dict) -> None:
        if not self._widget_alive():
            return
        pct = data["completed"] / max(data["total"], 1)
        try:
            self._progress_bar.set(pct)
            self._status_label.configure(
                text=f"Fetching {data['completed']}/{data['total']}  —  {data['running_total']} found"
            )
        except Exception:
            pass

    def _on_fetch_done(self, proxies: list) -> None:
        self._raw_proxies = proxies  # always keep data even if UI is gone
        if not self._widget_alive():
            return
        try:
            self._fetch_btn.configure(state="normal")
            self._progress_bar.set(1.0)
            n = len(proxies)
            self._gen_count_label.configure(text=f"{n:,} proxies fetched")
            self._status_label.configure(text=f"Fetch done  —  {n:,} unique proxies")

            self._raw_box.configure(state="normal")
            self._raw_box.delete("1.0", "end")
            for p in proxies[:3000]:
                self._raw_box.insert("end", f"{p.protocol}://{p.ip}:{p.port}\n")
            if len(proxies) > 3000:
                self._raw_box.insert("end", f"... {len(proxies)-3000} more (showing first 3000)\n")
            self._raw_box.configure(state="disabled")

            self._add_history_entry("Fetch", n, 0, 0, 0)
        except Exception:
            pass

    def _on_check_progress(self, data: dict) -> None:
        if not self._widget_alive():
            return
        try:
            pct = data["completed"] / max(data["total"], 1)
            self._progress_bar.set(pct)
            self._status_label.configure(
                text=f"Checking {data['completed']}/{data['total']}  "
                     f"—  last: {data['last_proxy']}  [{data['last_tier']}]"
            )
        except Exception:
            pass

    def _on_check_done(self, results: list) -> None:
        self._results = results   # always store, even if UI gone
        self._check_running = False
        self._stop_event = None
        if not self._widget_alive():
            return
        try:
            self._check_btn.configure(state="normal")
            self._stop_btn.configure(state="disabled")
            self._progress_bar.set(1.0)

            excellent = sum(1 for r in results if r.tier == "excellent")
            youtube   = sum(1 for r in results if getattr(r, "youtube_ok", False))
            good      = sum(1 for r in results if r.tier == "good")
            fair      = sum(1 for r in results if r.tier == "fair")
            rejected  = sum(1 for r in results if r.tier in ("rejected", "dead"))
            elite     = sum(1 for r in results if r.anonymity == "elite" and r.tier not in ("dead",))

            self._stat_labels["total"].configure(text=f"Total: {len(results):,}")
            self._stat_labels["excellent"].configure(text=f"Excellent: {excellent}")
            self._stat_labels["youtube"].configure(text=f"YouTube: {youtube}")
            self._stat_labels["good"].configure(text=f"Good: {good}")
            self._stat_labels["fair"].configure(text=f"Fair: {fair}")
            self._stat_labels["rejected"].configure(text=f"Rejected: {rejected}")
            self._stat_labels["elite"].configure(text=f"Elite anon: {elite}")

            working = excellent + good + fair
            was_stopped = len(results) < len(self._raw_proxies)
            suffix = "  (stopped early)" if was_stopped else ""
            self._status_label.configure(
                text=f"Check done  —  {working}/{len(results)} working{suffix}"
            )
            self._add_history_entry("Check", len(results), excellent, good, fair)
        except Exception:
            pass

    def _row_for_result(self, result: CheckResult) -> tuple[list[str], str]:
        # HTTPS column: YT OK = YouTube verified, OK = browse test passed, NO = failed
        if getattr(result, "youtube_ok", False):
            https_cell = "YT OK"
        elif result.browse_ok:
            https_cell = "OK"
        elif result.https_ok:
            https_cell = "~"   # CONNECT works but full browse test timed out
        elif result.tier in ("dead",):
            https_cell = "-"
        else:
            https_cell = "NO"

        cells = [
            result.proxy.address(),
            result.proxy.protocol.upper(),
            https_cell,
            result.country or "—",
            f"{result.tcp_latency_ms:.0f} ms" if result.tcp_latency_ms else "—",
            result.anonymity or "—",
            str(result.score),
            result.tier.upper(),
        ]
        return cells, result.tier

    def _reapply_table_filter(self) -> None:
        """Rebuilds the visible table from self._live_results against the
        current Hide Dead/Rejected setting — no re-checking needed, all
        results are already known."""
        hide_dead = self._hide_dead_var.get()
        rows = [
            self._row_for_result(r) for r in self._live_results
            if not (hide_dead and r.tier in ("dead", "rejected"))
        ]
        self._table.set_rows(rows)

    def _on_proxy_result_batch(self, batch: list[CheckResult]) -> None:
        """
        Handles a batch of newly-completed results. Throttled: table appends
        happen immediately but the stats strip is updated at most once per
        150ms to avoid cascading configure() calls under heavy load.
        """
        if not batch:
            return

        # Always accumulate data even if the UI frame is not visible/alive
        self._live_results.extend(batch)
        for result in batch:
            self._live_stats[result.tier] = self._live_stats.get(result.tier, 0) + 1
            if getattr(result, "youtube_ok", False):
                self._live_stats["youtube"] = self._live_stats.get("youtube", 0) + 1
            if result.anonymity == "elite" and result.tier != "dead":
                self._live_stats["elite"] = self._live_stats.get("elite", 0) + 1

        # Only touch widgets when the page is still alive
        if not self._widget_alive():
            return

        try:
            hide_dead = self._hide_dead_var.get()
            rows_data = []
            for result in batch:
                if hide_dead and result.tier in ("dead", "rejected"):
                    continue
                rows_data.append(self._row_for_result(result))

            # One redraw for the whole batch
            if rows_data:
                self._table.append_rows(rows_data)

            # Throttle stats strip: schedule one update 150ms from now,
            # cancelling any already-pending update (collapses rapid bursts)
            if self._check_running:
                if getattr(self, "_stats_update_id", None):
                    try:
                        self.frame.after_cancel(self._stats_update_id)
                    except Exception:
                        pass
                self._stats_update_id = self.frame.after(150, self._flush_live_stats)
        except Exception:
            pass

    def _flush_live_stats(self) -> None:
        """Write accumulated stats to labels — called throttled, not per-batch."""
        self._stats_update_id = None
        if not self._widget_alive():
            return
        try:
            total_done = sum(v for k, v in self._live_stats.items() if k not in ("elite", "youtube"))
            self._stat_labels["total"].configure(text=f"Total: {total_done:,}")
            self._stat_labels["excellent"].configure(text=f"Excellent: {self._live_stats.get('excellent', 0)}")
            self._stat_labels["youtube"].configure(text=f"YouTube: {self._live_stats.get('youtube', 0)}")
            self._stat_labels["good"].configure(text=f"Good: {self._live_stats.get('good', 0)}")
            self._stat_labels["fair"].configure(text=f"Fair: {self._live_stats.get('fair', 0)}")
            rejected = self._live_stats.get("rejected", 0) + self._live_stats.get("dead", 0)
            self._stat_labels["rejected"].configure(text=f"Rejected: {rejected}")
            self._stat_labels["elite"].configure(text=f"Elite anon: {self._live_stats.get('elite', 0)}")
        except Exception:
            pass

    # ── Actions ────────────────────────────────────────────────────────────

    def _fetch_proxies(self) -> None:
        self._fetch_btn.configure(state="disabled")
        self._progress_bar.set(0)
        self._gen_count_label.configure(text="")
        self._status_label.configure(text="Starting fetch...")
        self._raw_box.configure(state="normal")
        self._raw_box.delete("1.0", "end")
        self._raw_box.configure(state="disabled")
        worker.submit(fetch_all_sources)

    def _check_proxies(self) -> None:
        if not self._raw_proxies:
            self._status_label.configure(text="Fetch proxies first.")
            return

        # Clear table and stats
        self._table.clear()
        self._live_stats.clear()
        self._live_results.clear()
        for lbl in self._stat_labels.values():
            lbl.configure(text=lbl.cget("text").split(":")[0] + ": 0")

        self._check_running = True
        self._stop_event = threading.Event()
        self._check_btn.configure(state="disabled")
        self._stop_btn.configure(state="normal")
        self._progress_bar.set(0)

        try:
            workers = int(self._workers_var.get())
        except ValueError:
            workers = 50
        workers = max(1, min(workers, 150))

        # Filters — protocol/region/anonymity come from the Generator tab's
        # filter row (they used to be collected but never actually passed
        # to the checker, so they looked like they did nothing). Max
        # latency comes from this tab's own preset dropdown, or the custom
        # field if the user typed one (which wins over the preset).
        protocol_filter = getattr(self, "_var_tip_proto", None)
        protocol_filter = protocol_filter.get() if protocol_filter else "any"

        # Use the Checker tab's own region filter; fall back to Generator's
        # if the Checker tab hasn't been built yet (shouldn't happen in normal
        # flow since you must visit Checker to run a check).
        region_filter_var = getattr(self, "_checker_region_var", None) or \
                            getattr(self, "_var_tip_region", None)
        region_filter = region_filter_var.get() if region_filter_var else "Any"

        min_anonymity = getattr(self, "_var_tip_anon", None)
        min_anonymity = min_anonymity.get() if min_anonymity else "any"

        max_latency_ms: Optional[float] = None
        custom_text = self._custom_latency_var.get().strip()
        if custom_text:
            try:
                max_latency_ms = float(custom_text)
            except ValueError:
                max_latency_ms = None
        if max_latency_ms is None:
            preset = _PING_MAP.get(self._ping_var.get(), 9999)
            if preset < 9999:
                max_latency_ms = float(preset)

        proxies = list(self._raw_proxies)
        worker.submit(
            check_all, proxies,
            max_workers=workers, stop_event=self._stop_event,
            region_filter=region_filter, protocol_filter=protocol_filter,
            min_anonymity=min_anonymity, max_latency_ms=max_latency_ms,
            on_error=lambda e: bus.publish(Events.APP_ERROR, f"Check failed: {e}"),
        )

    def _stop_check(self) -> None:
        if self._stop_event:
            self._stop_event.set()
        self._check_running = False
        if hasattr(self, "_stop_btn"):
            self._stop_btn.configure(state="disabled")
        if hasattr(self, "_check_btn"):
            self._check_btn.configure(state="normal")
        if hasattr(self, "_status_label"):
            self._status_label.configure(text="Check stopped.")

    def _export_working(self) -> None:
        import tkinter as tk
        working = [r for r in self._results if r.tier in ("excellent", "good", "fair")]
        if not working:
            self._status_label.configure(text="No working proxies to export — run Check first.")
            return

        fmt = self._export_fmt_var.get()
        lines: list[str] = []

        for r in working:
            p = r.proxy
            if fmt == "ip:port":
                lines.append(f"{p.ip}:{p.port}")
            elif fmt == "protocol://ip:port":
                lines.append(f"{p.protocol}://{p.ip}:{p.port}")
            elif fmt == "ip:port:protocol":
                lines.append(f"{p.ip}:{p.port}:{p.protocol}")
            else:
                lines.append(f"{p.protocol}://{p.ip}:{p.port}")

        text = "\n".join(lines)
        self.frame.clipboard_clear()
        self.frame.clipboard_append(text)
        self._status_label.configure(
            text=f"Copied {len(lines)} proxies to clipboard in '{fmt}' format"
        )

    def _import_proxy_list(self) -> None:
        """
        Open a paste-in dialog so the user can check a custom list without
        having to use the Generator to fetch from public sources first.
        Accepted formats (one proxy per line, protocol optional):

            host:port
            host:port:protocol          (http / socks4 / socks5)
            protocol://host:port
            protocol://user:pass@host:port
        """
        import re as _re

        dialog = ctk.CTkToplevel(self.frame)
        dialog.title("Import Proxy List")
        dialog.geometry("520x440")
        dialog.resizable(False, False)
        dialog.grab_set()
        dialog.configure(fg_color=TOKENS["bg_base"])

        ctk.CTkLabel(
            dialog, text="Paste proxy list",
            font=get_font(13, "bold"), text_color=TOKENS["text_primary"],
        ).pack(anchor="w", padx=16, pady=(14, 2))

        ctk.CTkLabel(
            dialog,
            text="One proxy per line.  Accepted formats:\n"
                 "  host:port  |  protocol://host:port  |  host:port:protocol",
            font=get_font(10), text_color=TOKENS["text_secondary"],
            justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 6))

        # Default protocol selector — used when no protocol is present in line
        proto_row = ctk.CTkFrame(dialog, fg_color="transparent")
        proto_row.pack(fill="x", padx=16, pady=(0, 6))
        ctk.CTkLabel(
            proto_row, text="Default protocol:",
            font=get_font(11), text_color=TOKENS["text_secondary"],
        ).pack(side="left", padx=(0, 8))
        _proto_var = ctk.StringVar(value="http")
        ctk.CTkComboBox(
            proto_row, values=["http", "socks4", "socks5"],
            variable=_proto_var, width=110,
            fg_color=TOKENS["bg_input"], border_color=TOKENS["border"],
            text_color=TOKENS["text_primary"],
        ).pack(side="left")

        # Text area
        box = ctk.CTkTextbox(
            dialog,
            fg_color=TOKENS["bg_card"], text_color=TOKENS["text_primary"],
            font=get_font(10, mono=True), corner_radius=6,
        )
        box.pack(fill="both", expand=True, padx=16, pady=(0, 8))

        status_lbl = ctk.CTkLabel(
            dialog, text="", font=get_font(10),
            text_color=TOKENS["text_secondary"],
        )
        status_lbl.pack(anchor="w", padx=16, pady=(0, 2))

        btn_row = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_row.pack(fill="x", padx=16, pady=(0, 14))

        def _do_import() -> None:
            raw_text = box.get("1.0", "end").strip()
            if not raw_text:
                dialog.destroy()
                return

            default_proto = _proto_var.get()
            _RE_SCHEME = _re.compile(
                r"^(?P<proto>https?|socks[45])://(?:(?P<creds>[^@]+)@)?(?P<host>[^:/]+):(?P<port>\d+)",
                _re.IGNORECASE,
            )
            _RE_BARE = _re.compile(
                r"^(?P<host>[^:/\s]+):(?P<port>\d+)(?::(?P<proto>https?|socks[45]))?$",
                _re.IGNORECASE,
            )

            parsed: list[ProxyRecord] = []
            skipped = 0
            for line in raw_text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                m = _RE_SCHEME.match(line)
                if m:
                    proto = m.group("proto").lower().replace("https", "http")
                    creds = m.group("creds")
                    host  = m.group("host")
                    port  = int(m.group("port"))
                    parsed.append(ProxyRecord(
                        ip=host, port=port, protocol=proto,
                        credentials=creds,
                    ))
                    continue
                m = _RE_BARE.match(line)
                if m:
                    raw_proto = (m.group("proto") or "").lower().replace("https", "http")
                    proto = raw_proto if raw_proto in ("http", "socks4", "socks5") else default_proto
                    parsed.append(ProxyRecord(
                        ip=m.group("host"),
                        port=int(m.group("port")),
                        protocol=proto,
                    ))
                    continue
                skipped += 1

            if not parsed:
                status_lbl.configure(
                    text=f"No valid proxies found ({skipped} lines skipped).",
                    text_color=TOKENS["error"],
                )
                return

            # Merge: deduplicate by (ip, port, protocol), existing fetched
            # list takes priority for entries that already exist.
            existing_keys = {(p.ip, p.port, p.protocol) for p in self._raw_proxies}
            new_only = [p for p in parsed if (p.ip, p.port, p.protocol) not in existing_keys]
            self._raw_proxies = self._raw_proxies + new_only

            total = len(self._raw_proxies)
            msg = f"Imported {len(new_only)} new proxies  ({len(parsed) - len(new_only)} dupes skipped)"
            if skipped:
                msg += f"  |  {skipped} unparseable lines skipped"
            self._status_label.configure(text=msg)
            self._gen_count_label.configure(text=f"{total:,} proxies ready")
            dialog.destroy()

        ctk.CTkButton(
            btn_row, text="Import",
            **button_style("primary"), height=32,
            command=_do_import,
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            btn_row, text="Cancel",
            **button_style("ghost"), height=32,
            command=dialog.destroy,
        ).pack(side="left")

    # ── Chain helpers ──────────────────────────────────────────────────────

    def _chain_add_node(self) -> None:
        best = [r for r in self._results if r.tier in ("excellent", "good")]
        if not best:
            self._status_label.configure(text="No good proxies available — run Check first.")
            return
        # Pick first unused
        used = set(self._chain_nodes)
        for r in best:
            addr = r.proxy.address()
            if addr not in used:
                self._chain_nodes.append(addr)
                self._update_chain_display()
                return
        self._status_label.configure(text="All good proxies already added to chain.")

    def _chain_clear(self) -> None:
        self._chain_nodes.clear()
        self._update_chain_display()

    def _chain_test(self) -> None:
        if not self._chain_nodes:
            self._status_label.configure(text="Add nodes to the chain first.")
            return

        self._status_label.configure(text=f"Testing chain ({len(self._chain_nodes)} hops)…")

        nodes = list(self._chain_nodes)

        def _do_test() -> dict:
            """
            Test the chain by routing through each proxy hop in sequence,
            then hitting api.ipify.org to confirm the exit IP matches the
            last hop rather than our real IP.
            """
            import requests, socket, time
            results = {}

            timeout = 8

            # Step 1 — TCP reachability for every hop
            hop_ok = []
            for addr in nodes:
                try:
                    host, port_str = addr.rsplit(":", 1)
                    t0 = time.monotonic()
                    sock = socket.create_connection((host, int(port_str)), timeout=5)
                    sock.close()
                    ms = (time.monotonic() - t0) * 1000
                    hop_ok.append((addr, True, f"{ms:.0f}ms"))
                except Exception as exc:
                    hop_ok.append((addr, False, str(exc)))

            results["hops"] = hop_ok

            # Step 2 — Route through the last proxy to get exit IP
            last = nodes[-1]
            # Determine protocol from checker results (_results is the live list)
            protocol = "http"
            for r in self._results:
                if r.proxy.address() == last:
                    protocol = r.proxy.protocol
                    break

            proxy_url = f"{protocol}://{last}"
            proxies = {"http": proxy_url, "https": proxy_url}

            # Use HTTP (not HTTPS) so SOCKS proxies work without the
            # optional PySocks/requests[socks] extra for HTTPS tunnelling.
            # api.ipify.org supports plain HTTP — the response is just an IP.
            try:
                t0 = time.monotonic()
                resp = requests.get(
                    "http://api.ipify.org?format=json",
                    proxies=proxies, timeout=timeout,
                )
                ms = (time.monotonic() - t0) * 1000
                exit_ip = resp.json().get("ip", "?")
                results["exit_ip"] = exit_ip
                results["exit_ms"] = f"{ms:.0f}ms"
                results["success"] = True
            except Exception as exc:
                err_str = str(exc)
                # Give a clearer message for the missing PySocks case
                if "SOCKS" in err_str and "connect" in err_str.lower():
                    err_str = "SOCKS proxy unreachable (TCP connect failed)"
                elif "PySocks" in err_str or "socks" in err_str.lower() and "install" in err_str.lower():
                    err_str = "Install PySocks: pip install requests[socks]"
                results["exit_ip"] = "failed"
                results["exit_ms"] = "—"
                results["success"] = False
                results["error"] = err_str

            return results

        def _on_done(results: dict) -> None:
            hops = results.get("hops", [])
            all_hops_ok = all(ok for _, ok, _ in hops)
            success = results.get("success", False)
            exit_ip = results.get("exit_ip", "?")
            exit_ms = results.get("exit_ms", "—")

            # Build status summary
            failed_hops = [addr for addr, ok, _ in hops if not ok]
            if failed_hops:
                hop_status = f"TCP fail: {', '.join(failed_hops)}"
            else:
                hop_status = f"All {len(hops)} hops reachable"

            if success:
                msg = f"Chain OK — exit IP: {exit_ip}  ({exit_ms})  |  {hop_status}"
            else:
                err = results.get("error", "unknown error")
                msg = f"Chain FAILED — {err[:60]}  |  {hop_status}"

            try:
                self._status_label.configure(text=msg)
            except Exception:
                pass

        worker.submit(
            _do_test,
            on_done=lambda r: self.frame.after(0, _on_done, r),
            on_error=lambda e: self.frame.after(0, lambda: self._status_label.configure(
                text=f"Chain test error: {e}"
            )),
        )

    def _chain_export(self) -> None:
        if not self._chain_nodes:
            return
        text = "\n".join(self._chain_nodes)
        self.frame.clipboard_clear()
        self.frame.clipboard_append(text)
        self._status_label.configure(text=f"Chain ({len(self._chain_nodes)} nodes) copied to clipboard.")

    def _chain_import_from_checker(self) -> None:
        """Import top-scored working proxies from checker results into the chain."""
        good = sorted(
            [r for r in self._results if r.tier in ("excellent", "good")],
            key=lambda r: -(r.score or 0),
        )
        if not good:
            self._status_label.configure(
                text="No good proxies to import — run Check All first."
            )
            return
        used = set(self._chain_nodes)
        added = 0
        for r in good:
            if len(self._chain_nodes) >= 8:
                break
            addr = r.proxy.address()
            if addr not in used:
                self._chain_nodes.append(addr)
                used.add(addr)
                added += 1
        self._update_chain_display()
        self._status_label.configure(text=f"Imported {added} proxies into chain.")

    def _update_chain_display(self) -> None:
        """Rebuild the scrollable vertical chain node list."""
        # Clear all widgets in the scroll area
        for w in list(self._chain_scroll.winfo_children()):
            try:
                w.destroy()
            except Exception:
                pass

        if not self._chain_nodes:
            self._chain_empty_lbl = ctk.CTkLabel(
                self._chain_scroll,
                text="No proxies in chain.  Add below or Import from Checker.",
                font=get_font(10), text_color=TOKENS["text_disabled"],
            )
            self._chain_empty_lbl.pack(pady=20)
            self._chain_status_label.configure(
                text="\u25cf No chain", text_color=TOKENS["text_disabled"]
            )
            return

        # Render one row per node with index, address, and remove button
        for i, node in enumerate(list(self._chain_nodes)):
            # Lookup protocol + latency from results for badge colouring
            proto = "?"
            lat_str = ""
            for r in self._results:
                if r.proxy.address() == node:
                    proto = r.proxy.protocol.upper()
                    if r.tcp_latency_ms:
                        lat_str = f"{r.tcp_latency_ms:.0f}ms"
                    break

            row = ctk.CTkFrame(
                self._chain_scroll,
                fg_color=TOKENS["bg_card"] if i % 2 == 0 else TOKENS["bg_input"],
                corner_radius=4,
            )
            row.pack(fill="x", padx=4, pady=2)

            # Hop number
            ctk.CTkLabel(
                row, text=f"#{i+1}",
                font=get_font(10, "bold"), text_color=TOKENS["accent"],
                width=30, anchor="center",
            ).pack(side="left", padx=(8, 4), pady=6)

            # Arrow between hops
            if i < len(self._chain_nodes) - 1:
                arrow_char = "\u2192"
            else:
                arrow_char = "\u2605"  # star = exit node
            ctk.CTkLabel(
                row, text=arrow_char,
                font=get_font(10), text_color=TOKENS["text_disabled"],
                width=16, anchor="center",
            ).pack(side="left")

            # Address
            ctk.CTkLabel(
                row, text=node,
                font=get_font(11, "bold"), text_color=TOKENS["text_primary"],
                anchor="w",
            ).pack(side="left", padx=6)

            # Protocol badge
            if proto != "?":
                proto_color = {
                    "SOCKS5": TOKENS["accent"],
                    "SOCKS4": TOKENS["info"],
                    "HTTP":   TOKENS["warning"],
                }.get(proto, TOKENS["text_secondary"])
                ctk.CTkLabel(
                    row, text=proto,
                    font=get_font(8, "bold"),
                    text_color="#000000",
                    fg_color=proto_color,
                    corner_radius=3,
                    width=50, anchor="center",
                ).pack(side="left", padx=4)

            # Latency
            if lat_str:
                ctk.CTkLabel(
                    row, text=lat_str,
                    font=get_font(10), text_color=TOKENS["text_secondary"],
                ).pack(side="left", padx=2)

            # Remove button
            idx = i  # capture for closure
            def _make_remove(index: int):
                def _remove():
                    if 0 <= index < len(self._chain_nodes):
                        del self._chain_nodes[index]
                    self._update_chain_display()
                return _remove

            ctk.CTkButton(
                row, text="\u2715",
                fg_color="transparent", hover_color=TOKENS["error"],
                text_color=TOKENS["text_disabled"],
                font=get_font(12), width=28, height=24,
                command=_make_remove(idx),
            ).pack(side="right", padx=6)

        # Update status badge
        n = len(self._chain_nodes)
        self._chain_status_label.configure(
            text=f"\u25cf {n} hop{'s' if n != 1 else ''}",
            text_color=TOKENS["success"],
        )

    # ── History helpers ────────────────────────────────────────────────────

    def _add_history_entry(
        self, kind: str, total: int, excellent: int, good: int, fair: int
    ) -> None:
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")

        # Always record the data — the History tab may not have been built
        # yet (tabs are lazy, only built on first visit), so this can't
        # depend on self._history_scroll existing.
        self._history_data.append((kind, ts, total, excellent, good, fair))

        if not hasattr(self, "_history_scroll"):
            return   # tab not built yet — _build_history_tab will replay _history_data

        self._render_history_row(kind, ts, total, excellent, good, fair)

    def _render_history_row(
        self, kind: str, ts: str, total: int, excellent: int, good: int, fair: int
    ) -> None:
        # Clear "no sessions" label on first entry
        for w in self._history_scroll.winfo_children():
            if getattr(w, "_is_empty_state", False):
                w.destroy()

        row = ctk.CTkFrame(
            self._history_scroll,
            fg_color=TOKENS["bg_input"], corner_radius=4,
        )
        row.pack(fill="x", pady=2)

        ctk.CTkLabel(
            row, text=ts, font=get_font(10),
            text_color=TOKENS["text_disabled"], width=70, anchor="w",
        ).pack(side="left", padx=8, pady=6)

        ctk.CTkLabel(
            row, text=kind, font=get_font(11, "bold"),
            text_color=TOKENS["text_primary"], width=60, anchor="w",
        ).pack(side="left")

        summary = f"{total:,} proxies"
        if kind == "Check":
            working = excellent + good + fair
            summary += f"  |  {working} working ({excellent} excellent, {good} good, {fair} fair)"

        ctk.CTkLabel(
            row, text=summary, font=get_font(11),
            text_color=TOKENS["text_secondary"], anchor="w",
        ).pack(side="left", padx=8)

    def on_show(self) -> None:
        pass

    def on_hide(self) -> None:
        pass
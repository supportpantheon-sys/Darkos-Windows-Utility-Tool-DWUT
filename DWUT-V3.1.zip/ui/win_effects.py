"""
ui/win_effects.py

Windows 11 rounds top-level window corners automatically via its own
window manager — but ONLY for normally-decorated windows. Both the splash
and the main window use overrideredirect(True) (no native titlebar), which
opts them out of that automatic rounding, leaving hard square corners.

This restores it explicitly via the DWM API (DwmSetWindowAttribute with
DWMWA_WINDOW_CORNER_PREFERENCE), which is the same mechanism Windows 11
itself uses. No-ops harmlessly on Windows 10 or older (the attribute is
simply rejected) and on any non-Windows platform.

Alt-Tab / Taskbar
-----------------
overrideredirect(True) windows are classified as WS_EX_TOOLWINDOW by Tk,
which explicitly hides them from Alt-Tab and the taskbar.

Fix:
  Phase 1 (immediate): Remove WS_EX_TOOLWINDOW, add WS_EX_APPWINDOW.
  Phase 2 (after 200ms): Re-apply + force a hide→show cycle so Windows
    re-evaluates the window's taskbar entry. Required because Windows
    caches the extended style at first map and won't update the taskbar
    entry until the window is briefly hidden and re-shown.

We also set the App User Model ID so the taskbar and Alt-Tab thumbnail
show "DWUT" rather than the generic "python" entry.
"""

from __future__ import annotations

import sys

_ghost_window = None   # module-level singleton
_taskbar_phase2_done = False  # run Phase 2 only once, not on every restore


def get_top_hwnd(root) -> int:
    """Return the HWND of the true top-level OS window for root."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        frame = root.wm_frame()
        if frame:
            return int(frame, 16)
        wid = root.winfo_id()
        parent = user32.GetParent(wid)
        return parent if parent else wid
    except Exception:
        return root.winfo_id()


def round_window_corners(root) -> None:
    """Apply Windows 11 rounded-corner style via DWM API to the top-level OS window."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        top_hwnd = get_top_hwnd(root)
        child_hwnd = root.winfo_id()
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        value = ctypes.c_int(DWMWCP_ROUND)
        for h in {top_hwnd, child_hwnd}:
            if h:
                ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    ctypes.c_void_p(h),
                    ctypes.c_int(DWMWA_WINDOW_CORNER_PREFERENCE),
                    ctypes.byref(value),
                    ctypes.sizeof(value),
                )
    except Exception:
        pass


def _apply_taskbar_style(hwnd) -> None:
    """
    Core style application: remove TOOLWINDOW, add APPWINDOW on the target HWND.
    """
    try:
        import ctypes
        user32 = ctypes.windll.user32

        GWL_EXSTYLE      = -20
        WS_EX_APPWINDOW  = 0x00040000
        WS_EX_TOOLWINDOW = 0x00000080

        style = user32.GetWindowLongW(ctypes.c_void_p(hwnd), GWL_EXSTYLE)
        style &= ~WS_EX_TOOLWINDOW   # remove the flag that hides from taskbar & Alt-Tab
        style |=  WS_EX_APPWINDOW    # add the flag that forces taskbar & Alt-Tab presence
        user32.SetWindowLongW(ctypes.c_void_p(hwnd), GWL_EXSTYLE, style)

        # Notify Windows Shell that the extended style changed
        SWP_NOMOVE       = 0x0002
        SWP_NOSIZE       = 0x0001
        SWP_NOZORDER     = 0x0004
        SWP_FRAMECHANGED = 0x0020
        user32.SetWindowPos(
            ctypes.c_void_p(hwnd), None, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
        )
    except Exception:
        pass


def enable_taskbar_and_alt_tab(root) -> None:
    """
    Ensure borderless / overrideredirect window shows up cleanly in both
    the Windows Taskbar and the Alt-Tab switcher.
    """
    global _taskbar_phase2_done
    if sys.platform != "win32":
        return
    try:
        import ctypes
        # Set App User Model ID — taskbar/Alt-Tab shows app name not "python"
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "Darko.DWUT.App"
            )
        except Exception:
            pass

        top_hwnd = get_top_hwnd(root)
        child_hwnd = root.winfo_id()

        # Apply to both the top-level OS window and Tk's container window
        _apply_taskbar_style(top_hwnd)
        _apply_taskbar_style(child_hwnd)

        if not _taskbar_phase2_done:
            _taskbar_phase2_done = True
            def _phase2():
                try:
                    import ctypes
                    user32 = ctypes.windll.user32
                    SW_HIDE = 0
                    SW_SHOW = 5
                    # Re-apply styles first, then do a hide→show so Windows
                    # Shell re-evaluates the taskbar/Alt-Tab entry.  Without
                    # the hide→show the style change is applied but Windows
                    # keeps the old (hidden) classification it cached at first
                    # map, so the window only appears in Alt-Tab while minimised.
                    _apply_taskbar_style(top_hwnd)
                    _apply_taskbar_style(child_hwnd)
                    user32.ShowWindow(ctypes.c_void_p(top_hwnd), SW_HIDE)
                    user32.ShowWindow(ctypes.c_void_p(top_hwnd), SW_SHOW)
                except Exception:
                    pass
            root.after(100, _phase2)
    except Exception:
        pass

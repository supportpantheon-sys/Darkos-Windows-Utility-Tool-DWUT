"""
ui/widgets/smooth_scroll.py

Tear-free, instantaneous scrolling for CustomTkinter.

Key architecture for tear-free, responsive scrolling on Windows:
1. Native integer-unit canvas scrolling via yview("scroll", units, "units").
   No floating-point fractional jumps, no subpixel rounding artifacts.
2. Synchronous update_idletasks() on the canvas during scroll events so the
   canvas move and child widget repaints occur atomically before Windows DWM
   composites the screen.
3. Strict single-event routing via _mouse_wheel_all. No double-firing from
   recursive child widget bindings or delayed after() timer bursts.
4. Visibility guards: hidden/unmapped scroll frames immediately ignore wheel
   events, eliminating background event processing.
"""
from __future__ import annotations

import inspect
import sys
import tkinter as tk
import customtkinter as ctk

_CTK_VALID: frozenset | None = None


def _valid_kwargs() -> frozenset:
    global _CTK_VALID
    if _CTK_VALID is None:
        try:
            sig = inspect.signature(ctk.CTkScrollableFrame.__init__)
            _CTK_VALID = frozenset(k for k in sig.parameters if k != "self")
        except Exception:
            _CTK_VALID = frozenset()
    return _CTK_VALID


class SmoothScrollFrame(ctk.CTkScrollableFrame):

    def __init__(self, parent, **kwargs) -> None:
        valid = _valid_kwargs()
        if valid:
            for k in list(kwargs):
                if k not in valid:
                    kwargs.pop(k)

        super().__init__(parent, **kwargs)

        self._cv: tk.Canvas = self._parent_canvas

        # Set 1-pixel scroll increment on Windows for exact pixel-level scrolling
        if sys.platform.startswith("win"):
            try:
                self._cv.configure(xscrollincrement=1, yscrollincrement=1)
            except Exception:
                pass

    def _mouse_wheel_all(self, event) -> str:
        """
        Global mouse wheel event interceptor.
        Filters events to this frame only if the target widget belongs here,
        then executes an atomic, tear-free unit scroll.
        """
        try:
            if not self._cv.winfo_exists() or not self._cv.winfo_ismapped():
                return "continue"
            if not self._check_if_valid_scroll(event.widget):
                return "continue"
        except Exception:
            return "continue"

        try:
            if sys.platform.startswith("win"):
                delta = getattr(event, "delta", 0)
                if not delta:
                    return "break"

                # 48px per standard 120-delta notch (smooth, natural, responsive)
                units = -int((delta / 120.0) * 48.0)
                if getattr(self, "_shift_pressed", False):
                    if self._cv.xview() != (0.0, 1.0):
                        self._cv.xview("scroll", units, "units")
                else:
                    if self._cv.yview() != (0.0, 1.0):
                        self._cv.yview("scroll", units, "units")

            elif sys.platform == "darwin":
                delta = getattr(event, "delta", 0)
                if getattr(self, "_shift_pressed", False):
                    if self._cv.xview() != (0.0, 1.0):
                        self._cv.xview("scroll", -int(delta * 2), "units")
                else:
                    if self._cv.yview() != (0.0, 1.0):
                        self._cv.yview("scroll", -int(delta * 2), "units")

            else:  # Linux / X11
                step = -3 if getattr(event, "num", None) == 4 else 3
                if getattr(self, "_shift_pressed", False):
                    if self._cv.xview() != (0.0, 1.0):
                        self._cv.xview_scroll(step, "units")
                else:
                    if self._cv.yview() != (0.0, 1.0):
                        self._cv.yview_scroll(step, "units")

            return "break"
        except Exception:
            return "continue"

    def bind_children(self) -> None:
        """Compatibility no-op: _check_if_valid_scroll automatically handles all descendant widgets."""
        pass

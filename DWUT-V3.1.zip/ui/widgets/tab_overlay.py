"""
ui/widgets/tab_overlay.py — Loading overlay mixin for in-page tab bars.

Root causes of the loading glitches this file used to have:
  1. root.update() was called to force-paint the overlay.  update() drains
     the ENTIRE event queue — including any pending after() callbacks and
     expose events for the NEW page content that hasn't finished building
     yet.  This caused partial new-page content to flash through the overlay
     for one frame.  Fix: never call root.update().  Use update_idletasks()
     (geometry only) or just place() the overlay and trust the normal Tk
     paint cycle to show it before the synchronous build runs.

  2. The overlay was placed and then the tab builder ran synchronously on
     the same thread.  Tk can't repaint while Python is running, so the
     overlay never visually appeared before the content was already built —
     users saw a raw flicker of half-built widgets.  Fix: for sync tabs,
     use after(0) to defer the build by one event-loop iteration, so the
     overlay gets one full paint cycle before any widget construction starts.

  3. After the builder ran, frame.pack() raised the new content frame above
     the overlay.  Fix: always re-lift the overlay after do_switch returns.
"""
from __future__ import annotations
import customtkinter as ctk
from ui.theme import TOKENS, get_font


class TabOverlayMixin:

    def _init_tab_overlay(self, content_parent: ctk.CTkFrame) -> None:
        self._tab_overlay_parent = content_parent
        self._tab_overlay = ctk.CTkFrame(
            content_parent, fg_color=TOKENS["bg_base"], corner_radius=0,
        )
        self._tab_loading_label = ctk.CTkLabel(
            self._tab_overlay,
            text="Loading",
            font=get_font(13),
            text_color=TOKENS["text_secondary"],
        )
        self._tab_loading_label.place(relx=0.5, rely=0.5, anchor="center")
        self._tab_overlay_hide_id: str | None = None
        self._tab_overlay_watchdog_id: str | None = None
        self._tab_loading_anim_id: str | None = None
        self._tab_dots: int = 0

    def _start_tab_anim(self) -> None:
        if getattr(self, "_tab_loading_anim_id", None) is not None:
            return
        self._tab_dots = 0
        self._tick_tab_anim()

    def _tick_tab_anim(self) -> None:
        try:
            if not hasattr(self, "_tab_overlay") or not self._tab_overlay.winfo_ismapped():
                self._tab_loading_anim_id = None
                return
            self._tab_dots = (self._tab_dots % 3) + 1
            dots = "." * self._tab_dots
            self._tab_loading_label.configure(text=f"Loading{dots}")
            self._tab_loading_anim_id = self._tab_overlay.after(300, self._tick_tab_anim)
        except Exception:
            self._tab_loading_anim_id = None

    def _stop_tab_anim(self) -> None:
        if getattr(self, "_tab_loading_anim_id", None):
            try:
                self._tab_overlay.after_cancel(self._tab_loading_anim_id)
            except Exception:
                pass
        self._tab_loading_anim_id = None

    def _show_tab_overlay(self) -> None:
        if not hasattr(self, "_tab_overlay"):
            return
        if getattr(self, "_tab_overlay_hide_id", None):
            try:
                self._tab_overlay.after_cancel(self._tab_overlay_hide_id)
            except Exception:
                pass
            self._tab_overlay_hide_id = None

        if getattr(self, "_tab_overlay_watchdog_id", None):
            try:
                self._tab_overlay.after_cancel(self._tab_overlay_watchdog_id)
            except Exception:
                pass
            self._tab_overlay_watchdog_id = None

        self._tab_overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._tab_overlay.lift()
        self._start_tab_anim()

        # Fail-safe watchdog: never stay stuck loading longer than 2.5s
        try:
            self._tab_overlay_watchdog_id = self._tab_overlay.after(2500, self._do_hide_overlay)
        except Exception:
            pass

        try:
            self._tab_overlay.update_idletasks()
        except Exception:
            pass

    def _hide_tab_overlay(self, min_ms_remaining: int = 0) -> None:
        if not hasattr(self, "_tab_overlay"):
            return
        delay = max(0, int(min_ms_remaining))
        try:
            self._tab_overlay_hide_id = self._tab_overlay.after(
                delay, self._do_hide_overlay
            )
        except Exception:
            self._do_hide_overlay()

    def _do_hide_overlay(self) -> None:
        self._tab_overlay_hide_id = None
        if getattr(self, "_tab_overlay_watchdog_id", None):
            try:
                self._tab_overlay.after_cancel(self._tab_overlay_watchdog_id)
            except Exception:
                pass
            self._tab_overlay_watchdog_id = None
        self._stop_tab_anim()
        try:
            self._tab_overlay.place_forget()
        except Exception:
            pass

    def _switch_tab_with_overlay(
        self,
        tab: str,
        do_switch,
        built_tabs: set,
        min_ms: int = 40,
        async_tab: str | None = None,
    ) -> None:
        first_build = tab not in built_tabs
        is_async    = (async_tab == tab and first_build)

        if not is_async:
            # Synchronous switch: build off-screen and swap directly with ZERO overlay flicker or tearing
            try:
                do_switch(tab)
            except Exception:
                pass
            return

        # Long async tab (Tweaks): show overlay while background batches construct
        if hasattr(self, "_tab_overlay"):
            self._show_tab_overlay()

        try:
            do_switch(tab)
        except Exception:
            if hasattr(self, "_tab_overlay"):
                self._hide_tab_overlay(0)

    def _initial_switch_tab(self, tab: str, do_switch) -> None:
        """
        Build the first tab SYNCHRONOUSLY during __init__.

        The window-level loading overlay is already covering the entire page
        during __init__, so the tab overlay is redundant here.  More critically,
        the normal _switch_tab path defers the build via after(1, ...) which
        makes __init__ return before the tab is built.  The window overlay
        then hides 120 ms later to reveal an empty page, followed by the tab
        overlay appearing — two visible flashes instead of one clean reveal.

        This method builds the tab directly with no overlay and no deferral,
        so the page is fully populated when __init__ returns and the window
        overlay hides to reveal a complete page instantly.
        """
        try:
            do_switch(tab)
        except Exception:
            pass

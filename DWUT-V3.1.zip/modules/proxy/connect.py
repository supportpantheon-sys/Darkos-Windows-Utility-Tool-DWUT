"""
modules/proxy/connect.py — Set / clear the Windows system HTTP/HTTPS proxy
via the registry (WinInet) so every app that honours system proxy settings
(Chrome, Edge, curl, requests, etc.) routes through it.

Uses the same registry path that Windows Settings → Network → Proxy writes to.
No admin rights required for the current-user key.
"""
from __future__ import annotations

import subprocess
import winreg
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)

_REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"


def _reg_set(name: str, value, val_type=winreg.REG_SZ) -> bool:
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH, 0,
                             winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, val_type, value)
        winreg.CloseKey(key)
        return True
    except Exception as exc:
        _log.warning("reg_set %s: %s", name, exc)
        return False


def _notify_wininet() -> None:
    """Tell WinInet to refresh its proxy settings from the registry."""
    try:
        import ctypes
        INTERNET_OPTION_SETTINGS_CHANGED = 39
        INTERNET_OPTION_REFRESH          = 37
        wininet = ctypes.windll.wininet
        wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
        wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
    except Exception as exc:
        _log.debug("WinInet refresh failed (non-fatal): %s", exc)


def enable_proxy(host: str, port: int, protocol: str = "http") -> tuple[bool, str]:
    """
    Set the Windows system proxy to host:port.

    Works for http and socks proxies. In Windows WinInet:
    - SOCKS proxies MUST be prefixed with 'socks=' (e.g. socks=1.2.3.4:1080)
      otherwise Windows attempts to send HTTP CONNECT commands to a SOCKS daemon,
      resulting in immediate connection aborts (WinError 10054).
    - HTTP proxies are configured for both http and https protocols:
      'http=host:port;https=host:port'
    """
    proto = (protocol or "http").lower()
    if proto in ("socks", "socks4", "socks5"):
        proxy_str = f"socks={host}:{port}"
    else:
        proxy_str = f"http={host}:{port};https={host}:{port}"

    ok1 = _reg_set("ProxyEnable", 1, winreg.REG_DWORD)
    ok2 = _reg_set("ProxyServer", proxy_str)
    # Bypass localhost / private ranges so local apps still work
    ok3 = _reg_set("ProxyOverride", "localhost;127.*;10.*;172.16.*;192.168.*;<local>")

    _notify_wininet()

    if ok1 and ok2:
        _log.info("System proxy enabled: %s (%s)", proxy_str, proto)
        return True, f"System proxy set to {proxy_str}"
    return False, "Failed to write proxy settings to registry"


def disable_proxy() -> tuple[bool, str]:
    """Clear the Windows system proxy."""
    ok = _reg_set("ProxyEnable", 0, winreg.REG_DWORD)
    _notify_wininet()
    if ok:
        _log.info("System proxy disabled")
        return True, "System proxy disabled"
    return False, "Failed to disable proxy in registry"


def get_active_proxy() -> Optional[str]:
    """Return the current system proxy string, or None if disabled."""
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH, 0,
                             winreg.KEY_READ)
        enabled, _ = winreg.QueryValueEx(key, "ProxyEnable")
        if not enabled:
            winreg.CloseKey(key)
            return None
        server, _ = winreg.QueryValueEx(key, "ProxyServer")
        winreg.CloseKey(key)
        return server or None
    except Exception:
        return None

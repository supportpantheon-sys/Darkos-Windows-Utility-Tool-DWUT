"""
modules/cleaner/downloader.py

Download third-party scanner tools with:
  - Progress streaming
  - SHA-256 verification (where hashes are known)
  - Re-use cached copy if already downloaded this session
"""
from __future__ import annotations

import hashlib
import os
import urllib.request
from pathlib import Path
from typing import Callable

# Tool download definitions: id -> (url, expected_sha256_or_None, filename)
TOOL_URLS: dict[str, tuple[str, str | None, str]] = {
    "rkill":        ("https://download.bleepingcomputer.com/grinler/rkill64.exe",
                     None, "rkill64.exe"),
    "malwarebytes": ("https://downloads.malwarebytes.com/file/mb-windows",
                     None, "MBSetup.exe"),
    "adwcleaner":   ("https://adwcleaner.malwarebytes.com/adwcleaner/release/latest/windows/adwcleaner.exe",
                     None, "adwcleaner.exe"),
    "tdsskiller":   ("https://media.kaspersky.com/utilities/VirusUtilities/EN/tdsskiller.exe",
                     None, "tdsskiller.exe"),
    "hitmanpro":    ("https://dl.surfright.nl/HitmanPro64.exe",
                     None, "HitmanPro64.exe"),
    "roguekiller":  ("https://www.adlice.com/downloads/roguekillerx64.exe",
                     None, "RogueKillerX64.exe"),
    "msrt":         ("https://download.microsoft.com/download/safety/msrt/windows/en-us/msrt.exe",
                     None, "msrt.exe"),
    "kaspersky_vrt":("https://media.kaspersky.com/utilities/VirusUtilities/EN/kvrt.exe",
                     None, "kvrt.exe"),
    "sophos_vrt":   ("https://downloads.sophos.com/downloads/util/sophosvirustool/sophos_vrt.exe",
                     None, "sophos_vrt.exe"),
    "mcafee":       ("https://downloadcenter.mcafee.com/products/tools/mcpr/Stinger32.exe",
                     None, "Stinger.exe"),
    "eset":         ("https://download.eset.com/com/eset/tools/online_scanner/latest/esetonlinescanner.exe",
                     None, "esetonlinescanner.exe"),
    "npe":          ("https://norton-power-eraser.softonic.com/download",
                     None, "NPE.exe"),
    "clamwin":      ("https://sourceforge.net/projects/clamwin/files/latest/download",
                     None, "ClamWin-latest.exe"),
    "mbar":         ("https://downloads.malwarebytes.com/file/mbar",
                     None, "mbar.exe"),
    "gmer":         ("https://www.gmer.net/gmer.zip",
                     None, "gmer.zip"),
    "aswmbr":       ("https://download.avast.com/antivirus/aswmbr.exe",
                     None, "aswmbr.exe"),
    "frst":         ("https://www.bleepingcomputer.com/download/farbar-recovery-scan-tool/dl/81/",
                     None, "FRST64.exe"),
    "otl":          ("https://oldtimer.geekstogo.com/OTL.exe",
                     None, "OTL.exe"),
    "spybot":       ("https://www.safer-networking.org/dl/?product=spybotfree&language=en",
                     None, "spybotsd-setup.exe"),
}


def get_tool_dir() -> Path:
    """Return (creating if needed) the tool download directory."""
    from app.config import config  # type: ignore
    d = Path(os.environ.get("TEMP", "C:\\Temp")) / "DWUT_Tools"
    d.mkdir(parents=True, exist_ok=True)
    return d


def is_cached(tool_id: str) -> bool:
    if tool_id not in TOOL_URLS:
        return False
    _, _, fname = TOOL_URLS[tool_id]
    return (get_tool_dir() / fname).exists()


def download(
    tool_id: str,
    on_progress: Callable[[int, int], None] | None = None,
    on_log:      Callable[[str], None]      | None = None,
) -> Path | None:
    """
    Download a tool by ID.  Returns the local Path on success, None on failure.

    on_progress(bytes_downloaded, total_bytes) — may be called with total=-1
    on_log(message) — informational messages
    """
    if tool_id not in TOOL_URLS:
        if on_log:
            on_log(f"[downloader] unknown tool: {tool_id}")
        return None

    url, expected_sha256, fname = TOOL_URLS[tool_id]
    dest = get_tool_dir() / fname

    if dest.exists():
        if on_log:
            on_log(f"[downloader] cached: {fname}")
        return dest

    if on_log:
        on_log(f"[downloader] downloading {fname} ...")

    try:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0 Safari/537.36"
            )
        }
        req  = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=60) as resp:
            total = int(resp.headers.get("Content-Length", -1))
            done  = 0
            sha   = hashlib.sha256()
            with open(dest, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    sha.update(chunk)
                    done += len(chunk)
                    if on_progress:
                        try:
                            on_progress(done, total)
                        except Exception:
                            pass

        # Verify SHA-256 if we have an expected hash
        if expected_sha256:
            actual = sha.hexdigest()
            if actual.lower() != expected_sha256.lower():
                dest.unlink(missing_ok=True)
                if on_log:
                    on_log(f"[downloader] SHA-256 mismatch for {fname}: got {actual}")
                return None

        if on_log:
            on_log(f"[downloader] downloaded: {fname} ({done:,} bytes)")
        return dest

    except Exception as exc:
        dest.unlink(missing_ok=True)
        if on_log:
            on_log(f"[downloader] failed to download {fname}: {exc}")
        return None

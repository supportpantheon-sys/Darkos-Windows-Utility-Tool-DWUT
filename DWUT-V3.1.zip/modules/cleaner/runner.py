"""
modules/cleaner/runner.py

External process runner that:
  - Runs a command as administrator (via ShellExecute runas on Windows)
  - Streams stdout/stderr line-by-line to a callback
  - Enforces a timeout
  - Returns (exit_code, output_lines)
"""
from __future__ import annotations

import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable


def run(
    cmd: list[str],
    *,
    cwd: Path | str | None = None,
    timeout: int = 600,
    on_line: Callable[[str], None] | None = None,
    elevated: bool = False,
    shell: bool = False,
) -> tuple[int, list[str]]:
    """
    Run a command and stream its output.

    Parameters
    ----------
    cmd       : command + arguments
    cwd       : working directory
    timeout   : seconds before we give up (default 10 min)
    on_line   : called for each decoded output line (stdout + stderr merged)
    elevated  : if True, use ShellExecute runas (Windows only, creates a new
                UAC-elevated process — cannot capture output)
    shell     : pass shell=True to subprocess

    Returns
    -------
    (exit_code, output_lines)
    On elevated=True the output_lines list will always be empty.
    """
    lines: list[str] = []

    if elevated and sys.platform == "win32":
        import ctypes
        exe  = cmd[0]
        args = " ".join(f'"{a}"' if " " in str(a) else str(a) for a in cmd[1:])
        ret  = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", str(exe), args, str(cwd) if cwd else None, 1
        )
        # ShellExecuteW returns > 32 on success
        return (0 if ret > 32 else 1), []

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=cwd,
            shell=shell,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        def _reader():
            assert proc.stdout
            for raw_line in proc.stdout:
                line = raw_line.rstrip("\n\r")
                lines.append(line)
                if on_line:
                    try:
                        on_line(line)
                    except Exception:
                        pass

        reader_thread = threading.Thread(target=_reader, daemon=True)
        reader_thread.start()

        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            reader_thread.join(timeout=2)
            return -1, lines

        reader_thread.join(timeout=5)
        return proc.returncode, lines

    except FileNotFoundError:
        msg = f"[runner] command not found: {cmd[0]}"
        lines.append(msg)
        if on_line:
            on_line(msg)
        return 127, lines
    except Exception as exc:
        msg = f"[runner] error: {exc}"
        lines.append(msg)
        if on_line:
            on_line(msg)
        return 1, lines


def run_ps(
    script: str,
    *,
    timeout: int = 300,
    on_line: Callable[[str], None] | None = None,
) -> tuple[int, list[str]]:
    """Run a PowerShell script block and stream output."""
    return run(
        ["powershell", "-NoProfile", "-NonInteractive",
         "-ExecutionPolicy", "Bypass", "-Command", script],
        timeout=timeout,
        on_line=on_line,
    )

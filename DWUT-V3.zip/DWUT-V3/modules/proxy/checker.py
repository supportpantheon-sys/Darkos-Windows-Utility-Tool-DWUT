"""
modules/proxy/checker.py

Real proxy validation pipeline — now with HTTPS CONNECT testing.

WHY THE OLD VERSION SHOWED "WORKING" PROXIES THAT COULDN'T BROWSE
──────────────────────────────────────────────────────────────────
The old checker tested:
  1. TCP connect to the proxy port
  2. HTTP GET to httpbin.org/get  ← plain HTTP only
  3. HTTP GET to api.ipify.org    ← plain HTTP only

Browsers use HTTPS CONNECT for every https:// URL (virtually every
modern site).  HTTPS CONNECT is a completely different request type:

  CONNECT cloudflare.com:443 HTTP/1.0
  (then a TLS handshake through the tunnel)

Most free HTTP proxies do NOT support CONNECT.  They pass plain HTTP
fine (which is why ipify worked) but silently drop or reject CONNECT,
so browsers hang then fail on every real page.

THE FIX
───────
Stage 3 now does a real HTTPS CONNECT tunnel through the proxy and
then a TLS handshake.  If that fails → proxy is rejected.
Stage 4 does a full HTTPS GET to cloudflare.com through the proxy
with real browser headers.  If this succeeds you can browse.

SOCKS proxies (4/5) natively tunnel all traffic so requests handles
HTTPS automatically — the CONNECT test uses the same code path.

Pipeline:
  PARSE → TCP CONNECT → PROTOCOL + HTTP → HTTPS CONNECT/TUNNEL →
  BROWSE TEST → EXIT IP → GEOLOCATION → ANONYMITY →
  POOL ANALYSIS → SCORING → CLASSIFY
"""

from __future__ import annotations

import ipaddress
import socket
import ssl
import struct
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from typing import Optional

import requests
from requests.adapters import HTTPAdapter

from core.events import Events, bus
from core.logger import get_logger
from modules.proxy.sources import ProxyRecord

_log = get_logger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Per-thread requests.Session
# ─────────────────────────────────────────────────────────────────────────────

_thread_local = threading.local()


def _session() -> requests.Session:
    s = getattr(_thread_local, "session", None)
    if s is None:
        s = requests.Session()
        s.trust_env = False  # NEVER route checker through system/environment proxy!
        adapter = HTTPAdapter(pool_connections=4, pool_maxsize=4, max_retries=0)
        s.mount("http://", adapter)
        s.mount("https://", adapter)
        _thread_local.session = s
    return s


# Browser-like headers for the browse test — many proxies block non-browser UAs
_BROWSE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "close",
}

# ─────────────────────────────────────────────────────────────────────────────
# Known datacenter ASNs
# ─────────────────────────────────────────────────────────────────────────────

_DATACENTER_ASNS = {
    "AS14618", "AS16509",  # Amazon AWS
    "AS15169",             # Google Cloud
    "AS8075",              # Microsoft Azure
    "AS20473",             # Vultr
    "AS14061",             # DigitalOcean
    "AS16276",             # OVH
    "AS24940",             # Hetzner
    "AS63949",             # Linode / Akamai
    "AS9009",              # M247
    "AS60781",             # LeaseWeb
    "AS197540",            # Netcup
}

# ─────────────────────────────────────────────────────────────────────────────
# Anonymity-revealing headers
# ─────────────────────────────────────────────────────────────────────────────

_REVEALING_HEADERS = {
    "x-forwarded-for",
    "x-real-ip",
    "via",
    "proxy-connection",
    "x-proxy-id",
    "forwarded",
}

# ─────────────────────────────────────────────────────────────────────────────
# Result type
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CheckResult:
    proxy: ProxyRecord

    # Stage results
    tcp_ok:        bool  = False
    tcp_latency_ms: Optional[float] = None

    protocol_ok:   bool  = False
    https_ok:      bool  = False   # proxy can do HTTPS CONNECT/tunnel
    browse_ok:     bool  = False   # full real-website GET succeeded with valid SSL
    youtube_ok:    bool  = False   # verified able to load YouTube/Google 204

    exit_ip:            Optional[str]  = None
    is_transparent:     bool           = False
    is_pooled_candidate: bool          = False

    country:      Optional[str] = None
    country_code: Optional[str] = None
    isp:          Optional[str] = None
    asn:          Optional[str] = None
    timezone:     Optional[str] = None

    anonymity:         Optional[str]  = None
    revealing_headers: list[str]      = field(default_factory=list)

    pool_flags: list[str] = field(default_factory=list)

    score: int  = 0
    tier:  str  = "dead"
    reject_reason: Optional[str] = None

    def update_proxy(self) -> ProxyRecord:
        from dataclasses import replace
        return replace(
            self.proxy,
            status=self.tier,
            latency_ms=self.tcp_latency_ms,
            country=self.country,
            country_code=self.country_code,
            isp=self.isp,
            asn=self.asn,
            anonymity=self.anonymity,
            exit_ip=self.exit_ip,
            is_pooled=bool(self.pool_flags),
            score=self.score,
            youtube_ok=self.youtube_ok,
        )


# ─────────────────────────────────────────────────────────────────────────────
# Stage helpers
# ─────────────────────────────────────────────────────────────────────────────

def _my_real_ip(timeout: int = 5) -> Optional[str]:
    for url in ("https://api.ipify.org", "https://api.my-ip.io/ip"):
        try:
            r = _session().get(url, timeout=timeout)
            ip = r.text.strip()
            ipaddress.ip_address(ip)
            return ip
        except Exception:
            continue
    return None


_real_ip_cache: Optional[str] = None


def get_my_ip() -> Optional[str]:
    global _real_ip_cache
    if _real_ip_cache is None:
        _real_ip_cache = _my_real_ip()
    return _real_ip_cache


def _stage_tcp(proxy: ProxyRecord, timeout: float = 3.0) -> tuple[bool, Optional[float]]:
    """Raw TCP connect — fastest fail-fast stage."""
    t0 = time.monotonic()
    try:
        with socket.create_connection((proxy.ip, proxy.port), timeout=timeout):
            pass
        latency = (time.monotonic() - t0) * 1000
        return True, latency
    except Exception:
        return False, None


def _stage_protocol_http(proxy: ProxyRecord, timeout: int = 5) -> bool:
    """
    Test plain HTTP through the proxy.
    Uses a lightweight request to avoid heavy httpbin.org dependency.
    cloudflare.com/cdn-cgi/trace returns a tiny text response fast.
    """
    proxies = proxy.requests_proxies()
    try:
        r = _session().get(
            "http://cloudflare.com/cdn-cgi/trace",
            proxies=proxies,
            timeout=timeout,
            headers=_BROWSE_HEADERS,
            allow_redirects=True,
        )
        # Any 2xx or 3xx means the proxy forwarded our request
        return r.status_code < 400
    except Exception:
        pass

    # Fallback: try a plain HTTP HEAD
    try:
        r2 = _session().head(
            "http://example.com",
            proxies=proxies,
            timeout=timeout,
            allow_redirects=True,
        )
        return r2.status_code < 500
    except Exception:
        return False


def _stage_https_connect(proxy: ProxyRecord, timeout: int = 6) -> bool:
    """
    Test HTTPS CONNECT tunneling — the exact mechanism browsers use for every
    https:// URL.

    For HTTP proxies: sends a raw CONNECT cloudflare.com:443 through the
    proxy socket, then wraps it in TLS and does a minimal GET with certificate verification.

    For SOCKS proxies: uses requests with remote DNS (socks5h/socks4a)
    which tunnels all traffic natively.
    """
    if proxy.protocol in ("socks4", "socks5"):
        try:
            r = _session().get(
                "https://cloudflare.com/cdn-cgi/trace",
                proxies=proxy.requests_proxies(),
                timeout=timeout,
                headers=_BROWSE_HEADERS,
                verify=True,
            )
            return r.status_code == 200 and "ip=" in r.text
        except Exception:
            try:
                r2 = _session().get(
                    "https://www.google.com/generate_204",
                    proxies=proxy.requests_proxies(),
                    timeout=timeout,
                    headers=_BROWSE_HEADERS,
                    verify=True,
                )
                return r2.status_code == 204
            except Exception:
                return False

    # HTTP proxy — test raw CONNECT tunnel
    target_host = "cloudflare.com"
    target_port = 443
    try:
        sock = socket.create_connection((proxy.ip, proxy.port), timeout=timeout)
        try:
            connect_req = (
                f"CONNECT {target_host}:{target_port} HTTP/1.0\r\n"
                f"Host: {target_host}:{target_port}\r\n"
                f"Proxy-Connection: Keep-Alive\r\n"
                "\r\n"
            ).encode()
            sock.sendall(connect_req)

            # Read response — must be 200 Connection established
            response = b""
            while b"\r\n\r\n" not in response:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                response += chunk
                if len(response) > 8192:
                    break

            first_line = response.split(b"\r\n")[0].decode(errors="replace")
            if "200" not in first_line:
                return False

            # Wrap in TLS and verify valid certificate
            ctx = ssl.create_default_context()
            tls = ctx.wrap_socket(sock, server_hostname=target_host)
            tls.settimeout(timeout)

            http_req = (
                f"HEAD / HTTP/1.0\r\n"
                f"Host: {target_host}\r\n"
                "User-Agent: Mozilla/5.0\r\n"
                "Connection: close\r\n"
                "\r\n"
            ).encode()
            tls.sendall(http_req)

            resp = b""
            while True:
                try:
                    chunk = tls.recv(4096)
                    if not chunk:
                        break
                    resp += chunk
                    if b"\r\n" in resp:
                        break
                except Exception:
                    break

            first_resp = resp.split(b"\r\n")[0].decode(errors="replace")
            return "HTTP/" in first_resp and "407" not in first_resp
        finally:
            try:
                sock.close()
            except Exception:
                pass
    except Exception:
        return False


def _stage_browse_test(proxy: ProxyRecord, timeout: int = 8) -> tuple[bool, bool]:
    """
    Full HTTPS GET through the proxy to real websites with SSL verification.
    Returns (browse_ok, youtube_ok).

    Both browse_ok and youtube_ok guarantee:
    - Real HTTPS tunnel established
    - Valid TLS certificate (Chrome/Edge will not show SSL cert warnings)
    - Status code 200 or 204 (no 403 Forbidden, 407 Auth Required, 502/503 errors)
    - YouTube / Google streaming compatibility verified
    """
    proxies = proxy.requests_proxies()
    sess = _session()

    browse_ok = False
    youtube_ok = False

    # 1. Primary browsing test: Cloudflare trace
    try:
        r = sess.get(
            "https://cloudflare.com/cdn-cgi/trace",
            proxies=proxies,
            timeout=timeout,
            headers=_BROWSE_HEADERS,
            allow_redirects=True,
            verify=True,
        )
        if r.status_code == 200 and "ip=" in r.text and "ts=" in r.text:
            browse_ok = True
    except Exception:
        pass

    # Fallback to Google generate_204
    if not browse_ok:
        try:
            r = sess.get(
                "https://www.google.com/generate_204",
                proxies=proxies,
                timeout=timeout,
                headers=_BROWSE_HEADERS,
                allow_redirects=False,
                verify=True,
            )
            if r.status_code == 204:
                browse_ok = True
        except Exception:
            pass

    # 2. YouTube specific validation
    try:
        r_yt = sess.get(
            "https://www.youtube.com/generate_204",
            proxies=proxies,
            timeout=timeout,
            headers=_BROWSE_HEADERS,
            allow_redirects=False,
            verify=True,
        )
        if r_yt.status_code == 204:
            youtube_ok = True
            browse_ok = True  # If YouTube works, general browsing definitely works
    except Exception:
        pass

    return browse_ok, youtube_ok


def _stage_exit_ip(proxy: ProxyRecord, timeout: int = 6) -> Optional[str]:
    """Route through proxy to determine exit IP."""
    proxies = proxy.requests_proxies()
    for url in ("https://api.ipify.org", "https://api64.ipify.org", "https://api.my-ip.io/ip"):
        try:
            r = _session().get(url, proxies=proxies, timeout=timeout)
            ip = r.text.strip()
            ipaddress.ip_address(ip)
            return ip
        except Exception:
            continue
    # Fallback: try plain HTTP
    try:
        r2 = _session().get("http://api.ipify.org", proxies=proxies, timeout=timeout)
        ip = r2.text.strip()
        ipaddress.ip_address(ip)
        return ip
    except Exception:
        return None


# ── Geo cache ─────────────────────────────────────────────────────────────────
_geo_cache: dict[str, dict] = {}
_geo_lock  = threading.Lock()


def _geo_cached(ip: str) -> dict | None:
    with _geo_lock:
        return _geo_cache.get(ip)


def _geo_store(ip: str, data: dict) -> None:
    with _geo_lock:
        _geo_cache[ip] = data


def prefetch_geo_batch(ips: list[str]) -> None:
    """
    Pre-fill geo cache using ip-api.com's batch endpoint (100 IPs per request).
    Call before starting a check run so worker threads never hit the rate limit.
    """
    if not ips:
        return
    with _geo_lock:
        uncached = [ip for ip in ips if ip not in _geo_cache]
    if not uncached:
        return

    BATCH = 100
    fields = "query,country,countryCode,isp,org,as,timezone,status"
    for i in range(0, len(uncached), BATCH):
        chunk = uncached[i: i + BATCH]
        try:
            payload = [{"query": ip, "fields": fields} for ip in chunk]
            r = _session().post("http://ip-api.com/batch", json=payload, timeout=8)
            if r.status_code == 200:
                for entry in r.json():
                    ip_key = entry.get("query", "")
                    if ip_key and entry.get("status") == "success":
                        _geo_store(ip_key, entry)
        except Exception:
            pass


def _stage_geolocation(ip: str, timeout: int = 4) -> dict:
    cached = _geo_cached(ip)
    if cached:
        return cached

    for attempt in range(2):
        try:
            r = _session().get(
                f"http://ip-api.com/json/{ip}"
                f"?fields=country,countryCode,isp,org,as,timezone,status",
                timeout=timeout,
            )
            if r.status_code == 429:
                import time as _t; _t.sleep(1.2)
                continue
            data = r.json()
            if data.get("status") == "success":
                _geo_store(ip, data)
                return data
        except Exception:
            break

    # Fallback to ipinfo.io
    try:
        r2 = _session().get(f"https://ipinfo.io/{ip}/json", timeout=timeout)
        d = r2.json()
        if d.get("country"):
            fallback = {
                "countryCode": d.get("country", ""),
                "country":     d.get("country", ""),
                "isp":         d.get("org", ""),
                "as":          d.get("org", "").split(" ")[0] if d.get("org") else "",
                "timezone":    d.get("timezone", ""),
            }
            _geo_store(ip, fallback)
            return fallback
    except Exception:
        pass

    _geo_store(ip, {})
    return {}


def _stage_anonymity(proxy: ProxyRecord, timeout: int = 5) -> tuple[str, list[str]]:
    """Check which identifying headers the proxy injects."""
    proxies = proxy.requests_proxies()
    found: list[str] = []
    try:
        r = _session().get(
            "http://httpbin.org/headers",
            proxies=proxies,
            timeout=timeout,
        )
        headers_sent = {k.lower(): v for k, v in r.json().get("headers", {}).items()}
        for h in _REVEALING_HEADERS:
            if h in headers_sent:
                found.append(h)
    except Exception:
        return "unknown", []

    if "x-forwarded-for" in found:
        return "transparent", found
    if found:
        return "anonymous", found
    return "elite", found


def _stage_pool_analysis(
    proxy: ProxyRecord,
    exit_ip: Optional[str],
    geo: dict,
    timeout: int = 4,
) -> list[str]:
    flags: list[str] = []

    if exit_ip and exit_ip != proxy.ip:
        flags.append(f"exit IP ({exit_ip}) differs from proxy IP ({proxy.ip})")

    asn = geo.get("as", "")
    if any(dc in asn for dc in _DATACENTER_ASNS):
        flags.append(f"datacenter ASN detected ({asn})")

    org = geo.get("org", "").lower()
    for kw in ["hosting", "datacenter", "cloud", "server", "vps", "colocation", "colo"]:
        if kw in org:
            flags.append(f"datacenter org keyword: '{kw}'")
            break

    # Multi-request exit-IP check
    if exit_ip is None:
        return flags

    proxies = proxy.requests_proxies()
    exit_ips: set[str] = {exit_ip}
    for _ in range(2):
        try:
            r = _session().get("https://api.ipify.org", proxies=proxies, timeout=timeout)
            candidate = r.text.strip()
            ipaddress.ip_address(candidate)
            exit_ips.add(candidate)
        except Exception:
            pass

    if len(exit_ips) > 1:
        flags.append(f"multiple exit IPs observed ({', '.join(exit_ips)}) — confirmed pool")

    return flags


def _score(result: CheckResult) -> int:
    """
    0–100 score.

    HTTPS/browse/streaming capability is the dominant factor.
    Latency thresholds are strict:

      YouTube streaming pass: +45  (verified can watch YouTube/Google)
      Browse test pass:       +35  (can load HTTPS websites)
      HTTPS CONNECT pass:     +10  (tunnel works)
      Latency bonus:          <50ms=20, <75ms=12, <100ms=6
      Anonymity:              elite=10, anonymous=6, transparent=0, unknown=2
      Protocol:               socks5=10, socks4=6, http=3
      Pool-free:              +5
      Geo data available:     +5
    """
    s = 0

    # Core browsing capability — biggest weight
    if result.youtube_ok:
        s += 45
    elif result.browse_ok:
        s += 35
    elif result.https_ok:
        s += 10

    # Latency — strict thresholds
    lat = result.tcp_latency_ms or 9999
    if lat <= 50:
        s += 20
    elif lat <= 75:
        s += 12
    elif lat <= 100:
        s += 6
    # >100ms gets zero latency bonus (and is rejected in check_one)

    # Anonymity
    anon = result.anonymity or "unknown"
    if anon == "elite":
        s += 10
    elif anon == "anonymous":
        s += 6
    elif anon == "unknown":
        s += 2

    # Protocol
    proto = result.proxy.protocol
    if proto == "socks5":
        s += 10
    elif proto == "socks4":
        s += 6
    else:
        s += 3

    # Pool flags
    if not result.pool_flags:
        s += 5

    # Geo data
    if result.country:
        s += 5

    return min(100, s)


def _tier(score: int, result: CheckResult) -> str:
    # Transparent proxies leak your IP — always reject
    if result.is_transparent:
        return "rejected"

    # CANNOT BROWSE HTTPS WEBSITES -> HARD REJECT!
    # Browsing modern websites requires an actual working HTTPS tunnel
    if not result.browse_ok:
        return "rejected"

    # Excellent requires YouTube verified + high score
    if result.youtube_ok and score >= 65:
        return "excellent"
    if score >= 50:
        return "good"
    if score >= 30:
        return "fair"
    return "rejected"


# ─────────────────────────────────────────────────────────────────────────────
# Full single-proxy check
# ─────────────────────────────────────────────────────────────────────────────

def check_one(
    proxy: ProxyRecord,
    my_ip: Optional[str] = None,
    stop_event: Optional[threading.Event] = None,
) -> CheckResult:
    """Run all stages on a single proxy."""
    result = CheckResult(proxy=proxy)

    if stop_event is not None and stop_event.is_set():
        result.tier = "dead"
        return result

    # Stage 1 — TCP connect
    ok, latency = _stage_tcp(proxy)
    result.tcp_ok = ok
    result.tcp_latency_ms = latency
    if not ok:
        result.tier = "dead"
        return result

    if stop_event is not None and stop_event.is_set():
        result.tier = "dead"
        return result

    # Stage 2 — Plain HTTP test (fast sanity check)
    result.protocol_ok = _stage_protocol_http(proxy)
    if not result.protocol_ok:
        # Give it one more chance with the HTTPS test directly
        # (some proxies only support HTTPS CONNECT, not plain HTTP)
        result.https_ok = _stage_https_connect(proxy)
        if not result.https_ok:
            result.tier = "dead"
            result.reject_reason = "neither HTTP nor HTTPS forwarding works"
            return result
        # Full browse test (real check, no faking!)
        result.browse_ok, result.youtube_ok = _stage_browse_test(proxy)
        if not result.browse_ok:
            result.tier = "rejected"
            result.reject_reason = "failed HTTPS browse verification"
            return result
    else:
        if stop_event is not None and stop_event.is_set():
            result.tier = "dead"
            return result

        # Stage 3 — HTTPS CONNECT / tunnel test (the critical browsing test)
        result.https_ok = _stage_https_connect(proxy)

        # Stage 4 — Full browse test (only if HTTPS connect worked, saves time)
        if result.https_ok:
            result.browse_ok, result.youtube_ok = _stage_browse_test(proxy)
        else:
            result.tier = "rejected"
            result.reject_reason = "HTTPS CONNECT failed"
            return result

        if not result.browse_ok:
            result.tier = "rejected"
            result.reject_reason = "failed HTTPS browse verification"
            return result

    if stop_event is not None and stop_event.is_set():
        result.tier = "dead"
        return result

    # Stage 5 — Exit IP (only for proxies that passed HTTP at least)
    result.exit_ip = _stage_exit_ip(proxy)

    # Stage 6 — Transparent proxy check
    if result.exit_ip and my_ip and result.exit_ip == my_ip:
        result.is_transparent = True
        result.tier = "rejected"
        result.reject_reason = "transparent — leaks real IP"
        result.score = 0
        return result

    if result.exit_ip and result.exit_ip != proxy.ip:
        result.is_pooled_candidate = True

    # Stage 7 — Geolocation
    geo_ip = result.exit_ip or proxy.ip
    if geo_ip:
        geo = _stage_geolocation(geo_ip)
        result.country      = geo.get("country")
        result.country_code = geo.get("countryCode")
        result.isp          = geo.get("isp") or geo.get("org")
        result.asn          = geo.get("as")
        result.timezone     = geo.get("timezone")

    # Stage 8 — Anonymity (only if HTTP works — needs a response with headers)
    if result.protocol_ok:
        result.anonymity, result.revealing_headers = _stage_anonymity(proxy)
    else:
        result.anonymity = "unknown"

    # Stage 9 — Pool analysis
    geo_data = {"as": result.asn or "", "org": result.isp or ""}
    result.pool_flags = _stage_pool_analysis(proxy, result.exit_ip, geo_data)

    # Stage 10 — Score + Classify
    result.score = _score(result)
    result.tier  = _tier(result.score, result)

    return result


# ─────────────────────────────────────────────────────────────────────────────
# Batch checker
# ─────────────────────────────────────────────────────────────────────────────

def check_all(
    proxies: list[ProxyRecord],
    max_workers: int = 50,
    region_filter: Optional[str] = None,
    protocol_filter: Optional[str] = None,
    min_anonymity: Optional[str] = None,
    max_latency_ms: Optional[float] = None,
    stop_event: Optional[threading.Event] = None,
) -> list[CheckResult]:
    """
    Check a list of proxies concurrently.

    Only proxies that pass the HTTPS CONNECT test are surfaced as working.
    Filtered/failed proxies are counted for progress but excluded from results.

    Publishes:
      PROXY_CHECK_PROGRESS — periodically
      PROXY_RESULT_BATCH   — every ~200ms with newly-completed results
      PROXY_CHECK_DONE     — with the final results list
    """
    _ANON_RANK = {"transparent": 0, "anonymous": 1, "elite": 2}

    def _passes_post_filters(result: CheckResult) -> bool:
        if region_filter and region_filter.lower() != "any":
            if not result.country or result.country.lower() != region_filter.lower():
                return False
        if min_anonymity and min_anonymity.lower() != "any":
            want = _ANON_RANK.get(min_anonymity.lower())
            have = _ANON_RANK.get((result.anonymity or "").lower(), -1)
            if want is not None and have < want:
                return False
        if max_latency_ms is not None:
            if result.tcp_latency_ms is None or result.tcp_latency_ms > max_latency_ms:
                return False
        return True

    # Protocol pre-filter (saves network round-trips)
    if protocol_filter and protocol_filter.lower() != "any":
        proxies = [p for p in proxies if p.protocol.lower() == protocol_filter.lower()]

    my_ip  = get_my_ip()
    total  = len(proxies)
    completed = 0
    results: list[CheckResult] = []
    stopped = False

    _log.info("Checking %d proxies (%d workers) — HTTPS CONNECT test enabled", total, max_workers)

    t_start = time.monotonic()
    PROGRESS_EVERY = 10

    pool = ThreadPoolExecutor(max_workers=max_workers)
    try:
        futures = {pool.submit(check_one, p, my_ip, stop_event): p for p in proxies}
        pending = set(futures)

        while pending:
            if stop_event is not None and stop_event.is_set():
                stopped = True
                pool.shutdown(wait=False, cancel_futures=True)
                break

            done, pending = wait(pending, timeout=0.2, return_when=FIRST_COMPLETED)
            if not done:
                continue

            batch: list[CheckResult] = []
            for future in done:
                try:
                    result = future.result()
                except Exception as exc:
                    _log.warning("Proxy check task failed: %s", exc)
                    continue

                completed += 1
                if not _passes_post_filters(result):
                    continue
                results.append(result)
                batch.append(result)

            if batch:
                bus.publish(Events.PROXY_RESULT_BATCH, batch)

            if completed % PROGRESS_EVERY == 0 or completed == total:
                last = batch[-1] if batch else None
                bus.publish(Events.PROXY_CHECK_PROGRESS, {
                    "completed": completed,
                    "total":     total,
                    "last_proxy": last.proxy.address() if last else "—",
                    "last_tier":  last.tier if last else "—",
                })
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    elapsed = time.monotonic() - t_start
    ok = sum(1 for r in results if r.tier in ("excellent", "good", "fair"))
    if stopped:
        _log.info("Check stopped by user: %d/%d done (%d working) in %.1fs",
                  completed, total, ok, elapsed)
    else:
        _log.info("Check complete: %d/%d working (HTTPS capable) in %.1fs",
                  ok, total, elapsed)

    bus.publish(Events.PROXY_CHECK_DONE, results)
    return results

"""
modules/cleaner/engine.py

CleanerEngine — the main orchestrator.

Usage
-----
engine = CleanerEngine(win_version=10, on_log=..., on_step=..., on_phase=...)
engine.configure(enabled_steps={'sfc', 'dism', ...})  # optional subset
engine.run()          # blocking — call from a background thread
engine.cancel()       # thread-safe cancel
"""
from __future__ import annotations

import json
import os
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable

from core.logger import get_logger
from modules.cleaner.registry import ALL_PHASES, PHASE_MAP, STEP_MAP, Step

_log = get_logger(__name__)


# ── State file ────────────────────────────────────────────────────────────────

def _state_path() -> Path:
    d = Path(os.environ.get("LOCALAPPDATA", "C:\\Temp")) / "DWUT"
    d.mkdir(parents=True, exist_ok=True)
    return d / "cleaner_state.json"


def load_state() -> dict:
    try:
        p = _state_path()
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def save_state(state: dict) -> None:
    try:
        _state_path().write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass


def clear_state() -> None:
    try:
        _state_path().unlink(missing_ok=True)
    except Exception:
        pass


# ── Engine ────────────────────────────────────────────────────────────────────

class CleanerEngine:
    def __init__(
        self,
        win_version:   int = 10,
        on_log:        Callable[[str], None]         | None = None,
        on_step_start: Callable[[str, str], None]    | None = None,  # (step_id, label)
        on_step_done:  Callable[[str, bool], None]   | None = None,  # (step_id, success)
        on_phase_start:Callable[[int, str], None]    | None = None,  # (phase_num, name)
        on_phase_done: Callable[[int], None]         | None = None,
        on_done:       Callable[[bool], None]        | None = None,  # (completed_fully)
        on_manual_step:Callable[[Step], bool]        | None = None,  # returns True=continue
    ):
        self.win_version    = win_version
        self._on_log        = on_log        or (lambda msg: None)
        self._on_step_start = on_step_start or (lambda sid, lbl: None)
        self._on_step_done  = on_step_done  or (lambda sid, ok: None)
        self._on_phase_start= on_phase_start or (lambda n, name: None)
        self._on_phase_done = on_phase_done or (lambda n: None)
        self._on_done       = on_done       or (lambda ok: None)
        self._on_manual_step= on_manual_step

        self._cancel_event  = threading.Event()
        self._enabled_steps: set[str] = {s.id for p in ALL_PHASES for s in p.steps}
        self._session_state: dict     = {}

    def configure(self, enabled_steps: set[str]) -> None:
        self._enabled_steps = enabled_steps

    def cancel(self) -> None:
        self._cancel_event.set()

    @property
    def cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def log(self, msg: str) -> None:
        formatted = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
        self._on_log(formatted)
        try:
            print(formatted, flush=True)
        except Exception:
            try:
                print(formatted.encode("ascii", "replace").decode("ascii"), flush=True)
            except Exception:
                pass
        _log.info(msg)

    # ── Main run loop ─────────────────────────────────────────────────────────

    def run(self) -> None:
        self._cancel_event.clear()
        self._session_state = {
            "session_id":        datetime.now().isoformat(),
            "windows_version":   self.win_version,
            "phases_completed":  [],
            "disabled_services": [],
            "modified_registry": {},
            "backup_path":       "",
            "restore_point":     "",
        }

        try:
            for phase in ALL_PHASES:
                if self.cancelled:
                    break
                self._run_phase(phase)

            self._on_done(not self.cancelled)

        except Exception as exc:
            self.log(f"FATAL: {exc}")
            self._on_done(False)
        finally:
            if not self.cancelled:
                clear_state()

    def _run_phase(self, phase) -> None:
        steps = [
            s for s in phase.steps
            if s.id in self._enabled_steps
            and (self.win_version == 10 and s.win10 or self.win_version == 11 and s.win11)
        ]
        if not steps:
            return

        self.log(f"=== PHASE {phase.number}: {phase.name.upper()} ===")
        self._on_phase_start(phase.number, phase.name)

        for step in steps:
            if self.cancelled:
                break
            self._run_step(step)

        save_state(self._session_state)
        if phase.number not in self._session_state["phases_completed"]:
            self._session_state["phases_completed"].append(phase.number)
        self._on_phase_done(phase.number)

    def _run_step(self, step: Step) -> None:
        self.log(f"  -> {step.label}")
        self._on_step_start(step.id, step.label)

        # Manual step: ask the UI to handle it
        if not step.auto:
            if self._on_manual_step:
                cont = self._on_manual_step(step)
                self._on_step_done(step.id, cont)
            else:
                self.log(f"    [SKIP] {step.label} requires manual interaction")
                self._on_step_done(step.id, True)
            return

        # Dispatch to executor
        ok = self._dispatch(step)
        self._on_step_done(step.id, ok)

    def _dispatch(self, step: Step) -> bool:
        """Route step.id to the correct executor function."""
        try:
            fn = _EXECUTORS.get(step.id)
            if fn is None:
                self.log(f"    [TODO] {step.id} — executor not yet implemented")
                return True
            return fn(self, step)
        except Exception as exc:
            self.log(f"    [ERROR] {step.label}: {exc}")
            return False


# ── Executor functions ────────────────────────────────────────────────────────
# Each receives (engine: CleanerEngine, step: Step) -> bool (success)
# They call engine.log() and engine.cancelled as needed.

def _exec_restore_point(eng: CleanerEngine, step: Step) -> bool:
    eng.log("    Creating system restore point…")
    if sys.platform != "win32":
        return True
    desc = f"DWUT_Clean_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    from modules.cleaner.runner import run_ps
    ps_cmd = (
        'Enable-ComputerRestore -Drive "C:\\" -ErrorAction SilentlyContinue; '
        'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore" '
        '-Name "SystemRestorePointCreationFrequency" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue; '
        f'Checkpoint-Computer -Description "{desc}" -RestorePointType MODIFY_SETTINGS -ErrorAction Stop'
    )
    code, _ = run_ps(ps_cmd, on_line=eng.log)
    if code == 0:
        eng.log(f"    [OK] Restore point created successfully: {desc}")
        eng._session_state["restore_point"] = desc
        return True

    # Fallback via WMI
    try:
        import wmi  # type: ignore
        c = wmi.WMI()
        c.Win32_ComputerSystem()[0].SetRestorePoint(
            Description=desc,
            RestorePointType=12, EventType=100,
        )
        eng.log(f"    [OK] Restore point created via WMI: {desc}")
        eng._session_state["restore_point"] = desc
        return True
    except Exception as exc:
        eng.log(f"    [WARN] Restore point notice: {exc}")
        return True


def _exec_backup_registry(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    backup_dir = Path(os.environ.get("LOCALAPPDATA", "C:\\Temp")) / "DWUT" / "Backups" / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_dir.mkdir(parents=True, exist_ok=True)
    eng._session_state["backup_path"] = str(backup_dir)
    for hive, fname in [("HKLM", "HKLM.reg"), ("HKCU", "HKCU.reg")]:
        eng.log(f"    Backing up {hive}…")
        code, _ = run(["reg", "export", hive, str(backup_dir / fname), "/y"],
                      on_line=eng.log, timeout=120)
    return True


def _exec_flush_dns(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run, run_ps
    run(["ipconfig", "/flushdns"],            on_line=eng.log)
    run(["netsh", "winsock", "reset"],        on_line=eng.log)
    run(["netsh", "winhttp", "reset", "proxy"],on_line=eng.log)
    return True


def _exec_reset_firewall(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    code, _ = run(["netsh", "advfirewall", "reset"], on_line=eng.log)
    return True


def _exec_reset_hosts(eng: CleanerEngine, step: Step) -> bool:
    default = (
        "# Copyright (c) 1993-2009 Microsoft Corp.\r\n"
        "#\r\n"
        "# This is a sample HOSTS file used by Microsoft TCP/IP for Windows.\r\n"
        "#\r\n"
        "127.0.0.1       localhost\r\n"
        "::1             localhost\r\n"
    )
    hosts = Path(os.environ.get("SystemRoot", "C:\\Windows")) / "System32" / "drivers" / "etc" / "hosts"
    try:
        hosts.write_text(default, encoding="ascii")
        eng.log(f"    Hosts file reset: {hosts}")
        return True
    except PermissionError:
        from modules.cleaner.runner import run_ps
        run_ps(
            f'Set-Content -Path "{hosts}" -Value @"\\n{default}\\n"@ -Encoding ASCII -Force',
            on_line=eng.log,
        )
        return True


def _exec_disable_service(eng: CleanerEngine, step: Step, *svc_names: str) -> bool:
    from modules.cleaner.runner import run
    for svc in svc_names:
        run(["sc", "stop", svc],          on_line=eng.log)
        run(["sc", "config", svc, "start=", "disabled"], on_line=eng.log)
        if svc not in eng._session_state["disabled_services"]:
            eng._session_state["disabled_services"].append(svc)
    return True


def _exec_enable_service(eng: CleanerEngine, step: Step, *svc_names: str) -> bool:
    from modules.cleaner.runner import run
    for svc in svc_names:
        run(["sc", "config", svc, "start=", "auto"], on_line=eng.log)
        run(["sc", "start",  svc],                   on_line=eng.log)
    return True


def _exec_sfc(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Running SFC — this may take 10–20 minutes…")
    code, _ = run(["sfc", "/scannow"], on_line=eng.log, timeout=1800)
    return code in (0, 1)


def _exec_dism(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Running DISM RestoreHealth — may take 20–40 minutes…")
    code, _ = run(
        ["dism", "/Online", "/Cleanup-Image", "/RestoreHealth"],
        on_line=eng.log, timeout=3600,
    )
    return code == 0


def _exec_chkdsk(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    drive = os.environ.get("SystemDrive", "C:")
    eng.log(f"    Running CHKDSK on {drive}…")
    code, lines = run(["chkdsk", drive, "/f", "/r", "/x"], on_line=eng.log, timeout=60)
    if "would require" in " ".join(lines).lower() or code != 0:
        eng.log("    CHKDSK scheduled for next reboot.")
    return True


def _exec_tmp_cleanup(eng: CleanerEngine, step: Step) -> bool:
    """Delete a list of glob patterns / directories, skipping locked files with granular real-time logging."""
    import glob, shutil
    targets = _TEMP_TARGETS.get(step.id, [])
    total_freed = 0
    total_files = 0
    total_dirs  = 0
    total_locked = 0

    for pattern in targets:
        expanded = os.path.expandvars(pattern)
        matched_paths = glob.glob(expanded, recursive=True)
        if not matched_paths:
            continue

        dir_label = expanded.replace("*", "").rstrip("\\/")
        eng.log(f"    Scanning {dir_label}...")

        pat_freed = 0
        pat_files = 0
        pat_dirs  = 0
        pat_locked = 0

        for path in matched_paths:
            try:
                p = Path(path)
                if p.is_dir():
                    sz = _dir_size(p)
                    try:
                        shutil.rmtree(p, ignore_errors=False)
                        pat_freed += sz
                        pat_dirs += 1
                    except Exception:
                        pat_locked += 1
                elif p.is_file():
                    try:
                        sz = p.stat().st_size
                        p.unlink()
                        pat_freed += sz
                        pat_files += 1
                    except Exception:
                        pat_locked += 1
            except Exception:
                pat_locked += 1

        total_freed += pat_freed
        total_files += pat_files
        total_dirs  += pat_dirs
        total_locked += pat_locked

        freed_mb = pat_freed / (1024 * 1024)
        if pat_files > 0 or pat_dirs > 0:
            eng.log(f"      Cleaned {pat_files} file(s), {pat_dirs} folder(s) - {freed_mb:.1f} MB freed")
        if pat_locked > 0:
            eng.log(f"      Skipped {pat_locked} in-use or locked item(s)")

    freed_mb_total = total_freed / (1024 * 1024)
    eng.log(f"    [DONE] {step.label}: Cleaned {total_files} file(s), {total_dirs} folder(s) (~{freed_mb_total:.1f} MB total freed)")
    return True


def _dir_size(p: Path) -> int:
    total = 0
    try:
        for f in p.rglob("*"):
            if f.is_file():
                try:
                    total += f.stat().st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total


def _exec_wu(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run_ps
    eng.log("    Installing PSWindowsUpdate module…")
    run_ps("Install-Module PSWindowsUpdate -Force -Scope CurrentUser", on_line=eng.log)
    eng.log("    Running Windows Updates (this may take a long time)…")
    code, _ = run_ps(
        "Get-WindowsUpdate -Install -AcceptAll -AutoReboot:$false -IgnoreReboot",
        on_line=eng.log, timeout=7200,
    )
    return True


def _exec_defender_update(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run_ps
    code, _ = run_ps("Update-MpSignature", on_line=eng.log)
    return code == 0


def _exec_defrag(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run_ps
    # Detect HDD vs SSD
    code, lines = run_ps(
        "(Get-PhysicalDisk | Where-Object {$_.DeviceId -eq 0}).MediaType",
        on_line=eng.log,
    )
    media = " ".join(lines).strip().lower()
    drive = os.environ.get("SystemDrive", "C:").rstrip(":\\")
    if "ssd" in media or "solid" in media:
        eng.log("    SSD detected — running TRIM…")
        run_ps(f"Optimize-Volume -DriveLetter {drive} -ReTrim -Verbose", on_line=eng.log, timeout=600)
    else:
        eng.log("    HDD detected — defragmenting…")
        run_ps(f"Optimize-Volume -DriveLetter {drive} -Defrag -Verbose", on_line=eng.log, timeout=7200)
    return True


def _exec_dns(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run
    dns = getattr(step, "_dns_provider", "1.1.1.1")
    iface = "Ethernet"
    run(["netsh", "interface", "ip", "set", "dns", iface, "static", dns], on_line=eng.log)
    run(["netsh", "interface", "ip", "add",  "dns", iface, "8.8.8.8",    "index=2"], on_line=eng.log)
    eng.log(f"    DNS set to {dns}")
    return True


def _exec_scan_tool(eng: CleanerEngine, step: Step) -> bool:
    """Download and silently run a scanner tool."""
    from modules.cleaner.downloader import download, is_cached, get_tool_dir
    from modules.cleaner.runner import run

    eng.log(f"    Downloading {step.label}…")
    path = download(step.id, on_log=eng.log)
    if not path:
        eng.log(f"    [WARN] Could not download {step.label} — skipping.")
        return True  # Non-fatal

    silent_args = _TOOL_SILENT_ARGS.get(step.id, [])
    eng.log(f"    Running {step.label}…")
    code, _ = run([str(path)] + silent_args, on_line=eng.log, timeout=1800)
    return True


def _exec_repair_wu(eng: CleanerEngine, step: Step) -> bool:
    from modules.cleaner.runner import run, run_ps
    svcs = ["wuauserv", "cryptSvc", "bits", "msiserver"]
    for svc in svcs:
        run(["net", "stop", svc], on_line=eng.log)
    sd = Path(os.environ.get("SystemRoot", "C:\\Windows")) / "SoftwareDistribution"
    cat = Path(os.environ.get("SystemRoot", "C:\\Windows")) / "System32" / "catroot2"
    import shutil
    shutil.rmtree(str(sd),  ignore_errors=True)
    shutil.rmtree(str(cat), ignore_errors=True)
    for svc in svcs:
        run(["net", "start", svc], on_line=eng.log)
    return True


def _exec_report(eng: CleanerEngine, step: Step) -> bool:
    backup = eng._session_state.get("backup_path", "")
    report_path = (Path(backup) / "dwut_cleaner_report.json") if backup else None
    if report_path:
        eng._session_state["finished_at"] = datetime.now().isoformat()
        report_path.write_text(json.dumps(eng._session_state, indent=2), encoding="utf-8")
        eng.log(f"    Report saved: {report_path}")
    return True


# ── Temp target patterns ──────────────────────────────────────────────────────

_TEMP_TARGETS: dict[str, list[str]] = {
    "tmp_windows":    [
        r"%SystemRoot%\Temp\*",
        r"%TEMP%\*",
        r"%TMP%\*",
    ],
    "tmp_prefetch":   [r"%SystemRoot%\Prefetch\*.pf"],
    "tmp_wu":         [
        r"%SystemRoot%\SoftwareDistribution\Download\*",
        r"%SystemRoot%\SoftwareDistribution\DeliveryOptimization\*",
    ],
    "tmp_crashes":    [
        r"%SystemRoot%\Minidump\*",
        r"%LocalAppData%\CrashDumps\*",
        r"%ProgramData%\Microsoft\Windows\WER\*",
    ],
    "tmp_thumbs":     [
        r"%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*.db",
        r"%LocalAppData%\IconCache.db",
    ],
    "tmp_shaders":    [
        r"%LocalAppData%\D3DSCache\*",
        r"%LocalAppData%\DXCache\*",
    ],
    "tmp_browsers":   [
        r"%LocalAppData%\Google\Chrome\User Data\Default\Cache\*",
        r"%LocalAppData%\Mozilla\Firefox\Profiles\*\cache2\*",
        r"%LocalAppData%\Microsoft\Edge\User Data\Default\Cache\*",
        r"%LocalAppData%\Opera Software\Opera Stable\Cache\*",
    ],
    "tmp_java":       [
        r"%AppData%\Sun\Java\Deployment\cache\*",
        r"%AppData%\Macromedia\Flash Player\#SharedObjects\*",
    ],
    "tmp_logs":       [
        r"%SystemRoot%\Logs\CBS\*",
        r"%SystemRoot%\Logs\DISM\*",
    ],
    "tmp_old_windows":[
        r"%SystemDrive%\Windows.old",
        r"%SystemDrive%\$Windows.~BT",
        r"%SystemDrive%\$Windows.~WS",
        r"%SystemDrive%\MSOCache",
    ],
}

# ── Tool silent args ──────────────────────────────────────────────────────────

_TOOL_SILENT_ARGS: dict[str, list[str]] = {
    "rkill":         ["/s", "/NOERROR"],
    "malwarebytes":  ["/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES"],
    "adwcleaner":    ["--scan", "--clean", "--noreboot", "--verbose"],
    "tdsskiller":    ["-accepteula", "-silent"],
    "msrt":          ["/q", "/ERadiocal"],
    "kaspersky_vrt": ["-accepteula", "-afs", "-ai", "-processlevel", "1"],
    "mcafee":        ["/SILENT", "/NOCANCEL"],
    "clamwin":       ["--database", "C:\\ProgramData\\ClamWin\\db",
                      "--recursive", "--infected"],
    "spybot":        ["/verysilent", "/norestart"],
}

# ── Executor dispatch table ───────────────────────────────────────────────────

def _svc(*names):
    def fn(eng, step):
        return _exec_disable_service(eng, step, *names)
    return fn

def _re_svc(*names):
    def fn(eng, step):
        return _exec_enable_service(eng, step, *names)
    return fn


_EXECUTORS: dict[str, Callable] = {
    # Phase 0
    "kill_malware_procs":  lambda e, s: _kill_malware(e),
    "kill_nonessential":   lambda e, s: True,
    "restore_point":       _exec_restore_point,
    "backup_registry":     _exec_backup_registry,
    "export_programs":     lambda e, s: True,
    "export_network":      lambda e, s: True,
    "export_services":     lambda e, s: True,
    "clear_event_logs":    lambda e, s: _clear_evt_logs(e),
    "flush_dns":           _exec_flush_dns,
    "reset_firewall":      _exec_reset_firewall,
    "reset_hosts":         _exec_reset_hosts,
    "power_high":          lambda e, s: _set_power(e, "SCHEME_MIN"),
    "dis_telemetry":       _svc("DiagTrack", "dmwappushservice"),
    "dis_wd":              lambda e, s: _dis_wd(e),
    "dis_wu_restart":      lambda e, s: True,
    "dis_superfetch":      _svc("SysMain"),
    "dis_search":          _svc("WSearch"),
    "dis_delivery_opt":    _svc("DoSvc"),
    "dis_sleep":           lambda e, s: _dis_sleep(e),
    "dis_remote":          _svc("RemoteRegistry", "TermService"),
    "dis_smb1":            lambda e, s: _dis_smb1(e),
    "dis_homegroup":       _svc("HomeGroupListener", "HomeGroupProvider"),
    "dis_appcompat":       _svc("AeLookupSvc", "PcaSvc"),
    # Phase 1
    "tmp_windows":    _exec_tmp_cleanup,
    "tmp_prefetch":   _exec_tmp_cleanup,
    "tmp_wu":         _exec_tmp_cleanup,
    "tmp_crashes":    _exec_tmp_cleanup,
    "tmp_thumbs":     _exec_tmp_cleanup,
    "tmp_shaders":    _exec_tmp_cleanup,
    "tmp_browsers":   _exec_tmp_cleanup,
    "tmp_java":       _exec_tmp_cleanup,
    "tmp_logs":       _exec_tmp_cleanup,
    "tmp_old_windows":_exec_tmp_cleanup,
    "tmp_recycle":    lambda e, s: _empty_recycle(e),
    "tmp_installers": lambda e, s: True,
    # Phase 3
    "rkill":        _exec_scan_tool,
    "malwarebytes": _exec_scan_tool,
    "adwcleaner":   _exec_scan_tool,
    "tdsskiller":   _exec_scan_tool,
    "hitmanpro":    _exec_scan_tool,
    "roguekiller":  _exec_scan_tool,
    "msrt":         _exec_scan_tool,
    "defender":     lambda e, s: _full_wd_scan(e),
    "kaspersky_vrt":_exec_scan_tool,
    "sophos_vrt":   _exec_scan_tool,
    "mcafee":       _exec_scan_tool,
    "eset":         _exec_scan_tool,
    "npe":          _exec_scan_tool,
    "clamwin":      _exec_scan_tool,
    "mbar":         _exec_scan_tool,
    "gmer":         _exec_scan_tool,
    "aswmbr":       _exec_scan_tool,
    "frst":         _exec_scan_tool,
    "otl":          _exec_scan_tool,
    "spybot":       _exec_scan_tool,
    # Phase 4
    "sfc":            _exec_sfc,
    "dism":           _exec_dism,
    "chkdsk":         _exec_chkdsk,
    "repair_wu":      _exec_repair_wu,
    "repair_wmi":     lambda e, s: _repair_wmi(e),
    "repair_store":   lambda e, s: _repair_store(e),
    "repair_start":   lambda e, s: _repair_start(e),
    "repair_search":  lambda e, s: _repair_search(e),
    "repair_dotnet":  lambda e, s: True,
    "repair_vcpp":    lambda e, s: True,
    "repair_dx":      lambda e, s: True,
    "repair_boot":    lambda e, s: _repair_boot(e),
    "repair_gp":      lambda e, s: _repair_gp(e),
    "repair_explorer":lambda e, s: _repair_explorer(e),
    "repair_com":     lambda e, s: True,
    "repair_msi":     lambda e, s: _repair_msi(e),
    "repair_bits":    lambda e, s: _repair_bits(e),
    "repair_crypt":   lambda e, s: _repair_crypt(e),
    "repair_perm":    lambda e, s: True,
    "repair_winre":   lambda e, s: _repair_winre(e),
    "clean_comp_store": lambda e, s: _exec_comp_store_fast(e),
    # Phase 5
    "wu_all":       _exec_wu,
    "wu_defender":  _exec_defender_update,
    "wu_vcpp":      lambda e, s: True,
    "wu_dotnet":    lambda e, s: True,
    "wu_dx":        lambda e, s: True,
    # Phase 6
    "opt_disk":     _exec_defrag,
    "opt_startup":  lambda e, s: True,
    "opt_services": lambda e, s: True,
    "opt_network":  lambda e, s: _opt_network(e),
    "opt_dns":      _exec_dns,
    "opt_power":    lambda e, s: _set_power(e, "SCHEME_BALANCED"),
    "opt_pagefile": lambda e, s: True,
    "opt_prefetch": lambda e, s: _set_reg(e, r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters", "EnablePrefetcher", "REG_DWORD", "3"),
    "opt_memory":   lambda e, s: _set_reg(e, r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", "LargeSystemCache", "REG_DWORD", "0"),
    "opt_privacy":  lambda e, s: True,
    "opt_index":    lambda e, s: True,
    "opt_vis":      lambda e, s: True,
    "opt_cleanup":  lambda e, s: _disk_cleanup(e),
    "opt_onedrive": lambda e, s: _opt_onedrive(e),
    "opt_cortana":  lambda e, s: _opt_cortana(e),
    "opt_ram_trim": lambda e, s: _opt_ram_trim(e),
    # Phase 7
    "re_defender":   lambda e, s: _re_wd(e),
    "re_wu":         _re_svc("wuauserv"),
    "re_telemetry":  _re_svc("DiagTrack"),
    "re_superfetch": _re_svc("SysMain"),
    "re_search":     _re_svc("WSearch"),
    "re_delivery":   _re_svc("DoSvc"),
    "re_sleep":      lambda e, s: True,
    "re_services":   lambda e, s: _re_all_services(e),
    "re_remote":     _re_svc("RemoteRegistry"),
    "re_media":      lambda e, s: _verify_media(e),
    "report":        _exec_report,
}


# ── Small helpers ─────────────────────────────────────────────────────────────

_MALWARE_PROCS = [
    "adwcleaner", "Mbam", "YahooToolbar", "Conduit", "babylon",
    "delta", "iminent", "sweetim", "mywebsearch", "ask_",
]


def _kill_malware(eng: CleanerEngine) -> bool:
    try:
        import psutil
        from modules.cleaner.registry import PROTECTED_PROCESSES
        for proc in psutil.process_iter(["name", "pid"]):
            name = (proc.info.get("name") or "").lower()
            if name in PROTECTED_PROCESSES:
                continue
            if any(m.lower() in name for m in _MALWARE_PROCS):
                try:
                    proc.kill()
                    eng.log(f"    Killed: {name}")
                except Exception:
                    pass
    except ImportError:
        pass
    return True


def _clear_evt_logs(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    logs = ["Application", "System", "Security", "Setup"]
    for log in logs:
        run(["wevtutil", "cl", log], on_line=eng.log)
    return True


def _set_power(eng: CleanerEngine, scheme: str) -> bool:
    from modules.cleaner.runner import run
    run(["powercfg", "/setactive", scheme], on_line=eng.log)
    return True


def _dis_sleep(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["powercfg", "/h", "off"], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-ac",  "0"], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-dc",  "0"], on_line=eng.log)
    return True


def _dis_smb1(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run_ps
    run_ps("Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart",
           on_line=eng.log)
    return True


def _dis_wd(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run_ps
    run_ps("Set-MpPreference -DisableRealtimeMonitoring $true", on_line=eng.log)
    return True


def _re_wd(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run_ps
    run_ps("Set-MpPreference -DisableRealtimeMonitoring $false", on_line=eng.log)
    return True


def _full_wd_scan(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run_ps
    eng.log("    Starting Windows Defender full scan…")
    run_ps("Start-MpScan -ScanType FullScan", on_line=eng.log, timeout=7200)
    return True


def _empty_recycle(eng: CleanerEngine) -> bool:
    eng.log("    Emptying Windows Recycle Bin on all drives...")
    if sys.platform == "win32":
        try:
            import ctypes
            # SHERB_NOCONFIRMATION (0x1) | SHERB_NOPROGRESSUI (0x2) | SHERB_NOSOUND (0x4) = 7
            ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 7)
            eng.log("    [OK] Recycle Bin emptied successfully.")
            return True
        except Exception:
            pass
        try:
            from modules.cleaner.runner import run_ps
            run_ps("Clear-RecycleBin -Force -ErrorAction SilentlyContinue", on_line=eng.log)
            eng.log("    [OK] Recycle Bin emptied.")
        except Exception as exc:
            eng.log(f"    [INFO] Recycle bin notice: {exc}")
    return True


def _repair_wmi(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["winmgmt", "/resetrepository"], on_line=eng.log)
    return True


def _repair_store(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["wsreset.exe"], on_line=eng.log)
    return True


def _repair_start(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["taskkill", "/f", "/im", "StartMenuExperienceHost.exe"], on_line=eng.log)
    return True


def _repair_search(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["net", "stop", "WSearch"], on_line=eng.log)
    idx = Path(os.environ.get("ProgramData", "C:\\ProgramData")) / "Microsoft" / "Search" / "Data"
    import shutil; shutil.rmtree(str(idx), ignore_errors=True)
    run(["net", "start", "WSearch"], on_line=eng.log)
    return True


def _repair_boot(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    win_dir = os.environ.get("SystemRoot", "C:\\Windows")
    sys_drv = os.environ.get("SystemDrive", "C:")
    run(["bcdboot", f"{win_dir}", "/s", sys_drv], on_line=eng.log)
    return True


def _repair_gp(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["gpupdate", "/force"], on_line=eng.log)
    return True


def _repair_explorer(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["taskkill", "/f", "/im", "explorer.exe"], on_line=eng.log)
    import time; time.sleep(1)
    run(["explorer.exe"], on_line=eng.log)
    return True


def _repair_msi(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["msiexec", "/unregister"], on_line=eng.log)
    run(["msiexec", "/regserver"],  on_line=eng.log)
    return True


def _repair_bits(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["bitsadmin", "/reset", "/allusers"], on_line=eng.log)
    return True


def _repair_crypt(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["net", "stop", "CryptSvc"], on_line=eng.log)
    run(["net", "start", "CryptSvc"], on_line=eng.log)
    return True


def _opt_network(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    tweaks = [
        ["netsh", "int", "tcp", "set", "global", "autotuninglevel=normal"],
        ["netsh", "int", "tcp", "set", "global", "congestionprovider=ctcp"],
        ["netsh", "int", "tcp", "set", "global", "ecncapability=enabled"],
        ["netsh", "int", "ip",  "set", "global", "taskoffload=enabled"],
    ]
    for t in tweaks:
        run(t, on_line=eng.log)
    return True


def _set_reg(eng: CleanerEngine, key: str, name: str, typ: str, val: str) -> bool:
    from modules.cleaner.runner import run
    run(["reg", "add", key, "/v", name, "/t", typ, "/d", val, "/f"], on_line=eng.log)
    return True


def _disk_cleanup(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    run(["cleanmgr", "/sagerun:65535"], on_line=eng.log, timeout=600)
    return True


def _re_all_services(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    for svc in eng._session_state.get("disabled_services", []):
        run(["sc", "config", svc, "start=", "auto"], on_line=eng.log)
        run(["sc", "start",  svc], on_line=eng.log)
    return True


def _verify_media(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    code, out = run(["sc", "query", "WMPNetworkSvc"], on_line=eng.log)
    if any("running" in l.lower() for l in out):
        eng.log("    Windows Media Player network service: RUNNING OK")
    else:
        eng.log("    Windows Media Player network service: not running (may be normal if WMP not open)")
    return True


def _repair_winre(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Checking Windows Recovery Environment (WinRE)…")
    run(["reagentc", "/enable"], on_line=eng.log)
    run(["reagentc", "/info"],   on_line=eng.log)
    return True


def _opt_onedrive(eng: CleanerEngine) -> bool:
    eng.log("    Cleaning OneDrive cache and diagnostic logs…")
    local_app = os.environ.get("LOCALAPPDATA", "")
    if local_app:
        od_logs = Path(local_app) / "Microsoft" / "OneDrive" / "logs"
        if od_logs.exists():
            try:
                import shutil
                shutil.rmtree(od_logs, ignore_errors=True)
                eng.log("    Cleaned OneDrive diagnostic logs.")
            except Exception:
                pass
    return True


def _opt_cortana(eng: CleanerEngine) -> bool:
    eng.log("    Cleaning Cortana/Search cache…")
    local_app = os.environ.get("LOCALAPPDATA", "")
    if local_app:
        c_cache = Path(local_app) / "Packages" / "Microsoft.Windows.Cortana_cw5n1h2txyewy" / "AC" / "INetCache"
        if c_cache.exists():
            try:
                import shutil
                shutil.rmtree(c_cache, ignore_errors=True)
            except Exception:
                pass
    return True


def _exec_comp_store_fast(eng: CleanerEngine) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Running Component Store Cleanup (frees superseded update files)…")
    run(["dism", "/Online", "/Cleanup-Image", "/StartComponentCleanup"], on_line=eng.log, timeout=600)
    return True


def _opt_ram_trim(eng: CleanerEngine) -> bool:
    eng.log("    Optimizing memory working sets and standby caches...")
    if sys.platform == "win32":
        try:
            import ctypes
            # Flush working set of current and background system tasks
            ctypes.windll.psapi.EmptyWorkingSet(ctypes.c_void_p(-1))
            eng.log("    [OK] Memory working sets trimmed.")
        except Exception:
            pass
    return True

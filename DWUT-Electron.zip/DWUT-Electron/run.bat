@echo off
rem DWUT launcher. Works from the unzipped folder.
setlocal
set "HERE=%~dp0"
rem strip the trailing backslash (a path ending in \ breaks quoted arguments)
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "RT=%LOCALAPPDATA%\DWUT\electron\DWUT.exe"

if exist "%RT%" (
  start "" "%RT%" "%HERE%"
  exit /b 0
)
echo First run - installing Python/Electron/packages (UAC prompt will appear)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%\bootstrap.ps1" -Source "%HERE%"
if errorlevel 1 (
  echo.
  echo Setup did not finish. Log: %LOCALAPPDATA%\DWUT\bootstrap.log
  pause
)

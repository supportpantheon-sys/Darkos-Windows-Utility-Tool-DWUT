@echo off
rem DWUT 6 launcher — runs from the source folder using Node/Electron directly.
setlocal EnableDelayedExpansion
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

rem ─── 1. Require Node.js ───────────────────────────────────────────────────────
where node >nul 2>&1
if errorlevel 1 (
  echo [DWUT] Node.js not found.  Download it from https://nodejs.org ^(LTS^) and re-run.
  pause
  exit /b 1
)

rem ─── 2. Install npm packages if node_modules is missing ──────────────────────
if not exist "%HERE%\node_modules\electron\dist\electron.exe" (
  echo [DWUT] Installing packages ^(first run, takes about 30 seconds^)...
  cd /d "%HERE%"
  call npm install --prefer-offline --no-audit --no-fund 2>&1
  if errorlevel 1 (
    echo [DWUT] npm install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
  echo [DWUT] Packages installed OK.
)

rem ─── 3. Launch Electron from source ──────────────────────────────────────────
echo [DWUT] Starting...
cd /d "%HERE%"
set "ELECTRON=%HERE%\node_modules\electron\dist\electron.exe"
if not exist "%ELECTRON%" set "ELECTRON=npx electron"

rem Launch as admin (required for firewall/VPN features)
powershell -NoProfile -WindowStyle Hidden -Command ^
  "Start-Process -FilePath '%ELECTRON%' -ArgumentList '.' -WorkingDirectory '%HERE%' -Verb RunAs" 2>nul

if errorlevel 1 (
  rem Admin launch failed — try without elevation (limited features)
  echo [DWUT] Could not launch as Administrator. Some features need admin rights.
  start "" "%ELECTRON%" "."
)
exit /b 0

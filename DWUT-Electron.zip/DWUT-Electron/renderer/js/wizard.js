'use strict';
/* Shared wizard pieces (USB Flasher + VM Builder): OS picker and the un-dismissable progress window. */
const wzGb = (b) => (b / 1e9 >= 100 ? (b / 1e9).toFixed(0) : (b / 1e9).toFixed(1)) + ' GB';
function wzPickOS(CAT, only, opts) {
opts = opts || {};
  return Modal.custom((close) => {
    let sel = null, iso = '';
    const search = Entry({ placeholder: 'Search operating systems…', fill: true, h: 28, f: 12, onchange: () => paint() }); search.style.width = 'auto';
    const list = h('div', { class: 'scroll', style: 'max-height:300px;margin:8px 0' });
    const isoLbl = h('span', { class: 'f10 ts ell', style: 'max-width:300px' });
    const verify = Check('Verify the stick after writing', { checked: true, themed: true, sm: true, f: 11 });
    const del = Check('Delete the downloaded ISO afterwards', { checked: false, themed: true, sm: true, f: 11 });
    const swOpt = opts.software ? Option(['VirtualBox (recommended)', 'VMware Workstation'], { w: 240, f: 12 }) : null;
    if (swOpt) swOpt.classList.add('bordered');
    const next = Btn('Next', { w: 100, onclick: () => close({ software: swOpt && swOpt.value.startsWith('VMware') ? 'vmware' : 'virtualbox', os_id: iso ? '' : sel.id, iso_path: iso, verify: verify.checked, delete_iso: del.checked, name: iso ? iso.split('\\').pop() : sel.name }) }); next.disabled = true;
    const paint = () => {
      list.textContent = '';
      const q = search.value.trim().toLowerCase();
      for (const g of CAT.groups) {
        const items = CAT.os.filter((o) => o.group === g && (!only || only.includes(o.id)) && !(opts.exclude || []).includes(o.id) && (!q || (o.name + ' ' + o.desc).toLowerCase().includes(q)));
        if (!items.length) continue;
        list.append(h('div', { class: 'f11 b c-acc', text: g, style: 'margin:8px 4px 3px' }));
        items.forEach((o) => {
          const on_ = !iso && sel && sel.id === o.id;
          const row = h('div', { style: `padding:7px 10px;border-radius:6px;cursor:pointer;margin:2px 0;border:2px solid ${on_ ? 'var(--accent)' : 'transparent'};${on_ ? 'background:var(--sidebar_active)' : ''}` },
            h('div', { class: 'row' }, h('span', { class: 'f12 b tp grow', text: o.name }), h('span', { class: 'f10 ts', text: o.size_gb >= 0.1 ? `~${o.size_gb} GB` : 'tiny' })),
            h('div', { class: 'f10 ts', text: o.desc, style: 'white-space:normal' }), o.warn ? h('div', { class: 'f10 c-warn', text: o.warn, style: 'white-space:normal' }) : null);
          row.onclick = () => { sel = o; iso = ''; isoLbl.textContent = ''; next.disabled = false; paint(); };
          row.onmouseenter = () => { if (!on_) row.style.background = 'var(--bg_hover)'; }; row.onmouseleave = () => { if (!on_) row.style.background = ''; };
          list.append(row);
        });
      }
    };
    const own = Btn('Use my own ISO / IMG file…', { variant: 'ghost', w: 220, h: 28, onclick: async () => {
      const f = await dwut.dialog.open({ properties: ['openFile'], filters: [{ name: 'Disk images', extensions: ['iso', 'img'] }, { name: 'All files', extensions: ['*'] }] });
      if (f && f[0]) { iso = f[0]; sel = null; isoLbl.textContent = f[0]; next.disabled = false; paint(); }
    } });
    paint();
    return h('div', { class: 'modal', style: 'width:640px;max-width:92%' },
      h('h3', { text: 'Choose the operating system' }), h('div', { class: 'f11 ts', text: opts.subtitle || '', style: 'white-space:normal;margin-bottom:6px' }),
      search, list, h('div', { class: 'row', style: 'gap:10px;margin-top:2px' }, own, isoLbl), opts.vm ? null : h('div', { class: 'row', style: 'gap:18px;margin-top:10px' }, verify, del),
      opts.software ? h('div', { class: 'row', style: 'gap:10px;margin-top:10px' }, h('span', { class: 'f12 ts', text: 'VM software:' }), swOpt) : null,
      h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), h('div', { class: 'grow' }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), next));
  });
}


function wzRunJob(title, start, ev) {
ev = ev || 'usb';
  return Modal.custom((close) => {
    const overall = Progress({ height: 10 }), stageBar = Progress({ height: 5 });
    const msg = h('div', { class: 'f12 tp', text: 'Starting…', style: 'white-space:normal;min-height:34px' });
    const meta = h('div', { class: 'f10 ts', style: 'min-height:14px;margin-top:2px' });
    const stages = h('div', { class: 'row wrap', style: 'gap:4px 12px;margin:8px 0 10px' });
    const need = h('div', { class: 'f11 c-warn', style: 'display:none;white-space:pre-wrap;margin-top:8px' });
    const needBtn = Btn('Continue', { w: 110, h: 28, onclick: () => { need.style.display = needBtn.style.display = 'none'; rpc('usb.continue'); } }); needBtn.style.display = 'none';
    const cancel = Btn('Cancel', { variant: 'danger', w: 100, onclick: () => { cancel.disabled = true; cancel.textContent = 'Cancelling…'; rpc('usb.cancel'); } });
    const closeBtn = Btn('Close', { w: 100, onclick: () => close(true) }); closeBtn.style.display = 'none';
    let names = [];
    const L = { download: 'Download', resolve: 'Find latest', checksum: 'Verify file', prepare: 'Prepare stick', write: 'Write', verify: 'Verify stick', copy: 'Copy files', split: 'Split image', boot: 'Boot code', install: 'Install Ventoy', work: 'Working', vbox: 'VirtualBox', create: 'Create VM', start: 'Start VM' };
    const offs = [];
    offs.push(on(ev + '.progress', (d) => {
      if (d.stages && d.stages.join() !== names.join()) { names = d.stages; stages.textContent = ''; names.forEach((n) => stages.append(h('span', { class: 'f10', 'data-s': n, text: L[n] || n, style: 'color:var(--text_disabled)' }))); }
      const idx = names.indexOf(d.stage);
      $$('[data-s]', stages).forEach((s, i) => { s.style.color = i < idx ? 'var(--success)' : i === idx ? 'var(--accent)' : 'var(--text_disabled)'; s.style.fontWeight = i === idx ? '700' : '400'; });
      msg.textContent = d.msg || ''; overall.set(d.overall); d.indeterminate ? stageBar.indeterminate(true) : (stageBar.indeterminate(false), stageBar.set(d.stage_frac));
      meta.textContent = `${Math.floor(d.overall * 100)}% overall` + (d.speed > 0 ? `   |   ${(d.speed / 1048576).toFixed(1)} MB/s` : '') + (d.eta > 1 ? `   |   ${d.eta >= 60 ? Math.floor(d.eta / 60) + ' min ' : ''}${Math.floor(d.eta % 60)} s left` : '');
    }));
    offs.push(on(ev + '.need_user', (d) => { need.textContent = d.message; need.style.display = needBtn.style.display = ''; }));
    offs.push(on(ev + '.done', (d) => {
      offs.forEach((o) => o()); stageBar.indeterminate(false); stageBar.set(d.ok ? 1 : 0); if (d.ok) overall.set(1);
      msg.textContent = (d.ok ? 'Done!  ' : 'Stopped.  ') + d.message; msg.style.color = d.ok ? 'var(--success)' : 'var(--error)'; meta.textContent = '';
      cancel.style.display = 'none'; closeBtn.style.display = ''; need.style.display = needBtn.style.display = 'none';
    }));
    start().then((ok) => { if (!ok) { msg.textContent = 'Another USB job is already running.'; cancel.style.display = 'none'; closeBtn.style.display = ''; } }).catch((e) => { msg.textContent = e.message; msg.style.color = 'var(--error)'; cancel.style.display = 'none'; closeBtn.style.display = ''; });
    return h('div', { class: 'modal', style: 'width:560px' }, h('h3', { text: title }), stages, overall, h('div', { style: 'height:6px' }), stageBar, h('div', { style: 'height:8px' }), msg, meta, need, h('div', { style: 'margin-top:6px' }, needBtn),
      h('div', { class: 'f10 c-warn', text: 'Do not unplug the stick or close DWUT until this finishes.', style: 'margin-top:10px' }), h('div', { class: 'foot' }, cancel, closeBtn));
  });
}


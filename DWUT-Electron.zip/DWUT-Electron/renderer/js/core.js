'use strict';
/* DWUT renderer core: DOM builder, widgets, theme engine, RPC, dialogs */

// ── DOM builder ──────────────────────────────────────────────────────────────
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style') { if (typeof v === 'string') el.style.cssText = v; else Object.assign(el.style, v); }
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmt = {
  mb: (n) => (n >= 1024 ? (n / 1024).toFixed(2) + ' GB' : n.toFixed(1) + ' MB'),
  bytes(b) { for (const u of ['B', 'KB', 'MB', 'GB', 'TB']) { if (b < 1024) return b.toFixed(u === 'B' ? 0 : 1) + ' ' + u; b /= 1024; } return b.toFixed(1) + ' PB'; },
};

// ── RPC / events ─────────────────────────────────────────────────────────────
async function rpc(method, params) {
  try { return await window.dwut.call(method, params || {}); }
  catch (e) { console.error('rpc', method, e); throw new Error(String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); }
}
const on = (name, fn) => window.dwut.on(name, fn);

// ── theme engine ─────────────────────────────────────────────────────────────
const Theme = {
  name: 'dark', tokens: {},
  apply(name) {
    const T = window.DW_THEMES;
    if (!T.themes[name]) name = 'dark';
    this.name = name;
    this.tokens = Object.assign({}, T.base, T.themes[name]);
    const st = document.documentElement.style;
    for (const [k, v] of Object.entries(this.tokens)) st.setProperty('--' + k, v);
    if (this._textOverride) st.setProperty('--text_primary', this._textOverride);
    document.documentElement.dataset.light = T.light.includes(name) ? '1' : '0';
    try {
      localStorage.setItem('dwut_theme', name);
      if (typeof ipcRenderer !== 'undefined') {
        ipcRenderer.send('tm:theme-push', { name, tokens: this.tokens, light: T.light.includes(name) });
      } else if (window.ipcRenderer) {
        window.ipcRenderer.send('tm:theme-push', { name, tokens: this.tokens, light: T.light.includes(name) });
      }
    } catch {}
  },
  typography(font, scale, textColor) {
    const st = document.documentElement.style;
    if (font) st.setProperty('--font', `"${font}"`);
    if (scale) st.setProperty('--fs', String(Math.max(0.7, Math.min(1.5, scale))));
    this._textOverride = textColor || '';
    if (textColor) st.setProperty('--text_primary', textColor);
    else if (this.tokens.text_primary) st.setProperty('--text_primary', this.tokens.text_primary);
  },
};

// ── tooltip ──────────────────────────────────────────────────────────────────
let _tip;
function tip(el, text) {
  if (!text) return el;
  if (!_tip) { _tip = h('div', { id: 'tooltip' }); document.body.appendChild(_tip); }
  const place = (e) => {
    _tip.style.display = 'block';
    const w = _tip.offsetWidth, hh = _tip.offsetHeight;
    let x = e.clientX + 12, y = e.clientY + 12;
    if (x + w > innerWidth) x = e.clientX - w - 4;
    if (y + hh > innerHeight) y = e.clientY - hh - 4;
    _tip.style.left = Math.max(0, x) + 'px'; _tip.style.top = Math.max(0, y) + 'px';
  };
  el.addEventListener('mouseenter', (e) => { _tip.textContent = text; place(e); });
  el.addEventListener('mousemove', place);
  el.addEventListener('mouseleave', () => { _tip.style.display = 'none'; });
  el.addEventListener('mousedown', () => { _tip.style.display = 'none'; });
  return el;
}
const Info = (text, cls = '') => tip(h('i', { class: 'info ' + cls, text: 'i' }), text);

// ── widgets ──────────────────────────────────────────────────────────────────
function Btn(text, o = {}) {
  const v = o.variant || 'primary';
  const el = h('button', { class: `btn btn-${v} ${o.cls || ''}`, text, onclick: o.onclick });
  if (o.w) el.style.width = el.style.minWidth = o.w + 'px';
  if (o.h) el.style.height = o.h + 'px';
  if (o.f) el.style.fontSize = `max(8px,calc(${o.f}px*var(--fs)))`;
  if (o.bold) el.style.fontWeight = '700';
  if (o.style) Object.assign(el.style, o.style);
  if (o.tip) tip(el, o.tip);
  return el;
}
const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
function Check(label, o = {}) {
  const el = h('span', { class: `cb ${o.sm ? 'sm' : ''} ${o.themed ? 'themed' : ''}` });
  const box = h('span', { class: 'box', html: CHECK_SVG });
  const txt = label ? h('span', { class: 'ct ' + (o.f ? '' : 'f12'), text: label, style: o.color ? { color: o.color } : null }) : null;
  if (o.f && txt) txt.style.fontSize = `max(8px,calc(${o.f}px*var(--fs)))`;
  el.append(box); if (txt) el.append(txt);
  el.checked = !!o.checked;
  const paint = () => el.classList.toggle('on', el.checked);
  el.set = (v, silent) => { el.checked = !!v; paint(); if (!silent && o.onchange) o.onchange(el.checked); };
  el.toggle = () => { if (!el.classList.contains('dis')) el.set(!el.checked); };
  el.disable = (d) => el.classList.toggle('dis', d);
  el.addEventListener('click', () => el.toggle());
  paint();
  return el;
}
function Switch(o = {}) {
  const el = h('span', { class: 'sw ' + (o.big ? 'big' : '') });
  el.checked = !!o.checked;
  const paint = () => el.classList.toggle('on', el.checked);
  el.set = (v, silent) => { el.checked = !!v; paint(); if (!silent && o.onchange) o.onchange(el.checked); };
  el.addEventListener('click', () => el.set(!el.checked));
  paint();
  return el;
}
function Progress(o = {}) {
  const bar = h('div', { class: 'pbar', style: { height: (o.height || 8) + 'px', borderRadius: (o.radius ?? (o.height || 8) / 2) + 'px' } });
  const fill = h('i');
  if (o.color) fill.style.background = o.color;
  bar.append(fill);
  bar.set = (v) => { bar.classList.remove('indet'); fill.style.width = Math.max(0, Math.min(1, v)) * 100 + '%'; };
  bar.indeterminate = (on = true) => bar.classList.toggle('indet', on);
  bar.set(o.value || 0);
  return bar;
}
function Entry(o = {}) {
  const el = h('input', { class: 'entry ' + (o.fill ? 'fill ' : '') + (o.cls || ''), type: o.password ? 'password' : 'text', placeholder: o.placeholder || '', spellcheck: 'false' });
  if (o.w) el.style.width = o.w + 'px';
  if (o.h) el.style.height = o.h + 'px';
  if (o.f) el.style.fontSize = `max(8px,calc(${o.f}px*var(--fs)))`;
  if (o.value != null) el.value = o.value;
  if (o.onchange) el.addEventListener('input', () => o.onchange(el.value));
  if (o.onenter) el.addEventListener('keydown', (e) => { if (e.key === 'Enter') o.onenter(el.value); });
  return el;
}
function Textbox(o = {}) {
  const el = h('div', { class: 'textbox ' + (o.cls || '') });
  if (o.h) el.style.height = o.h + 'px';
  if (o.f) el.style.fontSize = `max(8px,calc(${o.f}px*var(--fs)))`;
  el.max = o.max || 500;
  el.line = (text, color) => {
    const row = h('div', { text, style: color ? { color } : null });
    const stick = el.scrollTop + el.clientHeight >= el.scrollHeight - 8;
    el.append(row);
    while (el.childNodes.length > el.max) el.removeChild(el.firstChild);
    if (stick) el.scrollTop = el.scrollHeight;
  };
  el.clear = () => { el.textContent = ''; };
  el.text = () => [...el.childNodes].map((n) => n.textContent).join('\n');
  return el;
}
function Option(values, o = {}) {
  const t = h('span', { class: 't' });
  const el = h('div', { class: 'opt', style: { width: (o.w || 140) + 'px' } }, t, h('span', { class: 'a', text: '▼' }));
  if (o.f) el.style.fontSize = `max(8px,calc(${o.f}px*var(--fs)))`; else el.classList.add('f12');
  el.values = values;
  el.value = o.value ?? values[0];
  const paint = () => { t.textContent = el.label ? el.label(el.value) : el.value; };
  el.setValues = (vs, keep) => { el.values = vs; if (!keep || !vs.includes(el.value)) el.value = vs[0]; paint(); };
  el.set = (v, silent) => { el.value = v; paint(); if (!silent && o.onchange) o.onchange(v); };
  el.label = o.label || null;
  el.addEventListener('click', (e) => {
    e.stopPropagation();
    closeMenus();
    const r = el.getBoundingClientRect();
    const pop = h('div', { class: 'menu-pop f11', style: { left: r.left + 'px', top: r.bottom + 2 + 'px', minWidth: r.width + 'px' } });
    for (const v of el.values) pop.append(h('div', { text: el.label ? el.label(v) : v, onclick: () => { closeMenus(); el.set(v); } }));
    document.body.append(pop);
    if (r.bottom + pop.offsetHeight > innerHeight) pop.style.top = Math.max(4, r.top - pop.offsetHeight - 2) + 'px';
  });
  paint();
  return el;
}
function closeMenus() { $$('.menu-pop').forEach((n) => n.remove()); }
document.addEventListener('click', closeMenus);

const Card = (kids, cls = '', style) => h('div', { class: 'card ' + cls, style }, kids);
const Lbl = (text, cls = '', style) => h('span', { class: 'lbl ' + cls, text, style });
const Sp = (w, hgt) => h('div', { style: { width: (w || 0) + 'px', height: (hgt || 0) + 'px', flex: 'none' } });

// ── modal dialogs ────────────────────────────────────────────────────────────
const Modal = {
  show(node) {
    const host = $('#modal-host'); host.textContent = ''; host.append(node); host.classList.add('on');
  },
  close() { const host = $('#modal-host'); host.classList.remove('on'); host.textContent = ''; },
  custom(build) {           // build(close) => node ; resolves when closed via close(value)
    return new Promise((res) => {
      const close = (v) => { Modal.close(); res(v); };
      Modal.show(build(close));
    });
  },
  alert(title, message, o = {}) {
    return Modal.custom((close) => h('div', { class: 'modal' },
      h('h3', { text: title, class: 'b', style: o.color ? { color: o.color } : null }),
      h('div', { class: 'body f12', text: message }),
      h('div', { class: 'foot' }, Btn('OK', { w: 90, onclick: () => close(true) }))));
  },
  confirm(title, message, o = {}) {
    return Modal.custom((close) => h('div', { class: 'modal' },
      h('h3', { text: title, class: 'b' }),
      h('div', { class: 'body f12', text: message }),
      h('div', { class: 'foot' },
        Btn(o.no || 'No', { variant: 'ghost', w: 90, onclick: () => close(false) }),
        Btn(o.yes || 'Yes', { variant: o.danger ? 'danger' : 'primary', w: 90, onclick: () => close(true) }))));
  },
};
const notify = (t, m) => Modal.alert(t, m);
const warn = (t, m) => Modal.alert(t, m, { color: 'var(--warning)' });
const fail = (t, m) => Modal.alert(t, m, { color: 'var(--error)' });

// ── page registry / periodic timers ──────────────────────────────────────────
const Pages = { factories: {}, register(name, fn) { this.factories[name] = fn; } };
const Cfg = { v: {}, async load() { this.v = await rpc('config.get'); return this.v; },
  set(values) { Object.assign(this.v, values); return rpc('config.set', { values }); } };

// text helper for copy
function copyText(t) { try { window.dwut.copy(t); } catch { navigator.clipboard?.writeText(t); } }
// title row used by most pages
function TitleRow(title, right) {
  return h('div', { class: 'title-row' }, h('h1', { text: title }), h('div', { class: 'grow' }), right || null);
}

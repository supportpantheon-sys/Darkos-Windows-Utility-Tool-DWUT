'use strict';
Pages.register('gaming', () => {
  // ─────────────── FPS unlocker panel ───────────────
  const fpsBadge = h('span', { class: 'f11 b c-err', text: 'OFF' });
  const gameLabel = h('div', { class: 'f11 ts', text: 'Roblox: not running', style: 'padding:0 14px 4px' });
  const valLabel = h('span', { class: 'f14 b c-acc', text: '240', style: 'width:50px;margin-left:8px;text-align:center' });
  const slider = h('input', { type: 'range', class: 'slider', min: 60, max: 1000, step: 10, value: 240 });
  const paintSlider = () => slider.style.setProperty('--pct', ((slider.value - 60) / 940) * 100 + '%');
  paintSlider();
  slider.addEventListener('input', () => { valLabel.textContent = slider.value; paintSlider(); rpc('gaming.fps_target', { fps: +slider.value }); });
  const setPreset = (f) => { slider.value = f; valLabel.textContent = f; paintSlider(); rpc('gaming.fps_target', { fps: f }); };
  const enableBtn = Btn('Enable FPS Unlock', { h: 36, cls: 'fill', style: { marginRight: '4px' }, onclick: () => rpc('gaming.fps_enable') });
  const stopBtn = Btn('Stop', { variant: 'ghost', h: 36, cls: 'fill', style: { marginLeft: '4px' }, onclick: () => rpc('gaming.fps_disable') });
  stopBtn.disabled = true;
  const fpsLog = Textbox({ f: 10, max: 100 }); fpsLog.style.margin = '0 12px 12px'; fpsLog.style.flex = '1'; fpsLog.style.minHeight = '130px';
  const warnFps = h('div', { class: 'f10 c-warn', style: 'text-align:center;padding:0 12px 10px;max-width:340px;align-self:center', text: '  Edits the game\'s own settings file — no memory modification, anti-cheat safe.  Restart the game after enabling.' });
  let games = [{ id: 'roblox', name: 'Roblox', note: '' }], curGame = games[0];
  const gameOpt = Option(['Roblox'], { w: 170, f: 11, onchange: (name) => {
    curGame = games.find((g) => g.name === name) || curGame;
    gameLabel.textContent = `${curGame.name}: not running`; note.textContent = curGame.note;
    rpc('gaming.fps_game', { game: curGame.id });
  } });
  const note = h('div', { class: 'f10 ts', style: 'padding:0 14px 2px' });
  rpc('gaming.fps_games').then((g) => { games = g; curGame = g[0]; gameOpt.setValues(g.map((x) => x.name)); gameLabel.textContent = `${curGame.name}: not running`; note.textContent = curGame.note; }).catch(() => {});
  const fpsCard = Card([
    h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:6px;margin:12px 12px 8px;padding:8px 12px' }, h('span', { class: 'f14 b tp', text: 'FPS Unlocker' }), h('div', { class: 'grow' }), fpsBadge),
    h('div', { class: 'row', style: 'padding:0 14px 6px;gap:8px' }, h('span', { class: 'f11 ts', text: 'Game:' }), gameOpt),
    note, gameLabel,
    h('div', { class: 'f12 tp', text: 'Target FPS', style: 'padding:8px 14px 2px' }),
    h('div', { class: 'row', style: 'padding:0 14px' }, slider, valLabel),
    h('div', { class: 'row wrap', style: 'padding:8px 14px;gap:4px 0' }, h('span', { class: 'f11 ts', text: 'Presets:', style: 'margin-right:2px' }),
      [60, 120, 144, 165, 240, 360, 500].map((f) => {
        const b = h('button', { class: 'btn f11', text: String(f), style: 'width:46px;min-width:46px;height:26px;border-radius:4px;background:var(--bg_input);color:var(--text_primary);margin:0 2px', onclick: () => setPreset(f) });
        b.onmouseenter = () => { b.style.background = 'var(--bg_hover)'; }; b.onmouseleave = () => { b.style.background = 'var(--bg_input)'; };
        return b;
      })),
    h('div', { class: 'row', style: 'padding:4px 14px 8px' }, enableBtn, stopBtn),
    h('div', { class: 'f11 ts', text: 'Activity', style: 'padding:4px 14px 2px' }), fpsLog, warnFps], 'col', { flex: '1', minWidth: 0 });

  const fl = (line) => fpsLog.line(String(line).replace(/\s+$/, ''));
  on('gaming.fps_status', (s) => {
    if (!s) return;
    fpsBadge.textContent = s.active ? 'ON' : 'OFF'; fpsBadge.style.color = s.active ? 'var(--success)' : 'var(--error)';
    gameLabel.textContent = s.roblox_running ? `${s.game_name}: running (PID ${s.roblox_pid})` : `${s.game_name}: not running`;
    enableBtn.disabled = s.active; stopBtn.disabled = !s.active;
    if (games.length && s.game && curGame.id !== s.game) { curGame = games.find((g) => g.id === s.game) || curGame; gameOpt.set(curGame.name, true); note.textContent = curGame.note; }
    fl(`[Status] ${s.message}`);
  });
  on('gaming.roblox_gone', () => { gameLabel.textContent = `${curGame.name}: closed — waiting for restart`; fl(`[Warning] ${curGame.name} closed — settings stay applied for the next launch`); });

  // ─────────────── Game Booster panel ───────────────
  const boostBadge = h('span', { class: 'f11 b ts', text: 'OFF' });
  const nameEntry = Entry({ placeholder: 'e.g. Rust, Fortnite — or leave empty to auto-detect', fill: true, h: 32, f: 12 });
  nameEntry.style.width = 'auto'; nameEntry.style.margin = '0 14px 8px'; nameEntry.style.flex = 'none';
  const labels = {};
  const resRow = (key) => {
    const v = h('span', { class: 'f11 tp', text: '—' }); labels[key] = v;
    return h('div', { class: 'row', style: 'padding:1px 0' }, h('span', { class: 'f11 ts', text: key + ':', style: 'width:110px' }), v);
  };
  const progress = h('div', { class: 'f10 ts', style: 'padding:0 14px;min-height:16px' });
  const notes = h('div', { class: 'f10 ts', style: 'padding:2px 14px 0;white-space:pre-wrap' });
  const applyBtn = Btn('Apply Boost', { h: 36, cls: 'fill', style: { marginRight: '4px' }, onclick: () => openBoostDialog() });
  const restoreBtn = Btn('Restore', { variant: 'ghost', h: 36, cls: 'fill', style: { marginLeft: '4px' }, onclick: () => rpc('gaming.boost_restore') });
  restoreBtn.disabled = true;
  const acts = ['Closes the background apps you approve (keep Discord etc.)', 'Auto-detects your game — or uses the name you typed', 'Sets game process to HIGH priority (real win32 call)',
    'Activates a performance power plan (verified, best your PC supports)', 'Enables Hardware GPU Scheduling (registry)', 'Disables Xbox Game Bar & capture (registry)',
    'Measures real RAM freed', 'Restores all settings on deactivate'];
  const boostCard = Card([
    h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:6px;margin:12px 12px 8px;padding:8px 12px' }, h('span', { class: 'f14 b tp', text: 'Game Booster' }), h('div', { class: 'grow' }), boostBadge),
    h('div', { class: 'f11 ts', text: 'Game name (optional)', style: 'padding:4px 14px 2px' }), nameEntry,
    h('div', { style: 'background:var(--bg_input);border-radius:6px;margin:0 12px 8px;padding:8px 10px 6px' },
      h('div', { class: 'f11 b tp', text: 'What this does:', style: 'padding-bottom:4px' }), acts.map((a) => h('div', { class: 'f10 ts', text: '   ' + a, style: 'padding:1px 0' }))),
    h('div', { style: 'padding:4px 14px 4px' }, ['Game', 'RAM Freed', 'Power Plan', 'Priority', 'GPU Scheduling'].map(resRow)),
    progress, notes,
    h('div', { class: 'grow' }),
    h('div', { class: 'row', style: 'padding:8px 14px' }, applyBtn, restoreBtn),
    h('div', { class: 'f10 c-warn', style: 'text-align:center;padding:0 12px 12px', text: '  All changes are restored on deactivate.  Requires administrator.' })], 'col', { flex: '1', minWidth: 0 });

  const setL = (k, t, c) => { labels[k].textContent = t; labels[k].style.color = c || 'var(--text_primary)'; };
  on('gaming.boost_progress', (d) => { progress.textContent = d && d.step ? '⏳ ' + d.step : ''; if (d && d.step && /^Detected/.test(d.step)) { setL('Priority', 'High', 'var(--success)'); setL('Game', d.step.replace(/ — priority set$/, ''), 'var(--success)'); } });
  on('gaming.boost_error', (d) => { progress.textContent = ''; applyBtn.disabled = false; fail('Boost failed', d.message); });
  on('gaming.boost_changed', (r) => {
    progress.textContent = '';
    if (r == null) {
      boostBadge.textContent = 'OFF'; boostBadge.style.color = 'var(--text_secondary)'; applyBtn.disabled = false; restoreBtn.disabled = true;
      for (const k of Object.keys(labels)) setL(k, '-'); notes.textContent = '';
    } else {
      boostBadge.textContent = 'ACTIVE'; boostBadge.style.color = 'var(--success)'; applyBtn.disabled = true; restoreBtn.disabled = false;
      setL('Game', r.game_pid ? `${r.game_name}${r.auto_detected ? ' (auto-detected)' : ''}` : `${r.game_name} (waiting for launch)`, r.game_pid ? 'var(--success)' : 'var(--text_primary)');
      setL('RAM Freed', `${r.ram_freed_mb.toFixed(1)} MB (measured)`, 'var(--success)');
      setL('Power Plan', r.power_plan_applied || 'Failed', r.power_plan_applied ? 'var(--success)' : 'var(--error)');
      setL('Priority', r.priority_applied ? 'High' : 'Not applied', r.priority_applied ? 'var(--success)' : 'var(--warning)');
      setL('GPU Scheduling', r.gpu_scheduling_enabled ? 'Enabled' : 'Not applied', r.gpu_scheduling_enabled ? 'var(--success)' : 'var(--warning)');
      const lines = [];
      if (r.terminated && r.terminated.length) lines.push('Closed: ' + r.terminated.join(', '));
      (r.notes || []).forEach((n) => lines.push('• ' + n));
      notes.textContent = lines.join('\n');
    }
  });

  // exclusion popup
  async function openBoostDialog() {
    applyBtn.disabled = true; progress.textContent = '⏳ Scanning running apps…';
    let cands = [];
    try { cands = await rpc('gaming.boost_candidates'); } catch (e) { progress.textContent = ''; applyBtn.disabled = false; return fail('Boost', e.message); }
    progress.textContent = '';
    const gameName = nameEntry.value.trim();
    const checks = [];
    const groups = [['background', 'Background apps — will be closed'], ['heavy', 'Other heavy apps (off by default)'], ['browser', 'Browsers (off by default — closing loses open tabs)']];
    const result = await Modal.custom((close) => {
      const list = h('div', { class: 'scroll', style: 'max-height:300px;margin-top:6px;padding-right:6px' });
      for (const [kind, title] of groups) {
        const items = cands.filter((c) => c.kind === kind);
        if (!items.length) continue;
        list.append(h('div', { class: 'f11 b c-acc', text: title, style: 'margin:8px 0 4px' }));
        for (const c of items) {
          const cb = Check('', { sm: true, checked: c.checked, themed: true }); checks.push([c, cb]);
          const row = h('div', { class: 'row', style: 'padding:4px 6px;border-radius:4px;cursor:pointer;gap:8px', onclick: (e) => { if (!cb.contains(e.target)) cb.toggle(); } },
            cb, h('span', { class: 'f12 tp grow ell', text: c.name.replace(/\.exe$/i, '') }), h('span', { class: 'f10 ts', text: `${c.count > 1 ? c.count + ' processes · ' : ''}${c.ram_mb.toFixed(0)} MB` }));
          row.onmouseenter = () => { row.style.background = 'var(--bg_hover)'; }; row.onmouseleave = () => { row.style.background = ''; };
          list.append(row);
        }
      }
      if (!checks.length) list.append(h('div', { class: 'f12 ts', text: 'No closable background apps found — the rest of the boost will still be applied.', style: 'padding:10px 0' }));
      return h('div', { class: 'modal', style: 'min-width:440px' },
        h('h3', { text: 'Game Boost — choose what to close' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: `Untick anything you want to KEEP running (e.g. Discord). System processes, drivers and anti-cheat are never touched.\n${gameName ? `Game: ${gameName}` : 'No game name typed — the game will be detected automatically after these apps are closed.'}` }),
        list,
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Boost', { w: 110, onclick: () => close(checks.filter(([, cb]) => cb.checked).map(([c]) => c.name.toLowerCase())) })));
    });
    if (result === null) { applyBtn.disabled = false; return; }
    progress.textContent = '⏳ Starting boost…';
    rpc('gaming.boost_apply', { game_name: gameName, only: result }).catch((e) => { applyBtn.disabled = false; fail('Boost failed', e.message); });
  }

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0;overflow-y:auto' },
    h('div', { class: 'f18 b', text: 'Gaming Suite', style: 'padding:16px 20px 12px' }),
    h('div', { class: 'row', style: 'flex:1;min-height:0;padding:0 20px 16px;align-items:stretch;gap:8px' }, fpsCard, boostCard));
  return { el };
});

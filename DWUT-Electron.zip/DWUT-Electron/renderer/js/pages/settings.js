'use strict';
/* Settings page + HSV colour picker (ring + square, same layout as the original dialog) */
function openColorPicker(initial, onSelect) {
  const BG = '#1a1a2e', BG2 = '#16213e', TXT = '#e0e0e0';
  const RO = 140, RI = 104, SQ = 96, D = RO * 2 + 4, C = RO + 2;
  let hh = 0, ss = 1, vv = 1, dragging = null;
  const hsv2rgb = (h, s, v) => { const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s); const m = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6]; return m.map((x) => Math.round(x * 255)); };
  const rgb2hsv = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0; if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h /= 6; if (h < 0) h += 1; } return [h, mx ? d / mx : 0, mx]; };
  const hex = () => '#' + hsv2rgb(hh, ss, vv).map((x) => x.toString(16).padStart(2, '0')).join('');
  const setHex = (s) => { const m = /^#?([0-9a-f]{6})$/i.exec(s.trim()); if (!m) return false; const n = parseInt(m[1], 16); [hh, ss, vv] = rgb2hsv(n >> 16, (n >> 8) & 255, n & 255); return true; };
  try { setHex(initial); } catch { /* ignore */ }
  const recent = (openColorPicker._recent = openColorPicker._recent || []);
  return Modal.custom((close) => {
    const cv = h('canvas', { width: D, height: D, style: `width:${D}px;height:${D}px;display:block;margin:0 auto 10px` });
    const ctx = cv.getContext('2d');
    const swatch = h('div', { style: 'width:44px;height:44px;margin-right:10px;border-radius:2px' });
    const hexIn = h('input', { class: 'entry', style: `background:${BG2};color:${TXT};border:0;width:110px;height:36px;font-size:14px;border-radius:2px` });
    const recWrap = h('div', { class: 'row', style: 'gap:4px;margin:2px 0 8px;min-height:32px' });
    const draw = () => {
      ctx.clearRect(0, 0, D, D);
      for (let i = 0; i < 360; i++) {
        const a1 = ((i - 1) * Math.PI) / 180, a2 = ((i + 1) * Math.PI) / 180, [r, g, b] = hsv2rgb(i / 360, 1, 1);
        ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.beginPath();
        ctx.moveTo(C + RO * Math.cos(a1), C - RO * Math.sin(a1)); ctx.lineTo(C + RO * Math.cos(a2), C - RO * Math.sin(a2));
        ctx.lineTo(C + RI * Math.cos(a2), C - RI * Math.sin(a2)); ctx.lineTo(C + RI * Math.cos(a1), C - RI * Math.sin(a1)); ctx.fill();
      }
      const x0 = C - SQ / 2, y0 = C - SQ / 2, ST = 24, st = SQ / ST;
      for (let vi = 0; vi < ST; vi++) for (let si = 0; si < ST; si++) { const [r, g, b] = hsv2rgb(hh, si / (ST - 1), 1 - vi / (ST - 1)); ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.fillRect(x0 + si * st, y0 + vi * st, st + 1, st + 1); }
      const ang = hh * 2 * Math.PI, mr = (RO + RI) / 2; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(C + mr * Math.cos(ang), C - mr * Math.sin(ang), 7, 0, 7); ctx.stroke();
      const mx = x0 + ss * SQ, my = y0 + (1 - vv) * SQ; ctx.beginPath(); ctx.arc(mx, my, 6, 0, 7); ctx.stroke(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(mx, my, 4, 0, 7); ctx.stroke();
      swatch.style.background = hex(); if (hexIn.value.toLowerCase() !== hex()) hexIn.value = hex();
    };
    const pos = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    const upd = (x, y) => {
      if (dragging === 'ring') { hh = ((Math.atan2(C - y, x - C) / (2 * Math.PI)) % 1 + 1) % 1; }
      else if (dragging === 'sq') { const x0 = C - SQ / 2, y0 = C - SQ / 2; ss = Math.max(0, Math.min(1, (x - x0) / SQ)); vv = Math.max(0, Math.min(1, 1 - (y - y0) / SQ)); }
      draw();
    };
    cv.addEventListener('mousedown', (e) => {
      const [x, y] = pos(e), dist = Math.hypot(x - C, y - C);
      if (dist > RI && dist <= RO) dragging = 'ring';
      else if (dist <= (SQ / 2) * 1.42 && x >= C - SQ / 2 && x <= C + SQ / 2 && y >= C - SQ / 2 && y <= C + SQ / 2) dragging = 'sq';
      if (dragging) upd(x, y);
    });
    const mv = (e) => { if (dragging) upd(...pos(e)); }, up = () => { dragging = null; };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
    hexIn.addEventListener('input', () => { if (setHex(hexIn.value)) draw(); });
    const paintRecent = () => { recWrap.textContent = ''; recent.slice(-8).forEach((c) => recWrap.append(h('div', { style: `width:32px;height:32px;background:${c};cursor:pointer;border-radius:2px`, onclick: () => { setHex(c); draw(); } }))); };
    const done = (v) => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); close(v); };
    const box = h('div', { class: 'modal', style: `background:${BG};border-color:#2d2d4e;padding:16px;min-width:340px;width:340px` }, cv,
      h('div', { class: 'row', style: 'margin-bottom:8px' }, swatch, hexIn),
      h('div', { class: 'f9', style: 'color:#666680', text: 'Recent' }), recWrap,
      h('div', { class: 'row', style: 'gap:8px;margin-top:4px' },
        h('button', { class: 'btn f11 b', text: 'Select', style: `width:auto;min-width:0;padding:0 18px;height:34px;border-radius:0;background:${Theme.tokens.accent};color:#fff`, onclick: () => { const c = hex(); if (!recent.includes(c)) recent.push(c); done(c); } }),
        h('button', { class: 'btn f11 b', text: 'Cancel', style: `width:auto;min-width:0;padding:0 18px;height:34px;border-radius:0;background:${BG2};color:${TXT}`, onclick: () => done(null) })));
    paintRecent(); setTimeout(draw, 0);
    return box;
  }).then((c) => { if (c) onSelect(c); });
}

Pages.register('settings', () => {
  const C = Cfg.v;
  const saved = h('span', { class: 'f11 c-ok' });
  const FONTS = ['Segoe UI Variable', 'Segoe UI', 'Inter', 'Roboto', 'Arial', 'Calibri', 'Verdana', 'Tahoma', 'Consolas', 'Courier New'];
  const SCALES = { 'Small (85%)': 0.85, 'Normal (100%)': 1.0, 'Large (110%)': 1.10, 'Larger (120%)': 1.20 };
  const hdr = (title, tipText) => h('div', { class: 'row', style: 'padding:12px 14px 8px' }, h('span', { class: 'f13 b tp', text: title }), tipText ? h('span', { style: 'margin-left:6px' }, Info(tipText)) : null);
  const row = (label, tipText, widget) => h('div', { class: 'row', style: 'padding:4px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: label }), h('span', { style: 'margin-left:4px' }, Info(tipText))), widget);
  const toggles = {}, ints = {}, combos = {};

  // ── appearance ──
  const themeHolder = h('div');
  function renderThemes() {
    const T = window.DW_THEMES; themeHolder.textContent = '';
    for (let i = 0; i < T.order.length; i += 4) {
      const r = h('div', { class: 'row', style: 'padding:3px 14px' });
      T.order.slice(i, i + 4).forEach((key) => {
        const m = Object.assign({}, T.base, T.themes[key]), cur = key === Theme.name;
        const nameRow = h('div', { class: 'row', style: 'padding:0 4px' }, h('span', { class: 'f10 grow', text: T.names[key], style: `font-weight:${cur ? 700 : 400};color:${cur ? 'var(--accent)' : 'var(--text_secondary)'}` }),
          cur ? h('span', { class: 'f9 c-acc', text: 'Active' }) : Btn('Use', { variant: 'plain', w: 28, h: 18, f: 9, style: { minWidth: '28px', borderRadius: '4px', padding: '0' }, onclick: () => applyTheme(key) }));
        r.append(h('div', { class: 'col', style: `background:var(--bg_input);border-radius:8px;border:2px solid ${cur ? 'var(--accent)' : 'var(--border)'};width:110px;height:64px;margin:2px 5px;flex:none` },
          h('div', { class: 'row', style: `background:${m.bg_card};border-radius:6px;height:28px;margin:4px 4px 2px;justify-content:flex-end` }, h('div', { style: `background:${m.accent};border-radius:4px;width:24px;height:16px;margin-right:4px` })), nameRow));
      });
      themeHolder.append(r);
    }
  }
  async function applyTheme(key) {
    Theme.apply(key); Theme.typography(C.ui_font, C.ui_font_scale, C.ui_text_color);
    await Cfg.set({ theme: key }); renderThemes(); Sidebar.build(); typoPreview();
  }
  const appearance = Card([hdr('Appearance', 'Choose a colour theme for the entire application.\n\nDark/Midnight/Obsidian/Abyss — distinct dark surface palettes\nViolet/Crimson/Ember/Emerald — dark base tinted toward the accent\nNord/Dracula/Solarized       — popular programmer colour schemes\nHigh Contrast                — maximum readability\nDaylight/Paper               — light themes\n\nApplies instantly — the whole app redraws in the new theme.'),
    themeHolder, h('div', { class: 'f10 td', text: 'Theme changes apply instantly. The preview swatch shows accent + background colours.', style: 'padding:4px 14px 12px' })], 'col', { marginBottom: '12px' });

  // ── typography ──
  const fontOpt = Option(FONTS, { w: 190, value: C.ui_font || 'Segoe UI Variable', f: 11, onchange: () => typoPreview() });
  const curScale = Object.keys(SCALES).find((k) => Math.abs(SCALES[k] - (C.ui_font_scale || 1)) < 0.01) || 'Normal (100%)';
  const scaleOpt = Option(Object.keys(SCALES), { w: 170, value: curScale, f: 11, onchange: () => typoPreview() });
  combos.ui_font = fontOpt;
  const colorIn = Entry({ placeholder: '#RRGGBB', w: 100, h: 30, value: C.ui_text_color || Theme.tokens.text_primary, onchange: () => onColorInput() });
  const swatch = h('button', { style: 'width:38px;height:30px;border-radius:4px;border:2px solid var(--border);cursor:pointer;margin-left:6px', onclick: () => openColorPicker(colorIn.value.trim() || Theme.tokens.text_primary, (c) => { colorIn.value = c; onColorInput(); }) });
  tip(swatch, 'Click to open the full colour picker.');
  const preview = h('div', { class: 'f12', text: 'Preview: The quick brown fox jumps over the lazy dog', style: 'padding:2px 14px 6px' });
  const typoStatus = h('span', { class: 'f10 c-ok', style: 'margin-left:4px' });
  function onColorInput() {
    const v = colorIn.value.trim(), ok = /^#[0-9A-Fa-f]{6}$/.test(v);
    swatch.style.background = ok ? v : Theme.tokens.text_primary; typoPreview();
  }
  function typoPreview() {
    const size = Math.max(8, Math.floor(12 * (SCALES[scaleOpt.value] || 1)));
    preview.style.fontFamily = `"${fontOpt.value}", sans-serif`; preview.style.fontSize = size + 'px';
    preview.style.color = colorIn.value.trim() || Theme.tokens.text_primary;
  }
  const flash = (t, c) => { typoStatus.textContent = t; typoStatus.style.color = c; setTimeout(() => { typoStatus.textContent = ''; }, 3000); };
  async function applyTypo() {
    let raw = colorIn.value.trim(); if (raw && !raw.startsWith('#')) raw = '#' + raw;
    if (raw && !/^#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?$/.test(raw)) return flash('Invalid hex colour — use #RRGGBB', 'var(--error)');
    // the default (theme) colour means "no override"
    const override = raw.toLowerCase() === (Theme.tokens.text_primary || '').toLowerCase() ? '' : raw;
    const vals = { ui_font: fontOpt.value, ui_font_scale: SCALES[scaleOpt.value] || 1.0, ui_text_color: override };
    await Cfg.set(vals); Theme.typography(vals.ui_font, vals.ui_font_scale, vals.ui_text_color); flash('Applied!', 'var(--success)');
  }
  async function resetTypo() {
    await Cfg.set({ ui_font: 'Segoe UI Variable', ui_font_scale: 1.0, ui_text_color: '' });
    fontOpt.set('Segoe UI Variable', true); scaleOpt.set('Normal (100%)', true); colorIn.value = Theme.tokens.text_primary; onColorInput();
    Theme.typography('Segoe UI Variable', 1.0, ''); flash('Reset to default', 'var(--info)');
  }
  onColorInput();
  const typography = Card([hdr('Typography', 'Customise the font, text size, and colour used across the whole app.\n\nFont      — changes the typeface for all labels and buttons\nSize      — scales all font sizes (85 % – 120 %)\nColour    — overrides the primary text colour (picker or hex)\n\nClick Apply Typography to apply your changes instantly.'),
    row('Font family', 'The typeface used throughout the app.\n\nSegoe UI Variable is the sharpest on Windows 11.\nInter and Roboto are clean open-source alternatives.', fontOpt),
    row('Text size', 'Scale all font sizes up or down.\n85% = compact  |  100% = default  |  110%/120% = accessibility.', scaleOpt),
    h('div', { class: 'row', style: 'padding:4px 14px 2px' }, h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: 'Text colour' }), h('span', { style: 'margin-left:4px' }, Info('Override the primary text colour for the whole app.\n\nClick the colour swatch to open the picker.\nYou can also type a hex code directly (e.g. #FFD700).\nLeave blank or click Reset to use the theme default.'))),
      h('div', { class: 'row' }, colorIn, swatch)),
    preview, h('div', { class: 'row', style: 'padding:2px 14px 12px;gap:8px' }, Btn('Apply Typography', { h: 32, w: 160, onclick: applyTypo }), Btn('Reset to Default', { variant: 'ghost', h: 32, w: 130, onclick: resetTypo }), typoStatus)], 'col', { marginBottom: '12px' });

  // ── dashboard / safety ──
  const toggle = (label, tipText, attr) => { const sw = Switch({ big: true, checked: C[attr] }); toggles[attr] = sw; return row(label, tipText, sw); };
  const refresh = Entry({ w: 100, h: 28, value: String(C.dashboard_refresh_ms) }); ints.dashboard_refresh_ms = refresh;
  const dashboard = Card([h('div', { class: 'f13 b tp', text: 'Dashboard', style: 'padding:12px 14px 6px' }),
    row('Refresh interval (ms)', 'How often the Dashboard updates CPU, RAM, Disk, and GPU stats.\n\nLower = more responsive but uses slightly more CPU.\nDefault is 2000ms (2 seconds). Minimum is 500ms.', refresh),
    toggle('Show GPU stats', "Display GPU usage and temperature on the Dashboard.\n\nRequires OpenHardwareMonitor to be running. If OHM is not running, GPU cards will show 'N/A'.", 'show_gpu_stats'), h('div', { style: 'height:6px' })], 'col', { marginBottom: '12px' });
  const safety = Card([h('div', { class: 'f13 b tp', text: 'Safety', style: 'padding:12px 14px 6px' }),
    toggle('Auto-create restore point before destructive operations', 'Automatically creates a Windows System Restore point before running Debloat, Feature changes, or Registry Cleaner.\n\nStrongly recommended. Allows rolling back if something goes wrong.\nRequires System Protection to be enabled on the C: drive.', 'auto_restore_point'),
    toggle('Confirm before destructive operations', 'Show a confirmation dialog before deleting files, removing packages, or modifying the registry.\n\nDisable only if you are certain of what you are doing.', 'confirm_destructive'),
    toggle('Restore game boost settings when game closes', 'When the Game Booster detects the game process has exited, automatically restore the original power plan, process priority, and registry settings.\n\nKeeps your system in its normal state when you are not gaming.', 'restore_on_game_close'), h('div', { style: 'height:6px' })], 'col', { marginBottom: '12px' });

  // ── about ──
  const lines = [`Version       6`, `Python        ${C.python || ''}`, '', 'All operations use real Windows APIs — no simulated output, no fake numbers.', 'Every destructive action creates a restore point or backup first.', '', 'Built with Electron, psutil, requests, pywin32.'];
  const about = Card([h('div', { class: 'f13 b tp', text: 'About DWUT', style: 'padding:12px 14px 6px' }),
    lines.map((l) => (l ? h('div', { class: 'f11 ts', text: l, style: 'padding:1px 14px;white-space:pre' }) : h('div', { style: 'height:6px' }))),
    h('div', { class: 'row', style: 'padding:12px 14px;gap:8px' },
      Btn('Open Logs Folder', { variant: 'ghost', h: 30, tip: 'Open the folder containing dwut.log and rotated log files.', onclick: () => rpc('os.open_folder', { which: 'logs' }) }),
      Btn('Open Backups Folder', { variant: 'ghost', h: 30, cls: 'auto', tip: 'Open the folder containing .reg registry backups and debloat session JSON logs.', onclick: () => rpc('os.open_folder', { which: 'backups' }) }),
      Btn('Check for Updates', { variant: 'ghost', h: 30, tip: 'Open the DWUT GitHub page to see the latest release.', onclick: () => rpc('os.open_url', { url: 'https://github.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT' }) }))], 'col', { marginBottom: '20px' });

  async function save() {
    const v = {};
    const n = parseInt(refresh.value, 10); if (!Number.isNaN(n)) v.dashboard_refresh_ms = n;
    v.ui_font = fontOpt.value;
    for (const [k, sw] of Object.entries(toggles)) v[k] = sw.checked;
    await Cfg.set(v); saved.textContent = 'Saved'; setTimeout(() => { saved.textContent = ''; }, 3000);
  }
  renderThemes();
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'Settings' }), h('div', { class: 'grow' }), saved),
    h('div', { class: 'divider', style: 'margin:0 20px' }),
    h('div', { class: 'scroll', style: 'flex:1;padding:10px 20px 0' }, appearance, typography, dashboard, safety, about),
    h('div', { class: 'row', style: 'background:var(--bg_card);border:1px solid var(--border);height:52px;flex:none;justify-content:flex-end;padding:0 16px' }, Btn('Save All Settings', { h: 36, w: 180, onclick: save })));
  return { el };
});

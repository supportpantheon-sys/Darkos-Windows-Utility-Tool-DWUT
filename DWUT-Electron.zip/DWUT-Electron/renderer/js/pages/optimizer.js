'use strict';
Pages.register('optimizer', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (m) => { status.textContent = m; };
  const out = Textbox({ f: 10, max: 500, h: 140 });
  const log = (t) => out.line(String(t).replace(/\s+$/, ''));
  const call = (module, fn, args, bg) => rpc('call', { module, fn, args: args || [], bg: !!bg });
  const bg = (module, fn, args) => call(module, fn, args, true).catch((e) => log('Error: ' + e.message));
  const W = 'modules.system.winutil';
  const confirmRun = async (msg, fn) => { if (await Modal.confirm('Confirm', msg)) fn(); };

  // ── action rows ──
  function actionRow(name, desc, duration, cmd, variant) {
    return Card([
      h('div', { class: 'grow col', style: 'padding:10px 14px;align-items:flex-start' },
        h('span', { class: 'f12 b tp', text: name }), h('span', { class: 'f10 ts', text: desc })),
      h('div', { class: 'col', style: 'padding:10px 12px;align-items:flex-end' },
        duration !== '—' ? h('span', { class: 'f9 td', text: duration, style: 'margin-bottom:4px' }) : null,
        Btn('Run', { variant, h: 30, w: 70, onclick: cmd }))], 'row', { margin: '4px 0' });
  }
  const tabs = {};        // name -> {btn, frame, build, built}
  const content = h('div', { style: 'flex:1;min-height:0;margin:6px 0 4px;position:relative' });

  // ── REPAIRS ──
  function buildRepairs() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    const rows = [
      ['SFC /scannow', 'Scans and repairs protected Windows system files', '5–20 min', () => confirmRun('Run SFC /scannow?\nThis scans and repairs Windows system files.\nTakes 5–20 minutes.', () => bg(W, 'run_sfc')), 'ghost'],
      ['DISM RestoreHealth', 'Repairs the Windows component store from Windows Update', '10–30 min', () => confirmRun('Run DISM /RestoreHealth?\nTakes 10–30 minutes and requires internet access.', () => bg(W, 'run_dism')), 'ghost'],
      ['SFC + DISM (Recommended)', 'Runs SFC first, then DISM — the most thorough repair sequence', '15–50 min', () => confirmRun('Run SFC then DISM?\nThis is the most thorough repair — takes 15–50 minutes.', () => bg(W, 'run_sfc_then_dism')), 'primary'],
      ['Network Stack Reset', 'Resets TCP/IP, Winsock, firewall rules, and flushes DNS', '~30 sec', () => confirmRun('Reset network stack?\nThis resets TCP/IP, Winsock, and flushes DNS.\nA restart may be required.', () => bg(W, 'reset_network_stack')), 'ghost'],
      ['Winsock Reset', 'Resets the Windows Sockets catalog — fixes many connectivity issues', '~5 sec', () => bg(W, 'reset_winsock'), 'ghost'],
      ['Flush DNS Cache', 'Clears the DNS resolver cache', '~1 sec', () => bg(W, 'flush_dns'), 'ghost'],
      ['Windows Update Repair', 'Stops WU services, clears SoftwareDistribution cache, restarts services', '~2 min', () => confirmRun('Repair Windows Update?\nThis stops WU services, clears the download cache, and restarts them.', () => bg(W, 'repair_windows_update')), 'ghost'],
      ['Microsoft Store Repair', 'Re-registers and resets the Microsoft Store app', '~1 min', () => bg(W, 'repair_microsoft_store'), 'ghost'],
      ['WinGet Repair', 'Re-registers the Windows Package Manager (winget)', '~30 sec', () => bg(W, 'repair_winget'), 'ghost'],
      ['NTP Time Sync', 'Enables Windows Time service and force-syncs the clock against time.windows.com', '~5 sec', () => bg(W, 'enable_ntp_sync'), 'ghost'],
    ];
    rows.forEach((r) => f.append(actionRow(...r)));
    const user = Entry({ placeholder: 'Username', w: 160 });
    const pass = Entry({ placeholder: 'Password', w: 160, password: true });
    const enable = () => {
      const u = user.value.trim(), p = pass.value;
      if (!u || !p) return setStatus('Enter both a username and password for AutoLogon.');
      confirmRun(`Enable AutoLogon for '${u}'?\n\nWindows will sign in as this user automatically at boot, skipping the login screen entirely. The password is saved in the registry in a readable form.`,
        () => bg(W, 'enable_autologon', [u, p]));
    };
    f.append(Card([
      h('div', { class: 'f13 b tp', text: 'AutoLogon', style: 'padding:10px 14px 2px' }),
      h('div', { class: 'f10 ts', style: 'padding:0 14px 8px;max-width:600px;white-space:normal', text: "Skips the login screen and signs in as this user automatically at boot. The password is stored in the registry, readable by anyone with admin access to this PC — only use this on a machine you're the sole user of." }),
      h('div', { class: 'row', style: 'padding:0 14px 12px;gap:12px' }, user, pass, Btn('Enable', { h: 30, w: 90, onclick: enable }),
        Btn('Disable', { variant: 'ghost', h: 30, w: 90, onclick: () => bg(W, 'disable_autologon') }))], 'col', { marginTop: '10px' }));
    return f;
  }

  // ── CLEANUP ──
  function buildCleanup() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    f.append(h('div', { class: 'f11 ts', text: 'All cleanup operations measure actual bytes freed — no fake numbers.', style: 'margin-bottom:8px' }));
    const tempClean = async () => {
      log('Cleaning temp files…');
      try { const r = await call(W, 'clean_temp_files'); log(`Temp cleanup done — ${r.files_deleted} items deleted, ${r.mb_freed.toFixed(1)} MB freed`); setStatus(`Cleaned ${r.mb_freed.toFixed(1)} MB`); }
      catch (e) { log('Error: ' + e.message); }
    };
    const updClean = async () => {
      log('Clearing Windows Update cache…');
      try { const r = await call(W, 'clear_update_cache'); log(`Update cache cleared — ${r.mb_freed.toFixed(1)} MB freed`); } catch (e) { log('Error: ' + e.message); }
    };
    [['Clean Temp Files', 'Deletes files from %TEMP%, Windows\\Temp, INetCache, and Prefetch', '~10 sec', tempClean, 'primary'],
     ['Clear Windows Update Cache', 'Stops WU, clears SoftwareDistribution\\Download, restarts WU', '~30 sec', updClean, 'ghost'],
     ['Flush DNS Cache', 'Clears the DNS resolver cache', '~1 sec', () => bg(W, 'flush_dns'), 'ghost'],
     ['Open Disk Cleanup (System)', 'Launches the built-in Windows Disk Cleanup tool', '—', () => call(W, 'launch_tool', ['Disk Cleanup']), 'ghost']]
      .forEach((r) => f.append(actionRow(...r)));
    return f;
  }

  // ── TWEAKS ──
  let featureChecks = {}, winChecks = {}, ultSw, extSw, f8Sw;
  const built = { tweaks: null };
  function buildTweaks() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    const mk = (title, desc) => [h('div', { class: 'f13 b tp', text: title, style: 'padding:10px 14px 2px' }), desc ? h('div', { class: 'f10 ts', text: desc, style: 'padding:0 14px 6px;white-space:normal' }) : null];
    // power
    const powerBox = (label, color, tipText, onchange) => {
      const sw = Switch({ big: true, onchange });
      if (color) sw.style.setProperty('--accent', color);
      const lab = h('span', { class: 'f11 b tp', text: label });
      const box = h('div', { class: 'row grow', style: 'background:var(--bg_input);border-radius:6px;padding:8px 10px' }, lab, h('div', { class: 'grow' }), sw);
      tip(box, tipText);
      return [box, sw];
    };
    const [ultBox, us] = powerBox('Ultimate Performance', null, "Unhides and activates Windows' own built-in Ultimate Performance power plan.\n\nRemoves small background power-saving throttles Windows normally applies (core parking, idle timers). Uses somewhat more power than Balanced.\n\nFine for laptops plugged in; drains battery noticeably faster on battery power.", (on) => togglePlan(on, 'ult'));
    const [extBox, es] = powerBox('Extreme Performance', 'var(--error)', "NOT FOR LAPTOPS ON BATTERY.\n\nEverything Ultimate Performance does, plus: disables USB selective suspend, disables PCI Express Link State Power Management (ASPM), and pins the CPU minimum state to 100% so cores never downclock.\n\nMeant for a desktop, or a laptop that's plugged in and stationary — it noticeably increases power draw, heat, and fan noise, and will drain a laptop battery fast if used unplugged.", (on) => togglePlan(on, 'ext'));
    ultSw = us; extSw = es;
    async function togglePlan(on, which) {
      if (on) (which === 'ult' ? extSw : ultSw).set(false, true);
      log(on ? `Activating ${which === 'ult' ? 'Ultimate' : 'Extreme'} Performance power plan…` : 'Reverting to Balanced power plan…');
      const sw = which === 'ult' ? ultSw : extSw;
      try {
        const fn = on ? (which === 'ult' ? 'enable_ultimate_performance' : 'enable_extreme_performance') : 'revert_to_balanced';
        const [ok, msg] = await call('modules.system.power_modes', fn);
        log(msg); setStatus(msg);
        if (!ok) sw.set(!on, true);
      } catch (e) { log('Error: ' + e.message); sw.set(!on, true); }
    }
    rpc('optimizer.power_state').then(([u, e]) => { if (u) ultSw.set(true, true); if (e) extSw.set(true, true); }).catch(() => {});
    f.append(Card([...mk('Performance Plans — NOT FOR LAPTOPS ON BATTERY', "Ultimate Performance unhides Windows' own high-performance plan. Extreme goes further (USB/PCIe power-saving off, CPU pinned to 100%) — best for a desktop or a laptop that's staying plugged in, since it noticeably increases power draw and heat. Only one can be active at a time; turning one off reverts to Balanced."),
      h('div', { class: 'row', style: 'padding:2px 14px 12px;gap:12px' }, ultBox, extBox)], 'col', { marginBottom: '10px' }));
    // DNS
    const dns = Option(S.dns_presets, { w: 260, value: 'Cloudflare (1.1.1.1)' });
    dns.style.border = '2px solid var(--border)';
    f.append(Card([...mk('DNS Server', 'Change DNS on all active network adapters. Cloudflare (1.1.1.1) is fastest for most users.'),
      h('div', { class: 'row', style: 'padding:0 14px 10px;gap:8px' }, dns, Btn('Apply DNS', { h: 32, onclick: async () => {
        const preset = dns.value; log(`Setting DNS to ${preset}…`);
        try { const ok = await call(W, 'set_dns', [preset]); const m = ok ? `DNS set to ${preset}` : 'DNS change failed — check permissions'; log(m); setStatus(m); } catch (e) { log('Error: ' + e.message); }
      } }))], 'col', { marginBottom: '10px' }));
    // quick actions
    f.append(Card([h('div', { class: 'f13 b tp', text: 'Quick Actions', style: 'padding:10px 14px 6px' }),
      h('div', { class: 'row', style: 'padding:0 14px 12px;gap:8px' },
        Btn('Open Debloat & Privacy', { h: 32, onclick: () => Nav.go('debloat') }), Btn('Open Gaming Suite', { variant: 'ghost', h: 32, onclick: () => Nav.go('gaming') }),
        Btn('Flush DNS Cache', { variant: 'ghost', h: 32, onclick: () => bg(W, 'flush_dns') }),
        Btn('Reset Network Stack', { variant: 'ghost', h: 32, onclick: () => confirmRun('Reset TCP/IP, Winsock, and flush DNS?', () => bg(W, 'reset_network_stack')) }))], 'col', { marginBottom: '10px' }));
    // windows features
    winChecks = {};
    const wfGrid = h('div', { style: 'display:grid;grid-template-columns:repeat(3,1fr);padding:0 12px 4px' });
    S.win_features.forEach((wf, i) => {
      const sw = Switch({}); winChecks[wf.key] = sw;
      const short = wf.desc.length <= 78 ? wf.desc : wf.desc.slice(0, 75) + '…';
      const c = h('div', { class: 'col', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:6px;margin:3px;padding:8px;min-width:0;align-items:flex-start` },
        sw, h('div', { class: 'f11 b tp', text: wf.name, style: 'margin-top:2px;white-space:normal;max-width:210px' }), h('div', { class: 'f9 ts', text: short, style: 'white-space:normal;max-width:210px;margin-bottom:0' }));
      tip(c, wf.desc); wfGrid.append(c);
    });
    f8Sw = Switch({ big: true, onchange: async (on) => {
      try { const r = await call('modules.system.windows_features', on ? 'enable_legacy_f8_recovery' : 'disable_legacy_f8_recovery');
        log(`${r.tool} — ${r.success ? 'success' : 'failed'}`); setStatus(r.tool); if (!r.success) f8Sw.set(!on, true); } catch (e) { log('Error: ' + e.message); f8Sw.set(!on, true); }
    } });
    f.append(Card([...mk('Windows Features', 'Windows optional features, installed/removed via DISM. Some take a minute or two and may need a restart to finish.'),
      h('div', { class: 'row', style: 'padding:0 14px 4px' }, Btn('Install Selected Features', { h: 30, cls: 'auto', onclick: async () => {
        const keys = Object.keys(winChecks).filter((k) => winChecks[k].checked);
        if (!keys.length) return setStatus('Select at least one Windows feature to install.');
        const names = S.win_features.filter((w) => keys.includes(w.key)).map((w) => w.name);
        if (!(await Modal.confirm('Install Windows Features', `Install ${keys.length} feature(s)?\n\n` + names.map((n) => '• ' + n).join('\n') + '\n\nThis can take a few minutes. Some features need a restart to finish.'))) return;
        setStatus(`Installing ${keys.length} Windows feature(s)…`); rpc('optimizer.install_win_features', { keys });
      } })), wfGrid,
      h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:4px;margin:2px 14px;padding:8px 10px' }, h('span', { class: 'f11 b tp', text: 'Legacy F8 Boot Recovery Menu' }), h('div', { class: 'grow' }), f8Sw),
      h('div', { class: 'row', style: 'background:var(--bg_card);border-radius:4px;margin:2px 14px 12px;padding:8px 10px' }, h('span', { class: 'f11 b tp', text: 'Registry Backup (Daily Task, 12:30am)' }), h('div', { class: 'grow' }),
        Btn('Enable', { variant: 'ghost', h: 26, w: 80, onclick: () => bg('modules.system.windows_features', 'enable_registry_backup_task') }))], 'col', { marginBottom: '8px' }));
    // fixes
    const fixes = [['AutoLogon — Configure', () => switchTab('Repairs')], ['Network — Reset', () => confirmRun('Reset TCP/IP, Winsock, and flush DNS?', () => bg(W, 'reset_network_stack'))],
      ['NTP Server — Enable', () => bg(W, 'enable_ntp_sync')], ['System Corruption Scan — Run', () => bg(W, 'run_sfc_then_dism')],
      ['Windows Update — Reset', () => confirmRun('Reset Windows Update components? This can take a few minutes.', () => bg(W, 'repair_windows_update'))], ['WinGet — Reinstall', () => bg(W, 'repair_winget')]];
    f.append(Card([h('div', { class: 'f13 b tp', text: 'Fixes', style: 'padding:10px 14px 6px' }),
      h('div', { style: 'display:grid;grid-template-columns:repeat(3,1fr);padding:0 10px 8px' }, fixes.map(([l, c]) => Btn(l, { variant: 'ghost', h: 32, cls: 'fill', style: { margin: '4px', width: 'auto' }, onclick: c })))], 'col', { marginBottom: '8px' }));
    // tweak bar
    featureChecks = {};
    const setAll = (fn) => Object.entries(featureChecks).forEach(([k, s]) => s.set(fn(k), true));
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px 4px;gap:8px' }, h('span', { class: 'f11 ts', text: 'System Tweaks:' }),
        Btn('Recommended', { h: 30, onclick: () => setAll((k) => (S.features.find((x) => x.key === k) || {}).recommended) }),
        Btn('Select All', { variant: 'ghost', h: 30, onclick: () => setAll(() => true) }), Btn('Deselect All', { variant: 'ghost', h: 30, onclick: () => setAll(() => false) })),
      h('div', { class: 'row', style: 'padding:0 12px 10px;gap:8px' }, Btn('Apply Selected', { variant: 'danger', h: 30, onclick: async () => {
          const keys = Object.keys(featureChecks).filter((k) => featureChecks[k].checked);
          if (!keys.length) return setStatus('Select at least one tweak to apply.');
          const names = keys.map((k) => (S.features.find((x) => x.key === k) || {}).name).filter(Boolean);
          if (!(await Modal.confirm('Apply Tweaks', `Apply ${keys.length} changes?\n\n` + names.slice(0, 8).map((n) => '• ' + n).join('\n') + (names.length > 8 ? '\n…and more' : '') + '\n\nA restore point will be created first.\nSome changes require a restart to take effect.'))) return;
          setStatus(`Applying ${keys.length} tweaks…`); rpc('optimizer.apply_features', { keys });
        } }),
        Btn('Create Restore Point', { variant: 'ghost', h: 30, cls: 'auto', onclick: () => bg('modules.debloat.operations', 'create_restore_point') }))], 'col', { marginBottom: '8px' }));
    // sections
    const sev = { Critical: 'var(--error)', High: 'var(--warning)', Medium: '#FF9500', Low: 'var(--text_disabled)' };
    const feats = S.is_win11 ? S.features : S.features.filter((x) => !x.windows11_only);
    const section = (title, sub, items) => {
      f.append(h('div', { class: 'f13 b c-acc', text: title, style: 'padding:10px 4px 0' }));
      if (sub) f.append(h('div', { class: 'f10 ts', text: sub, style: 'padding:0 4px 6px' }));
      const g = h('div', { style: 'display:grid;grid-template-columns:repeat(3,1fr);padding:0 2px 4px' });
      items.forEach((ft, i) => {
        const sw = Switch({ checked: ft.recommended }); sw.style.setProperty('--sw-knob', 'var(--text_primary)'); featureChecks[ft.key] = sw;
        const short = ft.desc.length <= 78 ? ft.desc : ft.desc.slice(0, 75) + '…';
        const top = h('div', { class: 'row', style: 'width:100%;padding:0 0 2px' }, sw, h('div', { class: 'grow' }),
          h('span', { class: 'f9 b', text: ft.severity, style: `color:${sev[ft.severity] || 'var(--text_secondary)'};margin:0 2px` }),
          ft.recommended ? h('span', { class: 'f9 b c-ok', text: 'REC', style: 'background:#132b1d;border-radius:3px;padding:1px 4px;margin-left:4px' }) : null);
        const c = h('div', { class: 'col', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:4px;margin:3px;padding:8px;min-width:0;align-items:flex-start;border:${ft.recommended ? '1px solid var(--success)' : '1px solid transparent'}` },
          top, h('div', { class: 'f11 b tp', text: ft.name, style: 'white-space:normal;max-width:210px' }), h('div', { class: 'f9 ts', text: short, style: 'white-space:normal;max-width:210px' }));
        tip(c, ft.desc); g.append(c);
      });
      f.append(g);
    };
    section('Essential Tweaks', '', feats.filter((x) => x.category === 'essential'));
    section('Advanced Tweaks — CAUTION', 'These go further than the essentials above — read each description before enabling.', feats.filter((x) => x.category === 'advanced'));
    section('Customize Preferences', 'Cosmetic/UX toggles — taskbar, logon screen, Start Menu, accessibility.', feats.filter((x) => x.category === 'preference'));
    return f;
  }

  // ── CONFIG TOOLS ──
  function buildConfig() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    f.append(h('div', { class: 'f11 ts', text: 'Click any button to open the tool directly. Hover for a description.', style: 'margin-bottom:8px' }));
    let row;
    S.tools.forEach(([name, desc], i) => {
      if (i % 4 === 0) { row = h('div', { class: 'row', style: 'margin:3px 0' }); f.append(row); }
      const b = h('button', { class: 'btn f11', text: name, style: 'flex:1;width:auto;min-width:0;height:38px;margin:0 3px;background:var(--bg_card);border:1px solid var(--border);color:var(--text_primary)', onclick: () => call(W, 'launch_tool', [name]).catch(() => {}) });
      b.onmouseenter = () => { b.style.background = 'var(--bg_hover)'; }; b.onmouseleave = () => { b.style.background = 'var(--bg_card)'; };
      if (desc) tip(b, desc);
      row.append(b);
    });
    return f;
  }

  // ── UPDATES ──
  function buildUpdates() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    [['Check for Windows Updates', 'Triggers a Windows Update scan via UsoClient', '~5 sec', () => bg(W, 'check_for_updates'), 'primary'],
     ['Update All Apps (WinGet)', 'Runs winget upgrade --all to update every installed application', '5–30 min', () => confirmRun('Update all apps with WinGet?\nThis may take 5–30 minutes depending on installed apps.', () => bg(W, 'update_all_apps')), 'ghost'],
     ['Open Windows Update Settings', 'Opens the Windows Update settings page', '—', () => call(W, 'launch_tool', ['Windows Update']), 'ghost'],
     ['Repair Windows Update', 'Stops WU services, clears download cache, restarts them', '~2 min', () => confirmRun('Repair Windows Update service?\nClears the download cache and restarts WU services.', () => bg(W, 'repair_windows_update')), 'ghost']]
      .forEach((r) => f.append(actionRow(...r)));
    return f;
  }

  const builders = { Repairs: buildRepairs, Cleanup: buildCleanup, Tweaks: buildTweaks, 'Config Tools': buildConfig, Updates: buildUpdates };
  function switchTab(name) {
    for (const [n, t] of Object.entries(tabs)) {
      const active = n === name;
      t.btn.classList.toggle('active', active);
      if (t.frame) t.frame.style.display = active ? '' : 'none';
    }
    const t = tabs[name];
    if (!t.frame) { t.frame = builders[name](); content.append(t.frame); }
    t.frame.style.display = '';
  }
  let S = null;
  const tabBar = h('div', { class: 'row', style: 'padding:0 20px' });
  for (const n of Object.keys(builders)) {
    const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => switchTab(n) });
    tabs[n] = { btn, frame: null }; tabBar.append(h('span', { style: 'margin:0 2px' }, btn));
  }
  const outCard = Card([h('div', { class: 'row', style: 'padding:8px 12px 4px' }, h('span', { class: 'f11 b ts', text: 'Output' }), h('div', { class: 'grow' }),
    Btn('Clear', { variant: 'plain', h: 22, w: 44, f: 10, style: { color: 'var(--text_disabled)', minWidth: '44px', borderRadius: '4px' }, onclick: () => out.clear() })),
    (() => { out.style.margin = '0 10px 10px'; return out; })()], 'col', { margin: '0 20px 8px', flex: 'none' });

  // events
  on(Events_REPAIR_PROGRESS(), log); on('storage.cleanup_progress', log);
  function Events_REPAIR_PROGRESS() { return 'repair.progress'; }
  on('repair.done', (r) => { if (!r) return; const m = ` ${r.tool} — ${r.success ? 'success' : 'completed with errors'} (${Number(r.duration_s).toFixed(0)}s)`; log(m); setStatus(m); });
  on('storage.cleanup_done', (r) => { if (!r) return; const mb = r.mb_freed != null ? r.mb_freed : (r.total_bytes_freed || 0) / 1048576; log(` Cleanup done — ${r.files_deleted} items, ${mb.toFixed(1)} MB freed`); });

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'System Optimizer & Windows Utility' }), h('div', { class: 'grow' }), status),
    tabBar, h('div', { class: 'divider', style: 'margin:0 20px' }),
    h('div', { style: 'flex:1;min-height:0;margin:0 20px;display:flex;flex-direction:column' }, content),
    outCard);
  rpc('optimizer.static').then((s) => { S = s; switchTab('Repairs'); }).catch((e) => log('Failed to load: ' + e.message));
  return { el };
});

'use strict';
/* VPN page — powered by the VPN tunnel (Automatic) or country proxy servers. v6
   The VPN tab is ONLY for the VPN. The Proxy tab is for proxies. */
Pages.register('vpn', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (t) => { status.textContent = t; };
  const regionName = (c) => { try { return c ? new Intl.DisplayNames(['en'], { type: 'region' }).of(c) : ''; } catch { return c || ''; } };

  const VOPT = { kill_switch: true, dns_protect: true, ipv6_block: true, browser_protect: true, store_apps: true, rotate_min: 0, region: 'Any' };
  let vpnState = { on: false, busy: false, status: 'off' }, vpnTimer = null, vUI = {};
  const upt = (since) => { const t = Math.max(0, Math.floor(Date.now() / 1000 - since)); const p2 = (n) => String(n).padStart(2, '0'); return `${p2(Math.floor(t / 3600))}:${p2(Math.floor((t % 3600) / 60))}:${p2(t % 60)}`; };

  // ── status badge ──────────────────────────────────────────────────────────
  function _modeLabel(s) {
    if (!s || !s.on) return '—';
    if (s.backend === 'tunnel') return 'VPN (Automatic)';
    return `VPN (${s.country || s.opts?.region || 'Proxy'})`;
  }

  // ── main card ─────────────────────────────────────────────────────────────
  function buildVpn() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });

    const shield = h('div', { class: 'f24 b', text: 'OFF', style: 'width:92px;height:92px;border-radius:46px;border:4px solid var(--border);display:flex;align-items:center;justify-content:center;flex:none;color:var(--text_disabled)' });
    const title = h('div', { class: 'f18 b', text: 'Not protected' });
    const sub = h('div', { class: 'f11 ts', text: 'Turn it on to hide your IP and encrypt your traffic.', style: 'margin-top:2px;white-space:normal' });
    const bar = Progress({ height: 4, radius: 2 });
    const msg = h('div', { class: 'f10 ts', style: 'min-height:14px;margin-top:4px' });
    const big = Btn('Connect VPN', { h: 46, w: 210, bold: true, f: 14, onclick: toggleVpn });

    const rows = {};
    const mk = (k, label) => { const v = h('span', { class: 'f11 tp', text: '—' }); rows[k] = v; return h('div', { class: 'row', style: 'padding:3px 0' }, h('span', { class: 'f11 ts', text: label, style: 'width:110px' }), v); };
    const info = h('div', { style: 'margin-left:20px;flex:1;min-width:0' },
      mk('mode',  'Mode'),
      mk('loc',   'Location'),
      mk('ip',    'Your IP now'),
      mk('speed', 'Throughput'),
      mk('up',    'Connected for'),
      mk('pool',  'Backup servers'));

    f.append(Card([
      h('div', { class: 'row', style: 'padding:18px 20px 8px' }, shield,
        h('div', { class: 'col grow', style: 'margin-left:18px;align-items:flex-start;min-width:0' }, title, sub, h('div', { style: 'margin-top:10px' }, big)),
        info),
      h('div', { style: 'padding:0 20px' }, bar),
      h('div', { style: 'padding:0 20px 12px' }, msg)],
      'col', { marginBottom: '12px' }));

    const notes = h('div', { class: 'f10 c-warn', style: 'white-space:pre-wrap;padding:0 4px 8px' });
    f.append(notes);

    // ── privacy toggles ───────────────────────────────────────────────────
    const tg = {};
    const feat = (key, label, tipText) => {
      const sw = Switch({ big: true, checked: VOPT[key], onchange: (v) => { VOPT[key] = v; } });
      tg[key] = sw;
      return h('div', { class: 'row', style: 'padding:6px 14px' },
        h('div', { class: 'row grow' }, h('span', { class: 'f12 tp', text: label }), h('span', { style: 'margin-left:6px' }, Info(tipText))), sw);
    };
    const rot = Option(['Off', 'Every 5 min', 'Every 10 min', 'Every 30 min', 'Every hour'], {
      w: 150, f: 11, onchange: (v) => { VOPT.rotate_min = { Off: 0, 'Every 5 min': 5, 'Every 10 min': 10, 'Every 30 min': 30, 'Every hour': 60 }[v]; }
    });
    rot.classList.add('bordered');

    let autostartOn = false;
    const autostartSw = Switch({ big: true, checked: false, onchange: async (v) => {
      autostartOn = v;
      await rpc('config.set', { values: { vpn_autostart: v } });
      setStatus(v ? 'VPN will auto-connect when DWUT starts' : 'VPN auto-connect disabled');
    }});
    rpc('vpn.autostart_get').then((v) => { autostartOn = !!v; autostartSw.set(!!v, true); }).catch(() => {});

    vUI = { shield, title, sub, bar, msg, big, rows, notes, tg, rot };

    f.append(buildLocationCard());

    f.append(Card([
      h('div', { class: 'f13 b tp', text: 'Privacy & Security Options', style: 'padding:12px 14px 4px' }),
      h('div', { class: 'f10 ts c-acc', style: 'padding:0 14px 6px;white-space:normal',
        text: 'Applied automatically when you connect. All options are reversed when you disconnect.' }),
      feat('kill_switch', 'Kill switch',
        'Blocks ALL internet if the VPN drops — no data leaks to your real IP.\nAutomatically removed when you disconnect.\n\nNeeds Administrator rights.'),
      feat('dns_protect', 'DNS leak protection',
        'Blocks DNS queries going outside the VPN tunnel.\nYour ISP cannot see which domains you visit.\n\nNeeds Administrator rights.'),
      feat('ipv6_block', 'Block IPv6 leaks',
        'The VPN tunnel is IPv4-only. This blocks IPv6 so sites cannot see your real IPv6 address.\n\nNeeds Administrator rights.'),
      feat('browser_protect', 'Browser WebRTC + QUIC protection',
        'Prevents Chrome/Edge/Brave from leaking your real IP via WebRTC.\nAlso disables QUIC (UDP) which can bypass the tunnel.\n\nRestart your browser after connecting.'),
      feat('store_apps', 'Microsoft Store app support',
        'Allows Store (UWP) apps to use the VPN. Microsoft blocks them from loopback by default.'),
      h('div', { class: 'row', style: 'padding:6px 14px' },
        h('div', { class: 'row grow' },
          h('span', { class: 'f12 tp', text: 'Auto-rotate server' }),
          h('span', { style: 'margin-left:6px' }, Info('Automatically reconnects to a different server on a timer, cycling through backup servers to keep your exit IP fresh.'))),
        rot),
      h('div', { class: 'row', style: 'padding:6px 14px' },
        h('div', { class: 'row grow' },
          h('span', { class: 'f12 tp', text: 'Connect VPN when DWUT opens' }),
          h('span', { style: 'margin-left:6px' }, Info('DWUT will automatically connect to the VPN every time it launches.'))),
        autostartSw),
      h('div', { style: 'height:8px' })],
      'col', { marginBottom: '12px' }));

    f.append(Card([
      h('div', { class: 'f13 b tp', text: 'What the VPN does', style: 'padding:12px 14px 4px' }),
      h('div', { class: 'f11 ts', style: 'padding:0 14px 12px;white-space:pre-wrap',
        text: '•  Hides your real IP from every website and service\n•  Encrypts all traffic — your ISP sees nothing\n•  Kill switch: traffic stops instantly if connection drops — no leaks\n•  Automatic mode: covers every app — browsers, games, Discord, streaming\n•  Country mode: lock your exit IP to a specific country\n•  Click any server in the list below to connect to it directly' })],
      'col', { marginBottom: '12px' }));

    f.append(h('div', { class: 'row', style: 'gap:8px;padding-bottom:10px;flex-wrap:wrap' },
      Btn('Switch Server', { variant: 'ghost', h: 30,
        tip: 'Reconnects to the next backup server. Use this if your current server is slow.',
        onclick: async () => { setStatus('Switching server…'); const ok = await rpc('vpn.switch'); setStatus(ok ? 'Switched to a new server' : 'No backup server available'); }
      }),
      Btn('Check My IP', { variant: 'ghost', h: 30,
        tip: 'Looks up your current public IP address through the VPN.',
        onclick: async () => { setStatus('Checking…'); const ip = await rpc('vpn.ip'); setStatus(ip ? `Your IP: ${ip}` : 'Not connected'); }
      }),
      Btn('Restore Internet (Panic)', { variant: 'danger', h: 30, w: 190,
        tip: 'Emergency restore — removes all VPN firewall rules and restores normal internet immediately.',
        onclick: async () => { await rpc('vpn.panic'); setStatus('Restored — all VPN rules removed'); }
      })));

    rpc('vpn.state').then(applyVpn).catch(() => {});
    return f;
  }

  // ── location accordion ────────────────────────────────────────────────────
  let locData = [], locFilter = '', expandedCountry = null, selectedServer = null;

  function buildLocationCard() {
    const search = Entry({ placeholder: 'Search countries or IPs…', fill: true, h: 28, f: 12,
      onchange: (v) => { locFilter = v.trim().toLowerCase(); paintLoc(); }
    });
    search.style.cssText += ';margin:0 14px 6px;width:auto';

    const modeLbl = h('span', { class: 'f11 b c-acc',
      text: 'Automatic', style: 'background:var(--bg_input);border-radius:4px;padding:2px 8px;margin-left:10px' });

    const scanBtn = Btn('Scan for more', { variant: 'ghost', h: 24, w: 110, f: 10,
      tip: 'Scans a larger pool of servers to find more countries and IPs. Takes 1–2 minutes.',
      onclick: async () => { scanBtn.disabled = true; setStatus('Scanning for servers…'); const ok = await rpc('vpn.discover'); if (!ok) { setStatus('Already scanning…'); scanBtn.disabled = false; } }
    });

    const connectBtn = Btn('Connect', { h: 30, w: 100, bold: true, f: 12,
      tip: 'Connect to the selected server.',
      onclick: () => toggleVpn()
    });

    const list = h('div', { class: 'scroll', style: 'height:280px;margin:0 14px;background:var(--bg_input);border-radius:6px;padding:4px' });

    const card = Card([
      h('div', { class: 'row', style: 'padding:12px 14px 6px' },
        h('span', { class: 'f13 b tp', text: 'Server & Location' }), modeLbl,
        h('span', { style: 'margin-left:6px' }, Info(
          'Automatic — full VPN tunnel, fastest, covers ALL apps (games, voice, streaming, everything).\n\nCountry — choose where your exit IP appears. Browse and stream from that country.\n\nClick a country to expand it and see all available servers.\nClick a server IP to select it, then hit Connect.'
        )),
        h('div', { class: 'grow' }), scanBtn),
      search, list,
      h('div', { class: 'row', style: 'padding:6px 14px 10px;gap:10px;align-items:center' },
        h('div', { class: 'f10 ts grow', style: 'white-space:normal',
          text: 'Click a country to expand servers. Click an IP to select. Automatic = full VPN, best speed.' }),
        connectBtn)],
      'col', { marginBottom: '12px' });

    vUI.locCard = card; vUI.locList = list; vUI.modeLbl = modeLbl; vUI.scanBtn = scanBtn;
    paintLoc();
    loadLocs();
    return card;
  }

  async function loadLocs() {
    try {
      const detailed = await rpc('vpn.locations_detailed');
      if (detailed && detailed.length) { locData = detailed; paintLoc(); return; }
    } catch { /* fall through */ }
    try { locData = await rpc('vpn.locations'); } catch { locData = []; }
    paintLoc();
  }

  function pickServer(country, server) {
    selectedServer = server;
    VOPT.region = country;
    if (vUI.modeLbl) {
      if (country === 'Any') vUI.modeLbl.textContent = 'Automatic';
      else if (server) vUI.modeLbl.textContent = `${country} — ${server.ip}:${server.port}`;
      else vUI.modeLbl.textContent = country;
    }
    paintLoc();
    if (vpnState.on) {
      vUI.msg.textContent = `Switching to ${country === 'Any' ? 'Automatic' : country}…`;
      const spec = server ? `${server.ip}:${server.port}:${server.protocol}` : '';
      rpc('vpn.set_location', { country, specific_server: spec }).then((ok) => { if (!ok) vUI.msg.textContent = 'Busy — try again in a moment'; });
    }
  }

  function tierColor(tier) {
    return { excellent: 'var(--success)', good: 'var(--accent)', fair: 'var(--warning)' }[tier] || 'var(--text_disabled)';
  }

  function paintLoc() {
    const list = vUI.locList; if (!list) return;
    list.textContent = '';
    const q = locFilter;

    // ── Automatic row (always first) ──
    const autoSel = (VOPT.region || 'Any') === 'Any' && !selectedServer;
    const autoRow = h('div', { class: 'row', style: `padding:8px 10px;border-radius:5px;cursor:pointer;margin-bottom:2px;${autoSel ? 'background:var(--sidebar_active);outline:1px solid var(--accent)' : 'background:var(--bg_card)'}`, onclick: () => pickServer('Any', null) });
    const autoItems = [
      h('span', { class: 'f10 b c-acc', style: 'width:32px;text-align:center;margin-right:8px' }, '[AUTO]'),
      h('div', { class: 'col grow' },
        h('span', { class: 'f12 b', text: 'Automatic', style: `color:var(--${autoSel ? 'accent' : 'text_primary'})` }),
        h('span', { class: 'f9 ts', text: 'Full VPN tunnel — fastest, covers all apps, games, Discord, streaming' })
      )
    ];
    if (autoSel) {
      autoItems.push(h('span', { class: 'f10 b c-acc', text: vpnState.on ? 'CONNECTED' : 'SELECTED', style: 'margin-left:8px' }));
    }
    autoItems.forEach(c => autoRow.append(c));
    autoRow.onmouseenter = () => { if (!autoSel) autoRow.style.background = 'var(--bg_hover)'; };
    autoRow.onmouseleave = () => { if (!autoSel) autoRow.style.background = ''; };
    if (!q || 'automatic'.includes(q) || 'vpn'.includes(q)) list.append(autoRow);

    // ── Country rows (accordion) ──
    const countries = locData.length ? locData : [];
    countries.filter((loc) => !q || loc.country.toLowerCase().includes(q) || (loc.servers || []).some(s => s.ip.includes(q))).forEach((loc) => {
      const countryId = loc.country;
      const expanded = expandedCountry === countryId;
      const selInCountry = VOPT.region === countryId;
      const servers = loc.servers || [];

      // Country header row
      const hdr = h('div', { class: 'row', style: `padding:7px 10px;border-radius:5px;cursor:pointer;margin-bottom:1px;background:var(--bg_card);${selInCountry && !selectedServer ? 'outline:1px solid var(--accent)' : ''}`,
        onclick: () => {
          expandedCountry = expanded ? null : countryId;
          if (!expanded && servers.length) pickServer(countryId, null);
          else if (!expanded) pickServer(countryId, null);
          paintLoc();
        }
      });
      const codeTag = loc.code ? `[${loc.code.toUpperCase()}]` : '[--]';
      const titleChildren = [
        h('span', { class: 'f12 b ell', text: loc.country, style: `color:var(--${selInCountry ? 'accent' : 'text_primary'})` }),
        loc.yt ? h('span', { class: 'f9 b', text: 'YT', style: 'color:#FF4444;background:rgba(255,68,68,.12);border-radius:3px;padding:1px 4px' }) : null,
        (loc.ping_ms != null && !isNaN(Number(loc.ping_ms))) ? h('span', { class: 'f9 ts', text: `${loc.ping_ms}ms` }) : null
      ].filter(Boolean);

      const titleRow = h('div', { class: 'row', style: 'align-items:center;gap:6px' });
      titleChildren.forEach(c => titleRow.append(c));

      const countSub = `${loc.count || servers.length} server${(loc.count || servers.length) !== 1 ? 's' : ''}${loc.best ? ' · score ' + loc.best : ''}`;

      const hdrItems = [
        h('span', { class: 'f10 b c-acc', style: 'width:32px;text-align:center;margin-right:8px', text: codeTag }),
        h('div', { class: 'col grow', style: 'min-width:0' },
          titleRow,
          h('span', { class: 'f9 td', text: countSub })
        ),
        h('span', { class: 'f11 ts', style: 'margin-left:8px;transition:transform .2s;transform:' + (expanded ? 'rotate(90deg)' : 'none'), text: '>' })
      ];

      if (selInCountry && !selectedServer) {
        hdrItems.push(h('span', { class: 'f9 b c-acc', text: vpnState.on ? 'CONNECTED' : 'SELECTED', style: 'margin-left:4px' }));
      }

      hdrItems.forEach(c => hdr.append(c));
      hdr.onmouseenter = () => { hdr.style.background = 'var(--bg_hover)'; };
      hdr.onmouseleave = () => { hdr.style.background = selInCountry && !selectedServer ? '' : 'var(--bg_card)'; };
      list.append(hdr);

      // Expanded server list
      if (expanded) {
        if (!servers.length) {
          const loadingRow = h('div', { class: 'f10 td', style: 'padding:6px 16px', text: 'Loading servers…' });
          list.append(loadingRow);
          rpc('vpn.servers', { country: countryId }).then((svrs) => {
            loc.servers = svrs || [];
            paintLoc();
          }).catch(() => { loadingRow.textContent = 'No servers found — try Scan for more'; });
        } else {
          const svrsToShow = servers.filter(s => !q || (s.ip && s.ip.includes(q)) || (s.city && s.city.toLowerCase().includes(q)));
          svrsToShow.forEach((srv) => {
            const isSel = selectedServer && selectedServer.ip === srv.ip && selectedServer.port === srv.port;
            const city = (srv.city && srv.city !== 'null' && srv.city !== 'None') ? srv.city : '';
            const pingNum = (srv.ping_ms != null && srv.ping_ms !== 'null' && !isNaN(Number(srv.ping_ms))) ? Number(srv.ping_ms) : null;
            const pingLabel = pingNum ? `${pingNum}ms` : '';
            const tierStr = (srv.tier && srv.tier !== 'null' && srv.tier !== 'None') ? String(srv.tier).toUpperCase() : '';
            const tierCol = tierColor(srv.tier || '');

            const sRow = h('div', { class: 'row', style: `padding:5px 10px 5px 36px;border-radius:4px;cursor:pointer;margin:1px 0;align-items:center;${isSel ? 'background:var(--sidebar_active);outline:1px solid var(--accent)' : ''}` });

            // Select / Selected toggle button
            const selBtn = h('button', {
              class: 'f9 b',
              text: isSel ? 'Selected' : 'Select',
              style: `border:1px solid var(--${isSel ? 'accent' : 'border'});background:var(--${isSel ? 'accent' : 'bg_input'});color:var(--${isSel ? 'accent_text' : 'text_secondary'});border-radius:4px;padding:2px 8px;cursor:pointer;transition:.12s;flex-shrink:0;margin:0 6px;font-family:inherit`,
              onclick: (e) => { e.stopPropagation(); pickServer(countryId, isSel ? null : srv); }
            });

            const children = [
              h('div', { class: 'col grow', style: 'min-width:0' },
                h('span', { class: 'f10 b mono ell', text: `${srv.ip}:${srv.port}`, style: `color:var(--${isSel ? 'accent' : 'text_primary'})` }),
                city ? h('span', { class: 'f9 td', text: city }) : null
              ),
              selBtn,
              pingLabel ? h('span', { class: 'f9 ts', text: pingLabel, style: 'width:48px;text-align:right;flex-shrink:0' }) : null,
              tierStr ? h('span', { class: 'f9 b', text: tierStr, style: `color:${tierCol};width:64px;text-align:right;flex-shrink:0` }) : null,
            ].filter(Boolean);

            children.forEach(c => sRow.append(c));
            sRow.onclick = (e) => { if (e.target === selBtn) return; e.stopPropagation(); pickServer(countryId, isSel ? null : srv); };
            sRow.onmouseenter = () => { if (!isSel) sRow.style.background = 'var(--bg_hover)'; };
            sRow.onmouseleave = () => { if (!isSel) sRow.style.background = ''; };
            list.append(sRow);
          });
          if (!svrsToShow.length) list.append(h('div', { class: 'f10 td', style: 'padding:4px 36px', text: 'No servers match your search.' }));
        }
      }
    });

    if (!countries.length && locData.length === 0) {
      list.append(h('div', { class: 'f11 td', style: 'padding:20px;text-align:center;white-space:normal',
        text: 'No country servers found yet.\n\nClick "Scan for more" to discover available locations, or connect in Automatic mode for instant VPN.' }));
    }
  }

  on('vpn.locations_changed', async (d) => {
    if (d && d.length) { locData = d; }
    else { try { locData = await rpc('vpn.locations_detailed'); } catch { /* ignore */ } }
    paintLoc();
    if (vUI.scanBtn) vUI.scanBtn.disabled = false;
  });

  // ── connect / disconnect ──────────────────────────────────────────────────
  async function toggleVpn() {
    if (vpnState.on) { vUI.big.disabled = true; await rpc('vpn.disconnect'); return; }
    if (vpnState.busy) return;
    vUI.big.disabled = true; vUI.msg.textContent = 'Connecting…'; vUI.notes.textContent = '';
    const opts = Object.assign({}, VOPT);
    if (selectedServer) opts.specific_server = `${selectedServer.ip}:${selectedServer.port}:${selectedServer.protocol}`;
    rpc('vpn.connect', { opts }).catch((e) => { vUI.msg.textContent = e.message; vUI.big.disabled = false; });
  }

  // ── state renderer ────────────────────────────────────────────────────────
  function applyVpn(s) {
    vpnState = s; if (!vUI.big) return;
    const { shield, title, sub, big, rows, notes, tg, rot } = vUI;

    const colMap = { connected: 'var(--success)', connecting: 'var(--warning)', reconnecting: 'var(--warning)', degraded: 'var(--error)', off: 'var(--text_disabled)' };
    const col = colMap[s.status] || 'var(--text_disabled)';

    shield.style.borderColor = s.status === 'off' ? 'var(--border)' : col;
    shield.style.color = col;
    shield.textContent = { connected: 'ON', connecting: '…', reconnecting: '↻', degraded: '!', off: 'OFF' }[s.status] || 'OFF';

    title.textContent = { connected: 'Protected', connecting: 'Connecting…', reconnecting: 'Reconnecting…', degraded: 'Connection issue — kill switch active', off: 'Not protected' }[s.status] || 'Not protected';
    title.style.color = s.status === 'off' ? 'var(--text_primary)' : col;
    sub.textContent = s.on ? 'Your connection is encrypted and your IP is hidden.' : 'Turn it on to encrypt your traffic and hide your IP.';

    big.textContent = s.on ? 'Disconnect' : s.busy ? 'Connecting…' : 'Connect VPN';
    big.style.background = s.on ? 'var(--error)' : '';
    big.style.color = s.on ? '#fff' : '';
    big.disabled = !!s.busy && !s.on;

    const sv = s.server;
    const isTunnel = s.backend === 'tunnel';

    rows.mode.textContent  = _modeLabel(s);
    rows.mode.style.color  = s.on ? col : '';
    rows.loc.textContent   = s.on ? (s.country || regionName(s.country_code) || sv?.country || 'Unknown') : '—';
    rows.ip.textContent    = s.on ? (s.ip || '…') : '—';
    rows.speed.textContent = isTunnel ? (s.on ? 'Full VPN (all apps)' : '—') : (sv?.mbps ? `${sv.mbps} Mbps` : '—');
    rows.pool.textContent  = !s.on ? '—' : (isTunnel ? 'n/a' : `${Math.max(0, (s.pool || 1) - 1)} ready`);
    rows.up.textContent    = s.on ? upt(s.since) : '—';

    notes.textContent = (s.notes || []).join('\n');

    const lock = s.on || s.busy;
    Object.values(tg).forEach((sw) => { sw.style.pointerEvents = lock ? 'none' : ''; sw.style.opacity = lock ? '.55' : ''; });
    rot.style.pointerEvents = lock ? 'none' : ''; rot.style.opacity = lock ? '.55' : '';

    if (vUI.modeLbl) {
      const switching = s.switching;
      if (!switching) {
        if (s.on) vUI.modeLbl.textContent = _modeLabel(s);
        else vUI.modeLbl.textContent = VOPT.region === 'Any' ? 'Automatic' : VOPT.region;
      } else {
        vUI.modeLbl.textContent = 'Switching…';
      }
    }
    paintLoc();

    clearInterval(vpnTimer);
    if (s.on) vpnTimer = setInterval(() => { rows.up.textContent = upt(s.since); }, 1000);
    if (s.status === 'off' && !s.busy) vUI.bar.set(0);
  }

  on('vpn.state', applyVpn);
  on('vpn.progress', (d) => { if (!vUI.msg) return; vUI.msg.textContent = d.msg || ''; if (d.pct != null) vUI.bar.set(d.pct); else vUI.bar.set(0); });

  const wrap = h('div', { style: 'position:relative;flex:1;min-height:0;margin:8px 20px 16px' }, buildVpn());
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'VPN' }), h('div', { class: 'grow' }), status), wrap);

  return { el, onShow() { loadLocs(); } };
});

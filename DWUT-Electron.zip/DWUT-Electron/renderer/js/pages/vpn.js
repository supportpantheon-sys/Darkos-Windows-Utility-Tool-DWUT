'use strict';
/* VPN - its own category.  Automatic mode = full-system tunnel; picking a country = shared servers. */
Pages.register('vpn', () => {
  const REGIONS = ['Any', 'Canada', 'United States', 'United Kingdom', 'Germany', 'France', 'Netherlands', 'Switzerland', 'Japan', 'South Korea', 'Australia', 'Singapore', 'Brazil', 'India', 'Russia'];
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (t) => { status.textContent = t; };
  const regionName = (c) => { try { return c ? new Intl.DisplayNames(['en'], { type: 'region' }).of(c) : ''; } catch { return c || ''; } };
  // ── VPN mode ──
  const VOPT = { kill_switch: true, dns_protect: true, ipv6_block: true, browser_protect: true, store_apps: true, rotate_min: 0, region: 'Any' };
  let vpnState = { on: false, busy: false, status: 'off' }, vpnTimer = null, vUI = {};
  const upt = (since) => { const t = Math.max(0, Math.floor(Date.now() / 1000 - since)); const p2 = (n) => String(n).padStart(2, '0'); return `${p2(Math.floor(t / 3600))}:${p2(Math.floor((t % 3600) / 60))}:${p2(t % 60)}`; };
  function buildVpn() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    const shield = h('div', { class: 'f24 b', text: 'OFF', style: 'width:92px;height:92px;border-radius:46px;border:4px solid var(--border);display:flex;align-items:center;justify-content:center;flex:none;color:var(--text_disabled)' });
    const title = h('div', { class: 'f18 b', text: 'Not protected' }), sub = h('div', { class: 'f11 ts', text: 'Turn it on to hide your IP address and protect your connection.', style: 'margin-top:2px;white-space:normal' });
    const bar = Progress({ height: 4, radius: 2 }); const msg = h('div', { class: 'f10 ts', style: 'min-height:14px;margin-top:4px' });
    const big = Btn('Connect VPN', { h: 46, w: 210, bold: true, f: 14, onclick: toggleVpn });
    const rows = {};
    const mk = (k, label, tipText) => { const v = h('span', { class: 'f11 tp', text: '—' }); rows[k] = v; return h('div', { class: 'row', style: 'padding:3px 0' }, h('span', { class: 'f11 ts', text: label, style: 'width:110px' }), v); };
    const info = h('div', { style: 'margin-left:20px;flex:1;min-width:0' }, mk('server', 'Route'), mk('loc', 'Location'), mk('ip', 'Your IP now'), mk('speed', 'Server speed'), mk('up', 'Connected for'), mk('pool', 'Backups'));
    f.append(Card([h('div', { class: 'row', style: 'padding:18px 20px 8px' }, shield, h('div', { class: 'col grow', style: 'margin-left:18px;align-items:flex-start;min-width:0' }, title, sub, h('div', { style: 'margin-top:10px' }, big)), info),
      h('div', { style: 'padding:0 20px' }, bar), h('div', { style: 'padding:0 20px 12px' }, msg)], 'col', { marginBottom: '12px' }));
    const notes = h('div', { class: 'f10 c-warn', style: 'white-space:pre-wrap;padding:0 4px 8px' });
    f.append(notes);
    const tg = {};
    const feat = (key, label, tipText) => { const sw = Switch({ big: true, checked: VOPT[key], onchange: (v) => { VOPT[key] = v; } }); tg[key] = sw;
      return h('div', { class: 'row', style: 'padding:6px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f12 tp', text: label }), h('span', { style: 'margin-left:6px' }, Info(tipText))), sw); };
    const rot = Option(['Off', 'Every 5 min', 'Every 10 min', 'Every 30 min', 'Every hour'], { w: 150, f: 11, onchange: (v) => { VOPT.rotate_min = { Off: 0, 'Every 5 min': 5, 'Every 10 min': 10, 'Every 30 min': 30, 'Every hour': 60 }[v]; } }); rot.classList.add('bordered');
    vUI = { shield, title, sub, bar, msg, big, rows, notes, tg, rot };
    f.append(buildLocationCard());
    f.append(Card([h('div', { class: 'f13 b tp', text: 'Options for country servers', style: 'padding:12px 14px 4px' }),
      feat('kill_switch', 'Kill switch', 'Windows Firewall rules block ALL internet traffic except to your LAN and the proxy servers in use.\n\nIf every proxy dies, nothing leaks onto your real connection - traffic just stops until a working server is found.\n\nRemoved automatically when you disconnect, when DWUT closes, or after a crash (next launch). Needs Administrator.'),
      feat('dns_protect', 'DNS leak protection', 'Blocks plain DNS (port 53) and DNS-over-TLS (853) to the internet. Names are resolved by the proxy, so your ISP never sees which sites you visit.\n\nNeeds Administrator.'),
      feat('ipv6_block', 'Block IPv6 leaks', 'Proxies carry IPv4 only. Blocking IPv6 stops sites from seeing your real IPv6 address.\n\nNeeds Administrator.'),
      feat('browser_protect', 'Browser leak protection (WebRTC + QUIC)', 'Sets Chrome / Edge / Brave policies so WebRTC cannot reveal your real IP and QUIC (UDP, which bypasses proxies) is off.\n\nRestart the browser after connecting. Those browsers will show "managed by your organization" while this is on; it is removed on disconnect.\n\nFirefox: set media.peerconnection.enabled = false in about:config.'),
      feat('store_apps', 'Microsoft Store app support', 'Store (UWP) apps are not allowed to talk to a local proxy by default, so they show "no internet". This exempts them while connected and puts it back afterwards.'),
      h('div', { class: 'row', style: 'padding:6px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f12 tp', text: 'Auto-switch server' }), h('span', { style: 'margin-left:6px' }, Info('Moves to a different server on a timer, like a VPN\'s "rotate IP". Streaming sessions may restart when it switches.'))), rot),
      h('div', { style: 'height:8px' })], 'col', { marginBottom: '12px' }));
    f.append(Card([h('div', { class: 'f13 b tp', text: 'What you get', style: 'padding:12px 14px 4px' }),
      h('div', { class: 'f11 ts', style: 'padding:0 14px 12px;white-space:pre-wrap', text: '•  Your real IP address is hidden\n•  Kill switch: if the connection drops, traffic is blocked instead of leaking\n•  DNS and IPv6 leak protection\n•  Automatic reconnect if anything goes wrong\n•  Automatic mode covers every app: browsers, Discord, games, music and video' })], 'col', { marginBottom: '12px' }));
    f.append(h('div', { class: 'row', style: 'gap:8px;padding-bottom:10px' },
      Btn('Switch Server', { variant: 'ghost', h: 30, tip: 'Move to the next backup server right now.', onclick: async () => { const ok = await rpc('vpn.switch'); setStatus(ok ? 'Switched server' : 'No other server available'); } }),
      Btn('Check My IP', { variant: 'ghost', h: 30, onclick: async () => { setStatus('Checking IP…'); const ip = await rpc('vpn.ip'); setStatus(ip ? `Your IP through the VPN: ${ip}` : 'Not connected'); } }),
      Btn('Restore Internet (Panic)', { variant: 'danger', h: 30, w: 190, tip: 'Removes every firewall rule, browser policy and proxy setting DWUT created - use this if you ever lose internet.', onclick: async () => { await rpc('vpn.panic'); setStatus('Internet restored: all VPN rules and proxy settings removed'); } })));
    rpc('vpn.state').then(applyVpn).catch(() => {});
    return f;
  }

  // ── location changer ──
  let locData = [], locFilter = '';
  function buildLocationCard() {
    const search = Entry({ placeholder: 'Search countries…', fill: true, h: 28, f: 12, onchange: (v) => { locFilter = v.trim().toLowerCase(); paintLoc(); } });
    search.style.width = 'auto'; search.style.margin = '0 14px 6px';
    const list = h('div', { class: 'scroll', style: 'height:236px;margin:0 14px;background:var(--bg_input);border-radius:6px;padding:3px' });
    const locLabel = h('span', { class: 'f11 b c-acc', text: 'Automatic', style: 'background:var(--bg_input);border-radius:4px;padding:2px 8px;margin-left:10px' });
    const find = Btn('Find more locations', { variant: 'ghost', h: 24, w: 150, f: 10, tip: 'Scans a larger sample of proxies so more countries appear in the list (about 1-2 minutes).', onclick: async () => { const ok = await rpc('vpn.discover'); if (!ok) setStatus('Busy - try again in a moment'); } });
    const rnd = Btn('Random', { variant: 'ghost', h: 24, w: 80, f: 10, tip: 'Pick a random available country.', onclick: () => { const c = locData.filter((x) => x.yt > 0 || x.count > 1); if (c.length) pickLoc(c[Math.floor(Math.random() * c.length)].country); } });
    const card = Card([h('div', { class: 'row', style: 'padding:12px 14px 6px' }, h('span', { class: 'f13 b tp', text: 'Location' }), locLabel, h('span', { style: 'margin-left:6px' }, Info('Choose where you appear to be browsing from. Servers are grouped by the country of their real exit IP.\n\nWhile connected, clicking a country switches instantly - the kill switch stays on during the change.\n\nTip: "YouTube" shows how many servers there passed the streaming test.')), h('div', { class: 'grow' }), rnd, h('span', { style: 'width:6px' }), find),
      search, list, h('div', { class: 'f10 td', text: 'Automatic gives the best speed and covers everything (games, voice chat, streaming). Picking a specific country uses shared servers - they work for browsing and video but can be slower, and games/voice chat will not work through them.', style: 'padding:6px 14px 12px;white-space:normal' })], 'col', { marginBottom: '12px' });
    vUI.locCard = card; vUI.locList = list; vUI.locLabel = locLabel;
    paintLoc(); loadLocs();
    return card;
  }
  async function loadLocs() { try { locData = await rpc('vpn.locations'); } catch { locData = []; } paintLoc(); }
  function pickLoc(country) {
    VOPT.region = country;
    paintLoc();
    if (vpnState.on) { vUI.msg.textContent = `Switching to ${country === 'Any' ? 'the fastest server' : country}…`; rpc('vpn.set_location', { country }).then((ok) => { if (!ok) vUI.msg.textContent = 'Busy - try again in a moment'; }); }
    else if (vUI.locLabel) vUI.locLabel.textContent = country === 'Any' ? 'Automatic' : country;
  }
  function paintLoc() {
    const list = vUI.locList; if (!list) return;
    list.textContent = '';
    const rows = [{ country: 'Any', name: 'Automatic - best speed (recommended)', code: '★', count: null }];
    const known = new Set(locData.map((l) => l.country));
    locData.forEach((l) => rows.push(Object.assign({ name: l.country }, l)));
    if (!locData.length) REGIONS.filter((r) => r !== 'Any' && !known.has(r)).forEach((r) => rows.push({ country: r, name: r, code: '··', count: null, unknown: true }));
    const q = locFilter;
    rows.filter((r) => !q || r.name.toLowerCase().includes(q)).forEach((r) => {
      const sel = (VOPT.region || 'Any') === r.country;
      const el = h('div', { class: 'row', style: `padding:6px 8px;border-radius:4px;cursor:pointer;margin:1px 0;${sel ? 'background:var(--sidebar_active);outline:1px solid var(--accent)' : ''}`, onclick: () => pickLoc(r.country) },
        h('span', { class: 'f10 b mono', text: (r.code || '').slice(0, 2).toUpperCase(), style: 'width:30px;text-align:center;background:var(--bg_card);border-radius:3px;padding:2px 0;margin-right:10px;color:var(--text_secondary)' }),
        h('span', { class: 'f12 grow ell', text: r.name, style: `color:var(--${sel ? 'accent' : 'text_primary'});font-weight:${sel ? 700 : 400}` }),
        r.count != null ? h('span', { class: 'f10 ts', text: `${r.count} server${r.count === 1 ? '' : 's'}`, style: 'margin-left:8px' }) : (r.unknown ? h('span', { class: 'f10 td', text: 'will search', style: 'margin-left:8px' }) : null),
        r.yt ? h('span', { class: 'f9 b', text: `${r.yt} YouTube`, style: 'margin-left:8px;color:#FF4444' }) : null,
        sel ? h('span', { class: 'f10 b c-acc', text: vpnState.on ? 'CURRENT' : 'SELECTED', style: 'margin-left:8px' }) : null);
      el.onmouseenter = () => { if (!sel) el.style.background = 'var(--bg_hover)'; }; el.onmouseleave = () => { if (!sel) el.style.background = ''; };
      list.append(el);
    });
  }
  on('vpn.locations_changed', (d) => { locData = d || []; paintLoc(); });

  async function toggleVpn() {
    if (vpnState.on) { vUI.big.disabled = true; await rpc('vpn.disconnect'); return; }
    if (vpnState.busy) return;
    vUI.big.disabled = true; vUI.msg.textContent = 'Starting…'; vUI.notes.textContent = '';
    rpc('vpn.connect', { opts: VOPT }).catch((e) => { vUI.msg.textContent = e.message; vUI.big.disabled = false; });
  }
  function applyVpn(s) {
    vpnState = s; if (!vUI.big) return;
    const { shield, title, sub, big, rows, notes, tg, rot } = vUI;
    const col = { connected: 'var(--success)', connecting: 'var(--warning)', reconnecting: 'var(--warning)', degraded: 'var(--error)', off: 'var(--text_disabled)' }[s.status] || 'var(--text_disabled)';
    shield.style.borderColor = s.status === 'off' ? 'var(--border)' : col; shield.style.color = col;
    shield.textContent = { connected: 'ON', connecting: '…', reconnecting: '↻', degraded: '!', off: 'OFF' }[s.status] || 'OFF';
    title.textContent = { connected: 'Protected', connecting: 'Connecting…', reconnecting: 'Reconnecting…', degraded: 'Connection lost - kill switch active', off: 'Not protected' }[s.status] || '';
    title.style.color = s.status === 'off' ? 'var(--text_primary)' : col;
    sub.textContent = s.on ? 'Your connection is protected.' : 'Turn it on to hide your IP address and protect your connection.';
    big.textContent = s.on ? 'Disconnect' : s.busy ? 'Connecting…' : 'Connect VPN';
    big.style.background = s.on ? 'var(--error)' : ''; big.style.color = s.on ? '#fff' : ''; big.disabled = !!s.busy && !s.on;
    const sv = s.server;
    rows.server.textContent = !s.on ? '—' : (s.backend === 'tunnel' ? 'Automatic (best route)' : (sv ? `${sv.ip}:${sv.port}  (${sv.protocol})` : '—'));
    rows.loc.textContent = s.on ? (s.country || regionName(s.country_code) || sv?.country || 'Unknown') : '—';
    rows.ip.textContent = s.on ? (s.ip || '…') : '—';
    rows.speed.textContent = sv && sv.mbps ? `${sv.mbps} Mbps` : '—';
    rows.pool.textContent = !s.on ? '—' : (s.backend === 'tunnel' ? 'Not needed' : `${Math.max(0, (s.pool || 1) - 1)} ready`);
    rows.up.textContent = s.on ? upt(s.since) : '—';
    notes.textContent = (s.notes || []).join('\n');
    const lock = s.on || s.busy;
    Object.values(tg).forEach((sw) => { sw.style.pointerEvents = lock ? 'none' : ''; sw.style.opacity = lock ? '.55' : ''; });
    rot.style.pointerEvents = lock ? 'none' : ''; rot.style.opacity = lock ? '.55' : '';
    if (vUI.locCard) { vUI.locCard.classList.toggle('busy', !!s.switching); vUI.locLabel.textContent = s.switching ? 'Switching…' : (VOPT.region === 'Any' ? 'Automatic' : VOPT.region); paintLoc(); }
    clearInterval(vpnTimer); if (s.on) vpnTimer = setInterval(() => { rows.up.textContent = upt(s.since); }, 1000);
    if (s.status === 'off' && !s.busy) { vUI.bar.set(0); }
  }
  on('vpn.state', applyVpn);
  on('vpn.progress', (d) => { if (!vUI.msg) return; vUI.msg.textContent = d.msg || ''; if (d.pct != null) vUI.bar.set(d.pct); else vUI.bar.set(0); });


  const wrap = h('div', { style: 'position:relative;flex:1;min-height:0;margin:8px 20px 16px' }, buildVpn());
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' }, h('div', { class: 'title-row' }, h('h1', { text: 'VPN' }), h('div', { class: 'grow' }), status), wrap);
  return { el, onShow() { loadLocs(); } };
});

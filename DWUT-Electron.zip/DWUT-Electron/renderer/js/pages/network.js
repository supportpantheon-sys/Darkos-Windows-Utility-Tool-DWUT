﻿'use strict';
Pages.register('network', () => {
  let monitorRunning = false, notificationsOn = false, autoBlockOn = false;
  let connData = [], allowlist = [], threatFilter = 'flagged', connFilter = '', pendingAlert = null;

  const T = {
    0:{label:'Safe',  color:'var(--success)', dim:'rgba(52,199,89,.06)'},
    1:{label:'Watch', color:'var(--warning)', dim:'rgba(255,189,46,.07)'},
    2:{label:'Warn',  color:'#FF9500',         dim:'rgba(255,149,0,.09)'},
    3:{label:'Danger',color:'var(--error)',   dim:'rgba(255,59,48,.1)'},
  };
  const tc = n => T[Math.min(Math.max(n,0),3)];

  // stat strip
  function mkStat(label, color) {
    const num = h('div',{class:'f18 b mono',style:`color:${color};font-variant-numeric:tabular-nums;line-height:1`,text:'0'});
    return { el: h('div',{class:'col',style:`align-items:center;padding:10px 18px;border-right:1px solid var(--border);flex:1;gap:2px`},
      num, h('div',{class:'f9 ts',text:label,style:'letter-spacing:.5px;text-transform:uppercase'})), num };
  }
  const sT=mkStat('Total','var(--text_primary)'),sW=mkStat('Watching','var(--warning)'),
        sX=mkStat('Warnings','#FF9500'),sD=mkStat('Dangerous','var(--error)'),sB=mkStat('Blocked IPs','var(--error)');
  function updateStats(snap) {
    const dan=snap.dangerous||0,sus=snap.suspicious||0;
    sT.num.textContent=snap.total||0; sW.num.textContent=Math.max(0,sus-dan);
    sX.num.textContent=dan; sD.num.textContent=dan; sB.num.textContent=snap.blocked||0;
  }
  const statsStrip=h('div',{class:'row',style:'background:var(--bg_card);border:1px solid var(--border);border-radius:8px;margin-bottom:10px;overflow:hidden;flex-shrink:0'},
    sT.el,sW.el,sX.el,sD.el,sB.el);

  // controls
  const dot=h('div',{style:'width:7px;height:7px;border-radius:50%;background:var(--text_disabled);transition:background .3s;flex-shrink:0'});
  const lbl=h('span',{class:'f11 td',text:'Stopped'});
  const monBtn=Btn('Start Monitor',{h:28,w:112,f:11,bold:true,onclick:async()=>{
    if(!monitorRunning){
      await rpc('network.start'); monitorRunning=true;
      monBtn.textContent='Stop Monitor'; monBtn.style.background='rgba(255,59,48,.12)';
      monBtn.style.borderColor='rgba(255,59,48,.5)'; monBtn.style.color='var(--error)';
      dot.style.background='var(--success)'; lbl.style.color='var(--success)'; lbl.textContent='Live';
    } else {
      await rpc('network.stop'); monitorRunning=false;
      monBtn.textContent='Start Monitor'; monBtn.style.cssText='';
      dot.style.background='var(--text_disabled)'; lbl.style.color='var(--text_disabled)'; lbl.textContent='Stopped';
    }
  }});
  const notifSw=Switch({big:false,checked:false,onchange:async v=>{notificationsOn=v;await rpc('network.set_notifications',{enabled:v});}});
  const autoSw=Switch({big:false,checked:false,onchange:async v=>{autoBlockOn=v;await rpc('network.set_auto_block',{enabled:v});}});
  const searchIn=Entry({placeholder:'Filter process or IP…',h:28,f:11,onchange:v=>{connFilter=v.trim().toLowerCase();paintConns();}});
  searchIn.style.width='200px';

  const pills={};
  [['flagged','Flagged'],['danger','Danger'],['warn','Warn'],['watch','Watch'],['all','All']].forEach(([k,l])=>{
    const p=h('div',{style:`padding:3px 10px;border-radius:99px;font-size:10px;cursor:pointer;border:1px solid var(--border);color:var(--text_disabled);transition:.1s;user-select:none`,text:l,
      onclick:()=>{threatFilter=k;repaintPills();paintConns();}});
    pills[k]=p;
  });
  function repaintPills(){
    const C={flagged:'var(--accent)',danger:'var(--error)',warn:'#FF9500',watch:'var(--warning)',all:'var(--text_secondary)'};
    Object.entries(pills).forEach(([k,p])=>{
      const a=k===threatFilter,c=C[k]||'var(--accent)';
      p.style.background=a?c+'1a':'transparent'; p.style.borderColor=a?c:'var(--border)';
      p.style.color=a?c:'var(--text_disabled)'; p.style.fontWeight=a?'600':'400';
    });
  }
  repaintPills();
  const ctrlRow=h('div',{class:'row',style:'gap:10px;align-items:center;padding:10px 14px;background:var(--bg_card);border:1px solid var(--border);border-radius:8px;margin-bottom:10px;flex-wrap:wrap;flex-shrink:0'},
    h('div',{class:'row',style:'gap:8px;align-items:center'},dot,lbl,monBtn),
    h('div',{class:'row',style:'gap:5px'},...Object.values(pills)),
    searchIn, h('div',{class:'grow'}),
    h('div',{class:'row',style:'gap:8px;align-items:center;border-left:1px solid var(--border);padding-left:10px'},
      h('span',{class:'f10 ts',text:'Alerts'}),
      h('span',{style:'margin-left:1px'},Info('Notification popup on serious threats.\nOnly fires when this toggle is ON.\nOnly Warn and above.')),
      notifSw,
      h('span',{class:'f10 ts',style:'margin-left:4px',text:'Auto-block'}),
      h('span',{style:'margin-left:1px'},Info('Automatically block Danger-level IPs via Windows Firewall without prompting.')),
      autoSw));

  // table
  const COLS=[['Threat','68px'],['Process','160px'],['Remote IP','135px'],['Port','52px'],['Proto','48px'],['State','90px'],['Reason','1']];
  const hdr=h('div',{class:'row',style:'padding:0 10px;background:var(--bg_card);border-bottom:1px solid var(--border);border-radius:6px 6px 0 0;position:sticky;top:0;z-index:2;flex-shrink:0'},
    ...COLS.map(([t,w])=>h('div',{class:'f9 b td',style:`${w==='1'?'flex:1':`width:${w};flex-shrink:0`};padding:5px 6px;white-space:nowrap`,text:t})));
  const tblBody=h('div');
  const tblWrap=h('div',{style:'flex:1;min-height:0;overflow-y:auto;background:var(--bg_input);border-radius:6px;border:1px solid var(--border);display:flex;flex-direction:column'},hdr,tblBody);

  function paintConns(){
    tblBody.textContent='';
    let rows=[...connData];
    if(threatFilter==='danger') rows=rows.filter(c=>c.threat>=3);
    else if(threatFilter==='warn')   rows=rows.filter(c=>c.threat>=2);
    else if(threatFilter==='watch')  rows=rows.filter(c=>c.threat>=1);
    else if(threatFilter==='flagged')rows=rows.filter(c=>c.threat>0);
    if(connFilter)rows=rows.filter(c=>(c.proc||'').toLowerCase().includes(connFilter)||(c.raddr||'').includes(connFilter)||String(c.rport||'').includes(connFilter));
    if(!rows.length){
      tblBody.append(h('div',{class:'f11 td',style:'padding:30px;text-align:center',
        text:!monitorRunning?'Click Start Monitor to begin scanning.':(connFilter||threatFilter!=='flagged')?'Nothing matches this filter.':'No flagged connections — all clear.'}));
      return;
    }
    rows.slice(0,300).forEach(c=>{
      const t=tc(c.threat);
      const row=h('div',{class:'row',style:`padding:5px 10px;border-bottom:1px solid rgba(255,255,255,.03);cursor:pointer;transition:background .08s`});
      if(c.threat>=2)row.style.background=t.dim;
      const cell=(w,txt,extra='')=>h('div',{class:'f11',title:String(txt),
        style:`${w==='1'?'flex:1':`width:${w};flex-shrink:0`};padding:0 6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${extra}`,text:String(txt)});
      const badge=h('div',{style:`width:68px;flex-shrink:0;padding:0 6px;display:flex;align-items:center`},
        h('div',{style:`padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700;background:${t.dim};border:1px solid ${t.color}55;color:${t.color};text-transform:uppercase`,text:t.label}));
      row.append(badge,
        cell('160px',c.proc||'(system)','font-weight:500'),
        cell('135px',c.raddr||'—','font-family:Consolas,monospace;font-size:10.5px;color:var(--text_secondary)'),
        cell('52px',c.rport||'—','font-variant-numeric:tabular-nums;color:var(--text_disabled)'),
        cell('48px',c.proto||'TCP','font-weight:600;color:var(--text_secondary)'),
        cell('90px',c.status||'—','color:var(--text_disabled)'),
        cell('1',c.reason||'',`color:${c.reason?t.color:'var(--text_disabled)'};font-size:10.5px`));
      row.onmouseenter=()=>{ row.style.filter='brightness(1.08)'; };
      row.onmouseleave=()=>{ row.style.filter=''; };
      row.addEventListener('click',()=>openAction(c));
      tblBody.append(row);
    });
    if(rows.length>300)tblBody.append(h('div',{class:'f10 td',style:'padding:8px;text-align:center',text:`+ ${rows.length-300} more — narrow with filter`}));
  }

  const actionStrip=h('div',{style:'display:none;padding:10px 14px;background:var(--bg_card);border-top:1px solid var(--border);border-radius:0 0 6px 6px;flex-shrink:0'});
  function openAction(c){
    const t=tc(c.threat);
    actionStrip.textContent='';
    actionStrip.append(
      h('div',{class:'row',style:'gap:10px;align-items:center;margin-bottom:8px'},
        h('div',{style:`font-size:9px;font-weight:700;padding:2px 7px;border-radius:3px;background:${t.dim};border:1px solid ${t.color}55;color:${t.color};text-transform:uppercase`,text:t.label}),
        h('span',{class:'f12 b',text:c.proc||'(system)'}),
        c.pid?h('span',{class:'f10 td',text:`PID ${c.pid}`}):null,
        c.raddr?h('span',{class:'f10 ts',style:'font-family:Consolas,monospace',text:`${c.raddr}:${c.rport}`}):null,
        c.reason?h('span',{class:'f10',style:`color:${t.color}`,text:c.reason}):null,
        h('div',{class:'grow'}),
        h('button',{class:'f10 td',style:'cursor:pointer;background:none;border:none;padding:0 4px',text:'Dismiss',
          onclick:()=>{actionStrip.style.display='none';}})),
      h('div',{class:'row',style:'gap:6px'},
        c.raddr?Btn(`Block ${c.raddr}`,{variant:'danger',h:26,f:10,onclick:async()=>{await rpc('network.block_ip',{ip:c.raddr});actionStrip.style.display='none';}}):null,
        c.proc?Btn(`Allow "${c.proc}"`,{variant:'ghost',h:26,f:10,onclick:async()=>{await addAllow(c.proc);actionStrip.style.display='none';}}):null,
        c.raddr?Btn(`Allow ${c.raddr}`,{variant:'ghost',h:26,f:10,onclick:async()=>{await addAllow(c.raddr);actionStrip.style.display='none';}}):null));
    actionStrip.style.display='block';
  }

  const alertEl=h('div',{style:'display:none;position:fixed;bottom:80px;right:20px;z-index:2000;width:330px;background:rgba(18,0,0,.97);border:1.5px solid var(--error);border-radius:10px;padding:16px;box-shadow:0 8px 40px rgba(255,59,48,.3);animation:nm-slidein .2s ease'});
  const alertTitle=h('div',{class:'f13 b',style:'color:var(--error);margin-bottom:5px',text:'Threat Detected'});
  const alertBody=h('div',{class:'f11',style:'color:var(--text_secondary);margin-bottom:12px;line-height:1.6;white-space:pre-wrap'});
  const aAct=Btn('Block Attacker',{h:30,f:11,bold:true,onclick:async()=>{if(pendingAlert?.raddr)await rpc('network.block_ip',{ip:pendingAlert.raddr});alertEl.style.display='none';pendingAlert=null;}});
  aAct.style.cssText+=';background:var(--error);color:#fff;flex:1';
  const aIgn=Btn('Ignore',{variant:'ghost',h:30,f:11,onclick:()=>{alertEl.style.display='none';pendingAlert=null;}});
  aIgn.style.flex='1';
  alertEl.append(alertTitle,alertBody,h('div',{class:'row',style:'gap:8px'},aAct,aIgn));
  document.body.append(alertEl);

  const allowBody=h('div',{style:'max-height:100px;overflow-y:auto'});
  function paintAllow(){
    allowBody.textContent='';
    if(!allowlist.length){allowBody.append(h('div',{class:'f10 td',style:'padding:4px 0',text:'Empty. Built-in safe apps always trusted.'}));return;}
    allowlist.forEach(e=>allowBody.append(h('div',{class:'row',style:'padding:2px 0'},
      h('span',{class:'f11 grow',text:e}),
      h('button',{class:'f10',style:'cursor:pointer;background:none;border:none;color:var(--error)',text:'Remove',onclick:async()=>{await removeAllow(e);} }))));
  }
  async function addAllow(e){if(!e?.trim())return;await rpc('network.allowlist_add',{entry:e.trim()});allowlist=await rpc('network.allowlist_get').catch(()=>[]);paintAllow();}
  async function removeAllow(e){await rpc('network.allowlist_remove',{entry:e});allowlist=await rpc('network.allowlist_get').catch(()=>[]);paintAllow();}
  const allowIn=Entry({placeholder:'Process name or IP…',fill:true,h:26,f:11});

  const histBody=h('div',{style:'max-height:150px;overflow-y:auto'});
  async function loadHistory(){
    const hist=await rpc('network.history').catch(()=>[]);
    histBody.textContent='';
    if(!hist.length){histBody.append(h('div',{class:'f10 td',style:'padding:4px 0',text:'No flagged connections yet.'}));return;}
    [...hist].reverse().slice(0,60).forEach(c=>{
      const t=tc(c.threat);
      histBody.append(h('div',{class:'row',style:'padding:3px 0;border-bottom:1px solid rgba(255,255,255,.04);gap:6px'},
        h('div',{style:`width:44px;flex-shrink:0;font-size:9px;font-weight:700;color:${t.color}`,text:t.label.toUpperCase()}),
        h('div',{class:'f10 grow ell',text:`${c.proc||'?'} — ${c.raddr}:${c.rport}`}),
        c.raddr?h('button',{class:'f9',style:'cursor:pointer;background:none;border:none;color:var(--error);flex-shrink:0',text:'Block',onclick:()=>rpc('network.block_ip',{ip:c.raddr})}):null));
    });
  }

  const sidePanel=h('div',{style:'width:260px;flex-shrink:0;display:flex;flex-direction:column;gap:10px;overflow-y:auto'},
    Card([h('div',{class:'f12 b tp',style:'padding:10px 14px 5px',text:'Allow List'}),
      h('div',{class:'f9 td',style:'padding:0 14px 5px;white-space:normal;line-height:1.5',text:'Listed apps/IPs are never flagged. Windows, Chrome, Steam, Discord and VPN software are trusted automatically. Add entries to stop false positives.'}),
      h('div',{style:'padding:0 14px 5px'},allowBody),
      h('div',{class:'row',style:'padding:0 14px 10px;gap:6px'},allowIn,
        Btn('Add',{h:26,w:46,f:10,onclick:()=>{addAllow(allowIn.value?.trim());allowIn.value='';}}))],'col',{marginBottom:'0',flexShrink:'0'}),
    Card([h('div',{class:'row',style:'padding:10px 14px 5px;align-items:center'},
        h('span',{class:'f12 b tp',text:'Flagged History'}),h('div',{class:'grow'}),
        Btn('Refresh',{variant:'ghost',h:22,f:9,onclick:loadHistory})),
      h('div',{style:'padding:0 14px 10px'},histBody)],'col',{marginBottom:'0',flexShrink:'0'}),
    Card([h('div',{class:'f12 b tp',style:'padding:10px 14px 5px',text:'Scoring Guide'}),
      h('div',{class:'f9 td',style:'padding:0 14px 10px;white-space:pre-wrap;line-height:1.7',
        text:'DANGER  Known bad port + unknown process.\nPort scans, C2 beacons, RAT ports (4444, 1337…).\n\nWARN    High ephemeral port, unknown process.\n\nWATCH   Unusual state or port combo.\n\nSAFE    Built-in apps, LAN/private IPs, standard\nports, all allowlisted entries. VPN, proxy and\ntunnel traffic is always safe (private range).'})],'col',{marginBottom:'0',flexShrink:'0'}));

  on('network.snapshot',snap=>{if(!snap)return;connData=snap.connections||[];updateStats(snap);paintConns();});
  on('network.alert',alert=>{
    if(!alert||!notificationsOn||alert.threat<2)return;
    pendingAlert=alert;
    alertTitle.textContent=alert.threat>=3?'Serious Threat Detected':'Suspicious Connection';
    alertTitle.style.color=alert.threat>=3?'var(--error)':'#FF9500';
    alertEl.style.borderColor=alert.threat>=3?'var(--error)':'#FF9500';
    alertBody.textContent=`Process: ${alert.proc||'Unknown'} (PID ${alert.pid||'?'})\nRemote: ${alert.raddr}:${alert.rport}\nReason: ${alert.reason||'Unusual activity'}`;
    alertEl.style.display='block';
    if(alert.threat>=3){try{window.electronAPI?.showNotification?.('DWUT — Threat Detected',`${alert.proc||'Unknown'} connected to ${alert.raddr}`);}catch{}}
  });

  const connCard=h('div',{style:'flex:1;min-height:0;display:flex;flex-direction:column;background:var(--bg_card);border:1px solid var(--border);border-radius:8px;overflow:hidden'},
    h('div',{style:'padding:10px 14px 8px;flex-shrink:0'},
      h('div',{class:'f13 b tp',text:'Live Connections'}),
      h('div',{class:'f10 td',text:'Click any row to block or allowlist it. VPN, proxy and LAN traffic is always safe.',style:'margin-top:1px'})),
    h('div',{style:'flex:1;min-height:0;display:flex;flex-direction:column;padding:0 14px 0'},tblWrap),
    actionStrip,h('div',{style:'height:8px'}));

  const el=h('div',{class:'col',style:'flex:1;min-height:0'},
    h('div',{class:'title-row'},h('h1',{text:'Network Monitor'}),h('div',{class:'grow'}),
      h('span',{class:'f10 td',text:'Real-time · threat detection · IP blocking'})),
    h('div',{style:'position:relative;flex:1;min-height:0;margin:8px 20px 16px;display:flex;flex-direction:column'},
      ctrlRow,statsStrip,
      h('div',{class:'row',style:'flex:1;min-height:0;gap:10px;align-items:stretch'},connCard,sidePanel)));
  return {
    el,
    async onShow(){
      allowlist=await rpc('network.allowlist_get').catch(()=>[]);
      paintAllow(); await loadHistory();
      if(!monitorRunning)monBtn.click();
    },
    onHide(){}
  };
});

# DWUT - Electron edition

The CustomTkinter UI is replaced by an Electron UI. **All logic is still the original Python**
(`backend/modules/*`, PowerShell scripts included) - Electron talks to it over a JSON pipe
(`backend/server.py`). The UI no longer builds thousands of Tk widgets, which was the source of the lag.

## Install / run
* One-liner (after you publish this zip as a GitHub release asset):
  `irm https://raw.githubusercontent.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT/main/bootstrap.ps1 | iex`
* From this folder: right-click `bootstrap.ps1` > Run with PowerShell (or `powershell -ep bypass -File bootstrap.ps1`).
  It installs Python (if missing), the Electron runtime (SHA-256 verified), the pip packages, makes a
  desktop shortcut and launches. Later: `run.bat`.
* Dev: `npm install` then `npm start` (needs Python 3.10+ and `pip install -r requirements.txt`).

## Fixes in this version
**Disk Cleanup (Tools)** - event logs: only the first 50 of 1000+ channels were cleared; now every channel
(parallel). Temp: read-only files made whole folders fail silently; junctions are no longer followed;
"freed" MB is now measured per deleted file instead of estimated; in-use files are counted and reported;
duplicate paths (TEMP == LocalAppData\Temp) are de-duplicated; long paths and admin ownership fallback.

**Game Booster** - power plan: `powercfg /duplicatescheme` returns a NEW GUID, the old code activated the
template GUID so it always failed. Now parsed + verified; falls back Ultimate > High > tuned copy of the
active plan (Modern Standby laptops). The typed game name was never turned into a PID, so priority was never
set - now matched against running processes. **Empty name = auto-detect** (known-game list, game folders,
`*-Win64-Shipping.exe`, fullscreen foreground window) *after* background apps are closed, and a watcher
boosts a game launched later. **Apply Boost opens an exclusion popup** (untick Discord etc.). Launchers
that are the game's parent (e.g. Steam) are protected automatically; anti-cheat/GPU/system processes are never killed.

**FPS Unlocker** - Roblox: old method scanned the heap for every `60.0` double and overwrote it (wrong
units, corrupts memory, blocked by Hyperion). Now writes the `DFIntTaskSchedulerTargetFps` client setting
into every Roblox version (+ Bloxstrap/Fishstrap/Voidstrap). **Also Fortnite** (`FrameRateLimit` in
GameUserSettings.ini) **and Minecraft Java** (`maxFps`). Nothing touches game memory, so it is anti-cheat safe.
Valorant/Apex/etc. are deliberately not offered: they have no config cap to remove. Restart the game after enabling.

**Deep Clean** - download layer rewritten (`modules/cleaner/downloader.py`): mirror lists, x64/x86/ARM64,
validates PE/ZIP headers (old code saved HTML error pages as .exe), extracts ZIPs (MBAR, GMER), checks
Authenticode, `python -m modules.cleaner.downloader --check` probes every link. Wrong links fixed
(HitmanPro, MSRT, FRST, KVRT, Norton NPE, Stinger...). Discontinued tools removed (aswMBR, Spybot, ClamWin).
Correct silent flags for rkill/AdwCleaner/TDSSKiller/MSRT/KVRT/Stinger; GUI-only tools are now guided
manual steps instead of hanging 30 min. Hibernate/sleep are now actually restored. Defrag no longer
runs on NVMe. `bcdboot` no longer pollutes UEFI systems. Explorer repair no longer pops a window. WU repair
renames instead of deleting. PSWindowsUpdate/NuGet prompt fixed. The DNS dropdown is now wired in. Pause/Skip work.
Previously silent no-op steps (VC++/DirectX/.NET repair, exports, installer cleanup, pagefile, visual effects,
privacy) are implemented; the ones that are deliberately not automated now say `[SKIP]` in the log.

## Honest limits
Built and regression-tested on Linux with Windows APIs stubbed: UI renders (all 8 pages, 0 errors), the RPC
layer, disk-cleanup logic and FPS file logic are tested. Real Windows behaviour (powercfg, wevtutil, tool
downloads, UAC) and `bootstrap.ps1` itself could not be executed here - run it once and send me the log if
anything misbehaves. Run `python -m modules.cleaner.downloader --check` on your PC to confirm every Deep Clean link.

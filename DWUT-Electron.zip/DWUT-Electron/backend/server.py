"""
backend/server.py — DWUT backend, spoken to by Electron over stdin/stdout.

Protocol: one JSON object per line.
  Electron -> Python   {"id": 7, "method": "gaming.boost", "params": {...}}
  Python -> Electron   {"id": 7, "result": ...}  |  {"id": 7, "error": "..."}
  Python -> Electron   {"event": "gaming.fps_status", "data": ...}       (pushed, any time)

All the real work is done by the ORIGINAL modules/ package — this file only routes
calls and forwards EventBus events.  The protocol runs on a private duplicate of
stdout so stray print() calls (the cleaner engine prints) can never corrupt it.
"""
from __future__ import annotations

import dataclasses
import datetime
import enum
import json
import os
import sys
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# ── isolate the protocol channel BEFORE anything else can print ───────────────
_PROTO = os.fdopen(os.dup(1), "w", encoding="utf-8", newline="\n", buffering=1)
os.dup2(2, 1)
sys.stdout = sys.stderr
# private copy of stdin for OUR protocol; every child process inherits NUL instead,
# so a tool that reads stdin can never swallow commands meant for this server
_STDIN = os.fdopen(os.dup(0), "r", encoding="utf-8", errors="replace", newline="\n")
_nul = os.open(os.devnull, os.O_RDONLY)
os.dup2(_nul, 0)
os.close(_nul)
try:
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")   # type: ignore[attr-defined]
except Exception:
    pass

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.modules.setdefault("server", sys.modules[__name__])   # api/* import `server` — must be THIS module, not a 2nd copy

from app.config import config, ensure_dirs           # noqa: E402

ensure_dirs()
from core.logger import _setup_logging, get_logger    # noqa: E402

_setup_logging(config.log_level)
_log = get_logger("server")

from app.permissions import is_admin                   # noqa: E402
from app.state import state                            # noqa: E402
from core.events import Events, bus                    # noqa: E402

state.is_admin = is_admin()

# ── JSON serialisation of dataclasses & friends ───────────────────────────────

_send_lock = threading.Lock()


def to_json(o):
    if o is None or isinstance(o, (bool, int, str)):
        return o
    if isinstance(o, float):
        return o if o == o and o not in (float("inf"), float("-inf")) else None
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        d = {f.name: to_json(getattr(o, f.name)) for f in dataclasses.fields(o)}
        for prop in ("total_mb", "total_gb", "total_mb_freed", "working", "url", "key", "address"):
            try:
                if prop not in d and isinstance(getattr(type(o), prop, None), property):
                    d[prop] = to_json(getattr(o, prop))
            except Exception:
                pass
        return d
    if isinstance(o, dict):
        return {str(k): to_json(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set, frozenset)):
        return [to_json(v) for v in o]
    if isinstance(o, datetime.datetime):
        return o.isoformat()
    if isinstance(o, datetime.timedelta):
        return o.total_seconds()
    if isinstance(o, enum.Enum):
        return to_json(o.value)
    if isinstance(o, Path):
        return str(o)
    if isinstance(o, bytes):
        return o.decode("utf-8", "replace")
    if isinstance(o, BaseException):
        return str(o)
    if hasattr(o, "__dict__"):
        return {k: to_json(v) for k, v in vars(o).items() if not k.startswith("_")}
    return str(o)


def send(obj: dict) -> None:
    try:
        line = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    except Exception as exc:
        line = json.dumps({"id": obj.get("id"), "error": f"serialisation failed: {exc}"})
    with _send_lock:
        try:
            _PROTO.write(line + "\n")
            _PROTO.flush()
        except Exception:
            os._exit(0)                                   # Electron went away


def emit(event: str, data=None) -> None:
    send({"event": event, "data": to_json(data)})


# ── method registry ───────────────────────────────────────────────────────────

METHODS: dict = {}


def rpc(name: str | None = None):
    def deco(fn):
        METHODS[name or fn.__name__] = fn
        return fn
    return deco


# ── forward every EventBus event to Electron ──────────────────────────────────

_EVENT_NAMES = [v for k, v in vars(Events).items() if not k.startswith("_") and isinstance(v, str)]
_EVENT_NAMES += ["gaming.boost_progress", "cleaner.log", "cleaner.step_start", "cleaner.step_done",
                 "cleaner.phase_start", "cleaner.phase_done", "cleaner.done", "cleaner.manual",
                 "cleaner.tool_status", "dashboard.tick", "speedtest.progress", "speedtest.done",
                 "vpn.state", "vpn.progress", "proxy.connect_progress"]


def _forward(ev):
    def cb(data):
        emit(ev, data)
    return cb


# proxy events carry big object lists — api/proxy_api.py re-publishes them as compact rows
_NO_FORWARD = {Events.PROXY_FETCH_DONE, Events.PROXY_CHECK_DONE, Events.PROXY_RESULT_BATCH}
for _ev in _EVENT_NAMES:
    if _ev not in _NO_FORWARD:
        bus.subscribe(_ev, _forward(_ev))

# ── load API modules (each registers its @rpc methods) ────────────────────────
from api import core_api, system_api, gaming_api, debloat_api, proxy_api, cleaner_api, vpn_api, usb_api, vm_api  # noqa: E402,F401


# ── dispatch ──────────────────────────────────────────────────────────────────

_pool = ThreadPoolExecutor(max_workers=48, thread_name_prefix="rpc")


def _handle(msg: dict) -> None:
    rid = msg.get("id")
    method = msg.get("method", "")
    params = msg.get("params") or {}
    fn = METHODS.get(method)
    if fn is None:
        send({"id": rid, "error": f"unknown method: {method}"})
        return
    try:
        result = fn(**params) if isinstance(params, dict) else fn(*params)
        send({"id": rid, "result": to_json(result)})
    except Exception as exc:
        _log.error("RPC %s failed: %s", method, exc, exc_info=True)
        send({"id": rid, "error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-1500:]})


def main() -> None:
    _log.info("Backend ready (admin=%s)", state.is_admin)
    emit("backend.ready", {"is_admin": state.is_admin, "pid": os.getpid()})

    try:
        from app.updater import check_for_update_async
        check_for_update_async(callback=lambda info: bus.publish(Events.UPDATE_AVAILABLE, info))
    except Exception as exc:
        _log.debug("Updater init failed (non-fatal): %s", exc)

    for line in _STDIN:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue
        if msg.get("method") == "backend.shutdown":
            break
        _pool.submit(_handle, msg)

    # stdin closed => Electron exited: undo anything still applied
    state.shutting_down = True
    for mod, attr, fn in (("modules.gaming.fps_unlock", "fps_unlocker", "disable"),
                          ("modules.gaming.booster", "booster", "deactivate")):
        try:
            import importlib
            obj = getattr(importlib.import_module(mod), attr)
            if getattr(obj, "is_active", False):
                getattr(obj, fn)()
        except Exception:
            pass
    try:
        from api.vpn_api import shutdown_vpn
        shutdown_vpn()
    except Exception:
        pass
    try:
        from api.proxy_api import shutdown_proxy
        shutdown_proxy()
    except Exception:
        pass
    os._exit(0)


if __name__ == "__main__":
    main()

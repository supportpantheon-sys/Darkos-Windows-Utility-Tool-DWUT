"""api/system_api.py — generic module-call bridge + Optimizer/Tools data."""
from __future__ import annotations

import importlib
import re

from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from server import rpc

_log = get_logger("api.system")


def _resolve(module: str, fn: str):
    if not module.startswith("modules."):
        raise PermissionError(f"module not allowed: {module}")
    if fn.startswith("_") and not module.endswith("popups"):
        raise PermissionError(f"function not allowed: {fn}")
    return getattr(importlib.import_module(module), fn)


@rpc("call")
def call(module: str, fn: str, args: list | None = None, kwargs: dict | None = None, bg: bool = False):
    """Call any modules.* function with the ORIGINAL signature.
    bg=True mirrors `worker.submit(fn, ...)`: return immediately, results arrive via events."""
    func = _resolve(module, fn)
    args, kwargs = args or [], kwargs or {}
    if bg:
        worker.submit(func, *args, on_error=lambda e: (_log.error("%s failed: %s", fn, e),
                      bus.publish(Events.APP_ERROR, f"{fn} failed: {e}")), **kwargs)
        return True
    return func(*args, **kwargs)


@rpc("optimizer.static")
def optimizer_static():
    from modules.debloat.operations import FEATURES
    from modules.system.platform_info import is_windows_11
    from modules.system.windows_features import WINDOWS_FEATURES
    from modules.system.winutil import get_available_tools, get_dns_presets
    return {
        "features": [dict(key=f.key, name=f.name, desc=f.desc, recommended=f.recommended, severity=f.severity,
                          category=f.category, windows11_only=f.windows11_only) for f in FEATURES],
        "win_features": [dict(key=w.key, name=w.name, desc=w.desc) for w in WINDOWS_FEATURES],
        "dns_presets": get_dns_presets(),
        "tools": get_available_tools(),
        "is_win11": is_windows_11(),
    }


@rpc("optimizer.power_state")
def power_state():
    from modules.system.power_modes import is_extreme_performance_active, is_ultimate_performance_active
    return [is_ultimate_performance_active(), is_extreme_performance_active()]


@rpc("optimizer.apply_features")
def apply_features_bg(keys: list):
    from modules.debloat.operations import apply_features
    worker.submit(apply_features, keys, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Tweak apply failed: {e}"))
    return True


@rpc("optimizer.install_win_features")
def install_win_features(keys: list):
    from modules.system.windows_features import enable_features_batch
    worker.submit(enable_features_batch, keys, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Feature install failed: {e}"))
    return True


# ═════════════════════════════ Tools page ════════════════════════════════════
_reg_issues: list = []
_startup: list = []


@rpc("tools.reg_scan")
def reg_scan():
    from modules.system.registry_cleaner import scan_registry
    global _reg_issues
    r = scan_registry()
    _reg_issues = list(r.issues)
    return {
        "issues": [dict(i=n, description=x.description, detail=x.detail, priority=x.priority) for n, x in enumerate(r.issues)],
        "duration": r.scan_duration_s, "high": r.high_count, "medium": r.medium_count, "low": r.low_count,
    }


@rpc("tools.reg_backup")
def reg_backup():
    from modules.system.registry_cleaner import export_registry_backup
    return export_registry_backup() or "Backup failed"


@rpc("tools.reg_clean")
def reg_clean(indices: list):
    from modules.system.registry_cleaner import clean_issues
    sel = [_reg_issues[i] for i in indices if 0 <= i < len(_reg_issues)]
    r = clean_issues(sel, create_backup=True)
    return {"deleted": r.deleted, "failed": r.failed, "backup_path": r.backup_path, "duration_s": r.duration_s}


@rpc("tools.startup_list")
def startup_list():
    from modules.system.startup import get_startup_entries
    global _startup
    _startup = list(get_startup_entries())
    return [dict(i=n, name=e.name, location=e.location, command=e.command, enabled=e.enabled, impact=e.impact_from_path())
            for n, e in enumerate(_startup)]


@rpc("tools.startup_set")
def startup_set(indices: list, enable: bool):
    from modules.system.startup import disable_startup_entry, enable_startup_entry
    fn = enable_startup_entry if enable else disable_startup_entry
    return sum(1 for i in indices if 0 <= i < len(_startup) and fn(_startup[i]))


@rpc("tools.startup_open")
def startup_open(index: int):
    from modules.system.startup import open_file_location
    if 0 <= index < len(_startup):
        worker.submit(open_file_location, _startup[index])
    return True


def _cat(c):
    return dict(key=c.key, name=c.name, description=c.description, aggressive=c.aggressive, estimated_mb=c.estimated_mb)


@rpc("tools.disk_categories")
def disk_categories():
    from modules.system.disk_cleanup import _make_categories
    return [_cat(c) for c in _make_categories()]


@rpc("tools.disk_scan")
def disk_scan():
    from modules.system.disk_cleanup import scan_disk_categories
    r = scan_disk_categories()
    return {"categories": [_cat(c) for c in r.categories], "total_bytes": r.total_bytes}


@rpc("tools.disk_clean")
def disk_clean(keys: list):
    from modules.system.disk_cleanup import clean_categories
    r = clean_categories(keys)
    return {"mb_freed": r.total_bytes_freed / (1024 * 1024), "files_deleted": r.files_deleted, "errors": r.errors}


@rpc("tools.drives")
def drives():
    import os
    import string
    from modules.system.disk_cleanup import get_drive_info
    return [get_drive_info(f"{d}:\\") for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]


# ═════════════ winget: apps whose installed version can't be determined ═════════════
def _parse_winget_table(text: str) -> list:
    """Rows of `winget upgrade` as dicts, using the header's column positions."""
    lines = [l.rstrip() for l in text.replace("\r", "").split("\n")]
    hdr = next((i for i, l in enumerate(lines) if "Name" in l and "Id" in l and "Version" in l), None)
    if hdr is None:
        return []
    h = lines[hdr]
    cols = [("name", h.index("Name")), ("id", h.index("Id")), ("version", h.index("Version"))]
    cols.append(("available", h.index("Available")) if "Available" in h else ("available", len(h)))
    rows = []
    for l in lines[hdr + 2:]:
        if not l.strip() or l.startswith(("---", " ")) and not l[:1].isalnum():
            continue
        if re.match(r"^\d+ (upgrade|package)", l.strip()):
            break
        r = {}
        for i, (k, st) in enumerate(cols):
            en = cols[i + 1][1] if i + 1 < len(cols) else len(l)
            r[k] = l[st:en].strip()
        if r["id"]:
            rows.append(r)
    return rows


@rpc("updates.winget_scan")
def winget_scan():
    """Find out what winget can update and which apps it can't read a version for."""
    from modules.system.winutil import _find_winget
    import subprocess
    w = _find_winget()
    def run_(args):
        r = subprocess.run([w, *args], capture_output=True, text=True, timeout=300, errors="replace",
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), stdin=subprocess.DEVNULL)
        return r.stdout + r.stderr
    normal = run_(["upgrade", "--accept-source-agreements"])
    m = re.search(r"(\d+) package\(s\) have version numbers that cannot be determined", normal)
    n_unknown = int(m.group(1)) if m else 0
    unknown = []
    if n_unknown:
        full = run_(["upgrade", "--include-unknown", "--accept-source-agreements"])
        unknown = [r for r in _parse_winget_table(full) if r["version"].lower().startswith("unknown")]
    return {"unknown_count": n_unknown, "unknown": unknown, "known": _parse_winget_table(normal)}

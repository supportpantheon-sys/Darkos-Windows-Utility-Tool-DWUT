"""api/proxy_api.py — Proxy Center bridge. Proxy lists/results stay in Python; the UI gets compact rows."""
from __future__ import annotations

import json
import re
import threading

from core.events import Events, bus
from core.worker import worker
from server import emit, rpc

_raw: list = []
_results: list = []
_live: list = []
_stop: threading.Event | None = None
_lock = threading.Lock()


def _row(r) -> dict:
    if getattr(r, "youtube_ok", False):
        https = "YT OK"
    elif r.browse_ok:
        https = "OK"
    elif r.https_ok:
        https = "~"
    elif r.tier in ("dead",):
        https = "-"
    else:
        https = "NO"
    p = r.proxy
    return {
        "address": p.address(), "ip": p.ip, "port": p.port, "protocol": p.protocol, "https": https,
        "country": r.country or "—", "latency": f"{r.tcp_latency_ms:.0f} ms" if r.tcp_latency_ms else "—",
        "anonymity": r.anonymity or "—", "score": r.score, "tier": r.tier,
        "yt": bool(getattr(r, "youtube_ok", False)), "elite": r.anonymity == "elite",
    }


# ── bus -> compact events ─────────────────────────────────────────────────────

def _on_fetch_done(proxies):
    global _raw
    _raw = list(proxies)
    emit("proxy.fetch_done", {"count": len(_raw), "preview": [f"{p.protocol}://{p.ip}:{p.port}" for p in _raw[:3000]]})


def _on_check_done(results):
    global _results, _stop
    _results = list(results)
    _stop = None
    t = lambda *names: sum(1 for r in _results if r.tier in names)  # noqa: E731
    excellent, good, fair = t("excellent"), t("good"), t("fair")
    emit("proxy.check_done", {
        "total": len(_results), "excellent": excellent, "good": good, "fair": fair, "rejected": t("rejected", "dead"),
        "youtube": sum(1 for r in _results if getattr(r, "youtube_ok", False)),
        "elite": sum(1 for r in _results if r.anonymity == "elite" and r.tier != "dead"),
        "working": excellent + good + fair, "stopped": len(_results) < len(_raw),
    })


def _on_batch(batch):
    if not batch:
        return
    with _lock:
        _live.extend(batch)
    emit("proxy.batch", [_row(r) for r in batch])


bus.subscribe(Events.PROXY_FETCH_DONE, _on_fetch_done)
bus.subscribe(Events.PROXY_CHECK_DONE, _on_check_done)
bus.subscribe(Events.PROXY_RESULT_BATCH, _on_batch)


# ── calls ─────────────────────────────────────────────────────────────────────

@rpc("proxy.fetch")
def proxy_fetch():
    from modules.proxy.sources import fetch_all_sources
    worker.submit(fetch_all_sources, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Fetch failed: {e}"))
    return True


@rpc("proxy.check")
def proxy_check(workers: int = 50, region: str = "Any", protocol: str = "any", min_anonymity: str = "any",
                max_latency_ms: float | None = None):
    global _stop
    from modules.proxy.checker import check_all
    if not _raw:
        return False
    with _lock:
        _live.clear()
    _stop = threading.Event()
    worker.submit(check_all, list(_raw), max_workers=max(1, min(int(workers), 150)), stop_event=_stop,
                  region_filter=region, protocol_filter=protocol, min_anonymity=min_anonymity,
                  max_latency_ms=max_latency_ms,
                  on_error=lambda e: bus.publish(Events.APP_ERROR, f"Check failed: {e}"))
    return True


@rpc("proxy.stop")
def proxy_stop():
    if _stop:
        _stop.set()
    return True


@rpc("proxy.counts")
def proxy_counts():
    return {"raw": len(_raw), "results": len(_results)}


def _best():
    for tier in ("excellent", "good", "fair"):
        c = [r for r in _results if r.tier == tier]
        if c:
            c.sort(key=lambda r: (not getattr(r, "youtube_ok", False), -r.score, r.tcp_latency_ms or 9999))
            return c[0]
    return None


@rpc("proxy.connect_best")
def proxy_connect_best():
    from modules.proxy.connect import enable_proxy
    b = _best()
    if b is None:
        return {"ok": False, "message": "No working proxies — run Check All first."}
    ok, msg = enable_proxy(b.proxy.ip, b.proxy.port, b.proxy.protocol)
    return {"ok": ok, "message": msg}


@rpc("proxy.enable")
def proxy_enable(ip: str, port: int, protocol: str = "http"):
    from modules.proxy.connect import enable_proxy
    proto = protocol
    for r in _live or _results:
        if r.proxy.ip == ip and r.proxy.port == int(port):
            proto = r.proxy.protocol
            break
    ok, msg = enable_proxy(ip, int(port), proto)
    return {"ok": ok, "message": msg}


@rpc("proxy.disconnect")
def proxy_disconnect():
    from modules.proxy.connect import disable_proxy
    ok, msg = disable_proxy()
    return {"ok": ok, "message": msg}


@rpc("proxy.active")
def proxy_active():
    from modules.proxy.connect import get_active_proxy
    return get_active_proxy()


_RE_SCHEME = re.compile(r"^(?P<proto>https?|socks[45])://(?:(?P<creds>[^@]+)@)?(?P<host>[^:/]+):(?P<port>\d+)", re.IGNORECASE)
_RE_BARE = re.compile(r"^(?P<host>[^:/\s]+):(?P<port>\d+)(?::(?P<proto>https?|socks[45]))?$", re.IGNORECASE)


@rpc("proxy.import")
def proxy_import(text: str, default_protocol: str = "http"):
    global _raw
    from modules.proxy.sources import ProxyRecord
    parsed, skipped = [], 0
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _RE_SCHEME.match(line)
        if m:
            parsed.append(ProxyRecord(ip=m.group("host"), port=int(m.group("port")),
                                      protocol=m.group("proto").lower().replace("https", "http"), credentials=m.group("creds")))
            continue
        m = _RE_BARE.match(line)
        if m:
            rp = (m.group("proto") or "").lower().replace("https", "http")
            parsed.append(ProxyRecord(ip=m.group("host"), port=int(m.group("port")),
                                      protocol=rp if rp in ("http", "socks4", "socks5") else default_protocol))
            continue
        skipped += 1
    if not parsed:
        return {"ok": False, "skipped": skipped, "new": 0, "dupes": 0, "total": len(_raw)}
    seen = {(p.ip, p.port, p.protocol) for p in _raw}
    new = []
    for p in parsed:
        k = (p.ip, p.port, p.protocol)
        if k not in seen:
            seen.add(k)
            new.append(p)
    _raw = _raw + new
    return {"ok": True, "new": len(new), "dupes": len(parsed) - len(new), "skipped": skipped, "total": len(_raw)}


@rpc("proxy.export")
def proxy_export(fmt: str):
    working = [r for r in _results if r.tier in ("excellent", "good", "fair")]
    if not working:
        return {"count": 0, "text": ""}
    P = [r.proxy for r in working]
    if fmt == "ip:port":
        lines = [f"{p.ip}:{p.port}" for p in P]
    elif fmt == "ip:port:protocol":
        lines = [f"{p.ip}:{p.port}:{p.protocol}" for p in P]
    elif fmt == "Proxifier (*.ppx)":
        tp = {"http": "HTTPS", "socks4": "SOCKS4", "socks5": "SOCKS5"}
        body = "".join(f'    <Proxy id="{100 + i}" type="{tp.get(p.protocol, "HTTPS")}">\n      <Address>{p.ip}</Address>\n      <Port>{p.port}</Port>\n      <Options>48</Options>\n    </Proxy>\n' for i, p in enumerate(P))
        lines = ['<?xml version="1.0" encoding="utf-8"?>', '<ProxifierProfile version="101" platform="Windows" product_id="0" product_minver="310">', "  <ProxyList>", body.rstrip("\n"), "  </ProxyList>", "</ProxifierProfile>"]
    elif fmt == "ProxyCap":
        lines = [f"{p.protocol.upper()} {p.ip} {p.port}" for p in P]
    elif fmt == "Shadowsocks JSON":
        lines = [json.dumps({"servers": [{"server": p.ip, "server_port": p.port, "protocol": p.protocol} for p in P]}, indent=2)]
    elif fmt == "Windows system proxy command":
        lines = [f'netsh winhttp set proxy proxy-server="{p.ip}:{p.port}"' for p in P]
    else:
        lines = [f"{p.protocol}://{p.ip}:{p.port}" for p in P]
    return {"count": len(P), "text": "\n".join(lines)}


@rpc("proxy.chain_info")
def proxy_chain_info(addrs: list):
    out = []
    for a in addrs:
        proto, lat = "?", ""
        for r in _results:
            if r.proxy.address() == a:
                proto = r.proxy.protocol.upper()
                if r.tcp_latency_ms:
                    lat = f"{r.tcp_latency_ms:.0f}ms"
                break
        out.append({"proto": proto, "latency": lat})
    return out


@rpc("proxy.chain_candidates")
def proxy_chain_candidates(used: list, limit: int = 1):
    good = sorted([r for r in _results if r.tier in ("excellent", "good")], key=lambda r: -(r.score or 0))
    if not good:
        return {"none": True, "addrs": []}
    used = set(used)
    addrs = [r.proxy.address() for r in good if r.proxy.address() not in used][:limit]
    return {"none": False, "addrs": addrs}


@rpc("proxy.chain_test")
def proxy_chain_test(nodes: list):
    import socket
    import time
    import requests
    hops = []
    for addr in nodes:
        try:
            host, port = addr.rsplit(":", 1)
            t0 = time.monotonic()
            socket.create_connection((host, int(port)), timeout=5).close()
            hops.append([addr, True, f"{(time.monotonic() - t0) * 1000:.0f}ms"])
        except Exception as exc:
            hops.append([addr, False, str(exc)])
    last = nodes[-1]
    protocol = next((r.proxy.protocol for r in _results if r.proxy.address() == last), "http")
    url = f"{protocol}://{last}"
    res = {"hops": hops}
    try:
        t0 = time.monotonic()
        resp = requests.get("http://api.ipify.org?format=json", proxies={"http": url, "https": url}, timeout=8)
        res.update(exit_ip=resp.json().get("ip", "?"), exit_ms=f"{(time.monotonic() - t0) * 1000:.0f}ms", success=True)
    except Exception as exc:
        err = str(exc)
        if "SOCKS" in err and "connect" in err.lower():
            err = "SOCKS proxy unreachable (TCP connect failed)"
        elif "PySocks" in err or ("socks" in err.lower() and "install" in err.lower()):
            err = "Install PySocks: pip install requests[socks]"
        res.update(exit_ip="failed", exit_ms="—", success=False, error=err)
    return res


@rpc("proxy.defaults")
def proxy_defaults():
    from app.config import config
    return {"workers": config.proxy_max_workers, "timeout": config.proxy_timeout_s,
            "anonymity": config.proxy_default_anonymity, "protocol": config.proxy_default_protocol}

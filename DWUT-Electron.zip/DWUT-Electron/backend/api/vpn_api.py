"""api/vpn_api.py — "VPN mode": one switch that turns the proxy pool into a VPN-style connection."""
from __future__ import annotations

import random
import threading
import time

from core.events import Events, bus
from core.logger import get_logger
from server import emit, rpc

_log = get_logger("api.vpn")

DEFAULT_OPTS = {"kill_switch": True, "dns_protect": True, "ipv6_block": True, "browser_protect": True,
                "store_apps": True, "rotate_min": 0, "region": "Any", "media_only": True}

_st = {"on": False, "busy": False, "status": "off", "since": 0.0, "server": None, "ip": "", "country": "",
       "opts": dict(DEFAULT_OPTS), "notes": [], "pool": 0}
_stop = threading.Event()
_lock = threading.Lock()
_state_rec: dict = {}


def _pa():
    from api import proxy_api
    return proxy_api


def _push() -> None:
    emit("vpn.state", dict(_st))


def _prog(msg: str, pct: float | None = None) -> None:
    emit("vpn.progress", {"msg": msg, "pct": pct})


def _server_info(up) -> dict:
    pa = _pa()
    country, score = "", 0
    for r in pa._results:
        if (r.proxy.ip, r.proxy.port) == (up.ip, up.port):
            country, score = r.country or "", r.score or 0
            break
    return {"ip": up.ip, "port": up.port, "protocol": up.protocol.upper(), "country": country, "score": score}


def _is_admin() -> bool:
    from app.state import state
    return bool(state.is_admin)


# ── pool preparation ──────────────────────────────────────────────────────────

def _good_results(region: str):
    pa = _pa()
    g = [r for r in pa._results if r.tier in ("excellent", "good", "fair")]
    if region and region != "Any":
        g = [r for r in g if (r.country or "").lower() == region.lower()]
    return g


def _autoprepare(region: str) -> None:
    """No checked proxies yet?  Fetch + check a sample, stopping as soon as enough good ones are found."""
    from modules.proxy.checker import check_all
    from modules.proxy.sources import fetch_all_sources
    pa = _pa()
    if len(pa._raw) < 200:
        _prog("Downloading fresh proxy lists…", 0.05)
        pa._raw = list(fetch_all_sources())
        emit("proxy.fetch_done", {"count": len(pa._raw), "preview": []})
    if not pa._raw:
        raise RuntimeError("Could not download any proxy lists - check your internet connection.")
    sample = random.sample(pa._raw, min(len(pa._raw), 1800))
    sample.sort(key=lambda p: {"socks5": 0, "http": 1, "socks4": 2}.get(p.protocol, 3))   # try the most useful kinds first
    ev = threading.Event()
    done = threading.Event()
    box = {}

    def run():
        try:
            box["r"] = check_all(sample, max_workers=120, region_filter=region if region != "Any" else None,
                                 protocol_filter="any", min_anonymity="any", stop_event=ev)
        finally:
            done.set()
    threading.Thread(target=run, daemon=True).start()
    t0 = time.monotonic()
    while not done.is_set():
        time.sleep(1.0)
        with pa._lock:
            live = list(pa._live)
        n = sum(1 for r in live if r.tier in ("excellent", "good"))
        _prog(f"Checking proxies… {n} good so far", min(0.45, 0.1 + n / 40))
        if n >= 14 or time.monotonic() - t0 > 150 or _stop.is_set():
            ev.set()
            done.wait(20)
            break
    if "r" in box:
        pa._results = list(box["r"])
    else:                                    # stopped early: use what was collected
        with pa._lock:
            pa._results = list(pa._live)


def _build_pool(opts: dict):
    from modules.proxy import vpn
    from modules.proxy.relay import Upstream
    region = opts.get("region", "Any")
    good = _good_results(region)
    if len(good) < 5:
        _autoprepare(region)
        good = _good_results(region)
    if not good:
        raise RuntimeError("No working proxies were found" + (f" in {region}" if region != "Any" else "")
                           + ". Try again, or choose a different region.")
    good.sort(key=lambda r: (not getattr(r, "youtube_ok", False), -(r.score or 0), r.tcp_latency_ms or 9999))
    cands = [Upstream(r.proxy.ip, r.proxy.port, r.proxy.protocol) for r in good[:24]]
    _prog(f"Testing {len(cands)} proxies for streaming (YouTube, video CDN, speed)…", 0.5)
    probes = vpn.rank(vpn.probe_many(cands, workers=8, budget_s=45,
                                     progress=lambda i, n: _prog(f"Streaming test {i}/{n}…", 0.5 + 0.25 * i / n)))
    streamers = [p for p in probes if p["youtube"] and p["googlevideo"] and p.get("stable")]
    notes = []
    chosen = streamers if streamers else [p for p in probes if p["youtube"]] or probes
    if not streamers:
        notes.append("No proxy passed the full video-streaming test - browsing should work, but video may be slow or blocked.")
    if not chosen:
        raise RuntimeError("None of the proxies could reach YouTube or move data. Run it again for a fresh set.")
    pool = [Upstream(p["ip"], p["port"], p["protocol"]) for p in chosen[:8]]
    speeds = {(p["ip"], p["port"]): p["mbps"] for p in chosen}
    return pool, speeds, notes


# ── connect / disconnect ──────────────────────────────────────────────────────

def _connect(opts: dict) -> None:
    from modules.proxy import vpn
    from modules.proxy.connect import enable_proxy
    from modules.proxy.relay import relay
    pa = _pa()
    try:
        _st.update(busy=True, status="connecting", notes=[], opts=opts, backend="proxy", country_code="")
        _push()
        notes: list[str] = [opts["_note"]] if opts.get("_note") else []
        admin = _is_admin()
        if not admin:
            notes.append("Not running as Administrator - kill switch, leak protection and Store-app support are unavailable.")
        pool, speeds, pnotes = _build_pool(opts)
        notes += pnotes
        _stop.clear()
        _prog("Starting local secure relay…", 0.78)
        port = relay.start(pool)
        relay.on_switch = lambda lab: (_prog(f"Switched server -> {lab}"), _refresh_server())
        rec: dict = {"active": True, "port": port}
        rec["winhttp_prev"] = vpn.winhttp_get()
        enable_proxy("127.0.0.1", port, "http")
        rec["winhttp_changed"] = vpn.winhttp_set(f"127.0.0.1:{port}")
        vpn.save_state(rec)
        pa._PORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        pa._PORT_FILE.write_text(str(port))

        ok, why = False, ""
        for i in range(min(len(pool), 5)):
            _prog(f"Verifying connection ({relay.current_label()})…", 0.82)
            ok, why = pa._verify(port)
            if ok:
                break
            if not relay.rotate():
                break
        if not ok:
            raise RuntimeError(f"Connected to proxies but traffic would not flow ({why}).")

        if admin:
            ips = [u.ip for u in relay.pool]
            if opts.get("browser_protect"):
                _prog("Blocking browser WebRTC / QUIC leaks…", 0.88)
                rec["browser_backup"] = vpn.apply_browser_policies()
            if opts.get("store_apps"):
                _prog("Enabling Microsoft Store app support…", 0.9)
                rec["store_added"] = vpn.apply_store_exemptions()
            vpn.save_state(rec)
            if opts.get("dns_protect"):
                _prog("Blocking DNS leaks…", 0.94)
                if not vpn.apply_dns_block():
                    notes.append("DNS leak rule could not be created.")
            if opts.get("kill_switch"):
                _prog("Arming kill switch…", 0.97)
                if not vpn.apply_kill_switch(ips, ipv6=opts.get("ipv6_block", True)):
                    notes.append("Kill switch rule could not be created (firewall disabled by policy?).")
            elif opts.get("ipv6_block"):
                from modules.proxy.vpn import _add_block, RULE_V6, kill_switch_ranges
                _add_block(RULE_V6, kill_switch_ranges([])[1])
            rec["rules"] = True
            vpn.save_state(rec)
        _state_rec.clear()
        _state_rec.update(rec)
        _st.update(on=True, busy=False, status="connected", since=time.time(), notes=notes, pool=len(relay.pool))
        _st["speeds"] = {f"{k[0]}:{k[1]}": v for k, v in speeds.items()}
        _refresh_server()
        _ip_lookup()
        _prog("Connected", 1.0)
        _push()
        threading.Thread(target=_monitor, daemon=True, name="vpn-monitor").start()
    except Exception as exc:
        _log.error("VPN connect failed: %s", exc)
        _teardown()
        _st.update(on=False, busy=False, status="off", notes=[f"Connection failed: {exc}"])
        _prog("", None)
        _push()


# ── full-system tunnel ("Automatic" mode) ────────────────────────────────────

def _connect_tunnel(opts: dict) -> bool:
    from modules.vpn import tunnel
    try:
        _st.update(busy=True, status="connecting", notes=[], opts=opts, backend="tunnel")
        _push()
        if not _is_admin():
            raise RuntimeError("administrator rights are needed")
        _prog("Preparing your secure connection…", 0.05)
        tunnel.ensure_client(lambda m: _log.info(m), lambda f: _prog("Setting things up (one time)…", 0.05 + 0.3 * f))
        tunnel.ensure_profile(lambda m: _log.info(m), lambda f: _prog("Setting things up (one time)…", 0.35 + 0.2 * f))
        _prog("Connecting…", 0.7)
        t = tunnel.connect(lambda m: _log.info(m))
        _stop.clear()
        _st.update(on=True, busy=False, status="connected", since=time.time(), ip=t["ip"], country="", country_code=t["loc"], pool=0,
                   server={"ip": t["ip"], "port": 0, "protocol": "", "country": t["loc"], "mbps": None}, notes=[])
        _st["opts"]["region"] = "Any"
        _prog("Connected", 1.0)
        _push()
        threading.Thread(target=_tunnel_monitor, daemon=True, name="vpn-tunnel-monitor").start()
        return True
    except Exception as exc:
        _log.warning("tunnel connect failed: %s", exc)
        try:
            tunnel.disconnect()
        except Exception:
            pass
        _st.update(on=False, busy=False, status="off", backend="")
        return False


def _tunnel_monitor() -> None:
    from modules.vpn import tunnel
    bad = 0
    while not _stop.wait(15):
        if not _st["on"] or _st.get("backend") != "tunnel":
            return
        up = tunnel.is_up()
        if up:
            try:
                t = tunnel.trace()
                up = t["on"]
                if up and t["ip"] != _st.get("ip"):
                    _st.update(ip=t["ip"], country_code=t["loc"])
            except Exception:
                up = False
        if up:
            bad = 0
            if _st["status"] != "connected":
                _st["status"] = "connected"
                _push()
            continue
        bad += 1
        if bad < 2:
            continue
        _st["status"] = "reconnecting"
        _push()
        try:
            t = tunnel.connect(lambda m: None)
            _st.update(status="connected", ip=t["ip"], country_code=t["loc"])
            bad = 0
        except Exception:
            _st["status"] = "degraded"
            _st["notes"] = ["Connection lost - your traffic is blocked until it comes back. Retrying…"]
        _push()


def _dispatch(opts: dict) -> None:
    """Automatic -> full tunnel; a specific country -> shared servers.  Falls back quietly if the tunnel can't start."""
    region = opts.get("region", "Any")
    if region in ("Any", "", None) and not opts.get("force_proxy"):
        if _connect_tunnel(opts):
            return
        opts = dict(opts)
        opts["_note"] = "Automatic mode isn't available on this network, so shared servers are being used (these can be slower)."
    _connect(opts)


def _refresh_server() -> None:
    from modules.proxy.relay import relay
    if relay.pool:
        with relay._lock:
            up = relay.pool[relay.current]
        info = _server_info(up)
        info["mbps"] = _st.get("speeds", {}).get(f"{up.ip}:{up.port}")
        _st["server"] = info
        _push()


def _ip_lookup() -> None:
    if _st.get("backend") == "tunnel":
        try:
            from modules.vpn import tunnel
            t = tunnel.trace()
            _st.update(ip=t["ip"], country_code=t["loc"])
        except Exception:
            pass
        return
    import requests
    from modules.proxy.relay import relay
    px = {"http": f"http://127.0.0.1:{relay.port}", "https": f"http://127.0.0.1:{relay.port}"}
    s = requests.Session()
    s.trust_env = False
    try:
        j = s.get("http://ip-api.com/json/?fields=query,country,isp", proxies=px, timeout=10).json()
        _st["ip"], _st["country"] = j.get("query", ""), f"{j.get('country', '')}"
    except Exception:
        try:
            _st["ip"] = s.get("https://api.ipify.org", proxies=px, timeout=10).text.strip()
        except Exception:
            _st["ip"] = "unknown"


def _monitor() -> None:
    from modules.proxy import vpn
    from modules.proxy.relay import Upstream, relay
    pa = _pa()
    last_rot = time.monotonic()
    fails = 0
    while not _stop.wait(20):
        if not _st["on"]:
            return
        if _st.get("switching"):
            continue
        rm = int(_st["opts"].get("rotate_min") or 0)
        if rm and time.monotonic() - last_rot > rm * 60:
            if relay.advance():
                last_rot = time.monotonic()
                _refresh_server()
                _ip_lookup()
                _push()
        ok, _ = pa._verify(relay.port)
        if ok:
            fails = 0
            if _st["status"] != "connected":
                _st["status"] = "connected"
                _push()
            continue
        fails += 1
        if fails < 2:
            continue                                  # one slow check is not a dead server
        _st["status"] = "reconnecting"
        _push()
        healed = False
        for _ in range(min(3, max(1, len(relay.pool)))):
            if relay.rotate():
                if pa._verify(relay.port)[0]:
                    healed = True
                    break
        if not healed:                                       # pool exhausted -> bring in fresh proxies
            _prog("All servers failed - finding new ones…")
            used = {(u.ip, u.port) for u in relay.pool}
            fresh = [Upstream(r.proxy.ip, r.proxy.port, r.proxy.protocol) for r in _good_results(_st["opts"].get("region", "Any"))
                     if (r.proxy.ip, r.proxy.port) not in used][:12]
            for p in vpn.rank(vpn.probe_many(fresh, workers=6, budget_s=30)):
                relay.add(Upstream(p["ip"], p["port"], p["protocol"]))
            relay._cool.clear()
            if _st["opts"].get("kill_switch") and _is_admin():
                vpn.apply_kill_switch([u.ip for u in relay.pool], ipv6=_st["opts"].get("ipv6_block", True))
            healed = pa._verify(relay.port)[0]
        if healed:
            fails = 0
            _st["status"] = "connected"
            _refresh_server()
            _ip_lookup()
        else:
            _st["status"] = "degraded"
            _st["notes"] = ["No working server right now - the kill switch is holding your traffic. Retrying…"]
        _push()


def _teardown() -> None:
    from modules.proxy import vpn
    from modules.proxy.connect import disable_proxy
    from modules.proxy.relay import relay
    _stop.set()
    relay.stop()
    try:
        from modules.vpn import tunnel
        tunnel.disconnect()
    except Exception:
        pass
    try:
        vpn.restore_everything()
    except Exception as exc:
        _log.warning("restore: %s", exc)
    try:
        disable_proxy()
    except Exception:
        pass
    try:
        _pa()._PORT_FILE.unlink()
    except OSError:
        pass


def _locations() -> list:
    pa = _pa()
    agg: dict = {}
    for r in pa._results:
        if r.tier in ("excellent", "good", "fair") and r.country:
            a = agg.setdefault(r.country, {"country": r.country, "code": r.country_code or "", "count": 0, "yt": 0, "best": 0})
            a["count"] += 1
            a["yt"] += 1 if getattr(r, "youtube_ok", False) else 0
            a["best"] = max(a["best"], r.score or 0)
    return sorted(agg.values(), key=lambda a: (-a["yt"], -a["count"], a["country"]))


@rpc("vpn.locations")
def vpn_locations():
    return _locations()


@rpc("vpn.discover")
def vpn_discover():
    """Scan a larger proxy sample (no early stop) so more countries show up in the location list."""
    if _st["busy"] or _st.get("switching"):
        return False

    def run():
        from modules.proxy.checker import check_all
        from modules.proxy.sources import fetch_all_sources
        pa = _pa()
        try:
            _st["switching"] = True
            _push()
            _prog("Downloading proxy lists to discover locations…", 0.05)
            if len(pa._raw) < 500:
                pa._raw = list(fetch_all_sources())
            sample = random.sample(pa._raw, min(len(pa._raw), 2500))
            ev, done, box = threading.Event(), threading.Event(), {}

            def chk():
                try:
                    box["r"] = check_all(sample, max_workers=140, stop_event=ev)
                finally:
                    done.set()
            threading.Thread(target=chk, daemon=True).start()
            t0 = time.monotonic()
            while not done.is_set() and time.monotonic() - t0 < 100:
                time.sleep(1.0)
                with pa._lock:
                    n = sum(1 for r in pa._live if r.tier in ("excellent", "good", "fair"))
                _prog(f"Scanning for locations… {n} working servers found", min(0.9, 0.1 + (time.monotonic() - t0) / 110))
            ev.set()
            done.wait(20)
            keep = list(box.get("r") or [])
            if not keep:
                with pa._lock:
                    keep = list(pa._live)
            known = {(r.proxy.ip, r.proxy.port) for r in keep}
            pa._results = keep + [r for r in pa._results if (r.proxy.ip, r.proxy.port) not in known]
        except Exception as exc:
            _log.warning("discover failed: %s", exc)
        finally:
            _st["switching"] = False
            _prog("", None)
            _push()
            emit("vpn.locations_changed", _locations())
    threading.Thread(target=run, daemon=True, name="vpn-discover").start()
    return True


def _relocate(country: str) -> None:
    """Hot-switch the exit country while connected (kill switch stays armed throughout)."""
    from modules.proxy import vpn
    from modules.proxy.relay import relay
    pa = _pa()
    old_pool, old_cur = list(relay.pool), relay.current
    opts = dict(_st["opts"])
    ks = bool(opts.get("kill_switch") and _is_admin())
    try:
        _st["switching"] = True
        _push()
        _prog(f"Finding servers in {country}…", 0.1)
        o = dict(opts)
        o["region"] = country
        pool, speeds, notes = _build_pool(o)
        if ks:                                   # allow old + new during the swap so nothing drops
            vpn.apply_kill_switch(sorted({u.ip for u in old_pool + pool}), ipv6=opts.get("ipv6_block", True))
        relay.set_pool(pool)
        ok, why = False, ""
        for _ in range(min(len(pool), 5)):
            _prog(f"Verifying {relay.current_label()}…", 0.85)
            ok, why = pa._verify(relay.port)
            if ok:
                break
            if not relay.rotate():
                break
        if not ok:
            raise RuntimeError(f"servers there would not carry traffic ({why})")
        if ks:
            vpn.apply_kill_switch([u.ip for u in relay.pool], ipv6=opts.get("ipv6_block", True))
        _st["opts"]["region"] = country
        _st.setdefault("speeds", {}).update({f"{k[0]}:{k[1]}": v for k, v in speeds.items()})
        _st["pool"] = len(relay.pool)
        _st["notes"] = notes
        _refresh_server()
        _ip_lookup()
        got = (_st.get("country") or "").lower()
        if country != "Any" and got and country.lower() not in got and got not in country.lower():
            _st["notes"] = notes + [f"Requested {country}, but the exit IP reports {_st.get('country')} (geo-IP databases disagree sometimes)."]
    except Exception as exc:
        _log.warning("relocate failed: %s", exc)
        relay.set_pool(old_pool)
        relay.current = old_cur
        if ks:
            try:
                vpn.apply_kill_switch([u.ip for u in old_pool], ipv6=opts.get("ipv6_block", True))
            except Exception:
                pass
        _st["notes"] = [f"Could not switch to {country}: {exc}. Staying on your previous location."]
    finally:
        _st["switching"] = False
        _prog("", None)
        _push()
        emit("vpn.locations_changed", _locations())


def _switch_backend(country: str) -> None:
    """Automatic <-> specific-country changes the kind of connection, so reconnect cleanly."""
    opts = dict(_st["opts"])
    opts["region"] = country
    _st["switching"] = True
    _push()
    _teardown()
    _st.update(on=False, busy=False, status="off", server=None, ip="", country="", country_code="", pool=0)
    _st["switching"] = False
    _dispatch(opts)


@rpc("vpn.set_location")
def vpn_set_location(country: str):
    if not _st["on"] or _st.get("switching") or _st["busy"]:
        return False
    if (_st.get("backend") == "tunnel") != (country in ("Any", "")):
        threading.Thread(target=_switch_backend, args=(country,), daemon=True, name="vpn-backend-switch").start()
        return True
    if _st.get("backend") == "tunnel":
        return True
    threading.Thread(target=_relocate, args=(country,), daemon=True, name="vpn-relocate").start()
    return True


@rpc("vpn.state")
def vpn_state():
    return dict(_st)


@rpc("vpn.connect")
def vpn_connect(opts: dict | None = None):
    with _lock:
        if _st["busy"] or _st["on"]:
            return False
        o = dict(DEFAULT_OPTS)
        o.update(opts or {})
        _st["busy"] = True
    threading.Thread(target=_dispatch, args=(o,), daemon=True, name="vpn-connect").start()
    return True


@rpc("vpn.disconnect")
def vpn_disconnect():
    _prog("Restoring your normal connection…", 0.5)
    _teardown()
    _st.update(on=False, busy=False, status="off", server=None, ip="", country="", notes=[], pool=0)
    _push()
    _prog("", None)
    return True


@rpc("vpn.switch")
def vpn_switch():
    from modules.proxy.relay import relay
    if not _st["on"] or not relay.advance():
        return False
    _refresh_server()
    threading.Thread(target=lambda: (_ip_lookup(), _push()), daemon=True).start()
    return True


@rpc("vpn.ip")
def vpn_ip():
    if _st["on"]:
        _ip_lookup()
        _push()
    return _st.get("ip", "")


@rpc("vpn.panic")
def vpn_panic():
    """Always-available escape hatch: remove every rule/policy/proxy DWUT may have set."""
    r = vpn_disconnect()
    return r


def shutdown_vpn() -> None:
    if _st["on"] or _st["busy"]:
        _teardown()


def _recover() -> None:
    """DWUT crashed / PC lost power while VPN mode was on?  Undo it now."""
    try:
        from modules.vpn import tunnel
        if tunnel.service_exists():
            tunnel.disconnect()
    except Exception:
        pass
    try:
        from modules.proxy import vpn
        if vpn.load_state():
            vpn.restore_everything()
            from modules.proxy.connect import disable_proxy
            disable_proxy()
            _log.info("Recovered from an interrupted VPN session")
    except Exception as exc:
        _log.debug("vpn recover: %s", exc)


_recover()

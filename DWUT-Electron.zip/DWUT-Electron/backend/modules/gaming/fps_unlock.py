"""
modules/gaming/fps_unlock.py

Multi-game FPS unlocker.

WHY THE OLD ONE NEVER WORKED
  * It scanned Roblox's heap for every double equal to 60.0 (and 1/60) and overwrote
    them all.  That corrupts unrelated data, wrote "240.0" into a frame-TIME slot
    (should be 1/240), and Roblox's Hyperion anti-tamper blocks the write handle
    anyway.  Memory patching is also exactly what anti-cheats ban for.

WHAT THIS DOES INSTEAD (nothing touches game memory, so it is anti-cheat safe)
  roblox     Writes the DFIntTaskSchedulerTargetFps client setting into every
             installed Roblox version (and Bloxstrap / Fishstrap / Voidstrap
             modification folders).  Re-applied automatically after Roblox updates.
  fortnite   Sets FrameRateLimit in GameUserSettings.ini (marks it read-only so the
             game cannot reset it on exit).
  minecraft  Sets maxFps / enableVsync in options.txt (Java Edition).

Games with kernel anti-cheat and no config cap (Valorant, Apex...) are NOT listed:
those either have no cap to remove or would require memory tampering.

Settings are applied when the game is closed; if it is already running the status
says "restart the game".  Everything is backed up and restored on disable().
"""

from __future__ import annotations

import json
import os
import re
import stat
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import psutil

from core.events import Events, bus
from core.logger import get_logger

_log = get_logger(__name__)

GAMES: dict[str, dict] = {
    "roblox":    {"name": "Roblox",       "procs": ("robloxplayerbeta.exe",),
                  "note": "Applies to every installed Roblox version. Restart Roblox after enabling."},
    "fortnite":  {"name": "Fortnite",     "procs": ("fortniteclient-win64-shipping.exe",),
                  "note": "Sets FrameRateLimit in GameUserSettings.ini. Close Fortnite first."},
    "minecraft": {"name": "Minecraft (Java)", "procs": ("javaw.exe",),
                  "note": "Sets maxFps in options.txt (260 = unlimited). Close Minecraft first."},
}


@dataclass
class FPSUnlockStatus:
    active: bool
    roblox_running: bool          # kept for UI compat: "selected game running"
    roblox_pid: Optional[int]
    target_fps: int
    patch_count: int
    message: str
    game: str = "roblox"
    game_name: str = "Roblox"
    needs_restart: bool = False


def _local() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))


def _roaming() -> Path:
    return Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))


def _backup_file() -> Path:
    d = _local() / "DWUT"
    d.mkdir(parents=True, exist_ok=True)
    return d / "fps_unlock_backup.json"


def _load_backup() -> dict:
    try:
        return json.loads(_backup_file().read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_backup(data: dict) -> None:
    try:
        _backup_file().write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as exc:
        _log.debug("backup write failed: %s", exc)


def _find_process(names: tuple[str, ...], minecraft: bool = False) -> Optional[int]:
    for p in psutil.process_iter(["pid", "name"]):
        try:
            n = (p.info["name"] or "").lower()
            if n in names:
                if minecraft and n == "javaw.exe" and "minecraft" not in " ".join(p.cmdline()).lower():
                    continue
                return p.pid
        except Exception:
            continue
    return None


def _clear_ro(path: Path) -> None:
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except Exception:
        pass


# ── Roblox ────────────────────────────────────────────────────────────────────

_RBX_FLAG = "DFIntTaskSchedulerTargetFps"
UNCAPPED = 9999


def _rbx_flags(target: int) -> dict:
    """Client settings Roblox honours.  The second one removes the in-client settings cap."""
    return {_RBX_FLAG: UNCAPPED if target >= 1000 else int(target), "FFlagGameBasicSettingsFramerateCap": False}


def _roblox_setting_files() -> list[Path]:
    """Return every ClientAppSettings.json path Roblox/launchers might read, deduplicated."""
    out: list[Path] = []
    seen: set[Path] = set()

    def _add(p: Path) -> None:
        if p not in seen:
            seen.add(p)
            out.append(p)

    # ── 1. Root-level ClientSettings (Roblox checks this FIRST since ~2024) ──
    _add(_local() / "Roblox" / "ClientSettings" / "ClientAppSettings.json")

    # ── 2. Per-version folders ─────────────────────────────────────────────
    versions = _local() / "Roblox" / "Versions"
    try:
        if versions.is_dir():
            for v in sorted(versions.iterdir(), key=lambda p: p.stat().st_mtime if p.is_dir() else 0, reverse=True):
                if not v.is_dir():
                    continue
                try:
                    has_roblox_exe = any(
                        f.suffix.lower() == ".exe" and "roblox" in f.name.lower()
                        for f in v.iterdir() if f.is_file()
                    )
                except OSError:
                    has_roblox_exe = False
                if has_roblox_exe or v.name.startswith("version-"):
                    _add(v / "ClientSettings" / "ClientAppSettings.json")
    except OSError:
        pass

    # ── 3. Bloxstrap / Fishstrap / Voidstrap (Modifications AND root) ─────
    for launcher in ("Bloxstrap", "Fishstrap", "Voidstrap"):
        base = _local() / launcher
        if base.is_dir():
            # Modifications folder (overrides that survive Roblox updates)
            _add(base / "Modifications" / "ClientSettings" / "ClientAppSettings.json")
            # Root launcher ClientSettings (some versions read this too)
            _add(base / "ClientSettings" / "ClientAppSettings.json")
            # Roblox versions installed under the launcher
            vers_dir = base / "Versions"
            try:
                if vers_dir.is_dir():
                    for v in sorted(vers_dir.iterdir(), key=lambda p: p.stat().st_mtime if p.is_dir() else 0, reverse=True):
                        if v.is_dir() and v.name.startswith("version-"):
                            _add(v / "ClientSettings" / "ClientAppSettings.json")
            except OSError:
                pass

    # ── 4. UWP / Microsoft Store package ─────────────────────────────────
    uwp = _local() / "Packages"
    try:
        if uwp.is_dir():
            for pkg in uwp.iterdir():
                if pkg.is_dir() and "roblox" in pkg.name.lower():
                    _add(pkg / "LocalState" / "ClientSettings" / "ClientAppSettings.json")
    except OSError:
        pass

    return out


def _read_json(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def _roblox_basic_settings() -> Path:
    return _local() / "Roblox" / "GlobalBasicSettings_13.xml"


def _roblox_apply(target: int, backup: dict) -> int:
    """Write the FPS flag into every known Roblox settings path, creating folders as needed."""
    n = 0
    flags = _rbx_flags(target)
    saved = backup.setdefault("roblox", {})
    paths = _roblox_setting_files()
    for f in paths:
        key = str(f)
        existed = f.exists()
        data = _read_json(f) if existed else {}
        if key not in saved:
            saved[key] = {"existed": existed, "old": {k: data.get(k) for k in flags}}
        # Always write — even if values look equal — to ensure the file exists
        data.update(flags)
        try:
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(json.dumps(data, indent=2), encoding="utf-8")
            n += 1
        except Exception as exc:
            _log.warning("Roblox settings write failed (%s): %s", f, exc)

    # Also patch GlobalBasicSettings_13.xml in-game FPS cap (if game is closed)
    bs = _roblox_basic_settings()
    if bs.exists() and _find_process(GAMES["roblox"]["procs"]) is None:
        try:
            txt = bs.read_text(encoding="utf-8", errors="replace")
            if 'name="FramerateCap"' in txt:
                saved.setdefault("__basic", {"text": txt})
                new = re.sub(r'(<int name="FramerateCap">)[^<]*(</int>)', r"\g<1>-1\g<2>", txt)
                if new != txt:
                    bs.write_text(new, encoding="utf-8")
        except Exception as exc:
            _log.debug("basic settings: %s", exc)
    return n


def _roblox_restore(backup: dict) -> None:
    for key, info in backup.get("roblox", {}).items():
        if key == "__basic":
            try:
                if _roblox_basic_settings().exists() and info.get("text"):
                    _roblox_basic_settings().write_text(info["text"], encoding="utf-8")
            except Exception:
                pass
            continue
        f = Path(key)
        try:
            data = _read_json(f) if f.exists() else {}
            for k, old in (info.get("old") or {}).items():
                if old is None:
                    data.pop(k, None)
                else:
                    data[k] = old
            if data:
                f.write_text(json.dumps(data, indent=2), encoding="utf-8")
            elif f.exists():
                f.unlink()
        except Exception as exc:
            _log.debug("Roblox restore failed (%s): %s", f, exc)


# ── Fortnite ──────────────────────────────────────────────────────────────────

def _fortnite_ini() -> Path:
    return _local() / "FortniteGame" / "Saved" / "Config" / "WindowsClient" / "GameUserSettings.ini"


def _set_ini_key(text: str, section: str, key: str, value: str) -> str:
    lines = text.splitlines()
    sec_hdr = f"[{section}]"
    start = next((i for i, l in enumerate(lines) if l.strip().lower() == sec_hdr.lower()), None)
    if start is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines += [sec_hdr, f"{key}={value}"]
        return "\r\n".join(lines) + "\r\n"
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("[")), len(lines))
    for i in range(start + 1, end):
        if re.match(rf"^{re.escape(key)}\s*=", lines[i], re.IGNORECASE):
            lines[i] = f"{key}={value}"
            break
    else:
        lines.insert(end, f"{key}={value}")
    return "\r\n".join(lines) + "\r\n"


def _fortnite_apply(target: int, backup: dict) -> int:
    ini = _fortnite_ini()
    if not ini.exists():
        return 0
    saved = backup.setdefault("fortnite", {})
    if "text" not in saved:
        saved["text"] = ini.read_text(encoding="utf-8", errors="replace")
    _clear_ro(ini)
    text = ini.read_text(encoding="utf-8", errors="replace")
    sec = "/Script/FortniteGame.FortGameUserSettings"
    limit = "0.000000" if target >= 1000 else f"{float(target):.6f}"
    text = _set_ini_key(text, sec, "FrameRateLimit", limit)
    text = _set_ini_key(text, sec, "bUseVSync", "False")
    ini.write_text(text, encoding="utf-8")
    try:
        os.chmod(ini, stat.S_IREAD)        # stops Fortnite resetting it on exit
    except Exception:
        pass
    return 1


def _fortnite_restore(backup: dict) -> None:
    ini = _fortnite_ini()
    txt = backup.get("fortnite", {}).get("text")
    if txt is not None and ini.exists():
        _clear_ro(ini)
        ini.write_text(txt, encoding="utf-8")


# ── Minecraft ─────────────────────────────────────────────────────────────────

def _mc_options() -> Path:
    return _roaming() / ".minecraft" / "options.txt"


def _mc_apply(target: int, backup: dict) -> int:
    f = _mc_options()
    if not f.exists():
        return 0
    saved = backup.setdefault("minecraft", {})
    text = f.read_text(encoding="utf-8", errors="replace")
    if "text" not in saved:
        saved["text"] = text
    fps = 260 if target >= 260 else max(10, target)
    lines, seen = text.splitlines(), set()
    for i, l in enumerate(lines):
        if l.startswith("maxFps:"):
            lines[i] = f"maxFps:{fps}"; seen.add("maxFps")
        elif l.startswith("enableVsync:"):
            lines[i] = "enableVsync:false"; seen.add("v")
    if "maxFps" not in seen:
        lines.append(f"maxFps:{fps}")
    if "v" not in seen:
        lines.append("enableVsync:false")
    f.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 1


def _mc_restore(backup: dict) -> None:
    txt = backup.get("minecraft", {}).get("text")
    f = _mc_options()
    if txt is not None and f.exists():
        f.write_text(txt, encoding="utf-8")


_APPLY = {"roblox": _roblox_apply, "fortnite": _fortnite_apply, "minecraft": _mc_apply}
_RESTORE = {"roblox": _roblox_restore, "fortnite": _fortnite_restore, "minecraft": _mc_restore}


class FPSUnlocker:
    """API-compatible with the previous unlocker, now multi-game."""

    LOOP_SLEEP_S = 2.0

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._active = False
        self._target_fps = 240
        self._game = "roblox"
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._patch_count = 0
        self._was_running_at_enable = False

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._active

    def list_games(self) -> list[dict]:
        return [{"id": k, "name": v["name"], "note": v["note"]} for k, v in GAMES.items()]

    def set_game(self, game: str) -> None:
        if game not in GAMES:
            return
        was = self.is_active
        if was:
            self.disable()
        with self._lock:
            self._game = game
        if was:
            self.enable()
        else:
            self._publish("Game set to " + GAMES[game]["name"])

    def set_target_fps(self, fps: int) -> None:
        with self._lock:
            self._target_fps = max(30, min(int(fps), 10000))
            active = self._active
        if active:
            self._apply_once()

    def enable(self) -> None:
        with self._lock:
            if self._active:
                return
            self._active = True
            self._stop.clear()
            self._patch_count = 0
        self._was_running_at_enable = self._pid() is not None
        self._thread = threading.Thread(target=self._loop, daemon=True, name="fps-unlock-loop")
        self._thread.start()
        self._apply_once(first=True)

    def disable(self) -> None:
        with self._lock:
            if not self._active:
                return
            self._active = False
            game = self._game
        self._stop.set()
        backup = _load_backup()
        try:
            _RESTORE[game](backup)
            backup.pop(game, None)
            _save_backup(backup)
        except Exception as exc:
            _log.warning("FPS restore failed: %s", exc)
        self._publish(f"FPS unlock stopped — {GAMES[game]['name']} back to its default cap")

    # ── internals ────────────────────────────────────────────────────────────

    def _pid(self) -> Optional[int]:
        g = GAMES[self._game]
        return _find_process(g["procs"], minecraft=(self._game == "minecraft"))

    def _apply_once(self, first: bool = False) -> None:
        with self._lock:
            game, target = self._game, self._target_fps
        backup = _load_backup()
        try:
            n = _APPLY[game](target, backup)
            _save_backup(backup)
        except Exception as exc:
            _log.error("FPS apply failed: %s", exc)
            self._publish(f"Could not apply: {exc}")
            return
        with self._lock:
            self._patch_count = n
        name = GAMES[game]["name"]
        running = self._pid() is not None
        shown = "UNCAPPED" if target >= 1000 else f"{target} FPS"
        if game == "roblox":
            written = [f for f in _roblox_setting_files() if f.exists()]
            for f in written[:6]:
                self._publish_log(f"  [OK] {f}")
            if not written:
                # Pre-create the root path so Roblox picks it up on first launch
                root_path = _local() / "Roblox" / "ClientSettings" / "ClientAppSettings.json"
                self._publish_log(f"  Created: {root_path}")
        if n == 0:
            # n==0 means ALL writes failed (permissions?), not "Roblox not installed"
            paths_tried = [str(p) for p in _roblox_setting_files()[:3]]
            self._publish(
                f"{name} settings pre-created — settings will apply when {name} next launches.\n"
                f"If Roblox is installed in a custom location, the setting was still written to:\n"
                + "\n".join(paths_tried)
            )
        elif running and (first or self._was_running_at_enable):
            self._publish(f"Unlocked ({shown}) — CLOSE and reopen {name} for it to take effect", restart=True)
        else:
            self._publish(f"Unlocked ({shown}) — applied to {n} path(s). Launch {name} to play!" if n > 1
                          else f"Unlocked ({shown}) — launch {name} to play unlocked")

    def _loop(self) -> None:
        last_running: Optional[bool] = None
        while not self._stop.wait(self.LOOP_SLEEP_S):
            with self._lock:
                if not self._active:
                    return
                game = self._game
            running = self._pid() is not None
            if game == "roblox":
                # Roblox updates create new version folders — keep them all covered
                backup = _load_backup()
                try:
                    _roblox_apply(self._target_fps, backup)
                    _save_backup(backup)
                except Exception:
                    pass
            if running != last_running:
                last_running = running
                name = GAMES[game]["name"]
                if not running:
                    bus.publish(Events.FPS_ROBLOX_GONE, None)
                    self._publish(f"Waiting for {name} to start…")
                else:
                    self._publish(f"{name} is running — unlock active")

    def _publish_log(self, message: str) -> None:
        bus.publish(Events.FPS_UNLOCK_STATUS, FPSUnlockStatus(active=self._active, roblox_running=self._pid() is not None, roblox_pid=self._pid(),
                    target_fps=self._target_fps, patch_count=self._patch_count, message=message, game=self._game, game_name=GAMES[self._game]['name']))

    def restart_game(self) -> bool:
        """Close the selected game so the new setting is read on its next launch."""
        pid = self._pid()
        if not pid:
            return False
        try:
            psutil.Process(pid).terminate()
            return True
        except Exception:
            return False

    def _publish(self, message: str, restart: bool = False) -> None:
        with self._lock:
            pid = self._pid()
            status = FPSUnlockStatus(
                active=self._active, roblox_running=pid is not None, roblox_pid=pid,
                target_fps=self._target_fps, patch_count=self._patch_count, message=message,
                game=self._game, game_name=GAMES[self._game]["name"], needs_restart=restart,
            )
        bus.publish(Events.FPS_UNLOCK_STATUS, status)


fps_unlocker: FPSUnlocker = FPSUnlocker()

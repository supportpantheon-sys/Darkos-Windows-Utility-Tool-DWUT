"""
modules/gaming/booster.py

Real Game Booster — no fake numbers.

Order of operations:
  1. Terminate the background apps you agreed to (Discord etc. can be excluded)
  2. Detect the game — from the name typed, or automatically from what is really
     running / in the foreground when no name is given
  3. Set the game to HIGH priority (+ high I/O priority)
  4. Activate a real performance power plan (Ultimate -> High -> tuned copy of the
     current plan, whichever this PC supports) and VERIFY it took effect
  5. Enable HAGS, turn Game DVR off, Game Mode on, pin the game to the fast GPU
  6. Trim working sets of leftover processes and measure the real RAM change
  7. Everything changed is saved first and restored on deactivate

FIXES vs. the previous version
  * Power plan: `powercfg /duplicatescheme` creates a plan with a NEW random GUID.
    The old code then tried to activate the *template* GUID, which always failed.
    The new GUID is parsed from powercfg's output and activation is verified.
    PCs without Ultimate/High Performance (Modern Standby laptops) fall back to a
    tuned copy of the active plan.
  * The game PID was never resolved from the typed name, so priority was never set.
  * Works with no name at all (auto-detect).
"""

from __future__ import annotations

import ctypes
import os
import re
import subprocess
import threading
import time
import winreg
from dataclasses import dataclass, field
from typing import Optional

import psutil

from core.events import Events, bus
from core.logger import get_logger

_log = get_logger(__name__)

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_PLAN_ULTIMATE_PERF = "e9a42b02-d5df-448d-aa00-03f14749eb61"
_PLAN_HIGH_PERF     = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
_PLAN_BALANCED      = "381b4222-f694-41f0-9685-ff5bb260df2e"

_GUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


# ──────────────────────────────────────────────────────────────────────────────
# powercfg helpers
# ──────────────────────────────────────────────────────────────────────────────

def _powercfg(*args: str, timeout: int = 15) -> tuple[bool, str]:
    try:
        r = subprocess.run(
            ["powercfg", *args], capture_output=True, text=True,
            timeout=timeout, creationflags=_NO_WINDOW, errors="replace",
        )
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception as exc:
        return False, str(exc)


def _list_schemes() -> list[tuple[str, str]]:
    """[(guid, name)] for every installed scheme (locale independent)."""
    ok, out = _powercfg("/list")
    schemes: list[tuple[str, str]] = []
    if not ok:
        return schemes
    for line in out.splitlines():
        m = _GUID_RE.search(line)
        if not m:
            continue
        nm = re.search(r"\((.*?)\)", line)
        schemes.append((m.group(0).lower(), nm.group(1).strip() if nm else ""))
    return schemes


def _get_active_power_plan() -> Optional[str]:
    ok, out = _powercfg("/getactivescheme")
    if not ok:
        return None
    m = _GUID_RE.search(out)
    return m.group(0).lower() if m else None


def _set_power_plan(guid: str) -> tuple[bool, str]:
    """Activate a plan and VERIFY it really became active."""
    ok, out = _powercfg("/setactive", guid)
    active = _get_active_power_plan()
    if active and active.lower() == guid.lower():
        return True, ""
    return False, out or "powercfg did not switch the plan"


def _duplicate(template_guid: str) -> Optional[str]:
    """Duplicate a scheme; the NEW plan has a NEW guid, parsed from the output."""
    ok, out = _powercfg("/duplicatescheme", template_guid)
    if not ok:
        return None
    m = _GUID_RE.search(out)
    return m.group(0).lower() if m else None


def _tune_plan_for_gaming(guid: str) -> None:
    for sub, setting, val in (
        ("SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"),
        ("SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"),
        ("SUB_PROCESSOR", "PERFBOOSTMODE", "2"),
        ("SUB_PROCESSOR", "CPMINCORES", "100"),
        ("SUB_SLEEP", "STANDBYIDLE", "0"),
        ("SUB_VIDEO", "VIDEOIDLE", "0"),
        ("SUB_PCIEXPRESS", "ASPM", "0"),
        ("SUB_USB", "USBSELECTSUSPEND", "0"),
    ):
        _powercfg("/setacvalueindex", guid, sub, setting, val)
        _powercfg("/setdcvalueindex", guid, sub, setting, val)


def ensure_performance_plan() -> tuple[Optional[str], str, bool, list[str]]:
    """Find or create the best performance plan this PC supports.
    Returns (guid, display_name, temp_plan_created_by_us, notes)."""
    notes: list[str] = []
    schemes = _list_schemes()

    def _find(fragment: str, guid: str) -> Optional[str]:
        for g, n in schemes:
            if g == guid or fragment in n.lower():
                return g
        return None

    g = _find("ultimate performance", _PLAN_ULTIMATE_PERF)
    if g:
        return g, "Ultimate Performance", False, notes

    g = _duplicate(_PLAN_ULTIMATE_PERF)
    if g:
        _powercfg("/changename", g, "Ultimate Performance",
                  "Windows built-in Ultimate Performance plan")
        return g, "Ultimate Performance", False, notes
    notes.append("Ultimate Performance isn't available on this PC")

    g = _find("high performance", _PLAN_HIGH_PERF)
    if g:
        return g, "High Performance", False, notes
    g = _duplicate(_PLAN_HIGH_PERF)
    if g:
        _powercfg("/changename", g, "High Performance")
        return g, "High Performance", False, notes
    notes.append("High Performance isn't available on this PC")

    active = _get_active_power_plan()
    if active:
        g = _duplicate(active)
        if g:
            _powercfg("/changename", g, "DWUT Game Boost", "Tuned for gaming by DWUT (temporary)")
            _tune_plan_for_gaming(g)
            notes.append("Used a tuned copy of the current plan instead")
            return g, "DWUT Game Boost (tuned)", True, notes

    return None, "", False, notes


# ──────────────────────────────────────────────────────────────────────────────
# Result types
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class BoostResult:
    success: bool
    game_name: str
    game_pid: Optional[int]
    ram_freed_mb: float
    power_plan_applied: str
    priority_applied: bool
    gpu_scheduling_enabled: bool
    gamebar_disabled: bool
    message: str
    detected_game: str = ""
    auto_detected: bool = False
    terminated: list = field(default_factory=list)
    notes: list = field(default_factory=list)


@dataclass
class _SavedState:
    original_power_plan: Optional[str] = None
    created_plan: Optional[str] = None
    original_priority: Optional[int] = None
    game_pid: Optional[int] = None
    game_exe: str = ""
    registry: list = field(default_factory=list)   # (hive, path, name, old_value, vtype)


# ──────────────────────────────────────────────────────────────────────────────
# Registry helpers
# ──────────────────────────────────────────────────────────────────────────────

def _reg_read(hive: int, path: str, name: str):
    try:
        k = winreg.OpenKey(hive, path, 0, winreg.KEY_READ)
        val, vtype = winreg.QueryValueEx(k, name)
        winreg.CloseKey(k)
        return val, vtype
    except Exception:
        return None, None


def _reg_write(hive: int, path: str, name: str, value, vtype: int) -> bool:
    try:
        k = winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, name, 0, vtype, value)
        winreg.CloseKey(k)
        return True
    except Exception as exc:
        _log.warning("Registry write failed [%s\\%s] %s: %s", path, name, value, exc)
        return False


def _reg_delete(hive: int, path: str, name: str) -> None:
    try:
        k = winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(k, name)
        winreg.CloseKey(k)
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────────
# Process knowledge
# ──────────────────────────────────────────────────────────────────────────────

_SYSTEM_DIR = os.path.normcase(os.environ.get("SystemRoot", r"C:\Windows"))

# Never terminated, whatever the user ticks
_NEVER_KILL = {
    "system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe",
    "winlogon.exe", "lsass.exe", "services.exe", "svchost.exe", "explorer.exe", "dwm.exe",
    "taskmgr.exe", "taskhostw.exe", "sihost.exe", "ctfmon.exe", "audiodg.exe", "fontdrvhost.exe",
    "msmpeng.exe", "securityhealthservice.exe", "securityhealthsystray.exe", "nissrv.exe",
    "python.exe", "pythonw.exe", "dwut.exe", "electron.exe", "node.exe",
    "gamebar.exe", "gamebarft.exe", "xboxapp.exe", "gamingservices.exe", "gamingservicesnet.exe",
    "wmplayer.exe", "searchhost.exe", "startmenuexperiencehost.exe", "shellexperiencehost.exe",
    "textinputhost.exe", "runtimebroker.exe", "conhost.exe", "wmiprvse.exe",
    # anti-cheat / GPU drivers — killing these breaks games or drivers
    "easyanticheat.exe", "easyanticheat_eos.exe", "beservice.exe", "battleye.exe",
    "vgc.exe", "vgtray.exe", "faceitclient.exe", "faceit.exe", "esea.exe",
    "nvcontainer.exe", "nvdisplay.container.exe", "nvidia share.exe", "nvsphelper64.exe",
    "radeonsoftware.exe", "amdrsserv.exe", "cncmd.exe",
}
_NEVER_KILL_PREFIX = ("nvidia", "nvcpl", "amd", "radeon", "igfx", "realtek", "rtk", "waves",
                      "xbox", "gamebar", "microsoft.", "windows", "dwut", "electron")

# Ticked by default in the exclusion popup (same set the booster always used)
_BACKGROUND_KILL_LIST = {
    "discord.exe", "slack.exe", "teams.exe", "ms-teams.exe",
    "onedrive.exe", "dropbox.exe",
    "adobeupdatedaemon.exe", "adobearmservice.exe",
    "creative cloud.exe", "creativecloudapp.exe",
    "spotifywebhelper.exe", "spotify.exe",
    "steam.exe",           # auto-protected when the game runs under Steam
}

_LAUNCHER_NAMES = {
    "steam.exe", "steamwebhelper.exe", "epicgameslauncher.exe", "riotclientservices.exe",
    "riotclientux.exe", "battle.net.exe", "agent.exe", "origin.exe", "eadesktop.exe",
    "ealauncher.exe", "upc.exe", "ubisoftconnect.exe", "galaxyclient.exe", "xboxpcapp.exe",
}

_BROWSERS = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe",
             "opera_gx.exe", "vivaldi.exe", "iexplore.exe"}

_KNOWN_GAMES: dict[str, str] = {
    "robloxplayerbeta.exe": "Roblox", "windows10universal.exe": "Roblox",
    "fortniteclient-win64-shipping.exe": "Fortnite",
    "valorant-win64-shipping.exe": "Valorant", "cs2.exe": "Counter-Strike 2", "csgo.exe": "CS:GO",
    "r5apex.exe": "Apex Legends", "r5apex_dx12.exe": "Apex Legends",
    "overwatch.exe": "Overwatch 2", "leagueoflegends.exe": "League of Legends",
    "league of legends.exe": "League of Legends", "dota2.exe": "Dota 2",
    "gta5.exe": "GTA V", "gtav.exe": "GTA V", "playgtav.exe": "GTA V", "rdr2.exe": "Red Dead Redemption 2",
    "eldenring.exe": "Elden Ring", "cyberpunk2077.exe": "Cyberpunk 2077", "witcher3.exe": "The Witcher 3",
    "minecraft.windows.exe": "Minecraft", "rustclient.exe": "Rust", "destiny2.exe": "Destiny 2",
    "tslgame.exe": "PUBG", "rocketleague.exe": "Rocket League", "escapefromtarkov.exe": "Escape from Tarkov",
    "cod.exe": "Call of Duty", "modernwarfare.exe": "Call of Duty", "blackopscoldwar.exe": "Call of Duty",
    "rainbowsix.exe": "Rainbow Six Siege", "rainbowsix_vulkan.exe": "Rainbow Six Siege",
    "fallguys_client_game.exe": "Fall Guys", "genshinimpact.exe": "Genshin Impact",
    "starrail.exe": "Honkai: Star Rail", "zenlesszonezero.exe": "Zenless Zone Zero",
    "wow.exe": "World of Warcraft", "wowclassic.exe": "WoW Classic", "diablo iv.exe": "Diablo IV",
    "pathofexile.exe": "Path of Exile", "pathofexile_x64steam.exe": "Path of Exile",
    "terraria.exe": "Terraria", "stardewvalley.exe": "Stardew Valley", "thefinals.exe": "THE FINALS",
    "helldivers2.exe": "Helldivers 2", "bg3.exe": "Baldur's Gate 3", "bg3_dx11.exe": "Baldur's Gate 3",
    "starfield.exe": "Starfield", "fc24.exe": "EA FC 24", "fc25.exe": "EA FC 25",
    "forzahorizon5.exe": "Forza Horizon 5", "marvelrivals.exe": "Marvel Rivals",
    "deadlock.exe": "Deadlock", "bf2042.exe": "Battlefield 2042",
}

_HELPER_SUBSTR = ("crashhandler", "crashreport", "unins", "setup", "update", "launcher", "webhelper",
                  "helper", "service", "anticheat", "easyanticheat", "battleye", "vgc", "redist")

_GAME_PATH_HINTS = ("steamapps\\common", "\\epic games\\", "\\riot games\\", "\\xboxgames\\",
                    "\\battle.net\\", "\\ubisoft game launcher\\games", "\\ea games\\",
                    "\\origin games\\", "\\gog galaxy\\games", "\\gog games\\", "\\games\\",
                    "\\rockstar games\\", "\\blizzard\\", "\\activision\\", "\\bethesda")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _exe_of(p: psutil.Process) -> str:
    try:
        return p.exe() or ""
    except Exception:
        return ""


def _foreground_pid() -> Optional[int]:
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value) or None
    except Exception:
        return None


def _foreground_is_fullscreen() -> bool:
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return False

        class RECT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long),
                        ("r", ctypes.c_long), ("b", ctypes.c_long)]

        rc = RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rc))
        sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        return (rc.r - rc.l) >= sw - 2 and (rc.b - rc.t) >= sh - 2
    except Exception:
        return False


def _ancestors(pid: int) -> set[int]:
    out: set[int] = set()
    try:
        cur = psutil.Process(pid)
        while True:
            par = cur.parent()
            if par is None or par.pid in out or par.pid == 0:
                break
            out.add(par.pid)
            cur = par
    except Exception:
        pass
    return out


def _descendants(pid: int) -> set[int]:
    try:
        return {c.pid for c in psutil.Process(pid).children(recursive=True)}
    except Exception:
        return set()


def _is_system_process(exe: str, name: str) -> bool:
    if not exe:
        return True                      # can't inspect it -> untouchable
    if os.path.normcase(exe).startswith(_SYSTEM_DIR):
        return True
    n = name.lower()
    return n in _NEVER_KILL or n.startswith(_NEVER_KILL_PREFIX)


def _score_game(p: psutil.Process, fg_pid: Optional[int], fg_full: bool) -> tuple[int, str]:
    """(score, display_name). Score >= 55 means 'this is a game'."""
    try:
        name = (p.name() or "").lower()
    except Exception:
        return 0, ""
    exe = _exe_of(p)
    if _is_system_process(exe, name) or name in _BROWSERS or name in _LAUNCHER_NAMES:
        return 0, ""
    if any(h in name for h in _HELPER_SUBSTR) and name not in _KNOWN_GAMES:
        return 0, ""

    score = 0
    disp = _KNOWN_GAMES.get(name, "")
    if disp:
        score += 100
    low = exe.lower()
    if any(h in low for h in _GAME_PATH_HINTS):
        score += 55
    if name.endswith("-win64-shipping.exe") or name.endswith("-win32-shipping.exe"):
        score += 55
        disp = disp or name.replace("-win64-shipping.exe", "").replace("-win32-shipping.exe", "")
    if name == "javaw.exe":
        try:
            if "minecraft" in " ".join(p.cmdline()).lower():
                score += 100
                disp = "Minecraft"
        except Exception:
            pass
    if fg_pid and p.pid == fg_pid:
        score += 30
        if fg_full:
            score += 30
    try:
        mem = p.memory_info().rss / (1024 * 1024)
        score += 10 if mem > 1500 else 5 if mem > 700 else 0
    except Exception:
        pass
    return score, disp or os.path.splitext(name)[0]


def detect_game() -> Optional[dict]:
    """Best guess at the game running right now (or None)."""
    fg = _foreground_pid()
    fg_full = _foreground_is_fullscreen()
    best: tuple[int, dict] | None = None
    for p in psutil.process_iter(["pid", "name"]):
        s, disp = _score_game(p, fg, fg_full)
        if s >= 55 and (best is None or s > best[0]):
            best = (s, {"pid": p.pid, "name": disp, "exe": _exe_of(p), "score": s})
    return best[1] if best else None


def resolve_game_by_name(query: str) -> Optional[dict]:
    """Match a typed game name against running processes."""
    q = _norm(query)
    if not q:
        return None
    fg = _foreground_pid()
    best: tuple[float, dict] | None = None
    for p in psutil.process_iter(["pid", "name"]):
        try:
            name = p.info["name"] or ""
        except Exception:
            continue
        exe = _exe_of(p)
        if _is_system_process(exe, name) or name.lower() in _BROWSERS:
            continue
        hay = _norm(name) + "|" + _norm(os.path.dirname(exe)) + "|" + _norm(_KNOWN_GAMES.get(name.lower(), ""))
        if q not in hay:
            continue
        try:
            mem = p.memory_info().rss
        except Exception:
            mem = 0
        pts = mem / 1e6 + (500 if name.lower() in _KNOWN_GAMES else 0) + (300 if p.pid == fg else 0)
        if name.lower() in _LAUNCHER_NAMES or any(h in name.lower() for h in _HELPER_SUBSTR):
            pts -= 400
        if best is None or pts > best[0]:
            best = (pts, {"pid": p.pid, "name": query.strip(), "exe": exe})
    return best[1] if best else None


# ──────────────────────────────────────────────────────────────────────────────
# Background process candidates + termination
# ──────────────────────────────────────────────────────────────────────────────

def _my_username() -> str:
    try:
        return psutil.Process().username()
    except Exception:
        return ""


def list_termination_candidates() -> list[dict]:
    """Processes the booster can terminate, grouped by exe name.
    `checked` is the default state in the exclusion popup."""
    me = _my_username()
    fg = detect_game()
    protected: set[int] = {os.getpid()}
    if fg:
        protected |= {fg["pid"]} | _ancestors(fg["pid"]) | _descendants(fg["pid"])

    groups: dict[str, dict] = {}
    for p in psutil.process_iter(["pid", "name", "username", "memory_info"]):
        try:
            name = p.info["name"] or ""
            low = name.lower()
            exe = _exe_of(p)
            if p.pid in protected or _is_system_process(exe, name) or low in _KNOWN_GAMES:
                continue
            if me and p.info.get("username") and p.info["username"] != me:
                continue
            mem = (p.info["memory_info"].rss if p.info.get("memory_info") else 0) / (1024 * 1024)
            in_default = low in _BACKGROUND_KILL_LIST
            if not in_default and mem < 200:
                continue
            g = groups.setdefault(low, {
                "name": name, "count": 0, "ram_mb": 0.0, "checked": in_default,
                "kind": "background" if in_default else ("browser" if low in _BROWSERS else "heavy"),
            })
            g["count"] += 1
            g["ram_mb"] += mem
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    out = sorted(groups.values(), key=lambda g: (not g["checked"], -g["ram_mb"]))
    for g in out:
        g["ram_mb"] = round(g["ram_mb"], 1)
    return out


def _measure_free_ram_mb() -> float:
    return psutil.virtual_memory().available / (1024 * 1024)


def _terminate_background(exclude: set[str], protect_pids: set[int],
                          only_names: Optional[set[str]]) -> tuple[list[str], float]:
    """Terminate the agreed processes. Returns (names, MB_freed)."""
    ram_before = _measure_free_ram_mb()
    me = _my_username()
    victims: list[psutil.Process] = []
    names: dict[str, int] = {}

    for proc in psutil.process_iter(["pid", "name", "username"]):
        try:
            name = proc.info["name"] or ""
            low = name.lower()
            if proc.pid in protect_pids or low in exclude:
                continue
            if _is_system_process(_exe_of(proc), name):
                continue
            if me and proc.info.get("username") and proc.info["username"] != me:
                continue
            if only_names is not None:
                if low not in only_names:
                    continue
            elif low not in _BACKGROUND_KILL_LIST:
                continue
            victims.append(proc)
            names[name] = names.get(name, 0) + 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    for proc in victims:
        try:
            proc.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    _, alive = psutil.wait_procs(victims, timeout=3)
    for proc in alive:
        try:
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if alive:
        psutil.wait_procs(alive, timeout=2)

    time.sleep(0.8)
    freed = max(0.0, _measure_free_ram_mb() - ram_before)
    for n, c in names.items():
        _log.info("Terminated background process: %s x%d", n, c)
    return [f"{n} x{c}" if c > 1 else n for n, c in sorted(names.items())], freed


def _trim_working_sets(skip_pids: set[int]) -> float:
    try:
        k32, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
    except Exception:
        return 0.0
    before = _measure_free_ram_mb()
    me = _my_username()
    for p in psutil.process_iter(["pid", "username"]):
        try:
            if p.pid in skip_pids or (me and p.info.get("username") != me):
                continue
            h = k32.OpenProcess(0x0100 | 0x0400, False, p.pid)   # SET_QUOTA | QUERY_INFORMATION
            if h:
                psapi.EmptyWorkingSet(h)
                k32.CloseHandle(h)
        except Exception:
            continue
    time.sleep(0.4)
    return max(0.0, _measure_free_ram_mb() - before)


# ──────────────────────────────────────────────────────────────────────────────
# Booster
# ──────────────────────────────────────────────────────────────────────────────

_GPU_PREF_KEY = r"Software\Microsoft\DirectX\UserGpuPreferences"


def _progress(text: str) -> None:
    bus.publish("gaming.boost_progress", {"step": text})


class GameBooster:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state: Optional[_SavedState] = None
        self._watch_stop = threading.Event()

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._state is not None

    def activate(
        self,
        game_name: str = "",
        game_pid: Optional[int] = None,
        exclude: Optional[set[str]] = None,
        only_names: Optional[set[str]] = None,
    ) -> BoostResult:
        game_name = (game_name or "").strip()
        if game_name.lower() == "unknown game":
            game_name = ""
        exclude = {e.lower() for e in (exclude or set())}
        notes: list[str] = []

        with self._lock:
            if self._state is not None:
                return BoostResult(
                    success=False, game_name=game_name, game_pid=game_pid,
                    ram_freed_mb=0, power_plan_applied="", priority_applied=False,
                    gpu_scheduling_enabled=False, gamebar_disabled=False,
                    message="Boost already active — deactivate first.",
                )

        saved = _SavedState()

        # 0. Work out what must NOT be killed (game + launcher chain)
        _progress("Looking at what is running…")
        target: Optional[dict] = None
        auto = False
        if game_pid:
            try:
                pr = psutil.Process(game_pid)
                target = {"pid": game_pid, "name": game_name or pr.name(), "exe": _exe_of(pr)}
            except Exception:
                target = None
        elif game_name:
            target = resolve_game_by_name(game_name)
        else:
            target = detect_game()
            auto = target is not None

        protect: set[int] = {os.getpid()}
        if target:
            protect |= {target["pid"]} | _ancestors(target["pid"]) | _descendants(target["pid"])

        # 1. Terminate background processes FIRST
        _progress("Closing background apps…")
        terminated, ram_freed = _terminate_background(exclude, protect, only_names)

        # 2. Detect again now that the noise is gone
        _progress("Detecting game…")
        if target is None or not psutil.pid_exists(target["pid"]):
            target = resolve_game_by_name(game_name) if game_name else detect_game()
            auto = auto or (target is not None and not game_name)
        pid: Optional[int] = None
        detected_name = ""
        if target:
            pid = target["pid"]
            detected_name = _KNOWN_GAMES.get(os.path.basename(target.get("exe", "")).lower(), "") \
                or target.get("name") or ""
            saved.game_pid = pid
            saved.game_exe = target.get("exe", "")
        elif game_name:
            notes.append(f"'{game_name}' isn't running yet — system boost applied; "
                         "priority is set automatically when it launches")
        else:
            notes.append("No game detected — system boost applied; "
                         "any game you launch next is boosted automatically")
        shown_name = game_name or detected_name or "System-wide"

        # 3. Priority
        _progress("Setting process priority…")
        priority_ok = self._set_priority(saved, pid)

        # 4. Power plan (verified)
        _progress("Activating performance power plan…")
        saved.original_power_plan = _get_active_power_plan()
        guid, plan_label, created, plan_notes = ensure_performance_plan()
        notes.extend(plan_notes)
        plan_ok, plan_name = False, ""
        if guid:
            plan_ok, err = _set_power_plan(guid)
            if plan_ok:
                plan_name = plan_label
                if created:
                    saved.created_plan = guid
                _log.info("Power plan set to %s (%s)", plan_label, guid)
            else:
                notes.append(f"Power plan switch failed: {err[:120]}")
                _log.warning("Failed to set power plan %s: %s", guid, err)
        else:
            notes.append("No usable performance power plan could be created on this PC")
        try:
            batt = psutil.sensors_battery()
            if batt is not None and not batt.power_plugged:
                notes.append("Laptop is on battery — plug in for best performance")
        except Exception:
            pass

        # 5. GPU scheduling, capture, Game Mode, GPU preference
        _progress("Applying GPU and Windows game settings…")
        H, U, DW = winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER, winreg.REG_DWORD

        def _set(hive, path, name, val, vt=DW) -> bool:
            old, otype = _reg_read(hive, path, name)
            saved.registry.append((hive, path, name, old, otype or vt))
            return _reg_write(hive, path, name, val, vt)

        gpu_sched_ok = _set(H, r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", 2)
        if gpu_sched_ok:
            notes.append("Hardware GPU Scheduling enabled (takes effect after a reboot)")

        gamebar_ok = False
        for hive, path, name, val in (
            (U, r"System\GameConfigStore", "GameDVR_Enabled", 0),
            (U, r"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0),
            (U, r"Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", 0),
            (U, r"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1),
        ):
            if _set(hive, path, name, val) and name != "AutoGameModeEnabled":
                gamebar_ok = True

        if saved.game_exe and _set(U, _GPU_PREF_KEY, saved.game_exe, "GpuPreference=2;", winreg.REG_SZ):
            notes.append("Game pinned to the high-performance GPU")

        # 6. Trim leftovers, measure real RAM
        _progress("Trimming memory…")
        ram_freed += _trim_working_sets(protect)

        with self._lock:
            self._state = saved

        result = BoostResult(
            success=True, game_name=shown_name, game_pid=pid,
            ram_freed_mb=round(ram_freed, 1), power_plan_applied=plan_name,
            priority_applied=priority_ok, gpu_scheduling_enabled=gpu_sched_ok,
            gamebar_disabled=gamebar_ok, message=f"Boost applied for {shown_name}",
            detected_game=detected_name, auto_detected=auto,
            terminated=terminated, notes=notes,
        )
        self._start_watcher(pid)
        _progress("")
        bus.publish(Events.GAME_BOOST_CHANGED, result)
        return result

    @staticmethod
    def _set_priority(saved: _SavedState, pid: Optional[int]) -> bool:
        if pid is None:
            return False
        try:
            p = psutil.Process(pid)
            saved.original_priority = p.nice()
            p.nice(psutil.HIGH_PRIORITY_CLASS)
            try:
                p.ionice(psutil.IOPRIO_HIGH)
            except Exception:
                pass
            _log.info("Set process %d to HIGH priority", pid)
            return True
        except Exception as exc:
            _log.warning("Priority change failed for PID %d: %s", pid, exc)
            return False

    def _start_watcher(self, pid: Optional[int]) -> None:
        """Boost games launched later; auto-restore when the bound game closes."""
        self._watch_stop.set()
        self._watch_stop = stop = threading.Event()

        def _loop() -> None:
            from app.config import config
            bound = pid
            while not stop.wait(3.0):
                with self._lock:
                    st = self._state
                if st is None:
                    return
                if bound is not None:
                    if not psutil.pid_exists(bound):
                        if config.restore_on_game_close:
                            _log.info("Boosted game closed — restoring settings")
                            threading.Thread(target=self.deactivate, daemon=True).start()
                            return
                        bound = None
                    continue
                g = detect_game()
                if g:
                    bound = g["pid"]
                    st.game_pid, st.game_exe = bound, g.get("exe", "")
                    self._set_priority(st, bound)
                    if st.game_exe:
                        old, ot = _reg_read(winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe)
                        st.registry.append((winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe,
                                            old, ot or winreg.REG_SZ))
                        _reg_write(winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe,
                                   "GpuPreference=2;", winreg.REG_SZ)
                    _log.info("Late-launched game detected: %s (PID %d)", g["name"], bound)
                    _progress(f"Detected {g['name']} — priority set")

        threading.Thread(target=_loop, daemon=True, name="boost-watch").start()

    def deactivate(self) -> bool:
        """Restore every setting changed by activate()."""
        with self._lock:
            saved = self._state
            self._state = None
        self._watch_stop.set()
        if saved is None:
            return False

        if saved.game_pid and saved.original_priority is not None:
            try:
                psutil.Process(saved.game_pid).nice(saved.original_priority)
            except Exception as exc:
                _log.debug("Priority restore skipped: %s", exc)

        if saved.original_power_plan:
            ok, _ = _set_power_plan(saved.original_power_plan)
            if ok:
                _log.info("Restored power plan: %s", saved.original_power_plan)
        if saved.created_plan:
            _powercfg("/delete", saved.created_plan)

        for hive, path, name, value, vtype in reversed(saved.registry):
            if value is not None:
                _reg_write(hive, path, name, value, vtype)
            else:
                _reg_delete(hive, path, name)

        bus.publish(Events.GAME_BOOST_CHANGED, None)
        _log.info("Game boost deactivated and all settings restored")
        return True


booster: GameBooster = GameBooster()

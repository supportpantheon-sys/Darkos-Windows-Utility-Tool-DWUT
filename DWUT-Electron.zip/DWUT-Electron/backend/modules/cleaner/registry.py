"""
modules/cleaner/registry.py

Phase and step definitions for the DWUT Cleaner.
Each Step is a dataclass with metadata, the actual executor function is
resolved at runtime by the phase modules — this registry just describes
what exists so the UI can display it without importing every phase module.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Step:
    id:          str
    label:       str
    description: str
    phase:       int
    auto:        bool = True        # False = requires user interaction (Manual Steps)
    enabled:     bool = True        # default enabled state
    win10:       bool = True
    win11:       bool = True
    dangerous:   bool = False       # show extra warning if True
    executor:    Callable | None = field(default=None, repr=False)


@dataclass
class Phase:
    number:      int
    name:        str
    description: str
    steps:       list[Step] = field(default_factory=list)

    @property
    def enabled_steps(self) -> list[Step]:
        return [s for s in self.steps if s.enabled]


# ── Hard-protected items — NEVER touched regardless of settings ────────────
PROTECTED_SERVICES = frozenset({
    # Xbox / Gaming
    "XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGip",
    "BcastDVR", "GameDVR",
    # Microsoft Store
    "ClipSVC", "StoreSvc", "InstallService", "AppXSvc",
    # Windows Media Player
    "WMPNetworkSvc",
    # UWP infrastructure
    "tiledatamodelsvc", "UserDataSvc", "cbdhsvc",
    # DRM
    "WMDRM",
})

PROTECTED_REGISTRY_PATHS = frozenset({
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR",
    r"SYSTEM\CurrentControlSet\Services\XblAuthManager",
    r"SYSTEM\CurrentControlSet\Services\WMPNetworkSvc",
    r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers",
})

PROTECTED_PROCESSES = frozenset({
    "GameBar.exe", "GameBarFT.exe", "XboxApp.exe",
    "WMPlayer.exe", "wmplayer.exe",
})

# ── Phase definitions ─────────────────────────────────────────────────────

PHASE_0 = Phase(
    number=0, name="Prep",
    description="Disable interfering services, back up registry, and create a restore point.",
    steps=[
        Step("kill_malware_procs",  "Kill known malware processes",
             "Terminate any running processes whose names match the known-malware list.",
             phase=0),
        Step("kill_nonessential",   "Kill non-essential background processes",
             "Stop unnecessary processes to free resources for cleaning.",
             phase=0),
        Step("restore_point",       "Create system restore point",
             "Create a Windows System Restore point named DWUT_Clean_<date>. Non-skippable.",
             phase=0, dangerous=False),
        Step("backup_registry",     "Back up registry",
             "Export HKLM and HKCU to timestamped .reg files in DWUT Backup folder.",
             phase=0),
        Step("export_programs",     "Export installed programs list",
             "Save a list of installed software to the backup folder.",
             phase=0),
        Step("export_network",      "Export network configuration",
             "Save full network config (ipconfig /all + netsh) to backup folder.",
             phase=0),
        Step("export_services",     "Export services / tasks / startup",
             "Export running services, scheduled tasks, and startup items.",
             phase=0),
        Step("clear_event_logs",    "Clear Windows event logs",
             "Wipe all Windows event logs via wevtutil.",
             phase=0),
        Step("flush_dns",           "Flush DNS / reset Winsock / reset proxy",
             "ipconfig /flushdns, netsh winsock reset, netsh winhttp reset proxy.",
             phase=0),
        Step("reset_firewall",      "Reset firewall rules",
             "Reset Windows Firewall to default rules via netsh advfirewall reset.",
             phase=0),
        Step("reset_hosts",         "Reset hosts file",
             "Overwrite hosts file with the clean Windows default.",
             phase=0),
        Step("power_high",          "Set High Performance power plan",
             "Switch to High Performance to prevent throttling during the clean.",
             phase=0),
        Step("dis_telemetry",       "Disable telemetry services",
             "Stop and disable DiagTrack, CEIP, RetailDemo data collection.",
             phase=0),
        Step("dis_wd",              "Disable Defender real-time protection (temporary)",
             "Temporarily disables Windows Defender real-time scanning so tools can run.",
             phase=0),
        Step("dis_wu_restart",      "Disable Windows Update auto-restarts",
             "Prevent Windows Update from rebooting mid-clean.",
             phase=0),
        Step("dis_superfetch",      "Disable Superfetch / SysMain",
             "Stop SysMain to free RAM and reduce disk I/O during cleaning.",
             phase=0),
        Step("dis_search",          "Disable Windows Search",
             "Stop WSearch indexer to reduce disk activity during cleaning.",
             phase=0),
        Step("dis_delivery_opt",    "Disable Delivery Optimization",
             "Stop DoSvc bandwidth sharing during the clean.",
             phase=0),
        Step("dis_sleep",           "Disable sleep / hibernation / fast startup",
             "Prevent the machine sleeping mid-clean.",
             phase=0),
        Step("dis_remote",          "Disable Remote Assistance / Registry / Desktop",
             "Disable common remote-access attack surfaces.",
             phase=0, enabled=False),
        Step("dis_smb1",            "Disable SMBv1",
             "Disable the obsolete SMBv1 protocol (EternalBlue attack vector).",
             phase=0, enabled=False),
        Step("dis_homegroup",       "Disable HomeGroup / WorkFolders / WiFi Sense",
             "Disable legacy sharing services.",
             phase=0, win10=True, win11=False),
        Step("dis_appcompat",       "Disable AppExp / PCA / AutoLogger",
             "Stop Application Experience, Program Compatibility Assistant, and AutoLogger.",
             phase=0),
    ],
)

PHASE_1 = Phase(
    number=1, name="Temp Cleanup",
    description="Delete temp files, browser caches, crash dumps, and leftover installer debris.",
    steps=[
        Step("tmp_windows",    "Clear Windows temp folders",
             "%SystemRoot%\\Temp and all per-user %TEMP% directories.", phase=1),
        Step("tmp_prefetch",   "Clear Prefetch",
             "%SystemRoot%\\Prefetch\\*.pf", phase=1),
        Step("tmp_wu",         "Clear Windows Update cache",
             "SoftwareDistribution\\Download and DeliveryOptimization cache.", phase=1),
        Step("tmp_crashes",    "Clear crash dumps",
             "Minidump, WER reports, LocalAppData CrashDumps.", phase=1),
        Step("tmp_thumbs",     "Clear thumbnail / icon cache",
             "Explorer thumbnail DB, IconCache.db.", phase=1),
        Step("tmp_shaders",    "Clear DirectX shader cache",
             "D3DSCache, DXCache, GPU shader cache directories.", phase=1),
        Step("tmp_browsers",   "Clear browser caches",
             "Chrome, Firefox, Edge, Opera cache directories for all user profiles.", phase=1),
        Step("tmp_java",       "Clear Java / Flash cache",
             "Java deployment cache, Flash player temp files.", phase=1),
        Step("tmp_logs",       "Clear system log files",
             "IIS logs, CBS logs, DISM logs.", phase=1),
        Step("tmp_old_windows","Clear Windows.old / upgrade leftovers",
             "Windows.old, $Windows.~BT, $Windows.~WS, MSOCache.", phase=1),
        Step("tmp_recycle",    "Empty Recycle Bin",
             "Empty the Recycle Bin for all drives.", phase=1),
        Step("tmp_installers", "Clear leftover installer files",
             "Orphaned installer temp files in ProgramData and AppData.", phase=1),
    ],
)

PHASE_3 = Phase(
    number=3, name="Disinfect",
    description="Run a battery of malware scanners and removal tools.",
    steps=[
        Step("rkill",        "RKill",                "Terminate malware processes to allow scanners to run.",              phase=3),
        Step("malwarebytes", "Malwarebytes",          "Guided Malwarebytes Anti-Malware threat scan.",                      phase=3, auto=False),
        Step("adwcleaner",   "AdwCleaner",            "Scan and remove adware, PUPs, toolbars, and hijackers.",            phase=3),
        Step("tdsskiller",   "TDSSKiller",            "Kaspersky rootkit / bootkit detection and removal.",                phase=3),
        Step("hitmanpro",    "HitmanPro",             "Second-opinion cloud scanner. Requires EULA acceptance.",           phase=3, auto=False),
        Step("roguekiller",  "RogueKiller",           "Scan for rogue processes, registry entries, and browser hijacks.",  phase=3, auto=False),
        Step("msrt",         "MSRT",                  "Microsoft Malicious Software Removal Tool.",                        phase=3),
        Step("defender",     "Windows Defender",      "Full Windows Defender antivirus scan.",                             phase=3),
        Step("kaspersky_vrt","Kaspersky VRT",         "Kaspersky Virus Removal Tool — full scan.",                         phase=3),
        Step("sophos_vrt",   "Sophos VRT",            "Sophos Virus Removal Tool — full scan. Requires GUI interaction.",                            phase=3, auto=False),
        Step("mcafee",       "McAfee Stinger",        "McAfee targeted malware removal tool.",                             phase=3),
        Step("eset",         "ESET Online Scanner",   "ESET cloud scanner. Requires GUI interaction.",                     phase=3, auto=False),
        Step("npe",          "Norton Power Eraser",   "Norton targeted rootkit remover. Requires GUI interaction.",        phase=3, auto=False),
        Step("mbar",         "Malwarebytes Anti-Rootkit", "Targeted rootkit scanner and removal.",                         phase=3, auto=False),
        Step("gmer",         "GMER",                  "Advanced rootkit scanner. Requires GUI interaction.",               phase=3, auto=False),
        Step("frst",         "FRST",                  "Farbar Recovery Scan Tool. Requires GUI interaction.",              phase=3, auto=False),
        Step("otl",          "OTL",                   "OldTimer ListIt. Requires GUI interaction.",                        phase=3, auto=False),
    ],
)

PHASE_4 = Phase(
    number=4, name="Repair",
    description="Repair Windows system files, component store, and broken services.",
    steps=[
        Step("sfc",           "SFC — System File Checker",   "sfc /scannow — scan and repair protected system files.",          phase=4),
        Step("dism",          "DISM — Component Store",      "DISM /Online /Cleanup-Image /RestoreHealth.",                     phase=4),
        Step("chkdsk",        "CHKDSK",                      "Check and repair disk errors on the system drive.",               phase=4),
        Step("repair_wu",     "Repair Windows Update",       "Re-register Windows Update DLLs, clear SoftwareDistribution.",    phase=4),
        Step("repair_wmi",    "Repair WMI",                  "winmgmt /resetrepository — rebuild the WMI repository.",          phase=4),
        Step("repair_store",  "Repair Windows Store",        "wsreset.exe — reset Store cache only, no debloat.",              phase=4),
        Step("repair_start",  "Repair Start Menu",           "Kill and restart StartMenuExperienceHost / Explorer.",            phase=4),
        Step("repair_search", "Repair Search index",         "Stop WSearch, delete index, restart.",                           phase=4),
        Step("repair_dotnet", "Repair .NET Framework",       "Repair .NET via Windows optional features.",                     phase=4),
        Step("repair_vcpp",   "Repair Visual C++ runtimes",  "Detect and silently re-run each installed VC++ redistributable.", phase=4),
        Step("repair_dx",     "Repair DirectX",              "Run DirectX End-User Runtime (dxwebsetup) silently.",            phase=4),
        Step("repair_boot",   "Repair Boot files",           "bcdboot C:\\Windows /s C: — rebuild boot configuration.",        phase=4),
        Step("repair_gp",     "Repair Group Policy",         "gpupdate /force.",                                               phase=4),
        Step("repair_explorer","Repair Explorer shell",      "taskkill /f explorer.exe then restart.",                         phase=4),
        Step("repair_com",    "Repair COM / DCOM",           "Re-register known system DLLs and reset DCOM permissions.",      phase=4),
        Step("repair_msi",    "Repair MSI Installer",        "msiexec /unregister then /regserver.",                           phase=4),
        Step("repair_bits",   "Repair BITS",                 "bitsadmin /reset /allusers — reset Background Intelligent Transfer.", phase=4),
        Step("repair_crypt",  "Repair Cryptographic Services","Stop, re-register, and restart CryptSvc.",                      phase=4),
        Step("repair_perm",   "Repair registry / file permissions", "secedit /configure — reset default security permissions.", phase=4),
        Step("repair_winre",  "Verify & repair WinRE (Recovery)",   "Reagentc /enable and verify Windows Recovery Environment.", phase=4, win10=False, win11=True),
        Step("clean_comp_store", "Clean Component Store (Fast DISM)", "Reclaims gigabytes of superseded update packages via DISM /StartComponentCleanup.", phase=4),
    ],
)

PHASE_5 = Phase(
    number=5, name="Patch",
    description="Install Windows Updates, driver updates, and runtime packages.",
    steps=[
        Step("wu_all",       "Windows Updates",           "Install all available updates via PSWindowsUpdate.",              phase=5),
        Step("wu_defender",  "Defender definitions",      "Update-MpSignature — update virus definitions.",                  phase=5),
        Step("wu_vcpp",      "Visual C++ redistributables","Download and install the latest VC++ bundle from Microsoft.",    phase=5),
        Step("wu_dotnet",    "NET Framework updates",     "Install .NET Framework updates via Windows Update.",              phase=5),
        Step("wu_dx",        "DirectX End-User Runtime",  "Install DirectX EUDR package from Microsoft.",                   phase=5),
    ],
)

PHASE_6 = Phase(
    number=6, name="Optimize",
    description="Tune registry, network stack, startup, and disk settings for performance.",
    steps=[
        Step("opt_disk",     "Defrag HDD / TRIM SSD",         "Auto-detect drive type and run Optimize-Volume.",              phase=6),
        Step("opt_startup",  "Optimize startup items",        "Disable known-junk startup entries.",                          phase=6),
        Step("opt_services", "Optimize service startup types","Set recommended startup types for non-critical services.",     phase=6),
        Step("opt_network",  "Optimize network / TCP stack",  "Apply tuned TCP/IP registry settings (MTU, TCP acks, etc).",  phase=6),
        Step("opt_dns",      "Set DNS provider",              "Switch primary DNS (user choice: Cloudflare / Google / ISP).", phase=6),
        Step("opt_power",    "Restore Balanced power plan",   "Return to Balanced after the High Performance clean phase.",   phase=6),
        Step("opt_pagefile", "Optimize pagefile",             "Set pagefile to Auto-manage or 1.5× RAM.",                    phase=6),
        Step("opt_prefetch", "Optimize Prefetch",             "Set EnablePrefetcher=3 in registry.",                         phase=6),
        Step("opt_memory",   "Optimize memory management",    "Set LargeSystemCache=0 for desktop systems.",                  phase=6),
        Step("opt_privacy",  "Optimize privacy settings",     "Reduce telemetry to minimum (no Xbox/gaming settings touched).", phase=6),
        Step("opt_index",    "Optimize search indexing",      "Rebuild index with trimmed scope.",                            phase=6),
        Step("opt_vis",      "Optimize visual effects",       "Set Windows visual effects to Adjust for best performance.",   phase=6),
        Step("opt_cleanup",  "Run Disk Cleanup",              "cleanmgr /sagerun:65535 — clean all categories.",              phase=6),
        Step("opt_onedrive", "Clean OneDrive sync cache",     "Remove OneDrive telemetry & temp files (keeps user sync intact).", phase=6, enabled=False),
        Step("opt_cortana",  "Clean Cortana search cache",    "Remove legacy Cortana temp query caches.", phase=6, enabled=False, win10=True, win11=False),
        Step("opt_ram_trim", "Optimize & trim RAM working sets","Flushes inactive working sets and standby caches to boost memory performance.", phase=6),
    ],
)

PHASE_7 = Phase(
    number=7, name="Wrap-up",
    description="Re-enable services and settings disabled during Phase 0, restore power plan.",
    steps=[
        Step("re_defender",      "Re-enable Windows Defender",          "Restore real-time protection.", phase=7),
        Step("re_wu",            "Re-enable Windows Update",            "Restore WU service and auto-restart policy.", phase=7),
        Step("re_telemetry",     "Re-enable telemetry (optional)",      "Restore DiagTrack / CEIP (only if originally enabled).", phase=7, enabled=False),
        Step("re_superfetch",    "Re-enable Superfetch / SysMain",      "Restore SysMain to original state.", phase=7),
        Step("re_search",        "Re-enable Windows Search",            "Restore WSearch indexer.", phase=7),
        Step("re_delivery",      "Re-enable Delivery Optimization",     "Restore DoSvc.", phase=7),
        Step("re_sleep",         "Re-enable sleep / hibernation",       "Restore original sleep and hibernate settings.", phase=7),
        Step("re_services",      "Re-enable all other stopped services","Restore all services disabled in Phase 0.", phase=7),
        Step("re_remote",        "Re-enable Remote Assistance (opt.)",  "Only if it was enabled before cleaning.", phase=7, enabled=False),
        Step("re_media",         "Confirm WMP / media services intact", "Verify Windows Media Player and DRM services are healthy.", phase=7),
        Step("report",           "Generate session report",             "Save a full log of everything done to the backup folder.", phase=7),
    ],
)

PHASE_8 = Phase(
    number=8, name="AV Cleanup",
    description="Uninstall downloaded AV tools that were used during the scan — keeps your system clean.",
    steps=[
        Step("uninstall_malwarebytes", "Uninstall Malwarebytes",
             "Silently uninstall the Malwarebytes copy that was downloaded for this clean.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_adwcleaner",   "Remove AdwCleaner",
             "Delete AdwCleaner and its leftover quarantine folder.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_tdsskiller",   "Remove TDSSKiller",
             "Delete TDSSKiller executable and any log files it created.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_hitmanpro",    "Uninstall HitmanPro",
             "Silently uninstall HitmanPro if it was downloaded and run.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_roguekiller",  "Remove RogueKiller",
             "Delete the RogueKiller executable and its report files.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_kaspersky_vrt","Remove Kaspersky VRT",
             "Delete the Kaspersky Virus Removal Tool and its log files.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_sophos_vrt",   "Remove Sophos VRT",
             "Delete the Sophos Virus Removal Tool.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_mcafee",       "Remove McAfee Stinger",
             "Delete the McAfee Stinger executable.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_eset",         "Remove ESET Online Scanner",
             "Silently uninstall ESET Online Scanner via its own uninstaller.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_npe",          "Remove Norton Power Eraser",
             "Delete the Norton Power Eraser executable.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_mbar",         "Remove MBAR",
             "Delete Malwarebytes Anti-Rootkit files from the tool directory.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_rkill",        "Remove RKill",
             "Delete the RKill executable — it does not install, just runs.",
             phase=8, auto=True, win10=True, win11=True),
        Step("uninstall_tools_dir",    "Clean DWUT tool download cache",
             "Delete the DWUT_Tools temp folder that held all downloaded AV executables.",
             phase=8, auto=True, win10=True, win11=True),
    ],
)

ALL_PHASES: list[Phase] = [PHASE_0, PHASE_1, PHASE_3, PHASE_4, PHASE_5, PHASE_6, PHASE_7, PHASE_8]
PHASE_MAP:  dict[int, Phase] = {p.number: p for p in ALL_PHASES}
STEP_MAP:   dict[str, Step]  = {s.id: s for p in ALL_PHASES for s in p.steps}

# Quick 3-5 minute maintenance clean steps (fast, high-impact, zero risk)
LIGHT_CLEAN_STEPS: frozenset[str] = frozenset({
    # Phase 0
    "restore_point",
    "flush_dns",
    "reset_firewall",
    # Phase 1
    "tmp_windows",
    "tmp_prefetch",
    "tmp_wu",
    "tmp_crashes",
    "tmp_thumbs",
    "tmp_shaders",
    "tmp_browsers",
    "tmp_logs",
    "tmp_recycle",
    "tmp_installers",
    # Phase 3
    "malwarebytes",
    # Phase 4
    "clean_comp_store",
    "repair_store",
    "repair_explorer",
    # Phase 6
    "opt_disk",
    "opt_ram_trim",
    "opt_dns",
    "opt_cleanup",
    # Phase 7
    "report",
    # Phase 8 — always uninstall the one AV tool used in Light Clean
    "uninstall_malwarebytes",
    "uninstall_tools_dir",
})

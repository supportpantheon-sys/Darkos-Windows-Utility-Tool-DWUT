"""
modules/network/monitor.py — Real-time network traffic monitor.

Captures live connections using psutil + netstat, scores them for threat level,
maintains an allowlist, and fires events for the UI and tray notifications.

Threat scoring:
  - Known bad ports, foreign IPs, unusual protocols → raise score
  - Allowlisted apps/IPs → score clamped to 0
  - Built-in whitelist covers Windows Update, Steam, Discord, Chrome, Edge, etc.
"""
from __future__ import annotations

import ipaddress
import os
import re
import socket
import subprocess
import threading
import time
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from core.events import bus
from core.logger import get_logger

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ── built-in safe app names (case-insensitive substring match) ────────────────
_SAFE_APPS = {
    "svchost", "system", "wininit", "services", "lsass", "csrss", "smss",
    "winlogon", "explorer", "dwm", "taskhostw", "sihost", "ctfmon", "rundll32",
    # Windows Update / Delivery Optimisation
    "usocoreworker", "wuauclt", "dosvc", "tiworker", "trustedinstaller",
    "musnotification", "wudfhost",
    # Browsers
    "chrome", "firefox", "msedge", "brave", "opera",
    # Communication
    "discord", "slack", "teams", "zoom", "skype", "telegram",
    # Gaming/apps
    "steam", "steamwebhelper", "epic", "battle", "origin",
    "spotify", "vlc", "obs64", "obs32", "obs",
    # Dev
    "python", "python3", "pythonw", "node", "electron", "git",
    # Cloud storage
    "onedrive", "dropbox", "googledrivesync", "box",
    # System tools
    "windowsterminal", "powershell", "cmd", "conhost",
    # Security
    "antimalware", "mssense", "mpengine", "securityhealthsystray",
    # GPU
    "nvidia", "amd", "intel", "igfx",
    # VPN clients — these intentionally make unusual connections
    "openvpn", "wireguard", "nordvpn", "expressvpn", "proton", "mullvad",
    "surfshark", "cyberghost", "ipvanish", "privateinternetaccess", "pia",
    "tunnelbear", "windscribe", "hotspotshield",
    # Proxy checkers / utilities — they scan ports by design
    "proxychecker", "proxycheck",
    # DWUT itself
    "dwut",
}

# ── known bad / suspicious ports (genuine RAT/C2/backdoor ports only) ────────
# ONLY classic attack tools use these. Legitimate software never uses these.
_SUSPICIOUS_PORTS = {
    1337, 4444, 5555, 6666, 7777, 31337, 12345, 12346, 20034, 54321,
    # Confirmed RAT defaults:
    1604, 5800, 9001, 9030,  # some Tor defaults
    # NOT included: 1080 (SOCKS — legit), 8888 (Jupyter — legit), 6697 (IRC — legit)
}

# Ports that are completely safe regardless of process
_KNOWN_SAFE_PORTS = {
    20, 21, 22, 23, 25, 53, 67, 68, 69, 80, 110, 119, 123, 143, 161,
    389, 443, 445, 465, 514, 587, 636, 993, 995,
    1080, 1194,   # SOCKS + OpenVPN — legit proxy/VPN
    3128, 8080, 8118,  # proxy ports
    3389,             # RDP
    5222, 5228, 5229, # XMPP / Google
    5353,             # mDNS
    6881, 6882, 6883, # BitTorrent — legit
    8443, 9443,
    51820, 51821,     # WireGuard
    # Steam
    27015, 27016, 27017, 27018, 27019, 27020, 27036, 27037,
    # Game servers
    3478, 3479, 3480,
    # Misc
    7000, 7001, 9000, 9988, 10000,
}

# ── private / reserved IP ranges (never flagged as suspicious) ────────────────
_PRIVATE = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


def _is_private(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip)
        return any(a in net for net in _PRIVATE)
    except ValueError:
        return False


# ── connection data ───────────────────────────────────────────────────────────
@dataclass
class Connection:
    pid:       int    = 0
    proc:      str    = ""
    laddr:     str    = ""
    lport:     int    = 0
    raddr:     str    = ""
    rport:     int    = 0
    status:    str    = ""
    proto:     str    = "TCP"
    threat:    int    = 0     # 0=safe 1=watch 2=warn 3=danger
    reason:    str    = ""
    first_seen: float = 0.0
    bytes_sent: int   = 0
    bytes_recv: int   = 0
    rdns:       str   = ""


@dataclass
class MonitorSnapshot:
    connections: list = field(default_factory=list)
    total:       int  = 0
    suspicious:  int  = 0
    dangerous:   int  = 0
    blocked:     int  = 0
    ts:          float = 0.0


# ── singleton monitor ─────────────────────────────────────────────────────────
class NetworkMonitor:
    def __init__(self):
        self._running    = False
        self._thread: Optional[threading.Thread] = None
        self._lock       = threading.Lock()
        self._allowlist: set[str] = set()  # process names or IPs the user added
        self._notifications = True
        self._auto_block = False
        self._history: deque = deque(maxlen=500)
        self._blocked_ips: set[str] = set()
        self._snap = MonitorSnapshot()
        self._last_alert_key: str = ""
        self._alert_cooldown: float = 0.0

    # ── allowlist ─────────────────────────────────────────────────────────────
    def add_allow(self, entry: str) -> None:
        self._allowlist.add(entry.lower().strip())

    def remove_allow(self, entry: str) -> None:
        self._allowlist.discard(entry.lower().strip())

    def get_allowlist(self) -> list[str]:
        return sorted(self._allowlist)

    def _is_allowed(self, conn: Connection) -> bool:
        if conn.proc.lower() in self._allowlist:
            return True
        if conn.raddr in self._allowlist:
            return True
        for entry in self._allowlist:
            if entry in conn.proc.lower() or entry == conn.raddr:
                return True
        return False

    # ── threat scoring — strict, low false-positive design ────────────────────
    def _score(self, conn: Connection) -> tuple[int, str]:
        name = conn.proc.lower()

        # 1. User allowlist — always safe
        if self._is_allowed(conn):
            return 0, ""

        # 2. Built-in safe apps — always safe (VPN, proxy checkers included)
        for safe in _SAFE_APPS:
            if safe in name:
                return 0, ""

        # 3. No remote address (LISTEN / local only) — safe
        if not conn.raddr or conn.raddr in ("", "0.0.0.0", "::"):
            return 0, ""

        # 4. Private IP / LAN / localhost — always safe
        #    This covers VPN tunnel addresses (10.x, 172.16-31.x, 192.168.x)
        if _is_private(conn.raddr):
            return 0, ""

        # 5. Blocked IP — instant Danger
        if conn.raddr in self._blocked_ips:
            return 3, "Blocked IP"

        # 6. Safe port — safe regardless of process
        if conn.rport in _KNOWN_SAFE_PORTS:
            return 0, ""

        # ── scoring starts here — only for unrecognised external connections ──
        reasons = []
        score = 0

        # Known RAT/C2 port — this alone is only Watch unless process is unknown AND established
        is_rat_port = conn.rport in _SUSPICIOUS_PORTS
        if is_rat_port:
            if not name or conn.pid == 0:
                # Unknown process on a classic RAT port AND actively connected = Danger
                if conn.status == "ESTABLISHED":
                    return 3, f"Unknown process on RAT/C2 port {conn.rport}"
                else:
                    score = 2
                    reasons.append(f"RAT port {conn.rport}, non-established")
            else:
                # Known process but still a suspicious port — Watch only
                score = 1
                reasons.append(f"suspicious port {conn.rport}")

        # High ephemeral port on fully unknown process AND established — Warn (not Danger)
        elif conn.rport > 49152 and (not name or conn.pid == 0) and conn.status == "ESTABLISHED":
            score = 2
            reasons.append(f"unknown process, high port {conn.rport}")

        # Everything else — unknown process on any external IP, not a bad port
        # This is Watch at most, never Warn or Danger by itself
        elif not name or conn.pid == 0:
            score = 0  # unknown process alone is NOT a threat

        score = min(score, 3)
        return score, " · ".join(reasons) if reasons else ""

    # ── block an attacker ─────────────────────────────────────────────────────
    def block_ip(self, ip: str) -> bool:
        """Add a Windows Firewall block rule for the given IP."""
        if not ip or ip in self._blocked_ips:
            return False
        try:
            rule = f"DWUT-NetBlock-{ip.replace(':', '-')}"
            subprocess.run(
                ["netsh", "advfirewall", "firewall", "add", "rule",
                 f"name={rule}", "dir=in", "action=block", f"remoteip={ip}", "enable=yes"],
                capture_output=True, timeout=20, creationflags=_NO_WINDOW)
            subprocess.run(
                ["netsh", "advfirewall", "firewall", "add", "rule",
                 f"name={rule}-out", "dir=out", "action=block", f"remoteip={ip}", "enable=yes"],
                capture_output=True, timeout=20, creationflags=_NO_WINDOW)
            self._blocked_ips.add(ip)
            _log.info("Blocked IP: %s", ip)
            return True
        except Exception as exc:
            _log.warning("block_ip %s: %s", ip, exc)
            return False

    def unblock_ip(self, ip: str) -> bool:
        rule = f"DWUT-NetBlock-{ip.replace(':', '-')}"
        try:
            subprocess.run(["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule}"],
                           capture_output=True, timeout=20, creationflags=_NO_WINDOW)
            subprocess.run(["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule}-out"],
                           capture_output=True, timeout=20, creationflags=_NO_WINDOW)
            self._blocked_ips.discard(ip)
            return True
        except Exception as exc:
            _log.warning("unblock_ip %s: %s", ip, exc)
            return False

    # ── connection scan ───────────────────────────────────────────────────────
    def _scan(self) -> list[Connection]:
        try:
            import psutil
        except ImportError:
            return []
        conns = []
        try:
            for c in psutil.net_connections(kind="all"):
                la = c.laddr.ip if c.laddr else ""
                lp = c.laddr.port if c.laddr else 0
                ra = c.raddr.ip if c.raddr else ""
                rp = c.raddr.port if c.raddr else 0
                status = c.status or ""
                proto = "UDP" if c.type and "DGRAM" in str(c.type) else "TCP"
                try:
                    proc = psutil.Process(c.pid).name() if c.pid else ""
                except Exception:
                    proc = ""
                conn = Connection(
                    pid=c.pid or 0, proc=proc,
                    laddr=la, lport=lp, raddr=ra, rport=rp,
                    status=status, proto=proto, first_seen=time.time())
                conn.threat, conn.reason = self._score(conn)
                conns.append(conn)
        except Exception as exc:
            _log.debug("scan error: %s", exc)
        return conns

    def _publish_alert(self, conn: Connection) -> None:
        # Only publish if notifications are ON — the frontend also checks, but belt-and-suspenders
        if not self._notifications:
            return
        # Only alert on genuine threats (Warn or Danger)
        if conn.threat < 2:
            return
        key = f"{conn.raddr}:{conn.rport}:{conn.proc}"
        now = time.time()
        if key == self._last_alert_key and now - self._alert_cooldown < 60:
            return
        self._last_alert_key = key
        self._alert_cooldown = now
        bus.publish("network.alert", {
            "threat": conn.threat,
            "proc":   conn.proc,
            "raddr":  conn.raddr,
            "rport":  conn.rport,
            "reason": conn.reason,
            "pid":    conn.pid,
        })

    # ── main loop ─────────────────────────────────────────────────────────────
    def _loop(self) -> None:
        while self._running:
            try:
                conns = self._scan()
                suspicious = sum(1 for c in conns if c.threat == 1)
                dangerous  = sum(1 for c in conns if c.threat >= 2)
                snap = MonitorSnapshot(
                    connections=[asdict(c) for c in conns],
                    total=len(conns),
                    suspicious=suspicious,
                    dangerous=dangerous,
                    blocked=len(self._blocked_ips),
                    ts=time.time())
                with self._lock:
                    self._snap = snap
                bus.publish("network.snapshot", asdict(snap))
                for c in conns:
                    if c.threat >= 2:  # only record/alert on Warn+
                        self._history.append(asdict(c))
                        self._publish_alert(c)
                        if self._auto_block and c.threat >= 3 and c.raddr:
                            self.block_ip(c.raddr)
            except Exception as exc:
                _log.debug("monitor loop: %s", exc)
            time.sleep(3)

    # ── lifecycle ─────────────────────────────────────────────────────────────
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="net-monitor")
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    def snapshot(self) -> dict:
        with self._lock:
            return asdict(self._snap)

    def history(self) -> list:
        return list(self._history)

    @property
    def notifications_on(self) -> bool:
        return self._notifications

    @notifications_on.setter
    def notifications_on(self, v: bool) -> None:
        self._notifications = v

    @property
    def auto_block(self) -> bool:
        return self._auto_block

    @auto_block.setter
    def auto_block(self, v: bool) -> None:
        self._auto_block = v


# ── singleton ─────────────────────────────────────────────────────────────────
net_monitor = NetworkMonitor()

"""modules/usb/catalog.py — every OS the flasher knows, and how to find its CURRENT download.

mode:
  dd      raw-write a hybrid ISO/IMG (all mainstream Linux ISOs are hybrid)
  winiso  Windows-style ISO: FAT32 + copy files + split install.wim + boot code (works for UEFI and BIOS)
  ventoy  install Ventoy, then copy the ISO onto it (for ISOs that are not hybrid, e.g. TempleOS)
  ventoy_only  just install Ventoy (multi-boot stick)

src:
  fido     Microsoft ISO via the Fido script (the only legitimate automated route)
  fixed    stable URL(s)
  listing  scrape a mirror's directory listing for the newest file  (never goes stale)
  github   newest release asset
"""
from __future__ import annotations

OS_LIST: list[dict] = [
    # ── Windows ──
    dict(id="win11", name="Windows 11", group="Windows", mode="winiso", src="fido", win="11", size_gb=6.5,
         desc="Official Microsoft ISO (latest release, x64, English). Works on UEFI and BIOS PCs."),
    dict(id="win10", name="Windows 10", group="Windows", mode="winiso", src="fido", win="10", size_gb=5.8,
         desc="Official Microsoft ISO (latest 22H2, x64, English)."),
    # ── Mainstream Linux ──
    dict(id="ubuntu", name="Ubuntu 24.04 LTS", group="Linux", mode="dd", src="listing", size_gb=6.0,
         base="https://releases.ubuntu.com/24.04/", file=r"^ubuntu-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="The most popular desktop Linux. Long-term support until 2029."),
    dict(id="mint", name="Linux Mint (Cinnamon)", group="Linux", mode="dd", src="listing", size_gb=2.9,
         base="https://mirrors.edge.kernel.org/linuxmint/stable/", subdir=r"^\d+(\.\d+)?/$", file=r"^linuxmint-[\d.]+-cinnamon-64bit\.iso$", checksum_files=["sha256sum.txt"],
         desc="Friendly, Windows-like desktop. Great first Linux."),
    dict(id="mint_xfce", name="Linux Mint (Xfce)", group="Linux", mode="dd", src="listing", size_gb=2.9,
         base="https://mirrors.edge.kernel.org/linuxmint/stable/", subdir=r"^\d+(\.\d+)?/$", file=r"^linuxmint-[\d.]+-xfce-64bit\.iso$", checksum_files=["sha256sum.txt"],
         desc="Lightweight Mint for older PCs."),
    dict(id="fedora", name="Fedora Workstation", group="Linux", mode="dd", src="listing", size_gb=2.3,
         base="https://dl.fedoraproject.org/pub/fedora/linux/releases/", subdir=r"^\d+/$", subpath="Workstation/x86_64/iso/",
         file=r"^Fedora-Workstation-Live.*x86_64.*\.iso$", checksum_re=r"CHECKSUM$",
         desc="Cutting-edge GNOME desktop from Red Hat's community."),
    dict(id="debian", name="Debian Live (GNOME)", group="Linux", mode="dd", src="listing", size_gb=3.1,
         base="https://cdimage.debian.org/debian-cd/current-live/amd64/iso-hybrid/", file=r"^debian-live-[\d.]+-amd64-gnome\.iso$", checksum_files=["SHA256SUMS"],
         desc="Rock-solid and stable. Boots live, installer included."),
    dict(id="arch", name="Arch Linux", group="Linux", mode="dd", src="fixed", size_gb=1.3,
         urls=["https://geo.mirror.pkgbuild.com/iso/latest/archlinux-x86_64.iso", "https://mirrors.kernel.org/archlinux/iso/latest/archlinux-x86_64.iso"],
         checksum_urls=["https://geo.mirror.pkgbuild.com/iso/latest/sha256sums.txt", "https://mirrors.kernel.org/archlinux/iso/latest/sha256sums.txt"],
         desc="Rolling release for people who like to build their own system. Command-line installer."),
    dict(id="opensuse", name="openSUSE Tumbleweed", group="Linux", mode="dd", src="fixed", size_gb=4.5,
         urls=["https://download.opensuse.org/tumbleweed/iso/openSUSE-Tumbleweed-DVD-x86_64-Current.iso"],
         checksum_urls=["https://download.opensuse.org/tumbleweed/iso/openSUSE-Tumbleweed-DVD-x86_64-Current.iso.sha256"],
         desc="Rolling release with excellent KDE and YaST tools."),
    dict(id="alpine", name="Alpine Linux", group="Linux", mode="dd", src="listing", size_gb=0.2,
         base="https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/x86_64/", file=r"^alpine-standard-[\d.]+-x86_64\.iso$", checksum_re=r"^alpine-standard-[\d.]+-x86_64\.iso\.sha256$",
         desc="Tiny (200 MB), security-oriented. Runs from RAM."),
    # ── Security / hacking ──
    dict(id="kali", name="Kali Linux", group="Security", mode="dd", src="listing", size_gb=4.4,
         base="https://cdimage.kali.org/current/", file=r"^kali-linux-[\d.]+-live-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Penetration-testing distro. Live image (boots without installing)."),
    dict(id="kali_purple", name="Kali Linux Purple", group="Security", mode="dd", src="listing", size_gb=4.5,
         base="https://cdimage.kali.org/current/", file=r"^kali-linux-[\d.]+-installer-purple-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Kali's defensive (blue-team) edition with SOC tooling. Installer image."),
    dict(id="parrot_sec", name="Parrot Security", group="Security", mode="dd", src="listing", size_gb=5.0,
         base="https://deb.parrot.sh/parrot/iso/", subdir=r"^\d+(\.\d+)*/$", file=r"^Parrot-security-[\d.]+_amd64\.iso$", checksum_re=r"hashes|SHA256|sha256",
         desc="Pentesting + privacy tools in a lighter package than Kali."),
    dict(id="parrot_home", name="Parrot Home", group="Security", mode="dd", src="listing", size_gb=4.0,
         base="https://deb.parrot.sh/parrot/iso/", subdir=r"^\d+(\.\d+)*/$", file=r"^Parrot-home-[\d.]+_amd64\.iso$", checksum_re=r"hashes|SHA256|sha256",
         desc="Everyday privacy-focused desktop (no hacking tools)."),
    dict(id="blackarch", name="BlackArch Linux (Slim)", group="Security", mode="dd", src="listing", size_gb=4.6,
         base="https://ftp.halifax.rwth-aachen.de/blackarch/iso/", file=r"^blackarch-linux-slim-[\d.]+-x86_64\.iso$",
         desc="Arch-based with 2800+ security tools."),
    # ── Privacy ──
    dict(id="qubes", name="Qubes OS", group="Privacy", mode="dd", src="listing", size_gb=6.8,
         base="https://mirrors.edge.kernel.org/qubes/iso/", file=r"^Qubes-R[\d.]+-x86_64\.iso$",
         desc="Security by compartmentalisation: every app in its own VM. Needs 16 GB RAM and VT-x/VT-d.",
         warn="Qubes needs a modern PC (16 GB RAM, virtualisation + IOMMU) - check hardware compatibility first."),
    dict(id="tails", name="Tails", group="Privacy", mode="dd", src="listing", size_gb=1.4,
         base="https://download.tails.net/tails/stable/", subdir=r"^tails-amd64-[\d.]+/$", file=r"^tails-amd64-[\d.]+\.img$",
         desc="Amnesic OS that routes everything through Tor and leaves no trace."),
    # ── Other / fun ──
    dict(id="templeos", name="TempleOS", group="Other", mode="ventoy", src="fixed", size_gb=0.02,
         urls=["https://templeos.org/Downloads/TempleOS.ISO", "https://www.templeos.org/Downloads/TempleOS.ISO"],
         desc="Terry Davis's 64-bit hobby OS. Not a hybrid ISO, so DWUT installs Ventoy and adds it.",
         warn="TempleOS is designed for a VM; on real PCs it needs legacy BIOS/CSM boot and may not run on all hardware."),
    dict(id="hbcd", name="Hiren's BootCD PE", group="Other", mode="winiso", src="fixed", size_gb=3.0,
         urls=["https://www.hirensbootcd.org/files/HBCD_PE_x64.iso"],
         desc="Windows PE rescue toolkit: disk, password, recovery and diagnostic tools."),
    dict(id="ventoy", name="Ventoy (multi-boot stick)", group="Other", mode="ventoy_only", src="github", size_gb=0.02,
         repo="ventoy/Ventoy", asset=r"^ventoy-[\d.]+-windows\.zip$",
         desc="Install once, then just drag-and-drop any number of ISOs onto the stick and pick one at boot."),
]

GROUPS = ["Windows", "Linux", "Security", "Privacy", "Other"]


def public() -> list[dict]:
    keys = ("id", "name", "group", "mode", "size_gb", "desc", "warn")
    return [{k: o.get(k, "") for k in keys} for o in OS_LIST]


def get(os_id: str) -> dict | None:
    return next((o for o in OS_LIST if o["id"] == os_id), None)

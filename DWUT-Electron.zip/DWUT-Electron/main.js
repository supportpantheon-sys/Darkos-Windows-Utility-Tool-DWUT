'use strict';
/**
 * DWUT — Electron main process.
 *  - supervises the Python backend (untouched modules/) over stdin/stdout JSON lines
 *  - offers to relaunch as Administrator (same wording as the original app)
 *  - frameless window: custom title bar lives in the renderer
 */
const { app, BrowserWindow, ipcMain, dialog, shell, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');
const readline = require('readline');

const MIN_W = 900, MIN_H = 580, DEF_W = 960, DEF_H = 620;
// NOTE: app.isPackaged is TRUE whenever the exe is not literally named "electron(.exe)" - and the
// bootstrap renames it to DWUT.exe - so locate the backend on disk instead of trusting that flag.
const localBackend = path.join(__dirname, 'backend');
const bundledBackend = path.join(process.resourcesPath || '', 'backend');
const runFromFolder = fs.existsSync(path.join(localBackend, 'server.py'));
const backendDir = runFromFolder ? localBackend : bundledBackend;

let win = null;
let backend = null;
let backendReady = false;
let nextId = 1;
const pending = new Map();
let shuttingDown = false;
let backendLog = null;

// ── helpers ──────────────────────────────────────────────────────────────────
function isAdmin() {
  if (process.platform !== 'win32') return true;
  try { cp.execFileSync('fltmc', [], { stdio: 'ignore', windowsHide: true }); return true; }
  catch { return false; }
}

function readConfig() {
  const appdata = process.env.APPDATA || path.join(require('os').homedir(), 'AppData', 'Roaming');
  const candidates = [path.join(backendDir, 'settings', 'config.json'), path.join(appdata, 'DWUT', 'settings', 'config.json')];
  for (const f of candidates) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { /* next */ }
  }
  return {};
}

function findPython() {
  const local = process.env.LOCALAPPDATA || '';
  const list = [];
  if (process.env.DWUT_PYTHON) list.push([process.env.DWUT_PYTHON, []]);
  try {   // written by bootstrap.ps1
    const recorded = fs.readFileSync(path.join(local, 'DWUT', 'python_path.txt'), 'utf8').trim();
    if (recorded) list.push([recorded, []]);
  } catch { /* none */ }
  list.push([path.join(local, 'DWUT', 'python', 'python.exe'), []]);
  list.push(['py', ['-3']]);
  list.push(['python', []]);
  list.push(['python3', []]);
  for (const [exe, pre] of list) {
    try {
      if (path.isAbsolute(exe) && !fs.existsSync(exe)) continue;
      const r = cp.spawnSync(exe, [...pre, '-c', 'import sys;print(sys.version_info[:2]>=(3,10))'],
        { encoding: 'utf8', windowsHide: true, timeout: 15000 });
      if (r.status === 0 && /True/.test(r.stdout)) return [exe, pre];
    } catch { /* next */ }
  }
  return null;
}

// ── backend ──────────────────────────────────────────────────────────────────
function startBackend() {
  const py = findPython();
  if (!py) {
    dialog.showErrorBox('Python not found',
      'DWUT needs Python 3.10 or newer.\n\nRun the DWUT bootstrap (bootstrap.ps1) or install Python from python.org, then start DWUT again.');
    app.quit();
    return false;
  }
  if (!fs.existsSync(path.join(backendDir, 'server.py'))) {
    dialog.showErrorBox('DWUT backend missing', `Could not find backend\\server.py in:\n${backendDir}\n\nRe-run bootstrap.ps1 to reinstall.`);
    app.quit();
    return false;
  }
  const [exe, pre] = py;
  const logDir = path.join(process.env.APPDATA || '.', 'DWUT', 'logs');
  try { fs.mkdirSync(logDir, { recursive: true }); backendLog = fs.createWriteStream(path.join(logDir, 'electron-backend.log'), { flags: 'a' }); } catch { /* ignore */ }

  backend = cp.spawn(exe, [...pre, '-u', path.join(backendDir, 'server.py')], {
    cwd: backendDir,
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1', PYTHONDONTWRITEBYTECODE: '1' },
  });

  backend.on('error', (err) => {
    dialog.showErrorBox('DWUT could not start its Python backend',
      `${err.message}\n\nPython: ${exe}\nBackend: ${backendDir}\n\nRe-run bootstrap.ps1 to repair the install.`);
    app.exit(1);
  });
  const rl = readline.createInterface({ input: backend.stdout, crlfDelay: Infinity });
  rl.on('line', (line) => {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.event) {
      if (msg.event === 'backend.ready') backendReady = true;
      if (win && !win.isDestroyed()) win.webContents.send('backend:event', msg.event, msg.data);
    } else if (msg.id != null) {
      const p = pending.get(msg.id);
      if (p) {
        pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error)); else p.resolve(msg.result);
      }
    }
  });
  backend.stderr.on('data', (d) => { if (backendLog) backendLog.write(d); });
  backend.on('exit', (code) => {
    backendReady = false;
    for (const [, p] of pending) p.reject(new Error('Backend stopped'));
    pending.clear();
    if (!shuttingDown && win && !win.isDestroyed()) {
      win.webContents.send('backend:event', 'backend.crashed', { code });
      // restart once so the UI keeps working
      setTimeout(() => { if (!shuttingDown) startBackend(); }, 800);
    }
  });
  return true;
}

function callBackend(method, params) {
  return new Promise((resolve, reject) => {
    if (!backend || !backend.stdin.writable) return reject(new Error('Backend not running'));
    const id = nextId++;
    pending.set(id, { resolve, reject });
    backend.stdin.write(JSON.stringify({ id, method, params: params || {} }) + '\n');
  });
}

async function stopBackend() {
  shuttingDown = true;
  if (!backend) return;
  try { backend.stdin.write(JSON.stringify({ method: 'backend.shutdown' }) + '\n'); backend.stdin.end(); } catch { /* ignore */ }
  await new Promise((r) => {
    const t = setTimeout(() => { try { backend.kill(); } catch { /* ignore */ } r(); }, 2500);
    backend.once('exit', () => { clearTimeout(t); r(); });
  });
}

// ── window ───────────────────────────────────────────────────────────────────
function createWindow() {
  const cfg = readConfig();
  const wa = screen.getPrimaryDisplay().size;           // physical-DIP screen size, like GetSystemMetrics
  let w = Math.max(parseInt(cfg.window_width || DEF_W, 10), MIN_W);
  let h = Math.max(parseInt(cfg.window_height || DEF_H, 10), MIN_H);
  w = Math.min(w, Math.max(wa.width - 40, MIN_W));
  h = Math.min(h, Math.max(wa.height - 40, MIN_H));
  const x = Math.max(Math.floor((wa.width - w) / 2), 0);
  const y = Math.max(Math.floor((wa.height - h) / 2), 0);

  win = new BrowserWindow({
    x, y, width: w, height: h, minWidth: MIN_W, minHeight: MIN_H,
    frame: false, show: false, backgroundColor: '#0D0F12',
    title: "Darko's Windows Utility Tool",
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
      spellcheck: false, backgroundThrottling: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  if (process.env.DWUT_SHOT_DIR) require('./devtools/shots.js')(win, process.env.DWUT_SHOT_DIR, app);
  win.on('maximize', () => win.webContents.send('win:state', { maximized: true }));
  win.on('unmaximize', () => win.webContents.send('win:state', { maximized: false }));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });
  win.on('closed', () => { win = null; });
}

async function gracefulClose() {
  if (!win) return app.quit();
  try {
    const page = await win.webContents.executeJavaScript('window.__currentPage || ""');
    const b = win.isMaximized() ? win.getNormalBounds() : win.getBounds();
    await Promise.race([
      callBackend('config.set', { values: { window_width: b.width, window_height: b.height, ...(page ? { start_page: page } : {}) } }),
      new Promise((r) => setTimeout(r, 800)),
    ]);
  } catch { /* ignore */ }
  await stopBackend();
  app.exit(0);
}

// ── elevation (mirrors app/permissions.py wording) ───────────────────────────
function relaunchElevated() {
  const exe = process.execPath;
  const args = runFromFolder ? [app.getAppPath()] : [];
  const argList = args.map((a) => `'${a.replace(/'/g, "''")}'`).join(',');
  const ps = `Start-Process -FilePath '${exe.replace(/'/g, "''")}' ${argList ? `-ArgumentList ${argList} ` : ''}-Verb RunAs`;
  app.releaseSingleInstanceLock();
  const r = cp.spawnSync('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true });
  if (r.status === 0) { app.exit(0); return true; }
  app.requestSingleInstanceLock();
  return false;                                         // UAC cancelled
}

function checkAndPromptAdmin() {
  if (process.env.DWUT_SKIP_ADMIN || isAdmin()) return;
  const btn = dialog.showMessageBoxSync({
    type: 'question', buttons: ['Yes', 'No'], defaultId: 0, cancelId: 1,
    title: 'Administrator Privileges Recommended',
    message: "DWUT isn't running as Administrator.\n\nMost of its features — registry tweaks, service changes, the Startup Manager, repairs, and Windows features — need admin rights to work at all.\n\nRestart as Administrator now?",
  });
  if (btn === 0) relaunchElevated();
}

// ── IPC ──────────────────────────────────────────────────────────────────────
ipcMain.handle('backend:call', (_e, method, params) => callBackend(method, params));
ipcMain.handle('backend:ready', () => backendReady);
ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:maximize', () => { if (!win) return; if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
ipcMain.on('win:close', () => gracefulClose());
ipcMain.on('win:resize', (_e, dw, dh, ow, oh) => { if (win && !win.isMaximized()) win.setSize(Math.max(MIN_W, Math.round(ow + dw)), Math.max(MIN_H, Math.round(oh + dh))); });
ipcMain.handle('win:size', () => (win ? win.getSize() : [DEF_W, DEF_H]));
ipcMain.handle('dialog:save', async (_e, opts) => {
  const r = await dialog.showSaveDialog(win, opts || {});
  return r.canceled ? null : r.filePath;
});
ipcMain.handle('dialog:open', async (_e, opts) => {
  const r = await dialog.showOpenDialog(win, opts || {});
  return r.canceled ? null : r.filePaths;
});
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
// One-click update: close DWUT, then re-run the official bootstrap (it downloads + installs the newest release and relaunches).
ipcMain.handle('app:update-now', async () => {
  const url = 'https://raw.githubusercontent.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT/main/bootstrap.ps1';
  const ps = `Start-Sleep -Seconds 3; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm '${url}' | iex`;
  const child = cp.spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: false });
  child.unref();
  setTimeout(() => gracefulClose(), 400);
  return true;
});
ipcMain.handle('app:relaunch-admin', () => relaunchElevated());

// ── lifecycle ────────────────────────────────────────────────────────────────
if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.setAppUserModelId('tool.darko.dwut');
  app.whenReady().then(() => {
    checkAndPromptAdmin();
    if (!startBackend()) return;
    createWindow();
  });
  app.on('window-all-closed', () => { gracefulClose(); });
  app.on('before-quit', () => { shuttingDown = true; });
}

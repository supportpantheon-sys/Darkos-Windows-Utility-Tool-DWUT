'use strict';
/**
 * DWUT — Electron main process v6.0
 *  - supervises the Python backend (untouched modules/) over stdin/stdout JSON lines
 *  - offers to relaunch as Administrator (same wording as the original app)
 *  - frameless window: custom title bar lives in the renderer
 *  - system tray: closing the window hides it (Discord-style); tray icon with context menu
 *  - creates a startup shortcut on first run so DWUT launches with Windows
 */
const { app, BrowserWindow, ipcMain, dialog, shell, screen, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');
const readline = require('readline');
const os = require('os');

const MIN_W = 900, MIN_H = 580, DEF_W = 960, DEF_H = 620;
const localBackend = path.join(__dirname, 'backend');
const bundledBackend = path.join(process.resourcesPath || '', 'backend');
const runFromFolder = fs.existsSync(path.join(localBackend, 'server.py'));
const backendDir = runFromFolder ? localBackend : bundledBackend;

let win = null;
let tmWin = null;   // Task Manager window
let tray = null;
let backend = null;
let backendReady = false;
let nextId = 1;
const pending = new Map();
let shuttingDown = false;
let backendLog = null;
let isQuitting = false;   // set to true only when the user picks "Exit" from tray
let _vpnConnected = false;
let _fpsUnlockActive = false;
let _fpsGameName = 'Auto-Detect';  // updated dynamically from detected running game

// ── helpers ──────────────────────────────────────────────────────────────────
function isAdmin() {
  if (process.platform !== 'win32') return true;
  try { cp.execFileSync('fltmc', [], { stdio: 'ignore', windowsHide: true }); return true; }
  catch { return false; }
}

function readConfig() {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const candidates = [path.join(backendDir, 'settings', 'config.json'), path.join(appdata, 'DWUT', 'settings', 'config.json')];
  for (const f of candidates) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { /* next */ }
  }
  return {};
}

function findPython() {
  const local = process.env.LOCALAPPDATA || '';
  const list = [];
  if (process.env.DWUT_PYTHON) list.push([process.env.DWUT_PYTHON, []]);
  try {
    const recorded = fs.readFileSync(path.join(local, 'DWUT', 'python_path.txt'), 'utf8').trim();
    if (recorded) list.push([recorded, []]);
  } catch { /* none */ }
  list.push([path.join(local, 'DWUT', 'python', 'python.exe'), []]);
  list.push(['py', ['-3']]);
  list.push(['python', []]);
  list.push(['python3', []]);
  for (const [exe, pre] of list) {
    try {
      if (path.isAbsolute(exe) && !fs.existsSync(exe)) continue;
      const r = cp.spawnSync(exe, [...pre, '-c', 'import sys;print(sys.version_info[:2]>=(3,10))'],
        { encoding: 'utf8', windowsHide: true, timeout: 15000 });
      if (r.status === 0 && /True/.test(r.stdout)) return [exe, pre];
    } catch { /* next */ }
  }
  return null;
}

// ── startup shortcut ─────────────────────────────────────────────────────────
function ensureStartupShortcut() {
  if (process.platform !== 'win32') return;
  try {
    const startupDir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
    const shortcutPath = path.join(startupDir, 'DWUT.lnk');
    const markerPath = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'DWUT', 'startup_shortcut_created.txt');

    // Only create once per installation
    if (fs.existsSync(markerPath)) return;

    fs.mkdirSync(path.dirname(markerPath), { recursive: true });

    const exePath = process.execPath;
    const appPath = runFromFolder ? app.getAppPath() : '';
    const args = appPath ? `"${appPath}"` : '';

    const ps = `
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("${shortcutPath.replace(/\\/g, '\\\\')}")
$Shortcut.TargetPath = "${exePath.replace(/\\/g, '\\\\')}"
${args ? `$Shortcut.Arguments = "${args.replace(/"/g, '\\"')}"` : ''}
$Shortcut.WorkingDirectory = "${path.dirname(exePath).replace(/\\/g, '\\\\')}"
$Shortcut.Description = "Darko's Windows Utility Tool"
$Shortcut.Save()
`;
    cp.spawnSync('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true });
    fs.writeFileSync(markerPath, new Date().toISOString());
  } catch (e) {
    console.error('Failed to create startup shortcut:', e.message);
  }
}

// ── backend ──────────────────────────────────────────────────────────────────
function startBackend() {
  const py = findPython();
  if (!py) {
    dialog.showErrorBox('Python not found',
      'DWUT needs Python 3.10 or newer.\n\nRun the DWUT bootstrap (bootstrap.ps1) or install Python from python.org, then start DWUT again.');
    app.quit();
    return false;
  }
  if (!fs.existsSync(path.join(backendDir, 'server.py'))) {
    dialog.showErrorBox('DWUT backend missing', `Could not find backend\\server.py in:\n${backendDir}\n\nRe-run bootstrap.ps1 to reinstall.`);
    app.quit();
    return false;
  }
  const [exe, pre] = py;
  const logDir = path.join(process.env.APPDATA || '.', 'DWUT', 'logs');
  try { fs.mkdirSync(logDir, { recursive: true }); backendLog = fs.createWriteStream(path.join(logDir, 'electron-backend.log'), { flags: 'a' }); } catch { /* ignore */ }

  backend = cp.spawn(exe, [...pre, '-u', path.join(backendDir, 'server.py')], {
    cwd: backendDir,
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1', PYTHONDONTWRITEBYTECODE: '1' },
  });

  backend.on('error', (err) => {
    dialog.showErrorBox('DWUT could not start its Python backend',
      `${err.message}\n\nPython: ${exe}\nBackend: ${backendDir}\n\nRe-run bootstrap.ps1 to repair the install.`);
    app.exit(1);
  });
  const rl = readline.createInterface({ input: backend.stdout, crlfDelay: Infinity });
  rl.on('line', (line) => {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.event) {
      if (msg.event === 'backend.ready') {
        backendReady = true;
        // Auto-connect VPN on startup if configured
        callBackend('vpn.autostart_get', {}).then((enabled) => {
          if (enabled) {
            setTimeout(() => {
              callBackend('vpn.connect', { region: 'Any' }).catch(() => {});
            }, 2000);
          }
        }).catch(() => {});
      }
      // Update tray menu when VPN state changes
      if (msg.event === 'vpn.state' && msg.data) {
        updateTrayVpnState(msg.data);
      }
      // Update tray menu when FPS unlock state changes
      if (msg.event === 'gaming.fps_status' && msg.data) {
        _fpsUnlockActive = !!msg.data.active;
        if (msg.data.game_name) _fpsGameName = msg.data.game_name;
        rebuildTrayMenu();
      }
      if (win && !win.isDestroyed()) win.webContents.send('backend:event', msg.event, msg.data);
    } else if (msg.id != null) {
      const p = pending.get(msg.id);
      if (p) {
        pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error)); else p.resolve(msg.result);
      }
    }
  });
  backend.stderr.on('data', (d) => { if (backendLog) backendLog.write(d); });
  backend.on('exit', (code) => {
    backendReady = false;
    for (const [, p] of pending) p.reject(new Error('Backend stopped'));
    pending.clear();
    if (!shuttingDown && win && !win.isDestroyed()) {
      win.webContents.send('backend:event', 'backend.crashed', { code });
      setTimeout(() => { if (!shuttingDown) startBackend(); }, 800);
    }
  });
  return true;
}

function callBackend(method, params) {
  return new Promise((resolve, reject) => {
    if (!backend || !backend.stdin.writable) return reject(new Error('Backend not running'));
    const id = nextId++;
    pending.set(id, { resolve, reject });
    backend.stdin.write(JSON.stringify({ id, method, params: params || {} }) + '\n');
  });
}

async function stopBackend() {
  shuttingDown = true;
  if (!backend) return;
  try { backend.stdin.write(JSON.stringify({ method: 'backend.shutdown' }) + '\n'); backend.stdin.end(); } catch { /* ignore */ }
  await new Promise((r) => {
    const t = setTimeout(() => { try { backend.kill(); } catch { /* ignore */ } r(); }, 2500);
    backend.once('exit', () => { clearTimeout(t); r(); });
  });
}

// ── tray ─────────────────────────────────────────────────────────────────────

function updateTrayVpnState(vpnState) {
  _vpnConnected = !!(vpnState && vpnState.on);
  if (tray) rebuildTrayMenu();
}

function rebuildTrayMenu() {
  if (!tray) return;
  const vpnLabel = _vpnConnected ? 'Disconnect VPN' : 'Connect VPN';
  const fpsLabel = _fpsUnlockActive
    ? `Disable FPS Unlock (${_fpsGameName})`
    : `Enable FPS Unlock (${_fpsGameName})`;
  const menu = Menu.buildFromTemplate([
    {
      label: 'Open DWUT',
      click: () => showWindow(),
    },
    {
      label: 'Task Manager',
      click: () => openTaskManager(),
    },
    { type: 'separator' },
    {
      label: vpnLabel,
      click: async () => {
        if (_vpnConnected) {
          await callBackend('vpn.disconnect', {}).catch(() => {});
        } else {
          await callBackend('vpn.connect', { opts: { region: 'Any' } }).catch(() => {});
        }
      },
    },
    { type: 'separator' },
    {
      label: 'Quick Optimize',
      click: async () => {
        try {
          await callBackend('system.quick_optimize', {});
        } catch (e) {
          console.error('Quick optimize failed:', e.message);
        }
      },
    },
    {
      label: 'Quick Game Boost',
      click: async () => {
        try {
          await callBackend('gaming.boost_apply', { game_name: '', only: null });
        } catch (e) {
          console.error('Quick game boost failed:', e.message);
        }
      },
    },
    {
      label: fpsLabel,
      click: async () => {
        try {
          const result = await callBackend('gaming.fps_toggle', {});
          if (result) {
            _fpsUnlockActive = !!result.active;
            if (result.game_name) _fpsGameName = result.game_name;
            rebuildTrayMenu();
          }
        } catch (e) {
          console.error('FPS toggle failed:', e.message);
        }
      },
    },
    {
      label: 'Network Monitor',
      click: () => { showWindow(); if (win) win.webContents.executeJavaScript('Nav.go("network")').catch(()=>{}); },
    },
    { type: 'separator' },
    {
      label: 'Exit',
      click: () => {
        isQuitting = true;
        gracefulClose();
      },
    },
  ]);
  tray.setContextMenu(menu);
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createTray() {
  const iconPath = path.join(__dirname, 'renderer', 'icon.png');
  let icon;
  try {
    icon = nativeImage.createFromPath(iconPath);
    if (icon.isEmpty()) {
      // create a simple 16x16 icon from scratch if file not found
      icon = nativeImage.createEmpty();
    }
  } catch {
    icon = nativeImage.createEmpty();
  }

  tray = new Tray(icon);
  tray.setToolTip("Darko's Windows Utility Tool");
  rebuildTrayMenu();

  // Periodically update detected game in background so tray menu is always accurate
  setInterval(async () => {
    try {
      const g = await callBackend('gaming.detected_game', {});
      if (g && g.game_name && g.game_name !== _fpsGameName) {
        _fpsGameName = g.game_name;
        _fpsUnlockActive = !!g.active;
        rebuildTrayMenu();
      }
    } catch {}
  }, 5000);

  tray.on('double-click', () => showWindow());
  tray.on('click', () => showWindow());
  tray.on('right-click', async () => {
    try {
      const g = await callBackend('gaming.detected_game', {});
      if (g && g.game_name) {
        _fpsGameName = g.game_name;
        _fpsUnlockActive = !!g.active;
        rebuildTrayMenu();
      }
    } catch {}
  });
}

// ── window ───────────────────────────────────────────────────────────────────
function createWindow() {
  const cfg = readConfig();
  const wa = screen.getPrimaryDisplay().size;
  let w = Math.max(parseInt(cfg.window_width || DEF_W, 10), MIN_W);
  let h = Math.max(parseInt(cfg.window_height || DEF_H, 10), MIN_H);
  w = Math.min(w, Math.max(wa.width - 40, MIN_W));
  h = Math.min(h, Math.max(wa.height - 40, MIN_H));
  const x = Math.max(Math.floor((wa.width - w) / 2), 0);
  const y = Math.max(Math.floor((wa.height - h) / 2), 0);

  win = new BrowserWindow({
    x, y, width: w, height: h, minWidth: MIN_W, minHeight: MIN_H,
    frame: false, show: false, backgroundColor: '#0D0F12',
    title: "Darko's Windows Utility Tool",
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
      spellcheck: false, backgroundThrottling: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  if (process.env.DWUT_SHOT_DIR) require('./devtools/shots.js')(win, process.env.DWUT_SHOT_DIR, app);
  win.on('maximize', () => win.webContents.send('win:state', { maximized: true }));
  win.on('unmaximize', () => win.webContents.send('win:state', { maximized: false }));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });

  // Intercept close: hide to tray instead of closing
  win.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      win.hide();
      // Show a balloon notification on first hide (Windows only)
      try {
        if (tray && process.platform === 'win32') {
          tray.displayBalloon({
            iconType: 'info',
            title: 'DWUT is still running',
            content: 'DWUT is minimized to the system tray. Right-click the icon to access options or exit.',
          });
        }
      } catch { /* ignore, older Electron or non-Windows */ }
    }
  });

  win.on('closed', () => { win = null; });
}

async function gracefulClose() {
  isQuitting = true;
  if (!win) return app.quit();
  try {
    const page = await win.webContents.executeJavaScript('window.__currentPage || ""');
    const b = win.isMaximized() ? win.getNormalBounds() : win.getBounds();
    await Promise.race([
      callBackend('config.set', { values: { window_width: b.width, window_height: b.height, ...(page ? { start_page: page } : {}) } }),
      new Promise((r) => setTimeout(r, 800)),
    ]);
  } catch { /* ignore */ }
  await stopBackend();
  if (tray) { tray.destroy(); tray = null; }
  app.exit(0);
}

// ── elevation ─────────────────────────────────────────────────────────────────
function relaunchElevated() {
  const exe = process.execPath;
  const args = runFromFolder ? [app.getAppPath()] : [];
  const argList = args.map((a) => `'${a.replace(/'/g, "''")}'`).join(',');
  const ps = `Start-Process -FilePath '${exe.replace(/'/g, "''")}' ${argList ? `-ArgumentList ${argList} ` : ''}-Verb RunAs`;
  app.releaseSingleInstanceLock();
  const r = cp.spawnSync('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true });
  if (r.status === 0) { app.exit(0); return true; }
  app.requestSingleInstanceLock();
  return false;
}

function checkAndPromptAdmin() {
  if (process.env.DWUT_SKIP_ADMIN || isAdmin()) return;
  const btn = dialog.showMessageBoxSync({
    type: 'question', buttons: ['Yes', 'No'], defaultId: 0, cancelId: 1,
    title: 'Administrator Privileges Recommended',
    message: "DWUT isn't running as Administrator.\n\nMost of its features — registry tweaks, service changes, the Startup Manager, repairs, and Windows features — need admin rights to work at all.\n\nRestart as Administrator now?",
  });
  if (btn === 0) relaunchElevated();
}

// ── IPC ───────────────────────────────────────────────────────────────────────
ipcMain.handle('backend:call', (_e, method, params) => callBackend(method, params));
ipcMain.handle('backend:ready', () => backendReady);
// Task manager uses nodeIntegration — route via ipcMain.on
ipcMain.on('backend:call', (event, id, method, params) => {
  callBackend(method, params || {})
    .then(r => { try { event.sender.send('backend:result', id, r); } catch {} })
    .catch(e => { try { event.sender.send('backend:error', id, String(e.message || e)); } catch {} });
});
ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:maximize', () => { if (!win) return; if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
ipcMain.on('win:close', () => {
  // X button: hide to tray (same as clicking the window X)
  if (!isQuitting && win) { win.hide(); }
});
ipcMain.on('win:resize', (_e, dw, dh, ow, oh) => { if (win && !win.isMaximized()) win.setSize(Math.max(MIN_W, Math.round(ow + dw)), Math.max(MIN_H, Math.round(oh + dh))); });
ipcMain.handle('win:size', () => (win ? win.getSize() : [DEF_W, DEF_H]));
ipcMain.handle('dialog:save', async (_e, opts) => {
  const r = await dialog.showSaveDialog(win, opts || {});
  return r.canceled ? null : r.filePath;
});
ipcMain.handle('dialog:open', async (_e, opts) => {
  const r = await dialog.showOpenDialog(win, opts || {});
  return r.canceled ? null : r.filePaths;
});
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
ipcMain.handle('app:update-now', async () => {
  const url = 'https://raw.githubusercontent.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT/main/bootstrap.ps1';
  const ps = `Start-Sleep -Seconds 3; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm '${url}' | iex`;
  const child = cp.spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: false });
  child.unref();
  setTimeout(() => { isQuitting = true; gracefulClose(); }, 400);
  return true;
});
ipcMain.handle('app:relaunch-admin', () => relaunchElevated());

// ── Task Manager window ───────────────────────────────────────────────────────
function openTaskManager() {
  if (tmWin && !tmWin.isDestroyed()) {
    tmWin.show(); tmWin.focus(); return;
  }
  const { width: sw, height: sh } = screen.getPrimaryDisplay().size;
  tmWin = new BrowserWindow({
    width: Math.min(1280, sw - 40), height: Math.min(880, sh - 40),
    minWidth: 1100, minHeight: 640,
    resizable: true,
    title: 'DWUT Task Manager',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    frame: false,
    backgroundColor: '#0d0d0f',
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });
  tmWin.setMenuBarVisibility(false);
  tmWin.loadFile(path.join(__dirname, 'renderer', 'taskmanager.html'));
  tmWin.once('ready-to-show', () => tmWin.show());
  tmWin.on('maximize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.webContents.send('tm:max-state', true); });
  tmWin.on('unmaximize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.webContents.send('tm:max-state', false); });
  tmWin.on('closed', () => { tmWin = null; });
  // Forward backend calls from task manager window
  tmWin.webContents.on('ipc-message', () => {});
}

ipcMain.on('tm:open', () => openTaskManager());
ipcMain.on('tm:shell-open', (_e, folderPath) => { try { shell.openPath(folderPath); } catch {} });
ipcMain.on('tm:close',    () => { if (tmWin && !tmWin.isDestroyed()) tmWin.close(); });
ipcMain.on('tm:minimize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.minimize(); });
ipcMain.on('tm:maximize', () => { if (tmWin && !tmWin.isDestroyed()) { if (tmWin.isMaximized()) tmWin.unmaximize(); else tmWin.maximize(); } });
ipcMain.handle('tm:get-bounds', () => {
  if (tmWin && !tmWin.isDestroyed()) return tmWin.getBounds();
  return null;
});
ipcMain.on('tm:set-bounds', (_e, bounds) => {
  if (tmWin && !tmWin.isDestroyed() && !tmWin.isMaximized()) {
    const cur = tmWin.getBounds();
    const b = { ...cur, ...bounds };
    b.width = Math.max(700, Math.round(b.width));
    b.height = Math.max(460, Math.round(b.height));
    tmWin.setBounds(b);
  }
});

// Theme sync — main window pushes theme name + CSS vars whenever theme changes
ipcMain.on('tm:theme-push', (_e, themeData) => {
  _lastThemeData = themeData;
  if (tmWin && !tmWin.isDestroyed()) {
    tmWin.webContents.send('tm:theme', themeData);
  }
});
// TM window requests current theme on startup
ipcMain.handle('tm:theme-get', () => _lastThemeData || null);

let _lastThemeData = null;

// Native Windows File Icon extraction (100% authentic shell icons for processes)
const _fileIconCache = new Map();

async function _fetchNativeIcon(filePath) {
  if (!filePath || typeof filePath !== 'string') return '';
  if (_fileIconCache.has(filePath)) return _fileIconCache.get(filePath);

  const sysRoot = process.env.SystemRoot || 'C:\\Windows';
  const base = path.basename(filePath);
  const exeBase = base.toLowerCase().endsWith('.exe') ? base : (base + '.exe');
  const candidates = [
    filePath,
    path.join(sysRoot, 'System32', base),
    path.join(sysRoot, 'System32', exeBase),
    path.join(sysRoot, base),
    path.join(sysRoot, exeBase),
    path.join(sysRoot, 'SysWOW64', base),
    path.join(sysRoot, 'SysWOW64', exeBase),
    path.join(sysRoot, 'explorer.exe'),
    path.join(sysRoot, 'System32', 'imageres.dll')
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      try {
        const icon = await app.getFileIcon(candidate, { size: 'small' });
        const dataUrl = icon.toDataURL();
        if (dataUrl && dataUrl.length > 50) {
          _fileIconCache.set(filePath, dataUrl);
          return dataUrl;
        }
      } catch {}
    }
  }

  // Final fallback attempt with getFileIcon directly on filePath or base
  try {
    const icon = await app.getFileIcon(filePath, { size: 'small' });
    const dataUrl = icon.toDataURL();
    _fileIconCache.set(filePath, dataUrl);
    return dataUrl;
  } catch {
    _fileIconCache.set(filePath, '');
    return '';
  }
}

ipcMain.handle('tm:get-file-icon', async (_e, filePath) => {
  return _fetchNativeIcon(filePath);
});

ipcMain.handle('tm:get-file-icons-batch', async (_e, paths) => {
  if (!Array.isArray(paths)) return {};
  const results = {};
  for (const p of paths) {
    if (!p) continue;
    results[p] = await _fetchNativeIcon(p);
  }
  return results;
});

// ── first-run startup prompt ──────────────────────────────────────────────────
function promptStartupOnFirstRun() {
  const local = process.env.LOCALAPPDATA || os.tmpdir();
  const markerPath = path.join(local, 'DWUT', 'first_run_done.txt');
  if (fs.existsSync(markerPath)) return;   // already ran once
  // Wait for window to be visible
  const doPrompt = () => {
    const btn = dialog.showMessageBoxSync(win, {
      type: 'question',
      buttons: ['Yes — Start with Windows', 'No thanks'],
      defaultId: 0,
      cancelId: 1,
      title: 'Launch DWUT with Windows?',
      message: "Welcome to DWUT 6!\n\nWould you like DWUT to start automatically when Windows boots?\n\nThis creates a startup shortcut so the app is always ready in the system tray.\nYou can change this anytime in Settings.",
      icon: path.join(__dirname, 'renderer', 'icon.png'),
    });
    try {
      fs.mkdirSync(path.dirname(markerPath), { recursive: true });
      fs.writeFileSync(markerPath, new Date().toISOString());
    } catch { /* ignore */ }
    if (btn === 0) {
      ensureStartupShortcut();
    } else {
      // User said no — delete any shortcut that may have been created earlier
      try {
        const startupDir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
        const shortcutPath = path.join(startupDir, 'DWUT.lnk');
        if (fs.existsSync(shortcutPath)) fs.unlinkSync(shortcutPath);
      } catch { /* ignore */ }
    }
  };
  if (win && win.isVisible()) {
    setTimeout(doPrompt, 800);
  } else {
    win && win.once('show', () => setTimeout(doPrompt, 800));
  }
}

// ── lifecycle ─────────────────────────────────────────────────────────────────
if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.setAppUserModelId('tool.darko.dwut');
  app.whenReady().then(() => {
    checkAndPromptAdmin();
    if (!startBackend()) return;
    createTray();
    createWindow();
    ensureStartupShortcut();
    // First-run: ask about startup after window is shown
    promptStartupOnFirstRun();
  });
  // Prevent default quit on all-windows-closed; tray keeps the app alive
  app.on('window-all-closed', () => {
    // Only quit if user explicitly chose Exit from tray
    if (isQuitting) gracefulClose();
    // Never auto-quit — task manager or other sub-windows closing must not kill the app
  });
  app.on('before-quit', () => { isQuitting = true; shuttingDown = true; });
  app.on('activate', () => { if (win) showWindow(); });
}

// Dev-only: DWUT_SHOT_DIR=/tmp/out electron .   -> saves a PNG of every page, then exits.
const fs = require('fs'), path = require('path');
module.exports = (win, dir, app) => {
  fs.mkdirSync(dir, { recursive: true });
  const pages = (process.env.DWUT_SHOT_PAGES || 'dashboard,optimizer,gaming,debloat,proxy,tools,cleaner,settings').split(',');
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  win.webContents.on('console-message', (_e, lvl, msg, line, src) => { if (lvl >= 2) console.log('[renderer error]', msg, src + ':' + line); });
  win.webContents.on('did-finish-load', async () => {
    await wait(1500);
    await win.webContents.executeJavaScript('document.body.dataset.t=1');
    await wait(3600); // splash
    for (const p of pages) {
      await win.webContents.executeJavaScript(`Nav.go('${p}')`);
      await wait(+process.env.DWUT_SHOT_WAIT || 2500);
      const img = await win.webContents.capturePage();
      fs.writeFileSync(path.join(dir, p + '.png'), img.toPNG());
      console.log('shot', p);
    }
    const extra = process.env.DWUT_SHOT_JS;
    if (extra) { try { const out = await win.webContents.executeJavaScript(extra); console.log('js ->', out); await wait(2500); fs.writeFileSync(path.join(dir, 'after.png'), (await win.webContents.capturePage()).toPNG()); } catch (e) { console.log('js err', e.message); } }
    app.exit(0);
  });
};

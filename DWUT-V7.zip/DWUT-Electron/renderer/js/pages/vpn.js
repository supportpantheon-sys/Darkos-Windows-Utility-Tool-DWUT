'use strict';
/* VPN page - DWUTVPN: free, no account (Cloudflare WARP). Connect + protection options. */
Pages.register('vpn', () => {
  if (!document.getElementById('vp-style')) {
    document.head.append(h('style', { id: 'vp-style', text: `
      .vp-grid{display:grid;grid-template-columns:minmax(300px,360px) minmax(0,1fr);gap:14px;align-items:start}
      @media (max-width:980px){.vp-grid{grid-template-columns:minmax(0,1fr)}}
      .vp-panel{padding:16px;display:flex;flex-direction:column;gap:12px;min-width:0}
      .vp-h{font-size:calc(11px*var(--fs));font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--text_secondary)}
      .vp-badge{width:132px;height:152px;display:block;margin:0 auto}
      .vp-badge .shell{fill:var(--bg_input);stroke:var(--border);stroke-width:2;transition:all .25s}
      .vp-badge .lock{fill:none;stroke:var(--text_disabled);stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round;transition:stroke .25s}
      .vp-badge .lockbody{fill:var(--text_disabled);transition:fill .25s}
      .vp-badge .lbl{fill:var(--text_disabled);font-weight:800;font-size:13px;letter-spacing:4px;text-anchor:middle;transition:fill .25s}
      .vp-badge .ring{fill:none;stroke:var(--accent);stroke-width:3;stroke-linecap:round;opacity:0}
      .vp-on .shell{fill:var(--accent_subtle);stroke:var(--accent)}
      .vp-on .lock{stroke:var(--accent)}.vp-on .lockbody{fill:var(--accent)}.vp-on .lbl{fill:var(--accent)}
      .vp-wait .ring{opacity:1;stroke-dasharray:70 330;animation:vpspin 1.3s linear infinite}
      .vp-wait .shell{stroke:var(--accent_dim)}
      @keyframes vpspin{to{stroke-dashoffset:-400}}
      .vp-kv{display:grid;grid-template-columns:auto 1fr;gap:7px 14px;font-size:calc(12px*var(--fs))}
      .vp-kv span:nth-child(odd){color:var(--text_secondary)}
      .vp-kv span:nth-child(even){color:var(--text_primary);font-weight:600;text-align:right;overflow-wrap:anywhere}
      .vp-opt{display:flex;align-items:center;gap:12px;padding:11px 13px;border-radius:8px;background:var(--bg_input);min-width:0}
      .vp-opt .t{flex:1;min-width:0}.vp-opt .t b{display:block;font-size:calc(12px*var(--fs))}
      .vp-opt .t span{display:block;font-size:calc(10.5px*var(--fs));color:var(--text_secondary);margin-top:2px;line-height:1.35}
      .vp-opts{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:8px}
      .vp-note{font-size:calc(11px*var(--fs));color:var(--text_secondary);line-height:1.45;border-left:2px solid var(--accent);padding:2px 0 2px 10px}
      .vp-dirty{display:none;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;background:var(--accent_subtle);border:1px solid var(--accent_dim);font-size:calc(11.5px*var(--fs))}
      .vp-dirty.show{display:flex}
    ` }));
  }

  // ── status badge: a shield (not a circle) with a lock that closes when protected ──
  const SVGNS = 'http://www.w3.org/2000/svg';
  const badge = h('div', { class: 'vp-off' });
  badge.innerHTML = `<svg class="vp-badge" viewBox="0 0 120 140" xmlns="${SVGNS}">
      <path class="shell" d="M60 6 L108 22 V70 C108 98 88 120 60 134 C32 120 12 98 12 70 V22 Z"/>
      <path class="ring"  d="M60 6 L108 22 V70 C108 98 88 120 60 134 C32 120 12 98 12 70 V22 Z"/>
      <rect class="lockbody" x="44" y="58" width="32" height="26" rx="5"/>
      <path class="lock shackle" d="M50 58 V50 a10 10 0 0 1 20 0 V58"/>
      <text class="lbl" x="60" y="108">OFF</text></svg>`;
  const shackle = badge.querySelector('.shackle'), lbl = badge.querySelector('.lbl');
  const setBadge = (mode) => {                      // 'off' | 'wait' | 'on'
    badge.className = mode === 'on' ? 'vp-on' : mode === 'wait' ? 'vp-wait' : 'vp-off';
    shackle.setAttribute('d', mode === 'on' ? 'M50 58 V50 a10 10 0 0 1 20 0 V58' : 'M50 58 V50 a10 10 0 0 1 19.5 -3 V48');
    lbl.textContent = mode === 'on' ? 'ON' : mode === 'wait' ? '···' : 'OFF';
  };
  setBadge('off');

  let S = { on: false, busy: false, status: 'off', opts: {} };
  let dirty = false, tick = null;

  const title = h('div', { class: 'f16 b', style: 'text-align:center' });
  const sub = h('div', { class: 'f11 ts', style: 'text-align:center;min-height:30px;overflow-wrap:anywhere' });
  const bar = Progress({ height: 4 });
  const msg = h('div', { class: 'f10 ts', style: 'text-align:center;min-height:14px' });
  const big = Btn('Connect', { h: 40, f: 13, bold: true, onclick: () => toggleConn() });
  const ipBtn = Btn('Check my IP', { variant: 'ghost', h: 32, f: 11, onclick: checkIp });
  big.style.width = ipBtn.style.width = '100%';
  const kv = {};
  const kvBox = h('div', { class: 'vp-kv' });
  [['ip', 'IP address'], ['loc', 'Exit'], ['proto', 'Protocol'], ['up', 'Connected for']].forEach(([k, l]) => {
    kv[k] = h('span', { text: '—' }); kvBox.append(h('span', { text: l }), kv[k]);
  });
  const notes = h('div', { class: 'vp-note', style: 'display:none;white-space:pre-line' });
  const left = Card(h('div', { class: 'vp-panel' },
    h('div', { class: 'vp-h', text: 'Status' }), badge, title, sub, bar, msg, big, ipBtn,
    h('div', { style: 'height:1px;background:var(--border)' }), kvBox, notes), 'col');

  // ── protection options ──
  const dirtyBar = h('div', { class: 'vp-dirty' }, h('span', { class: 'grow', text: 'These changes apply the next time you connect.' }),
    Btn('Reconnect now', { h: 26, f: 11, onclick: async () => { dirty = false; paintDirty(); await rpc('vpn.reconnect'); } }));
  const paintDirty = () => dirtyBar.classList.toggle('show', dirty && S.on);
  const OPTS = [
    ['kill_switch', 'Kill Switch', 'Blocks all internet traffic outside the VPN, so nothing leaks if the connection drops.'],
    ['dns_protect', 'DNS Leak Protection', 'Sends every DNS lookup through the tunnel using Cloudflare\u2019s private DNS servers.'],
    ['ipv6_block', 'Block IPv6 Leaks', 'Stops IPv6 traffic from bypassing the tunnel and exposing your real address.'],
    ['browser_protect', 'Browser Protection', 'Chrome, Edge and Brave: stops WebRTC and QUIC from revealing your real IP (restart the browser).'],
    ['auto_reconnect', 'Auto-Reconnect', 'Brings the VPN back up on its own if the connection drops.'],
  ];
  const optSw = {};
  const optBox = h('div', { class: 'vp-opts' });
  OPTS.forEach(([k, name, desc]) => {
    optSw[k] = Switch({ checked: true, onchange: async (v) => {
      S.opts[k] = v; dirty = S.on; paintDirty();
      try { await rpc('vpn.set_opts', { opts: { [k]: v } }); } catch (e) { fail('VPN', e.message); }
    } });
    optBox.append(h('div', { class: 'vp-opt' }, h('div', { class: 't' }, h('b', { text: name }), h('span', { text: desc })), optSw[k]));
  });
  const autoSw = Switch({ checked: false, onchange: onAutostart });
  optBox.append(h('div', { class: 'vp-opt' }, h('div', { class: 't' }, h('b', { text: 'Connect when DWUT starts' }), h('span', { text: 'Reconnects automatically every time DWUT opens. Remembered between restarts.' })), autoSw));
  const panicBtn = Btn('Restore internet (panic)', { variant: 'danger', h: 32, f: 11, onclick: async () => {
    if (await Modal.confirm('Restore internet', 'This removes the VPN tunnel, firewall rules and browser rules right now.\n\nUse it if your internet stops working.', { yes: 'Restore', danger: true })) { await rpc('vpn.panic'); }
  } });
  const right = Card(h('div', { class: 'vp-panel' },
    h('div', { class: 'row' }, h('div', { class: 'vp-h grow', text: 'Privacy & security' }), panicBtn), dirtyBar, optBox,
    h('div', { class: 'vp-note', text: 'DWUTVPN is completely free and needs no account. It encrypts your traffic (public Wi-Fi, ISP snooping) using Cloudflare WARP. Cloudflare picks the exit near you, so it does not change your location.' })), 'col');

  async function onAutostart(v) {
    await rpc('vpn.autostart_set', { on: v });
    if (!v) return;
    let st = { registered: false, enabled: false };
    try { st = await rpc('vpn.startup_status'); } catch { /* fall through */ }
    let has = st.registered && st.enabled;
    if (!has && window.dwut.hasStartup) { try { has = await window.dwut.hasStartup(); } catch { /* ignore */ } }
    if (has) return;
    if (st.registered && !st.enabled) {
      if (await Modal.confirm('DWUT is set not to start', 'DWUT is in your Windows startup list but turned off, so the VPN could not connect at boot.\n\nTurn it back on?', { yes: 'Turn on', no: 'Not now' })) {
        const ok = await rpc('vpn.startup_enable_existing');
        if (!ok) notify('Startup', 'Could not turn it on. Enable DWUT in Task Manager > Startup apps.');
      }
      return;
    }
    if (await Modal.confirm('Start DWUT with Windows?', 'Auto-connect only works while DWUT is open, and DWUT is not set to start with Windows yet.\n\nAdd DWUT to Windows startup so the VPN connects as soon as you sign in?', { yes: 'Add it', no: 'Not now' })) {
      try { const ok = await window.dwut.addToStartup(); notify('Startup', ok ? 'DWUT will now start with Windows.' : 'Could not add DWUT to startup.'); }
      catch (e) { fail('Startup', e.message); }
    }
  }

  async function toggleConn() {
    if (S.busy) return;
    try { await rpc(S.on ? 'vpn.disconnect' : 'vpn.connect', {}); } catch (e) { fail('VPN', e.message); }
  }
  async function checkIp() {
    ipBtn.disabled = true;
    try {
      const i = await rpc('vpn.check_ip');
      const where = [i.city, i.country || i.cc].filter(Boolean).join(', ') || 'unknown';
      notify('Your public IP', `${i.ip || 'unknown'}\n${where}\n\n` + (S.on ? 'This is what websites see while the VPN is on.' : 'The VPN is off - this is your real address.'));
    } catch (e) { fail('Check IP', e.message); }
    ipBtn.disabled = false;
  }
  const upt = (t) => { const s = Math.max(0, Math.floor(Date.now() / 1000 - t)); return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map((n) => String(n).padStart(2, '0')).join(':'); };

  function apply(s) {
    S = { ...S, ...s };
    const on = !!s.on, wait = !!s.busy || s.status === 'reconnecting';
    setBadge(on && !wait ? 'on' : wait ? 'wait' : 'off');
    title.textContent = wait ? (s.status === 'reconnecting' ? 'Reconnecting…' : on ? 'Updating…' : 'Connecting…') : on ? 'Protected' : s.status === 'degraded' ? 'Connection lost' : 'Not protected';
    sub.textContent = on ? 'Your traffic is encrypted' + (s.ip ? '  ·  ' + s.ip : '') : 'Your traffic is not going through the VPN.';
    big.textContent = on ? 'Disconnect' : wait ? 'Connecting…' : 'Connect';
    big.className = 'btn ' + (on ? 'btn-ghost' : 'btn-primary');
    big.disabled = wait && !on;
    kv.ip.textContent = on ? (s.ip || '…') : '—';
    kv.loc.textContent = on ? ([s.city, s.country].filter(Boolean).join(', ') || 'Cloudflare WARP') : '—';
    kv.proto.textContent = on ? 'DWUT Tunnel' : '—';
    kv.up.textContent = on ? upt(s.since) : '—';
    const n = (s.notes || []).filter(Boolean);
    notes.textContent = n.join('\n'); notes.style.display = n.length ? '' : 'none';
    Object.entries(optSw).forEach(([k, sw]) => { if (s.opts && k in s.opts) sw.set(s.opts[k], true); });
    paintDirty();
    clearInterval(tick);
    if (on) tick = setInterval(() => { kv.up.textContent = upt(s.since); }, 1000);
    if (!wait) { bar.set(on ? 1 : 0); msg.textContent = ''; }
  }

  on('vpn.state', apply);
  on('vpn.progress', (d) => { msg.textContent = d.msg || ''; if (d.pct != null) bar.set(d.pct); });

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'VPN' }), h('div', { class: 'grow' }), h('span', { class: 'f11 ts', text: 'DWUTVPN · free' })),
    h('div', { class: 'scroll', style: 'flex:1;min-height:0;padding:0 20px 16px' }, h('div', { class: 'vp-grid' }, left, right)));

  return {
    el,
    async onShow() {
      try { apply(await rpc('vpn.state')); } catch { /* ignore */ }
      try { autoSw.set(await rpc('vpn.autostart_get'), true); } catch { /* ignore */ }
    },
  };
});

'use strict';
Pages.register('dashboard', () => {
  const P = 16;
  let visible = false, timer = null, speedStarted = false, busy = false, logCount = 0;

  // ── stat card ──
  function StatCard(title, unit, colorVar, tooltip) {
    const val = h('div', { class: 'f24 b', text: '—', style: { color: colorVar, padding: '0 10px', textAlign: 'center' } });
    const bar = Progress({ height: 3, radius: 2, color: colorVar });
    const el = Card([
      h('div', { class: 'row', style: { justifyContent: 'center', margin: '10px 10px 2px' } },
        h('span', { class: 'f11 ts', text: title }), tooltip ? h('span', { style: 'margin-left:3px' }, Info(tooltip)) : null),
      val, h('div', { style: 'margin:4px 12px 10px' }, bar)], '', { minWidth: 0 });
    el.update = (v, pct) => {
      if (v == null) { val.textContent = 'N/A'; val.style.color = 'var(--text_disabled)'; bar.set(0); }
      else { val.textContent = `${v.toFixed(0)}${unit}`; val.style.color = colorVar; if (pct != null) bar.set(pct / 100); }
    };
    el.setText = (t, c) => { val.textContent = t; val.style.color = c || 'var(--text_secondary)'; bar.set(0); };
    return el;
  }
  const cpu = StatCard('CPU', '%', 'var(--accent)', 'CPU utilisation across all logical cores.');
  const ram = StatCard('RAM', '%', 'var(--success)', 'Physical memory in use as a percentage of total RAM.');
  const disk = StatCard('DISK', '%', 'var(--warning)', 'C: drive usage. High usage slows Windows significantly.');
  const gpu = StatCard('GPU', '%', 'var(--info)', "GPU core load, any vendor.\n\nUses NVML on NVIDIA, Windows' own GPU Engine counters otherwise (same source as Task Manager's GPU graph) — needs the 'wmi' package installed.");
  const temp = StatCard('GPU °C', '°', 'var(--error)', 'GPU temperature in Celsius.\nAvailable via pynvml (NVIDIA) or OpenHardwareMonitor.\nN/A is normal if neither is running — Windows has no vendor-agnostic temperature counter.');

  const health = h('span', { class: 'f12 b ts', text: 'Health: —' });
  const gpuName = h('span', { class: 'f9 td', style: 'text-align:right' });
  const gpuBtn = Btn('Install GPU Support', { variant: 'dim', w: 140, h: 22, f: 9, style: { display: 'none', marginRight: '8px' },
    onclick: async () => {
      gpuBtn.disabled = true; gpuBtn.textContent = 'Installing…';
      try { const r = await rpc('dashboard.install_gpu'); (r.ok ? notify : fail)(r.ok ? 'GPU Support' : 'Install Failed', r.ok ? r.message : `Couldn't install GPU packages:\n\n${r.message}`); }
      catch (e) { fail('Install Failed', e.message); }
      gpuBtn.disabled = false; gpuBtn.textContent = 'Install GPU Support';
    } });

  // ── detail cards ──
  function Detail(title, tipText, rows, keyW) {
    const labels = {};
    const body = rows.map(([k, t]) => {
      const v = h('span', { class: 'f11 tp grow', text: '—', style: 'padding-left:6px;text-align:left' });
      labels[k] = v;
      return h('div', { class: 'row', style: 'padding:2px 12px' },
        h('div', { class: 'row' }, h('span', { class: 'f11 ts', text: k + ':', style: `width:${keyW}px` }), Info(t, '')), v);
    });
    const el = Card([h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: title }),
      tipText ? h('span', { style: 'margin-left:5px' }, Info(tipText)) : null), body, h('div', { style: 'height:6px' })], '', { minWidth: 0 });
    el.labels = labels; return el;
  }
  const sys = Detail('System', '', [['CPU', 'CPU model name'], ['OS', 'Windows build number'], ['Uptime', 'Time since last restart — long uptimes lower the health score'],
    ['Host', 'Machine hostname'], ['Admin', 'Administrator rights — most DWUT features require this'], ['Reboot', 'Whether Windows needs a restart to finish installing updates']], 54);
  const net = Detail('Network', 'Live network send/receive rates and totals since boot.', [['Send Rate', 'Current upload speed'], ['Recv Rate', 'Current download speed'],
    ['Total Sent', 'Total bytes sent since boot'], ['Total Recv', 'Total bytes received since boot']], 74);
  const mem = Detail('Memory', 'Physical RAM usage breakdown.', [['Used', 'RAM currently in use'], ['Free', 'RAM available for new processes'],
    ['Total', 'Total physical RAM installed'], ['Usage', 'Percentage of RAM in use']], 46);

  // ── quick actions ──
  const quick = [
    ['Optimize & Repair', 'optimizer', 'SFC, DISM, network reset, tool launchers'],
    ['Game Booster', 'gaming', 'Real process priority + power plan boost'],
    ['Debloat Windows', 'debloat', 'Remove bloatware, disable telemetry & Recall'],
    ['VPN', 'vpn', 'Secure tunnel, DNS leak protection, server routing & killswitch'],
    ['Proxy Center', 'proxy', 'Fetch, validate and export proxies'],
    ['Tools', 'tools', 'Registry cleaner, startup manager, disk cleanup']
  ];
  const qa = Card([h('div', { class: 'row', style: 'padding:10px 12px 6px' }, h('span', { class: 'f13 b', text: 'Quick Actions' })),
    h('div', { style: 'display:grid;grid-template-columns:repeat(7,1fr);padding:0 12px 10px;gap:6px' },
      [...quick.map(([l, p, t]) => Btn(l, { h: 32, cls: 'fill', style: { margin: '0' }, tip: t, onclick: () => Nav.go(p) })),
       Btn('Task Manager', { h: 32, cls: 'fill', style: { margin: '0' }, tip: 'Open the DWUT Task Manager — a supercharged process manager with live charts, inspector, startup manager, services, and more.', onclick: () => window.dwut?.openTaskManager?.() })])]);

  // ── speed test ──
  const sres = {};
  const box = (key, label, colorVar, t) => {
    const v = h('div', { class: 'f18 b', text: '—', style: { color: colorVar, padding: '0 12px 4px' } });
    sres[key] = v;
    return h('div', { class: 'col', style: 'background:var(--bg_input);border-radius:6px;padding:4px 8px;margin-right:8px;align-items:center' },
      h('div', { class: 'row', style: 'padding-top:4px' }, h('span', { class: 'f10 ts', text: label }), h('span', { style: 'margin-left:2px' }, Info(t))), v);
  };
  const sbar = Progress({ height: 3, radius: 0 });
  const sbarWrap = h('div', { style: 'display:none;margin:0 12px 6px' }, sbar);
  const sstatus = h('div', { class: 'f9 td', style: 'margin-top:4px;text-align:center;max-width:220px' });
  const sbtn = Btn('Run Speed Test', { h: 34, onclick: () => runSpeed() });
  const speed = Card([
    h('div', { class: 'row', style: 'padding:10px 12px 6px' }, h('span', { class: 'f13 b', text: 'Internet Speed Test' }),
      h('span', { style: 'margin-left:5px' }, Info("Measures real download and upload speed using Cloudflare's\nspeed.cloudflare.com endpoint — no third-party service.\n\nDownload: fetches a 10 MB payload, measures throughput.\nUpload: sends a 2 MB payload, measures throughput.\nLatency: raw TCP connect time to 1.1.1.1:443."))),
    h('div', { class: 'row', style: 'padding:0 12px 12px' },
      h('div', { class: 'row grow' }, box('download', 'Download', 'var(--success)', 'Download speed in Mbps (megabits per second).'),
        box('upload', 'Upload', 'var(--accent)', 'Upload speed in Mbps (megabits per second).'),
        box('latency', 'Latency', 'var(--warning)', 'Round-trip latency to Cloudflare 1.1.1.1:443 in milliseconds.')),
      h('div', { class: 'col', style: 'align-items:center;margin-left:8px' }, sbtn, sstatus)),
    sbarWrap]);
  async function runSpeed() {
    sbtn.disabled = true; sbtn.textContent = 'Running…'; sbar.set(0); sbarWrap.style.display = ''; sstatus.textContent = 'Measuring latency…';
    for (const k of ['download', 'upload', 'latency']) sres[k].textContent = '…';
    try {
      const r = await rpc('speedtest.run');
      sres.latency.textContent = r.latency != null ? `${r.latency.toFixed(0)} ms` : 'err';
      sres.download.textContent = r.download != null ? `${r.download.toFixed(0)} Mbps` : 'err';
      sres.upload.textContent = r.upload != null ? `${r.upload.toFixed(0)} Mbps` : 'err';
      setTimeout(() => { sbar.set(0); sbarWrap.style.display = 'none'; }, 2000);
    } catch (e) { sstatus.textContent = 'Error: ' + e.message; }
    sbtn.disabled = false; sbtn.textContent = 'Run Speed Test';
  }
  on('speedtest.progress', (d) => { sbar.set(d.value); sstatus.textContent = d.status; });

  // ── log ──
  const logBox = Textbox({ f: 10, max: 150 }); logBox.style.flex = '1'; logBox.style.margin = '0 10px 10px';
  const logCard = Card([h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: 'Recent Activity' }), h('div', { class: 'grow' }),
    Btn('Clear', { variant: 'plain', h: 22, w: 44, f: 10, style: { color: 'var(--text_disabled)', minWidth: '44px', borderRadius: '4px' }, onclick: () => logBox.clear() })), logBox], '', { flex: '1', display: 'flex', flexDirection: 'column', minHeight: '110px' });
  on('log.line', (rec) => {
    if (!visible) return;
    const d = new Date(rec.timestamp);
    const ts = [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, '0')).join(':');
    logBox.line(`[${ts}]  ${String(rec.level).padEnd(7)}  ${rec.message}`);
  });

  // ── assemble ──
  const gpuRow = h('div', { class: 'row', style: 'justify-content:flex-end;padding:0 4px 2px' }, gpuBtn, gpuName);
  const cards = h('div', { style: 'display:grid;grid-template-columns:repeat(5,1fr);gap:0' }, [cpu, ram, disk, gpu, temp].map((c) => { c.style.margin = '2px 4px'; return c; }));
  const el = h('div', { class: 'col scroll', style: `flex:1;padding:0 ${P}px ${P}px;overflow-y:auto` },
    h('div', { class: 'row', style: `height:48px;margin-top:${P}px;flex:none` }, h('span', { class: 'f18 b', text: 'System Overview' }), h('div', { class: 'grow' }), health),
    h('div', { style: 'margin:10px 0 8px' }, cards, gpuRow),
    h('div', { style: 'display:grid;grid-template-columns:3fr 2fr 2fr;gap:4px;margin-bottom:8px' }, sys, net, mem),
    h('div', { style: 'margin-bottom:8px' }, qa), h('div', { style: 'margin-bottom:8px' }, speed), logCard);

  function upd(s) {
    const snap = s.snap;
    cpu.update(snap.cpu_pct, snap.cpu_pct); ram.update(snap.ram_pct, snap.ram_pct); disk.update(snap.disk_pct, snap.disk_pct);
    if (snap.gpu) {
      const src = { nvml: 'NVML', ohm: 'OHM', perfcounter: 'GPU Engine', wmi_name: 'WMI' }[snap.gpu.source] || '';
      gpuName.textContent = src ? `${snap.gpu.name}  [${src}]` : snap.gpu.name;
      snap.gpu.usage_pct != null ? gpu.update(snap.gpu.usage_pct, snap.gpu.usage_pct) : gpu.setText('Detected');
      temp.update(snap.gpu.temp_c != null ? snap.gpu.temp_c : null);
      gpuBtn.style.display = 'none';
    } else {
      gpu.update(null); temp.update(null);
      gpuName.textContent = `GPU: not detected — ${s.gpu_status || ''}`;
      gpuBtn.style.display = s.gpu_missing ? '' : 'none';
    }
    const up = Math.floor(snap.uptime), d = Math.floor(up / 86400), hr = Math.floor((up % 86400) / 3600), m = Math.floor((up % 3600) / 60);
    sys.labels.CPU.textContent = snap.cpu_name; sys.labels.OS.textContent = snap.windows_version;
    sys.labels.Uptime.textContent = d ? `${d}d ${hr}h ${m}m` : `${hr}h ${m}m`; sys.labels.Host.textContent = snap.hostname;
    sys.labels.Admin.textContent = snap.is_admin ? 'Yes' : 'No — restart as admin'; sys.labels.Admin.style.color = snap.is_admin ? 'var(--success)' : 'var(--warning)';
    sys.labels.Reboot.textContent = snap.pending_reboot ? 'Restart pending' : 'None'; sys.labels.Reboot.style.color = snap.pending_reboot ? 'var(--warning)' : 'var(--success)';
    const rate = (v) => (v == null ? '—' : v > 1024 ? `${(v / 1024).toFixed(1)} MB/s` : `${v.toFixed(0)} KB/s`);
    const n = snap.net;
    net.labels['Send Rate'].textContent = rate(n.send_rate_kbps); net.labels['Recv Rate'].textContent = rate(n.recv_rate_kbps);
    net.labels['Total Sent'].textContent = fmt.bytes(n.bytes_sent); net.labels['Total Recv'].textContent = fmt.bytes(n.bytes_recv);
    mem.labels.Used.textContent = `${snap.ram_used_gb.toFixed(1)} GB`; mem.labels.Free.textContent = `${(snap.ram_total_gb - snap.ram_used_gb).toFixed(1)} GB`;
    mem.labels.Total.textContent = `${snap.ram_total_gb.toFixed(1)} GB`; mem.labels.Usage.textContent = `${snap.ram_pct.toFixed(1)}%`;
    const hc = { Excellent: 'var(--success)', Good: 'var(--accent)', Fair: 'var(--warning)', Poor: 'var(--error)' };
    health.textContent = `Health: ${s.health.total}%  —  ${s.health.label}`; health.style.color = hc[s.health.label] || 'var(--text_secondary)';
  }
  async function refresh() {
    if (!visible || busy) return; busy = true;
    try { const s = await rpc('dashboard.snapshot'); if (s && visible) upd(s); } catch (e) { console.warn(e); }
    busy = false;
  }
  return {
    el,
    onShow() {
      visible = true; refresh();
      timer = setInterval(refresh, Math.max(500, Cfg.v.dashboard_refresh_ms || 2000));
      if (!speedStarted) { speedStarted = true; setTimeout(runSpeed, 800); }
    },
    onHide() { visible = false; clearInterval(timer); },
  };
});

'use strict';
Pages.register('vm', () => {
  const gb = wzGb;
  const logBox = Textbox({ f: 10, max: 400, h: 150 });
  on('vm.log', (t) => logBox.line(t));
  const hostLbl = h('div', { class: 'f11 ts', style: 'margin:2px 0 12px;white-space:normal' });
  let CAT = null, HOST = null;
  const status = h('span', { class: 'f11 ts' });

  // ───────────── step 1: where should the VM live? ─────────────
  function pickDrive(host) {
    return Modal.custom((close) => {
      let sel = null;
      const next = Btn('Next', { w: 100, onclick: () => close(sel) }); next.disabled = true;
      const list = h('div', { class: 'scroll', style: 'max-height:280px;margin:10px 0;min-width:520px' });
      if (!host.drives.length) list.append(h('div', { class: 'f12 ts', text: 'No drives found.', style: 'padding:16px' }));
      host.drives.forEach((d) => {
        const low = d.free < 25e9;
        const row = h('div', { class: 'row', style: 'padding:9px 10px;border-radius:6px;cursor:pointer;margin:2px 0;border:2px solid transparent;gap:10px' },
          h('div', { class: 'f18 b c-acc', text: d.letter + ':', style: 'width:46px;text-align:center;background:var(--bg_input);border-radius:4px;padding:4px 0' }),
          h('div', { class: 'col grow', style: 'align-items:flex-start' },
            h('span', { class: 'f12 b tp', text: `${d.label || 'Local Disk'}  -  ${d.fs}` }),
            h('span', { class: 'f10 ts', text: `${gb(d.free)} free of ${gb(d.size)}` }),
            low ? h('span', { class: 'f10 c-warn', text: 'Low on space - a VM needs at least 25 GB free.' }) : null));
        row.onclick = () => { sel = d; next.disabled = false; $$('.row', list).forEach((r) => { r.style.borderColor = 'transparent'; r.style.background = ''; }); row.style.borderColor = 'var(--accent)'; row.style.background = 'var(--sidebar_active)'; };
        list.append(row);
      });
      return h('div', { class: 'modal', style: 'min-width:560px' }, h('h3', { text: 'Step 1 of 3 - Choose the drive for your VM' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: 'The virtual machine and its virtual disk are stored on this drive (in a folder called DWUT-VMs). Nothing on the drive is erased.' }), list,
        h('div', { class: 'foot' }, h('div', { class: 'grow' }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), next));
    });
  }

  // ───────────── step 3: VM specs ─────────────
  async function specDialog(choice, drive, host) {
    const d = await rpc('vm.defaults', { os_id: choice.os_id });
    const H = d.host, maxRam = Math.max(1, Math.floor(H.ram_gb * 0.75)), maxDisk = Math.max(8, Math.floor(drive.free / 1e9) - 10);
    const pick = (arr, max) => arr.filter((x) => x <= max);
    const near = (arr, v) => arr.reduce((a, b) => (Math.abs(b - v) < Math.abs(a - v) ? b : a), arr[0]);
    const cpuOpts = Array.from({ length: Math.max(1, H.cores - 1) }, (_, i) => i + 1);
    const ramOpts = pick([1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64], maxRam), diskOpts = pick([8, 16, 20, 30, 40, 50, 60, 80, 100, 128, 200, 256, 512, 1024], maxDisk);
    const name = Entry({ value: choice.name.replace(/[\\/:*?"<>|]/g, ''), w: 260, h: 28 });
    const mk = (vals, v, w = 100) => { const o = Option(vals.map(String), { w, f: 12, value: String(near(vals, v)) }); o.classList.add('bordered'); return o; };
    const cpu = mk(cpuOpts, d.cpus), ram = mk(ramOpts, d.ram_gb), disk = mk(diskOpts, d.disk_gb), vram = mk([16, 32, 64, 128, 256], d.vram_mb);
    const efi = Check('UEFI firmware (needed for Windows 11)', { checked: d.efi, themed: true, f: 12 }), tpm = Check('Virtual TPM 2.0 (needed for Windows 11)', { checked: d.tpm, themed: true, f: 12 });
    const acc = Check('3D acceleration (experimental)', { checked: false, themed: true, f: 12 });
    const auto = Check('Install the operating system automatically (recommended)', { checked: true, themed: true, f: 12, onchange: (v) => { cred.style.display = v ? '' : 'none'; } });
    const user = Entry({ value: 'user', w: 150, h: 28 }), pass = Entry({ value: 'changeme', w: 150, h: 28 });
    const cred = h('div', { class: 'row', style: 'gap:10px;margin:2px 0 0 30px' }, h('span', { class: 'f11 ts', text: 'Username' }), user, h('span', { class: 'f11 ts', text: 'Password' }), pass);
    let ostype = d.ostype; const typeOpt = choice.iso_path ? Option(Object.keys(window.__OSC || { 'Linux (64-bit)': 1, 'Windows 11': 1, 'Windows 10': 1, 'Other (64-bit)': 1 }), { w: 180, f: 12, onchange: (v) => { ostype = { 'Windows 11': 'Windows11_64', 'Windows 10': 'Windows10_64', 'Linux (64-bit)': 'Linux26_64', 'Other (64-bit)': 'Other_64' }[v]; } }) : null;
    const row = (label, w) => h('div', { class: 'row', style: 'gap:10px;margin:5px 0' }, h('span', { class: 'f12 ts', text: label, style: 'width:120px' }), w);
    const warns = [];
    if (!H.virt_enabled && choice.software === 'virtualbox') warns.push('Hardware virtualisation (VT-x / AMD-V) looks OFF in your BIOS/UEFI. 64-bit VMs may refuse to start until you enable it.');
    if (H.hyperv) warns.push('Windows features such as Hyper-V/WSL are active. VirtualBox still works but runs somewhat slower.');
    return Modal.custom((close) => {
      const go = () => close({ name: name.value.trim() || choice.name, ostype, cpus: +cpu.value, ram_gb: +ram.value, disk_gb: +disk.value, vram_mb: +vram.value, efi: efi.checked, tpm: tpm.checked,
        accel3d: acc.checked, unattended: choice.software === 'virtualbox' && auto.checked, user: user.value.trim() || 'user', password: pass.value || 'changeme' });
      return h('div', { class: 'modal', style: 'width:600px;max-width:94%' }, h('h3', { text: 'Step 3 of 3 - Virtual machine specs' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal;margin-bottom:6px', text: `Your PC: ${H.cores} CPU threads, ${H.ram_gb} GB RAM.  ${drive.letter}: has ${gb(drive.free)} free.  Defaults are tuned for ${choice.name}.` }),
        warns.map((w) => h('div', { class: 'f10 c-warn', text: w, style: 'white-space:normal;margin:2px 0' })),
        row('Name', name), typeOpt ? row('Operating system', typeOpt) : null, row('CPU cores', cpu), row('Memory (GB)', ram), row('Disk size (GB)', disk), row('Video memory (MB)', vram),
        h('div', { style: 'margin:6px 0 2px' }, efi), h('div', { style: 'margin:4px 0' }, tpm), h('div', { style: 'margin:4px 0' }, acc),
        choice.software === 'virtualbox' ? h('div', { style: 'margin-top:8px' }, auto, cred) : h('div', { class: 'f10 ts', text: 'VMware: DWUT downloads the ISO and gives you a step-by-step guide with exactly these settings.', style: 'margin-top:8px;white-space:normal' }),
        h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), h('div', { class: 'grow' }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), Btn('Create VM', { w: 130, onclick: go })));
    });
  }

  // ───────────── the guide (only closes with Done) ─────────────
  function showGuide(g) {
    return Modal.custom((close) => h('div', { class: 'modal', style: 'width:640px;max-width:94%' }, h('h3', { text: g.title }),
      h('div', { class: 'scroll', style: 'max-height:380px;padding-right:6px' },
        h('div', { style: 'background:var(--bg_input);border-radius:6px;padding:10px 14px;margin-bottom:10px' }, h('div', { class: 'f11 b c-acc', text: `${g.software} - your VM`, style: 'margin-bottom:4px' }), g.specs.map((l) => h('div', { class: 'f11 ts', text: l }))),
        g.steps.map((t, i) => h('div', { class: 'row', style: 'align-items:flex-start;gap:10px;padding:5px 0' }, h('div', { class: 'f12 b', text: String(i + 1), style: 'width:24px;height:24px;border-radius:12px;background:var(--accent);color:var(--accent_text);display:flex;align-items:center;justify-content:center;flex:none' }), h('div', { class: 'f12 tp', text: t, style: 'white-space:normal;line-height:1.35;user-select:text' })))),
      h('div', { class: 'foot', style: 'justify-content:flex-start;flex-wrap:wrap' },
        g.url ? Btn('Open VMware download page', { variant: 'ghost', w: 210, onclick: () => rpc('os.open_url', { url: g.url }) }) : null,
        Btn('Open VM folder', { variant: 'ghost', w: 140, onclick: () => rpc('os.open_path', { path: g.folder }) }), Btn('Copy specs', { variant: 'ghost', w: 110, onclick: () => copyText(g.specs.join('\n')) }),
        h('div', { class: 'grow' }), Btn('Done', { w: 110, onclick: () => close(true) }))));
  }

  // ───────────── wizard ─────────────
  async function wizard() {
    status.textContent = 'Checking your PC…';
    try { CAT = CAT || await rpc('usb.catalog'); HOST = await rpc('vm.host'); } catch (e) { status.textContent = ''; return fail('VM Builder', e.message); }
    status.textContent = '';
    let drive, choice, spec;
    for (;;) {
      drive = await pickDrive(HOST); if (!drive) return;
      choice = await wzPickOS(CAT, null, { vm: true, software: true, exclude: ['ventoy'], subtitle: `The VM will be stored on ${drive.letter}:\\DWUT-VMs.  The ISO is downloaded automatically.` });
      if (choice === 'back') continue; if (!choice) return;
      spec = await specDialog(choice, drive, HOST);
      if (spec === 'back') continue; if (!spec) return;
      break;
    }
    const sw = choice.software === 'vmware' ? 'VMware Workstation' : 'VirtualBox';
    const ok = await Modal.confirm('Ready to build', `DWUT will now:\n\n1. Download ${choice.iso_path ? 'nothing (using your ISO)' : choice.name} if it is not already in your library\n2. ${choice.software === 'vmware' ? 'Prepare a step-by-step guide for VMware (it needs a free Broadcom login, so you install it yourself)' : 'Install VirtualBox if it is not installed yet'}\n3. ${choice.software === 'vmware' ? 'Show you exactly which settings to enter' : `Create "${spec.name}" on ${drive.letter}: (${spec.cpus} cores, ${spec.ram_gb} GB RAM, ${spec.disk_gb} GB disk)`}\n4. ${choice.software === 'vmware' ? '' : (spec.unattended ? 'Start it - the operating system installs itself' : 'Start it with the ISO inserted')}`, { yes: 'Start', no: 'Cancel' });
    if (!ok) return;
    let done = null; const off = on('vm.done', (d) => { done = d; });
    await wzRunJob(`Building ${spec.name} (${sw})`, () => rpc('vm.start', { software: choice.software, drive: drive.letter, spec, os_id: choice.os_id, iso_path: choice.iso_path }), 'vm');
    off();
    if (done && done.ok && done.guide) await showGuide(done.guide);
  }

  const el = h('div', { class: 'col scroll', style: 'flex:1;padding:0 20px 16px' },
    h('div', { class: 'title-row', style: 'padding:0' }, h('h1', { text: 'VM Builder' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'f11 ts', text: 'Build a ready-to-install virtual machine in a few clicks: pick a drive, pick an operating system, choose its specs. DWUT downloads the ISO and VirtualBox (recommended), creates the VM and - where the OS supports it - lets the installer run by itself.', style: 'margin:2px 0 12px;white-space:normal' }),
    Card([h('div', { class: 'f14 b tp', text: 'Build a virtual machine', style: 'padding:14px 16px 4px' }),
      h('div', { class: 'f11 ts', style: 'padding:0 16px 12px;white-space:normal', text: 'Windows 10/11, Ubuntu, Linux Mint, Fedora, Debian, Arch, Kali, Parrot, BlackArch, Qubes, Tails, TempleOS and more - or use your own ISO. VirtualBox is fully automatic. VMware gets a guide with your exact settings (it needs a free Broadcom account to download).' }),
      h('div', { style: 'padding:0 16px 16px' }, Btn('Create', { h: 36, w: 170, onclick: wizard }))], 'col', { marginBottom: '12px' }),
    Card([h('div', { class: 'row', style: 'padding:10px 14px 4px' }, h('span', { class: 'f12 b ts', text: 'Activity' }), h('div', { class: 'grow' }), Btn('Clear', { variant: 'plain', h: 22, w: 44, f: 10, style: { minWidth: '44px', color: 'var(--text_disabled)' }, onclick: () => logBox.clear() })),
      (() => { logBox.style.margin = '0 10px 10px'; return logBox; })()], 'col', { flex: 'none' }));
  return { el };
});

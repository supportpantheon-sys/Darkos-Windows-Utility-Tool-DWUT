'use strict';
Pages.register('tools', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (m) => { status.textContent = m; };
  const content = h('div', { style: 'flex:1;min-height:0;margin:8px 20px 16px;position:relative' });
  const tabs = {};
  const rowBg = (i) => `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:4px`;
  const pcol = { High: 'var(--error)', Medium: 'var(--warning)', Low: 'var(--text_disabled)' };

  // ── Registry Cleaner ──
  function buildRegistry() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    let issues = [], checks = [];
    const stat = {};
    const mk = (k, t, c) => { stat[k] = h('span', { class: 'f12 b', text: t, style: `color:${c};margin-right:16px` }); return stat[k]; };
    const bar = Progress({ height: 3, radius: 2 }); bar.style.margin = '0 0 4px';
    const list = h('div', { class: 'scroll', style: 'flex:1;padding:0 4px 8px' });
    const log = Textbox({ f: 10, max: 300 }); log.style.cssText += ';flex:1;margin:0 8px 8px';
    const lg = (t) => t.split('\n').forEach((l, i, a) => { if (!(i === a.length - 1 && l === '')) log.line(l); });
    lg('Registry Cleaner ready.\nClick \'Scan Registry\' to begin.\n');
    const populate = (arr) => {
      list.textContent = ''; checks = [];
      if (!arr.length) return list.append(h('div', { class: 'f11 c-ok', text: 'No issues found — registry looks clean.', style: 'padding:20px;text-align:center' }));
      arr.forEach((it, i) => {
        const cb = Check('', { themed: true }); checks.push(cb);
        list.append(h('div', { class: 'row', style: rowBg(i) + ';margin:1px 0' }, h('div', { style: 'padding:6px 8px' }, cb),
          h('div', { class: 'grow col', style: 'padding:4px 0;align-items:flex-start;min-width:0' }, h('span', { class: 'f11 b tp ell', text: it.description, style: 'max-width:100%' }), h('span', { class: 'f9 ts ell', text: (it.detail || '').slice(0, 80), style: 'max-width:100%' })),
          h('span', { class: 'f9 b', text: it.priority, style: `width:55px;text-align:center;margin:0 8px;color:${pcol[it.priority] || 'var(--text_secondary)'}` })));
      });
    };
    const scan = async () => {
      list.textContent = ''; checks = []; issues = []; bar.set(0); lg('\n--- Starting registry scan ---\n'); stat.total.textContent = 'Issues: …';
      try {
        const r = await rpc('tools.reg_scan'); issues = r.issues; bar.set(1);
        lg(`\nScan complete in ${r.duration.toFixed(1)}s\n  Found: ${issues.length} issues\n  High: ${r.high}  Medium: ${r.medium}  Low: ${r.low}\n`);
        stat.total.textContent = `Issues: ${issues.length}`; stat.high.textContent = `High: ${r.high}`; stat.medium.textContent = `Medium: ${r.medium}`; stat.low.textContent = `Low: ${r.low}`;
        populate(issues); setStatus(`Scan done — ${issues.length} issues found`);
      } catch (e) { lg('Scan failed: ' + e.message + '\n'); stat.total.textContent = 'Issues: 0'; }
    };
    const clean = async () => {
      const sel = checks.map((c, i) => (c.checked ? issues[i].i : null)).filter((x) => x != null);
      if (!sel.length) return setStatus('Select at least one issue to clean.');
      if (!(await Modal.confirm('Clean Registry Issues', `Delete ${sel.length} registry entries?\n\nA .reg backup will be created first so you can restore if needed.\n\nContinue?`))) return;
      lg(`\nCleaning ${sel.length} issues…\n`); bar.set(0.1);
      try {
        const r = await rpc('tools.reg_clean', { indices: sel }); bar.set(1);
        lg(`\n Clean complete in ${r.duration_s.toFixed(1)}s\n  Deleted: ${r.deleted}\n  Failed:  ${r.failed.length}\n  Backup:  ${r.backup_path || 'none'}\n`);
        if (r.failed.length) lg('  Failed items:\n' + r.failed.slice(0, 5).map((e) => '    ' + e).join('\n'));
        setStatus(`Cleaned ${r.deleted} entries, ${r.failed.length} failed`); scan();
      } catch (e) { lg('Clean failed: ' + e.message + '\n'); }
    };
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px 4px' }, mk('total', 'Issues: 0', 'var(--text_primary)'), mk('high', 'High: 0', 'var(--error)'), mk('medium', 'Medium: 0', 'var(--warning)'), mk('low', 'Low: 0', 'var(--success)')),
      h('div', { class: 'row', style: 'padding:0 12px 10px;gap:6px' }, Btn('Scan Registry', { h: 30, onclick: scan }), Btn('Select All', { variant: 'ghost', h: 30, onclick: () => checks.forEach((c) => c.set(true, true)) }),
        Btn('Deselect All', { variant: 'ghost', h: 30, onclick: () => checks.forEach((c) => c.set(false, true)) }),
        Btn('Create Backup', { variant: 'ghost', h: 30, onclick: async () => { lg('\nCreating registry backup…\n'); try { const p = await rpc('tools.reg_backup'); lg(`Backup saved: ${p}\n`); setStatus('Backup: ' + p); } catch (e) { lg('Backup failed: ' + e.message + '\n'); } } }),
        Btn('Clean Selected', { variant: 'danger', h: 30, onclick: clean }))], 'col', { marginBottom: '8px', flex: 'none' }));
    f.append(bar);
    f.append(h('div', { class: 'row', style: 'flex:1;min-height:0;align-items:stretch' },
      h('div', { class: 'col', style: 'width:280px;flex:none;background:var(--bg_card);border-radius:6px;margin-right:6px;min-height:0' }, h('div', { class: 'f11 b ts', text: 'Registry Issues', style: 'padding:8px 10px 4px' }), list),
      h('div', { class: 'col grow', style: 'background:var(--bg_card);border-radius:6px;min-height:0' }, h('div', { class: 'f11 b ts', text: 'Scan / Clean Log', style: 'padding:8px 10px 4px' }), log)));
    f.__log = lg;
    return f;
  }

  // ── Startup Manager ──
  function buildStartup() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const count = h('span', { class: 'f12 ts', text: 'Startup entries: —' });
    let entries = [], checks = [];
    const list = h('div', { class: 'scroll', style: 'flex:1;background:var(--bg_card);border-radius:6px' });
    const icol = { High: 'var(--error)', Medium: 'var(--warning)', Low: 'var(--success)', Unknown: 'var(--text_disabled)' };
    const load = async () => {
      list.textContent = ''; count.textContent = 'Loading…';
      try {
        entries = await rpc('tools.startup_list'); count.textContent = `Startup entries: ${entries.length}`; checks = [];
        if (!entries.length) return list.append(h('div', { class: 'f12 ts', text: 'No startup entries found.', style: 'padding:20px;text-align:center' }));
        entries.forEach((e, i) => {
          const cb = Check('', { themed: true }); checks.push(cb);
          const cmd = e.command.length > 26 ? e.command.slice(0, 26) + '…' : e.command;
          const w = (t, cls, wd, st) => h('span', { class: cls + ' ell', text: t, style: `width:${wd}px;margin:0 2px;flex:none;${st || ''}` });
          list.append(h('div', { class: 'row', style: rowBg(i) + ';margin:1px 0;padding:0 0 0 0' }, h('div', { style: 'padding:6px 8px' }, cb),
            w(e.name.slice(0, 22), 'f11 b tp', 170), w(e.location.slice(0, 16), 'f10 ts', 90), w(cmd, 'f9 ts mono', 170),
            w(e.impact, 'f9 b', 60, `color:${icol[e.impact] || 'var(--text_disabled)'}`), w(e.enabled ? 'Enabled' : 'Disabled', 'f9 b', 60, `color:${e.enabled ? 'var(--success)' : 'var(--error)'}`),
            h('div', { class: 'grow' }), Btn('↗', { variant: 'plain', w: 28, h: 26, style: { minWidth: '28px', borderRadius: '4px', margin: '0 6px' }, tip: 'Open file location', onclick: () => rpc('tools.startup_open', { index: e.i }) })));
        });
      } catch (e) { count.textContent = 'Failed to load'; }
    };
    const sel = () => checks.map((c, i) => (c.checked ? entries[i].i : null)).filter((x) => x != null);
    const disable = async () => {
      const s = sel(); if (!s.length) return setStatus('Select entries to disable.');
      if (!(await Modal.confirm('Disable Startup Entries', `Disable ${s.length} startup entries?\n\nThis uses the same method as Task Manager — entries are not deleted,\njust prevented from starting at login.`))) return;
      const n = await rpc('tools.startup_set', { indices: s, enable: false }); setStatus(`Disabled ${n}/${s.length} entries`); load();
    };
    const enable = async () => {
      const s = sel(); if (!s.length) return setStatus('Select entries to enable.');
      const n = await rpc('tools.startup_set', { indices: s, enable: true }); setStatus(`Enabled ${n}/${s.length} entries`); load();
    };
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px;gap:8px' }, count, h('div', { class: 'grow' }), Btn('Enable Selected', { variant: 'ghost', h: 30, onclick: enable }), Btn('Disable Selected', { variant: 'danger', h: 30, onclick: disable }), Btn('Refresh', { variant: 'ghost', h: 30, onclick: load }))], 'col', { marginBottom: '8px', flex: 'none' }));
    const cols = [['', 30], ['Application', 220], ['Location', 110], ['Command', 240], ['Impact', 70], ['Status', 70]];
    f.append(h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:4px;margin-bottom:2px;flex:none' }, cols.map(([c, w]) => h('span', { class: 'f10 b ts', text: c, style: `width:${w}px;margin:6px 4px;flex:none` }))));
    f.append(list); f.__load = load; return f;
  }

  // ── Disk Cleanup ──
  function buildDisk() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const total = h('span', { class: 'f12 ts', text: 'Total cleanable: not scanned' });
    const bar = Progress({ height: 3, radius: 2 }); bar.style.marginBottom = '6px';
    const plabel = h('div', { class: 'f10 ts', style: 'min-height:14px' });
    const list = h('div', { class: 'scroll', style: 'flex:1;background:var(--bg_card);border-radius:6px;padding:2px' });
    let cats = [], checks = {};
    const populate = (cs) => {
      cats = cs; list.textContent = ''; const prev = Object.fromEntries(Object.entries(checks).map(([k, c]) => [k, c.checked])); checks = {};
      cs.forEach((c, i) => {
        const cb = Check('', { checked: c.key in prev ? prev[c.key] : !c.aggressive, themed: true }); checks[c.key] = cb;
        list.append(h('div', { class: 'row', style: rowBg(i) + ';margin:2px 0' }, h('div', { style: 'padding:10px' }, cb),
          h('div', { class: 'grow col', style: 'padding:8px 0;align-items:flex-start' },
            h('div', { class: 'row' }, h('span', { class: 'f12 b tp', text: c.name }), c.aggressive ? h('span', { class: 'f9 b', text: 'Aggressive', style: 'background:var(--error);color:#000;border-radius:4px;padding:0 6px;margin-left:6px' }) : null),
            h('span', { class: 'f10 ts', text: c.description })),
          h('span', { class: 'f11 b', text: c.estimated_mb != null ? `${c.estimated_mb.toFixed(1)} MB` : 'Not scanned', style: `width:90px;text-align:right;margin-right:12px;color:${c.estimated_mb ? 'var(--accent)' : 'var(--text_disabled)'}` })));
      });
    };
    const scan = async () => {
      bar.set(0.1); plabel.textContent = 'Scanning…'; total.textContent = 'Scanning…';
      try { const r = await rpc('tools.disk_scan'); bar.set(1); const mb = r.total_bytes / 1048576; total.textContent = `Total cleanable: ${mb.toFixed(1)} MB`; plabel.textContent = `Scan done — ${mb.toFixed(1)} MB found`; populate(r.categories); }
      catch (e) { plabel.textContent = 'Scan failed: ' + e.message; }
    };
    const clean = async () => {
      const keys = Object.keys(checks).filter((k) => checks[k].checked);
      if (!keys.length) return setStatus('Select at least one category.');
      const sel = cats.filter((c) => keys.includes(c.key)), aggr = sel.filter((c) => c.aggressive);
      let msg = `Clean ${keys.length} categories?\n\n` + sel.slice(0, 8).map((c) => (c.estimated_mb ? `• ${c.name} (${c.estimated_mb.toFixed(1)} MB)` : `• ${c.name}`)).join('\n');
      if (aggr.length) msg += '\n\n Aggressive categories selected:\n' + aggr.map((c) => `  - ${c.name}`).join('\n');
      if (!(await Modal.confirm('Confirm Disk Cleanup', msg + '\n\nContinue?'))) return;
      bar.set(0.1); bar.indeterminate(true); plabel.textContent = 'Cleaning…'; setStatus('Cleaning…');
      try {
        const r = await rpc('tools.disk_clean', { keys }); bar.indeterminate(false); bar.set(1);
        const m = ` Cleaned ${r.mb_freed.toFixed(1)} MB (${r.files_deleted} items)`; setStatus(m); plabel.textContent = m; total.textContent = `Last clean: ${r.mb_freed.toFixed(1)} MB freed`;
        if (r.errors && r.errors.length) plabel.textContent = m + ` — ${r.errors.length} note(s), e.g. ${r.errors[0].slice(0, 70)}`;
      } catch (e) { bar.indeterminate(false); plabel.textContent = 'Clean failed: ' + e.message; }
    };
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px;gap:8px' }, total, h('div', { class: 'grow' }), Btn('Clean Selected', { variant: 'danger', h: 30, onclick: clean }),
      Btn('Select All', { variant: 'ghost', h: 30, onclick: () => Object.values(checks).forEach((c) => c.set(true, true)) }), Btn('Scan Sizes', { variant: 'ghost', h: 30, onclick: scan }))], 'col', { marginBottom: '8px', flex: 'none' }));
    f.append(bar, plabel, list);
    rpc('tools.disk_categories').then(populate);
    f.__progress = (line) => { plabel.textContent = String(line).slice(0, 80); };
    return f;
  }

  // ── Storage ──
  function buildStorage() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0' });
    const holder = h('div');
    const load = async () => {
      const infos = await rpc('tools.drives'); holder.textContent = '';
      infos.forEach((info) => {
        const pct = info.used_pct, color = pct > 90 ? 'var(--error)' : pct > 75 ? 'var(--warning)' : 'var(--success)';
        const bar = Progress({ height: 16, radius: 4, color }); bar.set(pct / 100);
        holder.append(Card([h('div', { class: 'row', style: 'padding:10px 14px' }, h('span', { class: 'f16 b tp', text: info.drive, style: 'width:50px' }), h('div', { class: 'grow', style: 'margin:0 12px' }, bar),
          h('span', { class: 'f11 ts', text: `${info.used_gb.toFixed(1)} / ${info.total_gb.toFixed(1)} GB  (${pct.toFixed(0)}%)`, style: 'width:200px;text-align:right' }))], '', { margin: '4px 0' }));
      });
    };
    f.append(h('div', { class: 'f14 b tp', text: 'Drive Storage Overview', style: 'margin-bottom:10px' }), holder, h('div', { style: 'margin:8px 0' }, Btn('Refresh', { variant: 'ghost', h: 30, onclick: load })));
    f.__load = load; return f;
  }

  const builders = { 'Registry Cleaner': buildRegistry, 'Startup Manager': buildStartup, 'Disk Cleanup': buildDisk, Storage: buildStorage };
  function switchTab(name) {
    for (const [n, t] of Object.entries(tabs)) { t.btn.classList.toggle('active', n === name); if (t.frame) t.frame.style.display = n === name ? '' : 'none'; }
    const t = tabs[name];
    if (!t.frame) { t.frame = builders[name](); content.append(t.frame); if (t.frame.__load) t.frame.__load(); }
    t.frame.style.display = '';
  }
  const tabBar = h('div', { class: 'row', style: 'padding:0 20px' });
  for (const n of Object.keys(builders)) { const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => switchTab(n) }); tabs[n] = { btn, frame: null }; tabBar.append(h('span', { style: 'margin:0 2px' }, btn)); }
  on('repair.progress', (line) => { const t = tabs['Registry Cleaner']; if (t.frame && t.frame.__log) t.frame.__log(line + '\n'); });
  on('storage.cleanup_progress', (line) => { const t = tabs['Disk Cleanup']; if (t.frame && t.frame.__progress) t.frame.__progress(line); });
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' }, h('div', { class: 'title-row' }, h('h1', { text: 'Tools' }), h('div', { class: 'grow' }), status), tabBar, h('div', { class: 'divider', style: 'margin:0 20px' }), content);
  switchTab('Registry Cleaner');
  return { el };
});

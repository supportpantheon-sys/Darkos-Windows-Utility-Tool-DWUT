'use strict';
Pages.register('cleaner', () => {
  let S = null, running = false, paused = false, enabled = new Set(), total = 0, doneSteps = new Set();
  const rows = {}, dots = {}, checks = {};
  const quick = { onedrive: false, cortana: false, scanners: true, wd: true, power: true };
  let dnsChoice = 'Keep Current';
  const C_IDLE = '#2d2d4e';

  const logBox = h('div', { class: 'textbox', style: 'height:196px;margin:0 18px 12px;font-size:calc(10px*var(--fs));background:var(--bg_input);border-radius:6px;padding:6px' });
  const lg = (m) => { const stick = logBox.scrollTop + logBox.clientHeight >= logBox.scrollHeight - 8; logBox.append(h('div', { text: m })); while (logBox.childNodes.length > 4000) logBox.removeChild(logBox.firstChild); if (stick) logBox.scrollTop = logBox.scrollHeight; };

  const stepLabel = h('div', { class: 'f12 tp', text: 'Ready to clean', style: 'padding:0 18px 4px' });
  const bar = Progress({ height: 6 }); const barWrap = h('div', { style: 'margin:0 18px 4px' }, bar);
  const progLbl = h('div', { class: 'f10 td', style: 'padding:0 18px 10px;min-height:14px' });
  const statusLbl = h('span', { class: 'f10 ts', style: 'margin-left:12px' });
  const skipBtn = Btn('Skip Step', { variant: 'ghost', h: 24, w: 80, onclick: () => rpc('cleaner.control', { action: 'skip' }) });
  const pauseBtn = Btn('Pause', { variant: 'ghost', h: 32, w: 90, onclick: async () => { paused = !paused; pauseBtn.textContent = paused ? 'Resume' : 'Pause'; rpc('cleaner.control', { action: paused ? 'pause' : 'resume' }); } });
  const cancelBtn = Btn('Cancel', { variant: 'danger', h: 32, w: 90, onclick: () => { rpc('cleaner.control', { action: 'cancel' }); statusLbl.textContent = 'Cancelling…'; } });
  [skipBtn, pauseBtn, cancelBtn].forEach((b) => { b.disabled = true; });

  const setButtons = (run) => { [skipBtn, pauseBtn, cancelBtn].forEach((b) => { b.disabled = !run; }); startLight.disabled = run; startDeep.disabled = run; };

  // ── header pieces ──
  const advHolder = h('div', { class: 'hide' });
  const adv = Switch({ big: true, onchange: (on) => advHolder.classList.toggle('hide', !on) });
  let startLight, startDeep;

  function checkItem(label, tipText, key, onch) {
    const cb = Check('', { sm: true, checked: quick[key], onchange: (v) => { quick[key] = v; onch && onch(v); } });
    return h('div', { class: 'row', style: 'margin-right:24px' }, cb, h('span', { class: 'f11 ts', text: label, style: 'margin-left:6px' }), h('span', { style: 'margin-left:4px' }, Info(tipText)));
  }

  function build() {
    const ver = S.win_ver;
    const tierCard = (title, badge, badgeAcc, tipText, desc, btn) => Card([
      h('div', { class: 'row', style: 'padding:14px 18px 6px' }, h('span', { class: 'f14 b tp', text: title }),
        h('span', { class: 'f9 b', text: badge, style: `background:var(--bg_input);border-radius:3px;padding:2px 7px;margin-left:10px;color:var(--${badgeAcc ? 'accent' : 'text_secondary'})` }), h('span', { style: 'margin-left:6px' }, Info(tipText))),
      h('div', { class: 'f11 ts', text: desc, style: 'padding:0 18px 12px;white-space:normal' }), h('div', { style: 'padding:0 18px 16px' }, btn)], '', { marginBottom: '12px' });
    startLight = Btn(`Start Windows ${ver} Light Clean ->`, { h: 36, w: 280, onclick: () => start(true) });
    startDeep = Btn(`Start Windows ${ver} Deep Clean ->`, { variant: 'ghost', h: 36, w: 280, onclick: () => start(false) });
    const banner = Card([h('div', { class: 'row', style: 'padding:10px 16px' }, h('span', { class: 'f11 b c-ok', text: 'SAFETY GUARANTEED' }),
      h('span', { class: 'f10 ts', text: '• System Restore Point created first  • Xbox & Gaming untouched  • Microsoft Store untouched  • Windows Media Player untouched', style: 'margin-left:12px' }))], '', { marginBottom: '12px' });
    const light = tierCard(`Windows ${ver} Light Clean`, 'RECOMMENDED · 3–5 MINS', true,
      `Windows ${ver} Light Clean includes:\n  1. Automatic System Restore Point (C:)\n  2. Wipes user & system Temp, Prefetch, crash dumps, and logs\n  3. Clears Windows Update & Delivery Optimization caches\n  4. Clears DirectX shader caches and Explorer thumbnail DB\n  5. Cleans all browser caches (Chrome, Edge, Firefox, Brave, Opera)\n  6. Guided Malwarebytes quick threat scan with popup helper\n  7. Fast Component Store Cleanup (DISM /StartComponentCleanup)\n  8. Resets Microsoft Store cache (wsreset) without touching installed apps\n  9. Flushes DNS resolver cache and resets Winsock\n 10. Runs SSD TRIM (Restore write speeds) / HDD defrag\n 11. Trims memory working sets and standby caches\n 12. Empty Recycle Bin on all drives and generates session report\n\nFast, high-impact maintenance with zero risk.`,
      `High-impact, safe maintenance for Windows ${ver}. Reclaims gigabytes of disk space, optimizes RAM, runs a guided Malwarebytes check, and trims SSDs in just a few minutes.`, startLight);
    const deep = tierCard(`Windows ${ver} Deep Clean`, 'FULL TRON WORKFLOW · 30–60 MINS', false,
      `Windows ${ver} Deep Clean includes all 7 Tron workflow phases:\n  Phase 0: Process termination, restore point, registry backup, network backup\n  Phase 1: Deep temp file & cache cleanup\n  Phase 3: Battery of malware, adware & rootkit scanners (MBAM, KVRT, Sophos, ESET, etc.)\n  Phase 4: Full system file & component repair (SFC /scannow, DISM /RestoreHealth, WMI, boot)${ver === 11 ? '\n  • Windows Recovery Environment (WinRE) integrity check' : ''}\n  Phase 5: Patch updates & runtime repair (VC++, DirectX)\n  Phase 6: TCP stack, registry, and system performance optimizations\n  Phase 7: Service restoration, power plan restore, and detailed log report`,
      `Comprehensive Tron-inspired disinfection and deep system repair for Windows ${ver}. Recommended for heavily slowed or infected systems.`, startDeep);

    const dnsOpt = Option(['Keep Current', '1.1.1.1 (Cloudflare)', '8.8.8.8 (Google)', '9.9.9.9 (Quad9)'], { w: 160, f: 10, onchange: (v) => { dnsChoice = v; } });
    const quickCard = Card([
      h('div', { class: 'row', style: 'padding:12px 18px 6px' }, h('span', { class: 'f13 b tp', text: 'Quick Customization' }), h('span', { class: 'f10 td', text: 'Customize preferences directly without opening Advanced Mode', style: 'margin-left:10px' })),
      h('div', { style: 'padding:4px 18px 12px' },
        h('div', { class: 'row', style: 'padding:2px 0' }, checkItem('Clean OneDrive cache & sync logs', 'Removes temporary sync files and telemetry logs. User files remain intact.', 'onedrive'),
          ver === 10 ? checkItem('Clean Cortana query cache', 'Removes legacy Cortana and Windows search cached temp files.', 'cortana') : null),
        h('div', { class: 'row', style: 'padding:2px 0' }, checkItem('Pause Defender during deep scans', 'Temporarily disables real-time scanning so third-party tools can run faster. Automatically re-enabled in Wrap-up.', 'wd'),
          checkItem('Set High Performance power plan during clean', 'Prevents CPU throttling and sleep during cleaning. Automatically restores Balanced in Wrap-up.', 'power')),
        h('div', { class: 'row', style: 'padding:2px 0' }, checkItem('Include third-party anti-malware scanners (Deep Clean)', 'Runs Malwarebytes, KVRT, Sophos, ESET, and AdwCleaner during Phase 3 Disinfect.', 'scanners'),
          h('div', { class: 'row' }, h('span', { class: 'f11 ts', text: 'DNS Provider:', style: 'margin-right:6px' }), dnsOpt)))], '', { marginBottom: '12px' });

    const dotRow = h('div', { class: 'row', style: 'padding:0 18px 12px' });
    S.phases.forEach((p) => {
      const dot = h('div', { class: 'f18', text: '●', style: `color:${C_IDLE};text-align:center;line-height:1.1` }); dots[p.number] = dot;
      dotRow.append(h('div', { class: 'col grow', style: 'align-items:center' }, dot, h('div', { class: 'f9 td', text: `P${p.number}\n${p.name}`, style: 'text-align:center;white-space:pre' })));
    });
    const phaseCard = Card([h('div', { class: 'f11 b ts', text: 'Phase Progress', style: 'padding:10px 18px 6px' }), dotRow], '', { marginBottom: '12px' });
    const progCard = Card([h('div', { class: 'row', style: 'padding:10px 18px 4px' }, h('span', { class: 'f11 b ts', text: 'Status & Progress' }), h('div', { class: 'grow' }), skipBtn), stepLabel, barWrap, progLbl,
      h('div', { class: 'row', style: 'padding:0 18px 12px;gap:8px' }, pauseBtn, cancelBtn, statusLbl)], '', { marginBottom: '12px' });
    const hb = (t, tp, fn) => Btn(t, { variant: 'ghost', h: 24, w: 54, tip: tp, onclick: fn, style: { marginLeft: '4px' } });
    const logCard = Card([h('div', { class: 'row', style: 'padding:10px 18px 4px' }, h('span', { class: 'f11 b ts', text: 'Live Output Log' }), h('div', { class: 'grow' }),
      hb('Clear', 'Clear the log display', () => { logBox.textContent = ''; }),
      hb('Save', 'Save log to a .txt file', async () => { const d = new Date(), p2 = (n) => String(n).padStart(2, '0'); const path = await dwut.dialog.save({ defaultPath: `dwut_clean_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}.txt`, filters: [{ name: 'Text files', extensions: ['txt'] }, { name: 'All files', extensions: ['*'] }] }); if (path) rpc('os.write_text', { path, text: [...logBox.childNodes].map((n) => n.textContent).join('\n') }); }),
      hb('Copy', 'Copy all log text to clipboard', () => copyText([...logBox.childNodes].map((n) => n.textContent).join('\n')))), logBox], '', { marginBottom: '12px' });

    // advanced: phase step lists
    S.phases.forEach((p) => {
      const sf = h('div', { style: 'padding:0 18px 10px' });
      p.steps.forEach((s) => {
        const supported = (ver === 10 && s.win10) || (ver === 11 && s.win11);
        if (!supported) return;
        const isRestore = s.id === 'restore_point';
        const cb = Check('', { sm: true, checked: isRestore || enabled.has(s.id), onchange: (v) => { if (isRestore) return; v ? enabled.add(s.id) : enabled.delete(s.id); } });
        if (isRestore) cb.disable(true);
        checks[s.id] = cb;
        const dot = h('span', { class: 'f12', text: '-', style: 'width:20px;text-align:center;color:var(--text_disabled)' }); dots['s' + s.id] = dot;
        sf.append(h('div', { class: 'row', style: 'padding:2px 0' }, dot, h('span', { style: 'margin:0 4px' }, cb),
          h('span', { class: 'f10', text: s.label + (isRestore ? ' (Mandatory Rollback Point)' : ''), style: `color:var(--${isRestore ? 'text_primary' : 'text_secondary'})` }),
          s.auto ? null : h('span', { class: 'f9 c-warn', text: 'manual', style: 'background:var(--bg_input);border-radius:3px;width:46px;text-align:center;margin-left:6px' })));
      });
      advHolder.append(Card([h('div', { class: 'row', style: 'padding:10px 18px 4px' }, h('span', { class: 'f12 b tp', text: `Phase ${p.number} — ${p.name}` }), h('span', { class: 'f10 td', text: p.description, style: 'margin-left:10px' })), sf], '', { marginBottom: '8px' }));
    });
    return [banner, light, deep, quickCard, phaseCard, progCard, logCard, advHolder];
  }


  // ── "which programs must NOT be killed?" ──
  async function protectDialog() {
    let tasks = [];
    try { tasks = await rpc('cleaner.running_tasks'); } catch { tasks = []; }
    let saved = []; try { saved = JSON.parse(localStorage.getItem('dwut_protect') || '[]'); } catch { saved = []; }
    return Modal.custom((close) => {
      const boxes = [];
      const search = Entry({ placeholder: 'Search running programs…', fill: true, h: 28, f: 12, onchange: () => paint() }); search.style.width = 'auto';
      const list = h('div', { class: 'scroll', style: 'max-height:300px;margin:8px 0;min-width:500px' });
      const paint = () => {
        list.textContent = ''; boxes.length = 0;
        const q = search.value.trim().toLowerCase();
        const own = tasks.filter((t) => t.dwut), rest = tasks.filter((t) => !t.dwut && (!q || t.name.toLowerCase().includes(q)));
        list.append(h('div', { class: 'f11 b c-acc', text: 'DWUT itself - always protected', style: 'margin:4px 4px 3px' }));
        own.forEach((t) => { const cb = Check('', { sm: true, checked: true, themed: true }); cb.disable(true); list.append(h('div', { class: 'row', style: 'padding:4px 6px;gap:8px' }, cb, h('span', { class: 'f12 tp grow ell', text: t.name }), h('span', { class: 'f10 ts', text: 'DWUT' }))); });
        list.append(h('div', { class: 'f11 b c-acc', text: 'Your running programs - tick the ones to keep alive', style: 'margin:10px 4px 3px' }));
        if (!rest.length) list.append(h('div', { class: 'f11 ts', text: 'Nothing else to show.', style: 'padding:8px' }));
        rest.forEach((t) => {
          const key = t.name.toLowerCase();
          const cb = Check('', { sm: true, checked: saved.includes(key), themed: true, onchange: (v) => { saved = v ? [...new Set([...saved, key])] : saved.filter((x) => x !== key); } });
          const row = h('div', { class: 'row', style: 'padding:4px 6px;gap:8px;border-radius:4px;cursor:pointer', onclick: (e) => { if (!cb.contains(e.target)) cb.toggle(); } },
            cb, h('span', { class: 'f12 tp grow ell', text: t.name }), h('span', { class: 'f10 ts', text: `${t.count > 1 ? t.count + ' processes · ' : ''}${t.ram_mb.toFixed(0)} MB` }));
          row.onmouseenter = () => { row.style.background = 'var(--bg_hover)'; }; row.onmouseleave = () => { row.style.background = ''; };
          list.append(row);
        });
      };
      paint();
      return h('div', { class: 'modal', style: 'width:560px;max-width:94%' }, h('h3', { text: 'Protect programs from being closed' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: "The cleaner runs tools (RKill and others) that close suspicious running programs. DWUT itself is always protected. Tick anything else you want left running - e.g. a game launcher, OBS, a download manager or your work apps." }),
        h('div', { style: 'margin-top:8px' }, search), list,
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Start cleaning', { w: 150, onclick: () => { localStorage.setItem('dwut_protect', JSON.stringify(saved)); close(saved); } })));
    });
  }

  async function start(isLight) {
    if (running) return;
    const protect = await protectDialog();
    if (protect === null) return;
    const ver = S.win_ver;
    Object.values(dots).forEach((d, i) => {}); // reset
    S.phases.forEach((p) => { dots[p.number].style.color = C_IDLE; p.steps.forEach((s) => { const d = dots['s' + s.id]; if (d) { d.textContent = '-'; d.style.color = 'var(--text_disabled)'; } }); });
    bar.set(0); progLbl.textContent = ''; stepLabel.textContent = 'Starting...'; logBox.textContent = ''; doneSteps = new Set(); paused = false; pauseBtn.textContent = 'Pause';
    let active = new Set(isLight ? S.light_steps : enabled);
    active.add('restore_point');
    quick.onedrive ? active.add('opt_onedrive') : active.delete('opt_onedrive');
    quick.cortana && ver === 10 ? active.add('opt_cortana') : active.delete('opt_cortana');
    if (!quick.scanners) S.phases[2].steps.forEach((s) => active.delete(s.id));
    if (!quick.wd) active.delete('dis_wd');
    if (!quick.power) { active.delete('power_high'); active.delete('opt_power'); }
    S.phases.forEach((p) => p.steps.forEach((s) => { if ((ver === 10 && !s.win10) || (ver === 11 && !s.win11)) active.delete(s.id); }));
    running = true; setButtons(true); total = active.size;
    statusLbl.textContent = `Running Windows ${ver} ${isLight ? 'Light Clean' : 'Deep Clean'}…`;
    try { await rpc('cleaner.start', { win_ver: ver, steps: [...active], dns: dnsChoice, protect }); }
    catch (e) { running = false; setButtons(false); fail('Cleaner', e.message); }
  }

  on('cleaner.log', lg);
  on('cleaner.step_start', (d) => { stepLabel.textContent = `Running: ${d.label}`; const dot = dots['s' + d.id]; if (dot) { dot.textContent = '>'; dot.style.color = 'var(--accent)'; } });
  on('cleaner.step_done', (d) => {
    const dot = dots['s' + d.id]; if (dot) { dot.textContent = d.success ? '+' : 'x'; dot.style.color = d.success ? 'var(--success)' : 'var(--error)'; }
    doneSteps.add(d.id); const frac = doneSteps.size / Math.max(total, 1); bar.set(Math.min(frac, 1)); progLbl.textContent = `${doneSteps.size} / ${total} steps  (${Math.floor(Math.min(frac, 1) * 100)}%)`;
  });
  on('cleaner.phase_start', (d) => { if (dots[d.num]) dots[d.num].style.color = 'var(--accent)'; lg(`\n${'='.repeat(50)}\nPHASE ${d.num}: ${String(d.name).toUpperCase()}\n${'='.repeat(50)}`); });
  on('cleaner.phase_done', (d) => { if (dots[d.num]) dots[d.num].style.color = 'var(--success)'; });
  on('cleaner.done', (d) => {
    running = false; setButtons(false);
    if (d.completed) { stepLabel.textContent = 'Cleaning complete!'; statusLbl.textContent = 'All tasks finished successfully.'; bar.set(1); }
    else { stepLabel.textContent = 'Cancelled or stopped.'; statusLbl.textContent = ''; }
  });

  // ── manual step dialog ──
  const INSTR = {
    malwarebytes: ['Malwarebytes has opened in a new window.', "1. Click 'Scan' on the Malwarebytes dashboard.", '2. Wait for the scan to complete (usually 2–5 minutes).', "3. If threats are found, click 'Quarantine'.", "4. When finished, click  I'm Done  below — DWUT will move to the next tool."],
    hitmanpro: ['HitmanPro has opened in a new window.', "1. Accept the licence and choose 'No, I only want to perform a one-time scan'.", '2. Wait for the scan to complete.', "3. To remove threats click 'Next', then 'Activate free licence' (free 30-day, no payment or card needed).", "4. When finished, click  Next  below."],
    eset: ['ESET Online Scanner has opened.', '1. Accept the Terms of Use.', "2. Click 'Get started'.", "3. Choose 'Full Scan' and enable 'Remove found threats'.", '4. Wait for the scan to complete.', "5. Click 'Finish', then click  I'm Done  below."],
    npe: ['Norton Power Eraser has launched.', "1. Click 'Scan for Risks'.", '2. Review the results.', "3. Click 'Fix' to remove any threats found.", "4. When finished, click  I'm Done  below."],
    gmer: ['GMER is scanning for advanced rootkits.', '1. GMER auto-scans on startup — wait for it to finish.', "2. If anything appears in RED, click 'Disable' or 'Delete'.", "3. Click 'Save' to save the log.", 'WARNING: Do not click anything else in GMER unless you know what it is.', "When finished, click  I'm Done  below."],
    frst: ['Farbar Recovery Scan Tool (FRST) has opened.', "1. Click 'Scan' — this creates FRST.txt and Addition.txt.", '2. These logs help diagnose persistent infections.', "3. When the scan is complete, click  I'm Done  below."],
    otl: ['OTL (OldTimer ListIt) has opened.', "1. Click 'Run Scan'.", '2. Wait for OTL.txt and Extras.txt to be created.', "3. When finished, click  I'm Done  below."],
    mbar: ['Malwarebytes Anti-Rootkit has opened.', "1. Click 'Next' through the wizard, then 'Scan'.", '2. Wait for the scan to complete.', "3. Click 'Cleanup' if threats are found, then click  I'm Done  below."],
    roguekiller: ['RogueKiller has opened.', "1. Accept the licence and click 'Start Scan'.", '2. Review the results.', 'NOTE: the free edition only DETECTS - removal needs a paid licence, so use another tool to clean what it finds.', "3. Click  Next  below when done."],
    sophos_vrt: ['Sophos Virus Removal Tool has opened.', "1. Accept the license and click 'Start scanning'.", '2. Wait for the scan to finish and clean any threats.', "3. Click  I'm Done  below."],
  };
  on('cleaner.manual', (step) => {
    const lines = INSTR[step.id] || ['{label} has been launched in a new window.', 'Please complete the scan or operation in that window.', "When you are done, click  Next  below.", 'DWUT will then move on to the next step.'].map((l) => l.replace('{label}', step.label));
    const fixed = lines.map((l) => l.replace(/I'm Done/g, 'Next'));
    Modal.custom((close) => {
      let page = '';
      const note = h('div', { class: 'f11', text: 'Starting…', style: 'margin:0 0 4px;color:var(--text_secondary);white-space:pre-wrap' });
      const detail = h('div', { class: 'f9 td', style: 'margin:0 0 10px;white-space:pre-wrap;max-height:70px;overflow:auto;user-select:text' });
      const next = Btn('Next  →', { w: 150, h: 34, bold: true, onclick: () => close('done') }); next.disabled = true;
      const retry = Btn('Retry download', { variant: 'ghost', w: 130, h: 34, onclick: () => launch() }); retry.style.display = 'none';
      const open = Btn('Open download page', { variant: 'ghost', w: 160, h: 34, onclick: () => page && dwut.openExternal(page) }); open.style.display = 'none';
      const launch = () => { next.disabled = true; retry.style.display = 'none'; open.style.display = 'none'; detail.textContent = ''; note.textContent = 'Starting…'; note.style.color = 'var(--text_secondary)'; rpc('cleaner.manual_launch', { step_id: step.id }); };
      on('cleaner.tool_status', (d) => {                      // the dialog is modal: it only ever closes via a button
        if (d.id !== step.id) return;
        note.textContent = d.text; detail.textContent = d.detail || ''; page = d.page || page;
        note.style.color = d.failed ? 'var(--error)' : d.ready ? 'var(--success)' : 'var(--text_secondary)';
        if (d.ready) next.disabled = false;
        if (d.failed) { retry.style.display = ''; if (page) open.style.display = ''; next.disabled = false; next.textContent = 'Continue without it  →'; }
      });
      setTimeout(launch, 50);
      return h('div', { class: 'modal', style: 'width:560px' }, h('h3', { text: 'Manual Step Required', style: 'color:var(--warning)' }), h('div', { class: 'f12 b tp', text: step.label, style: 'margin-bottom:12px' }),
        h('div', { style: 'background:var(--bg_input);padding:10px 14px;margin-bottom:14px;border-radius:2px' }, fixed.map((l) => h('div', { class: 'f10', text: l, style: `padding:2px 0;color:var(--${l.startsWith('WARNING') ? 'warning' : 'text_secondary'});white-space:normal` }))),
        note, detail, h('div', { class: 'foot', style: 'justify-content:flex-start;margin-top:4px;flex-wrap:wrap' }, next, retry, open, Btn('Skip This Tool', { variant: 'ghost', w: 130, h: 34, onclick: () => close('skip') }), Btn('Cancel All', { variant: 'danger', w: 110, h: 34, onclick: () => close('cancel') })));
    }).then((choice) => rpc('cleaner.manual_reply', { choice: choice || 'skip' }));
  });

  const scroll = h('div', { class: 'scroll', style: 'flex:1;padding:10px 20px' });
  const osBadge = h('span', { class: 'f10 b c-acc', style: 'background:var(--bg_card);border-radius:4px;padding:3px 8px;margin-left:12px' });
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'row', style: 'height:54px;padding:0 20px;margin-top:12px;flex:none' }, h('span', { class: 'f18 b', text: 'Cleaner' }), osBadge, h('div', { class: 'grow' }),
      Btn('Check Tool Links', { variant: 'ghost', h: 24, w: 130, f: 10, style: { marginRight: '12px' }, tip: 'Tests every security-tool download link and prints the result in the Live Output Log.', onclick: async () => { lg('--- Checking tool download links (takes ~30s) ---'); try { const rows = await rpc('cleaner.check_links'); rows.forEach((r) => lg(`${r.ok ? 'OK ' : 'BAD'}  ${r.tool.padEnd(14)} ${String(r.status).padEnd(4)} ${r.note}`)); lg('--- link check finished ---'); } catch (e) { lg('Link check failed: ' + e.message); } } }), h('span', { class: 'f11 ts', text: 'Advanced Mode' }), h('span', { style: 'margin-left:4px' }, Info('Advanced Mode reveals all 7 phases and lets you toggle every single step individually.')), h('span', { style: 'margin-left:6px' }, adv)),
    h('div', { class: 'divider', style: 'margin:0 20px' }), scroll);
  rpc('cleaner.static').then((s) => {
    S = s; osBadge.textContent = `Detected: ${s.os_label}`;
    enabled = new Set(s.phases.flatMap((p) => p.steps).filter((x) => ((s.win_ver === 10 && x.win10) || (s.win_ver === 11 && x.win11)) && x.enabled !== false).map((x) => x.id));
    scroll.append(...build());
  }).catch((e) => scroll.append(h('div', { class: 'c-err', text: 'Cleaner failed to load: ' + e.message })));
  return { el };
});

'use strict';
/* Network Monitor - watches your VPN, your proxy and your Wi-Fi/Ethernet at the same time, plus any IP you add.
   One column per network (1-4 columns, sized automatically). Settings are remembered between launches.
   YOUR OWN addresses (LAN / Wi-Fi IPs, MACs, adapter names, SSID, devices, your real public IP) are hidden behind a click
   (see js/privacy.js) so the whole program can be streamed safely. VPN / proxy / other people's servers are shown normally. */
Pages.register('network', () => {
if (!document.getElementById('nm-style')) {
    document.head.append(h('style', { id: 'nm-style', text: `
      .nm-bar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 10px;padding:0 20px 10px}
      .nm-sp{flex:1}
      .nm-pill{display:inline-flex;align-items:center;gap:7px;padding:6px 12px;border-radius:999px;border:1px solid var(--border);background:var(--bg_input);color:var(--text_secondary);font-family:inherit;font-size:calc(12px*var(--fs));font-weight:600;cursor:pointer}
      .nm-pill i{width:8px;height:8px;border-radius:50%;background:var(--text_disabled)}
      .nm-pill.on{border-color:var(--accent);color:var(--text_primary);background:var(--accent_subtle)}
      .nm-pill.on i{background:var(--accent)}
      .nm-pill b{font-weight:700;color:var(--text_secondary);font-size:calc(11px*var(--fs))}
      .nm-sw{display:inline-flex;align-items:center;gap:7px;font-size:calc(12px*var(--fs));color:var(--text_secondary)}
      .nm-tabs{display:inline-flex;background:var(--bg_input);border-radius:7px;padding:2px}
      .nm-tabs button{border:0;background:transparent;color:var(--text_secondary);padding:5px 12px;border-radius:5px;cursor:pointer;font-family:inherit;font-size:calc(11.5px*var(--fs));font-weight:600}
      .nm-tabs button.on{background:var(--accent);color:var(--text_on_accent)}
      .nm-grid{display:grid;gap:12px;padding:0 20px;flex:1;min-height:0;overflow-x:auto}
      .nm-col{display:flex;flex-direction:column;min-width:0;min-height:0;padding:14px;gap:10px;overflow-y:auto}
      .nm-head{display:flex;flex-direction:column;gap:3px}
      .nm-title{display:flex;align-items:center;gap:8px;font-size:calc(14px*var(--fs));font-weight:700}
      .nm-dot{width:9px;height:9px;border-radius:50%;background:var(--text_disabled);flex:none}
      .nm-dot.on{background:var(--accent);box-shadow:0 0 0 3px var(--accent_subtle)}
      .nm-state{margin-left:auto;font-size:calc(10.5px*var(--fs));font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--text_secondary)}
      .nm-detail{font-size:calc(11px*var(--fs));color:var(--text_secondary);overflow-wrap:anywhere;line-height:1.35}
      .nm-tiles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
      .nm-tile{background:var(--bg_input);border-radius:7px;padding:7px 10px;min-width:0}
      .nm-tile span{display:block;font-size:calc(10px*var(--fs));color:var(--text_secondary);text-transform:uppercase;letter-spacing:.5px}
      .nm-tile b{display:block;font-size:calc(14px*var(--fs));margin-top:1px;overflow-wrap:anywhere}
      .nm-spark{width:100%;height:38px;border-radius:6px;background:var(--bg_input);display:block}
      .nm-sec{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:calc(11px*var(--fs));font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--text_secondary);padding:2px 0;user-select:none}
      .nm-sec .c{margin-left:auto;font-weight:600}
      .nm-list{display:flex;flex-direction:column;gap:4px;overflow:auto;min-height:140px;flex:1 1 auto}
      .nm-box{display:flex;flex-direction:column;gap:4px;max-height:170px;overflow:auto;flex:none}
      .nm-conn{position:relative;padding:7px 10px 7px 12px;border-radius:7px;background:var(--bg_input);display:flex;flex-direction:column;gap:2px;min-width:0;flex:none}
      .nm-conn::before{content:"";position:absolute;left:0;top:6px;bottom:6px;width:3px;border-radius:2px;background:transparent}
      .nm-conn.t1::before{background:var(--accent_dim)}.nm-conn.t2::before{background:var(--accent)}.nm-conn.t3::before{background:var(--error)}
      .nm-c1{display:flex;align-items:center;gap:7px;min-width:0;font-size:calc(12px*var(--fs))}
      .nm-c1 .p{font-weight:700;overflow-wrap:anywhere;min-width:0}
      .nm-c1 .m{color:var(--text_secondary);font-size:calc(10px*var(--fs));font-weight:600}
      .nm-tag{font-size:calc(9.5px*var(--fs));font-weight:800;letter-spacing:.5px;padding:1px 6px;border-radius:4px;background:var(--accent_subtle);color:var(--accent);flex:none}
      .nm-tag.red{background:rgba(255,69,58,.16);color:var(--error)}
      .nm-tag.dim{background:var(--bg_hover);color:var(--text_secondary)}
      .nm-c2{font-family:Consolas,monospace;font-size:calc(10.5px*var(--fs));color:var(--text_secondary);overflow-wrap:anywhere;line-height:1.35}
      .nm-c3{font-size:calc(10.5px*var(--fs));color:var(--text_primary);opacity:.85}
      .nm-act{display:none;position:absolute;right:6px;top:6px;gap:4px}
      .nm-conn:hover .nm-act{display:flex}
      .nm-act button{border:1px solid var(--border);background:var(--bg_card);color:var(--text_primary);font-size:calc(10px*var(--fs));font-family:inherit;padding:2px 8px;border-radius:5px;cursor:pointer}
      .nm-act button:hover{border-color:var(--accent)}
      .nm-empty{padding:18px 10px;text-align:center;color:var(--text_secondary);font-size:calc(11.5px*var(--fs));line-height:1.5}
      .nm-ports{display:flex;flex-wrap:wrap;gap:5px}
      .nm-act2{display:flex;gap:6px}.nm-act2 .btn{flex:1;width:auto !important;min-width:0}
      .nm-feed{margin:10px 20px 16px;padding:10px 14px;display:flex;flex-direction:column;gap:6px;max-height:150px;flex:none}
      .nm-feed .l{overflow:auto;display:flex;flex-direction:column;gap:3px;font-size:calc(11.5px*var(--fs))}
      .nm-ev{display:flex;gap:10px;align-items:baseline}.nm-ev .t{color:var(--text_secondary);font-family:Consolas,monospace;font-size:calc(10.5px*var(--fs));flex:none}
      .nm-toasts{position:absolute;right:20px;bottom:20px;display:flex;flex-direction:column;gap:8px;z-index:50;pointer-events:none}
      .nm-toast{background:var(--bg_card);border:1px solid var(--accent);border-left-width:4px;border-radius:8px;padding:10px 14px;max-width:380px;box-shadow:0 8px 24px rgba(0,0,0,.45);font-size:calc(12px*var(--fs))}
      .nm-toast.red{border-color:var(--error)}
      .nm-toast b{display:block;margin-bottom:2px}
      .nm-ov{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;padding:0 20px 10px}
      .nm-ovc{padding:10px 12px;display:flex;flex-direction:column;gap:3px;min-width:0}
      .nm-ovc .k{font-size:calc(10px*var(--fs));letter-spacing:.6px;text-transform:uppercase;color:var(--text_secondary);font-weight:700}
      .nm-ovc .v{font-size:calc(16px*var(--fs));font-weight:700;overflow-wrap:anywhere}
      .nm-ovc .s{font-size:calc(10.5px*var(--fs));color:var(--text_secondary);line-height:1.35;overflow-wrap:anywhere}
      .nm-mini{width:100%;height:26px;display:block;border-radius:5px;background:var(--bg_input);margin-top:3px}
      .nm-sel{background:var(--bg_input);color:var(--text_primary);border:1px solid var(--border);border-radius:6px;padding:4px 8px;font-family:inherit;font-size:calc(11.5px*var(--fs))}
      .nm-ses{font-size:calc(10.5px*var(--fs));color:var(--text_secondary);line-height:1.4}
      .nm-adp{display:flex;flex-direction:column;gap:3px}
      .nm-adp div{font-size:calc(11px*var(--fs));display:flex;gap:6px;align-items:center;flex-wrap:wrap}
      .nm-adp b{font-weight:600}
      .nm-blk{margin:0 20px 6px;padding:8px 14px;display:flex;flex-direction:column;gap:6px;flex:none;max-height:130px;overflow:auto}
      .nm-blk .r{display:flex;align-items:center;gap:10px;font-size:calc(11.5px*var(--fs))}
      .nm-viewtabs{display:inline-flex;background:var(--bg_input);border-radius:6px;padding:2px;align-self:flex-start}
      .nm-viewtabs button{border:0;background:transparent;color:var(--text_secondary);padding:3px 10px;border-radius:4px;cursor:pointer;font-family:inherit;font-size:calc(10.5px*var(--fs));font-weight:600}
      .nm-viewtabs button.on{background:var(--accent);color:var(--text_on_accent)}
    ` }));
  }

  // ── state ──
  let D = null, q = '', sortBy = 'risk', openSec = { listen: false, devices: true, blocked: false };
  const view = { vpn: 'conns', proxy: 'conns', lan: 'conns' };
  const scrollKeep = {};
  let pressed = false, dirty = false;
  const H = (html, cls) => h('span', { html, class: cls || null });
  const hhmmss = (t) => new Date(t * 1000).toTimeString().slice(0, 8);
  const mbps = (v) => (v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)) + ' Mbps';
  const ago = (t) => { const s = Math.max(0, Math.floor(Date.now() / 1000 - t)); return s < 60 ? s + 's ago' : s < 3600 ? Math.floor(s / 60) + 'm ago' : Math.floor(s / 3600) + 'h ago'; };
  const dur = (s) => (s < 60 ? s + 's' : s < 3600 ? Math.floor(s / 60) + 'm' : Math.floor(s / 3600) + 'h ' + Math.floor((s % 3600) / 60) + 'm');
  const ms = (v) => (v == null ? '—' : Math.round(v) + ' ms');

  // ── toolbar ──
  const statusChip = h('span', { class: 'f11 ts' });
  const runBtn = Btn('Pause monitoring', { h: 30, f: 11, onclick: async () => { try { await rpc(D && D.running ? 'netmon.stop' : 'netmon.start'); refresh(); } catch (e) { fail('Network Monitor', e.message); } } });
  const pills = {};
  const NETS = [['vpn', 'VPN'], ['proxy', 'Proxy'], ['lan', 'Wi-Fi / Ethernet']];
  const pillBox = h('div', { class: 'row', style: 'gap:8px;flex-wrap:wrap' });
  NETS.forEach(([k, label]) => {
    const dot = h('i'), cnt = h('b', { text: '' });
    pills[k] = h('button', { class: 'nm-pill', title: 'Show or hide this network', onclick: async () => {
      const cur = !(D && D.prefs_nets && D.prefs_nets[k]);
      if (D) D.prefs_nets[k] = cur;
      render();
      await rpc('netmon.set_prefs', { patch: { nets: { [k]: cur } } });
    } }, dot, h('span', { text: label }), cnt);
    pills[k].cnt = cnt;
    pillBox.append(pills[k]);
  });
  const filterIn = Entry({ placeholder: 'Filter connections…', h: 30, f: 12, w: 190, onchange: (v) => { q = v.toLowerCase(); render(); } });
  const targetIn = Entry({ placeholder: 'Monitor an IP or hostname (e.g. 8.8.8.8)', h: 30, f: 12, w: 270, onenter: () => addTargets() });
  const targetBtn = Btn('Start monitoring', { h: 30, f: 11, onclick: () => addTargets() });
  async function addTargets() {
    const v = targetIn.value.trim(); if (!v) return;
    targetBtn.disabled = true;
    try { await rpc('netmon.target_add', { text: v }); targetIn.value = ''; refresh(); }
    catch (e) { fail('Monitor target', e.message); }
    targetBtn.disabled = false;
  }
  const alertSw = Switch({ checked: true, onchange: (v) => rpc('netmon.set_prefs', { patch: { alerts: v } }) });
  const blockSw = Switch({ checked: false, onchange: async (v) => {
    if (v && !(await Modal.confirm('Auto-block', 'Dangerous connections will be blocked automatically with a Windows Firewall rule for their IP address.\n\nYou can unblock addresses at any time.', { yes: 'Enable', no: 'Cancel' }))) { blockSw.set(false, true); return; }
    rpc('netmon.set_prefs', { patch: { auto_block: v } });
  } });
  const tabs = h('div', { class: 'nm-tabs' });
  [['all', 'All'], ['flagged', 'Flagged']].forEach(([id, label]) => tabs.append(h('button', { 'data-f': id, text: label, onclick: () => { if (D) D.filter = id; render(); rpc('netmon.set_prefs', { patch: { filter: id } }); } })));
  const sortSel = h('select', { class: 'nm-sel', title: 'Sort connections', onchange: (e) => { sortBy = e.target.value; render(); } },
    [['risk', 'Sort: risk'], ['app', 'Sort: app'], ['new', 'Sort: newest'], ['old', 'Sort: oldest'], ['remote', 'Sort: remote']].map(([v, l]) => h('option', { value: v, text: l })));
  const exportBtn = Btn('Copy report', { variant: 'ghost', h: 30, f: 11, tip: 'Copies the visible connections as JSON. Your own addresses stay hidden unless you have revealed them.', onclick: () => {
    if (!D) return;
    const rep = {};
    NETS.forEach(([k]) => { const n = D.nets[k]; if (n) rep[k] = n.conns.map((c) => ({ app: c.proc, proto: c.proto, state: c.status, local: Priv.text(c.l, c.lm, ''), remote: Priv.text(c.r, c.rm, ''), risk: c.threat, why: c.reason })); });
    copyText(JSON.stringify({ time: new Date().toISOString(), networks: rep }, null, 2));
    exportBtn.textContent = 'Copied!'; setTimeout(() => { exportBtn.textContent = 'Copy report'; }, 1500);
  } });
  const reveal = Priv.masterButton();

  const bar1 = h('div', { class: 'nm-bar' }, pillBox, h('div', { class: 'nm-sp' }), tabs, sortSel, filterIn, targetIn, targetBtn);
  const blockedBtn = h('button', { class: 'nm-pill', onclick: () => { openSec.blocked = !openSec.blocked; render(); } }, h('i'), h('span', { text: 'Blocked IPs' }), h('b', { text: '0' }));
  const bar2 = h('div', { class: 'nm-bar', style: 'padding-top:0' },
    h('label', { class: 'nm-sw' }, alertSw, 'Alerts'), h('label', { class: 'nm-sw' }, blockSw, 'Auto-block dangerous IPs'), blockedBtn,
    h('div', { class: 'nm-sp' }), statusChip, exportBtn, reveal, runBtn);

  const ov = h('div', { class: 'nm-ov' });
  const grid = h('div', { class: 'nm-grid' });
  const blkBox = Card(h('div', { class: 'col', style: 'gap:6px' }), 'nm-blk');
  blkBox.style.display = 'none';
  const feedList = h('div', { class: 'l' });
  const feed = Card(h('div', { class: 'col', style: 'gap:6px;min-height:0' },
    h('div', { class: 'row' }, h('span', { class: 'vp-h f11 b grow ts', text: 'ACTIVITY' }), Btn('Clear', { variant: 'ghost', h: 22, f: 10, onclick: async () => { await rpc('netmon.events_clear'); refresh(); } })), feedList), 'nm-feed');
  const toasts = h('div', { class: 'nm-toasts' });

  function toast(ev) {
    const detail = ev.priv ? Priv.text(ev.detail, true, 'text') : ev.detail;
    const t = h('div', { class: 'nm-toast ' + (ev.level >= 3 ? 'red' : '') }, h('b', { text: ev.title }), h('span', { class: 'ts', text: detail }));
    toasts.append(t); setTimeout(() => t.remove(), 7000);
    try { if (document.hidden) new Notification(ev.title, { body: ev.priv ? 'Open DWUT to see the details.' : ev.detail }); } catch { /* ignore */ }
  }

  // ── building blocks ──
  function spark(canvas, down, up, label) {
    const dpr = window.devicePixelRatio || 1, w = canvas.clientWidth, hh = canvas.clientHeight;
    if (!w) return;
    canvas.width = w * dpr; canvas.height = hh * dpr;
    const c = canvas.getContext('2d'); c.scale(dpr, dpr); c.clearRect(0, 0, w, hh);
    const cs = getComputedStyle(document.documentElement);
    const max = Math.max(0.5, ...down, ...up);
    const line = (arr, color, fill) => {
      if (arr.length < 2) return;
      c.beginPath();
      arr.forEach((v, i) => { const x = (i / (arr.length - 1)) * w, y = hh - 3 - (v / max) * (hh - 8); i ? c.lineTo(x, y) : c.moveTo(x, y); });
      c.strokeStyle = color; c.lineWidth = 1.5; c.stroke();
      if (fill) { c.lineTo(w, hh); c.lineTo(0, hh); c.closePath(); c.globalAlpha = 0.14; c.fillStyle = color; c.fill(); c.globalAlpha = 1; }
    };
    line(up, cs.getPropertyValue('--accent_dim').trim() || '#888', false);
    line(down, cs.getPropertyValue('--accent').trim() || '#4a7cff', true);
    c.fillStyle = cs.getPropertyValue('--text_secondary').trim() || '#999'; c.font = '9px sans-serif';
    c.fillText('peak ' + (label ? label(max) : max.toFixed(max < 10 ? 1 : 0)), 4, 10);
  }
  const miniSpark = (vals) => {
    const cv = h('canvas', { class: 'nm-mini' });
    requestAnimationFrame(() => spark(cv, vals, [], (m) => Math.round(m) + ' ms'));
    return cv;
  };
  const tile = (label, value) => h('div', { class: 'nm-tile' }, h('span', { text: label }), h('b', { text: String(value) }));

  function connText(c) {
    return [c.proc, c.proto, c.status, c.service, c.reason, Priv.text(c.l, c.lm), Priv.text(c.r, c.rm), c.rm ? '' : c.rdns].join(' ').toLowerCase();
  }
  function connRow(c) {
    const tag = c.threat >= 3 ? h('span', { class: 'nm-tag red', text: 'DANGER' }) : c.threat === 2 ? h('span', { class: 'nm-tag', text: 'WARN' }) : c.threat === 1 ? h('span', { class: 'nm-tag dim', text: 'WATCH' }) : null;
    const note = c.rm ? '' : (c.rdns || c.service ? '  ·  ' + (c.rdns || c.service) : '');
    const acts = h('div', { class: 'nm-act' },
      h('button', { text: 'Allow', title: `Always treat ${c.proc} as safe`, onclick: async () => { await rpc('netmon.allow', { entry: c.proc.toLowerCase() }); refresh(); } }),
      c.ra && !(c.rm ? false : false) && c.ra ? h('button', { text: 'Copy IP', title: 'Copy the remote address', onclick: () => copyText(c.ra) }) : null,
      c.ra && !c.rm ? h('button', { text: 'Block IP', title: 'Add a Windows Firewall rule for this address', onclick: async () => {
        if (await Modal.confirm('Block IP', `Block all traffic to and from ${c.ra}?`, { yes: 'Block', danger: true })) { await rpc('netmon.block', { ip: c.ra }); refresh(); }
      } }) : null);
    return h('div', { class: 'nm-conn t' + c.threat },
      h('div', { class: 'nm-c1' }, h('span', { class: 'p', text: c.proc }), h('span', { class: 'm', text: c.proto + (c.status && c.status !== 'ESTABLISHED' && c.status !== 'NONE' ? ' · ' + c.status.toLowerCase() : '') + (c.age > 5 ? ' · ' + dur(c.age) : '') }), h('span', { class: 'grow' }), tag),
      h('div', { class: 'nm-c2' }, H(Priv.addr(c.l, c.lm)), '  →  ', H(Priv.addr(c.r, c.rm)), note),
      c.reason ? h('div', { class: 'nm-c3', text: c.reason }) : null, acts);
  }
  function appRow(a) {
    const tag = a.worst >= 3 ? h('span', { class: 'nm-tag red', text: 'DANGER' }) : a.flag ? h('span', { class: 'nm-tag', text: a.flag + ' FLAGGED' }) : null;
    return h('div', { class: 'nm-conn t' + Math.min(a.worst, 3), style: 'cursor:pointer', title: 'Show only this app\'s connections', onclick: () => { filterIn.value = a.proc; q = a.proc.toLowerCase(); view.vpn = view.proxy = view.lan = 'conns'; render(); } },
      h('div', { class: 'nm-c1' }, h('span', { class: 'p', text: a.proc }), a.procs > 1 ? h('span', { class: 'm', text: a.procs + ' processes' }) : null, h('span', { class: 'grow' }), tag),
      h('div', { class: 'nm-c2', text: `${a.total} connection${a.total === 1 ? '' : 's'} · ${a.est} established · ${a.udp} UDP · ${a.remotes} remote address${a.remotes === 1 ? '' : 'es'}` }));
  }
  function sortConns(rows) {
    const by = {
      risk: (a, b) => b.threat - a.threat || (a.status !== 'ESTABLISHED') - (b.status !== 'ESTABLISHED') || a.proc.localeCompare(b.proc),
      app: (a, b) => a.proc.localeCompare(b.proc) || b.threat - a.threat,
      new: (a, b) => (a.age || 0) - (b.age || 0),
      old: (a, b) => (b.age || 0) - (a.age || 0),
      remote: (a, b) => (a.rm ? '~' : a.r).localeCompare(b.rm ? '~' : b.r),
    }[sortBy];
    return rows.slice().sort(by);
  }

  function section(key, label, count, body, extra) {
    const open = openSec[key];
    return [h('div', { class: 'nm-sec', onclick: () => { openSec[key] = !open; render(); } }, h('span', { text: (open ? '▾ ' : '▸ ') + label }), extra || null, h('span', { class: 'c', text: String(count) })),
      open ? body : null];
  }

  function netColumn(n) {
    const col = h('div', { class: 'nm-col', 'data-sk': n.key + ':col' });
    const state = !D.running ? 'Paused' : n.present ? 'Active' : 'Not active';
    col.append(h('div', { class: 'nm-head' },
      h('div', { class: 'nm-title' }, h('span', { class: 'nm-dot' + (n.present && D.running ? ' on' : '') }), h('span', { text: n.label }), h('span', { class: 'nm-state', text: state })),
      n.key === 'lan'
        ? h('div', { class: 'nm-adp' }, n.adapters.length ? n.adapters.map((a) => h('div', {}, h('b', { text: a.label }), a.speed ? h('span', { class: 'ts', text: a.speed + ' Mbps' }) : null,
            H(Priv.html(a.ip)), a.mac ? H(Priv.html(a.mac, 'mac')) : null, a.name && a.name !== a.label ? H(Priv.html(a.name, 'text')) : null)) : h('div', { class: 'nm-detail', text: n.detail }))
        : h('div', { class: 'nm-detail', text: n.detail })));
    const flagged = n.warn + n.danger;
    const tiles = n.key === 'proxy'
      ? [tile('Connections', n.total), tile('Flagged', flagged + (n.watch ? ` (+${n.watch} watch)` : ''))]
      : [tile('Download', mbps(n.down)), tile('Upload', mbps(n.up)), tile('Connections', n.total), tile('Flagged', flagged + (n.watch ? ` (+${n.watch} watch)` : ''))];
    col.append(h('div', { class: 'nm-tiles' }, tiles));
    if (n.key !== 'proxy') {
      const cv = h('canvas', { class: 'nm-spark' }); col.append(cv); requestAnimationFrame(() => spark(cv, n.hist_down, n.hist_up));
      const se = n.session;
      if (se) col.append(h('div', { class: 'nm-ses', text: `This session: ↓ ${fmt.bytes(se.down_b)}  ↑ ${fmt.bytes(se.up_b)}  ·  peak ↓ ${mbps(se.peak_down)}  ↑ ${mbps(se.peak_up)}  ·  ${dur(Math.floor(Date.now() / 1000 - se.since))}` }));
    }

    if (n.key === 'lan') {
      const L = n.listen || [];
      const lbody = h('div', { class: 'nm-box', 'data-sk': 'listen' }, L.length ? L.map((p) => h('div', { class: 'nm-conn' + (p.exposed ? ' t1' : '') },
        h('div', { class: 'nm-c1' }, h('span', { class: 'p', text: p.proc }), h('span', { class: 'm', text: `${p.proto} ${p.port}${p.service ? ' · ' + p.service : ''}` }), p.am ? H(Priv.html(p.addr)) : null, h('span', { class: 'grow' }),
          h('span', { class: 'nm-tag ' + (p.exposed ? '' : 'dim'), text: p.exposed ? 'ALL NETWORKS' : 'THIS PC' })))) : h('div', { class: 'nm-empty', text: 'No listening ports.' }));
      col.append(...section('listen', 'Open ports on this PC', L.length, lbody).flat().filter(Boolean));
      const Dv = n.devices || [];
      const scanBtn = h('button', { class: 'nm-tag', style: 'border:0;cursor:pointer', text: n.dev_scanning ? 'SCANNING…' : 'SCAN', onclick: async (e) => { e.stopPropagation(); if (!n.dev_scanning) { await rpc('netmon.devices_scan'); refresh(); } } });
      const dbody = h('div', { class: 'nm-box', 'data-sk': 'devices', style: 'max-height:210px' }, Dv.length ? Dv.map((d) => h('div', { class: 'nm-conn' + (d.new ? ' t2' : '') },
        h('div', { class: 'nm-c1' }, H(Priv.html(d.name || d.ip, 'text')), h('span', { class: 'grow' }),
          d.gateway ? h('span', { class: 'nm-tag dim', text: 'ROUTER' }) : null, d.you ? h('span', { class: 'nm-tag dim', text: 'THIS PC' }) : null,
          d.new ? h('span', { class: 'nm-tag', text: 'NEW' }) : null, d.random ? h('span', { class: 'nm-tag dim', text: 'PRIVATE MAC' }) : null),
        h('div', { class: 'nm-c2' }, H(Priv.html(d.ip)), '  ·  ', H(Priv.html(d.mac, 'mac'))),
        d.new ? h('div', { class: 'nm-act' }, h('button', { text: 'Trust', onclick: async () => { await rpc('netmon.device_trust', { mac: d.mac }); refresh(); } })) : null))
        : h('div', { class: 'nm-empty', text: n.dev_scanning ? 'Looking for devices…' : 'Press SCAN to discover devices on your network.' }));
      col.append(...section('devices', 'Devices on your network', Dv.length, dbody, scanBtn).flat().filter(Boolean));
      if (n.dev_scanned) col.append(h('div', { class: 'f10 ts', style: 'margin-top:-4px', text: 'Last scan ' + ago(n.dev_scanned) + '. Unknown devices raise an alert.' }));
    }

    col.append(h('div', { class: 'nm-viewtabs' }, [['conns', 'Connections'], ['apps', 'By app']].map(([id, l]) =>
      h('button', { class: view[n.key] === id ? 'on' : '', text: l, onclick: () => { view[n.key] = id; render(); } }))));

    const list = h('div', { class: 'nm-list', 'data-sk': n.key + ':list' });
    let rows = n.conns.filter((c) => (D.filter !== 'flagged' || c.threat >= 1));
    if (q) rows = rows.filter((c) => connText(c).includes(q));
    if (!n.present) list.append(h('div', { class: 'nm-empty', text: n.key === 'vpn' ? 'No VPN adapter is up.\nConnect the DWUTVPN (VPN page) or any VPN to see its traffic here.' : n.key === 'proxy' ? 'No proxy detected.\nTraffic appears here when a system proxy, DWUT Proxy Center or a tool like Clash / V2Ray / Tor is in use.' : 'No network adapter is up.' }));
    else if (view[n.key] === 'apps') {
      const apps = (n.apps || []).filter((a) => !q || a.proc.toLowerCase().includes(q));
      if (!apps.length) list.append(h('div', { class: 'nm-empty', text: 'No apps are using this network right now.' })); else apps.forEach((a) => list.append(appRow(a)));
    }
    else if (!rows.length) list.append(h('div', { class: 'nm-empty', text: D.filter === 'flagged' && !q ? 'Nothing flagged on this network. All connections look normal.' : q ? 'No connections match the filter.' : 'No active connections right now.' }));
    else sortConns(rows).slice(0, 200).forEach((c) => list.append(connRow(c)));
    col.append(h('div', { class: 'nm-sec', style: 'cursor:default' }, h('span', { text: view[n.key] === 'apps' ? 'Apps' : 'Connections' }), h('span', { class: 'c', text: view[n.key] === 'apps' ? `${(n.apps || []).length} apps` : `${rows.length} shown` })), list);
    return col;
  }

  function targetColumn() {
    const col = h('div', { class: 'nm-col', 'data-sk': 'targets:col' });
    col.append(h('div', { class: 'nm-head' }, h('div', { class: 'nm-title' }, h('span', { class: 'nm-dot on' }), h('span', { text: 'Monitored targets' }), h('span', { class: 'nm-state', text: String(D.targets.length) })),
      h('div', { class: 'nm-detail', text: 'Ping, latency, open ports and live connections for each address you add.' })));
    const list = h('div', { class: 'nm-list', 'data-sk': 'targets:list' });
    D.targets.forEach((t) => {
      const cv = h('canvas', { class: 'nm-spark', style: 'height:30px' });
      const live = t.live || [];
      const name = t.mine ? H(Priv.html(t.text, 'text'), 'p') : h('span', { class: 'p', text: t.text });
      const sub = t.mine
        ? [t.ip && t.ip !== t.text ? Priv.html(t.ip) : '', t.rdns ? Priv.html(t.rdns, 'text') : ''].filter(Boolean).join('  ·  ')
        : [t.ip && t.ip !== t.text ? Priv.esc(t.ip) : '', Priv.esc(t.rdns || ''), t.geo && t.geo.country ? Priv.esc([t.geo.city, t.geo.country].filter(Boolean).join(', ')) : '', Priv.esc(t.geo && t.geo.org ? t.geo.org : '')].filter(Boolean).join('  ·  ');
      list.append(h('div', { class: 'nm-conn', style: 'gap:6px;padding:10px 12px' },
        h('div', { class: 'nm-c1' }, name, h('span', { class: 'grow' }),
          t.error ? h('span', { class: 'nm-tag red', text: 'NO DNS' }) : t.up === null ? h('span', { class: 'nm-tag dim', text: 'CHECKING' }) : t.up ? h('span', { class: 'nm-tag', text: 'UP' + (t.rtt ? ` · ${Math.round(t.rtt)} ms` : '') }) : h('span', { class: 'nm-tag red', text: 'DOWN' })),
        h('div', { class: 'nm-c2' }, sub ? H(sub) : t.error || ''),
        t.hist.length > 1 ? cv : null,
        h('div', { class: 'nm-ports' }, t.scanning ? h('span', { class: 'nm-tag dim', text: 'SCANNING PORTS…' }) : t.ports.length ? t.ports.map((p) => h('span', { class: 'nm-tag', text: p.port + (p.service ? ' ' + p.service : '') })) : (t.scanned ? h('span', { class: 'nm-tag dim', text: 'NO OPEN PORTS FOUND' }) : null)),
        live.length ? h('div', { class: 'nm-c2', text: `${live.length} live connection${live.length > 1 ? 's' : ''}: ` + [...new Set(live.map((c) => c.proc))].slice(0, 4).join(', ') }) : null,
        h('div', { class: 'nm-act2' },
          Btn('Rescan ports', { variant: 'ghost', h: 24, f: 10.5, onclick: async () => { await rpc('netmon.target_scan', { text: t.text }); refresh(); } }),
          Btn('Stop', { variant: 'ghost', h: 24, f: 10.5, onclick: async () => { await rpc('netmon.target_remove', { text: t.text }); refresh(); } }))));
      if (t.hist.length > 1) requestAnimationFrame(() => spark(cv, t.hist, [], (m) => Math.round(m) + ' ms'));
    });
    col.append(list);
    return col;
  }

  function overview() {
    ov.textContent = '';
    if (!D) return;
    const hl = D.health || {}, pub = D.public || {}, wf = D.wifi || {};
    const ovc = (k, v, s, extra) => h('div', { class: 'nm-ovc card' }, h('span', { class: 'k', text: k }), v, s ? h('span', { class: 's', text: s }) : null, extra || null);
    ov.append(ovc('Your address on the internet',
      pub.ip ? H(pub.mine ? Priv.html(pub.ip) : Priv.esc(pub.ip), 'v') : h('span', { class: 'v', text: '—' }),
      pub.ip ? (pub.vpn ? 'VPN exit - this is what websites see' : 'Your real address (hidden) - no VPN is up') + (pub.loc ? ' · ' + pub.loc : '') : 'Looking it up…'));
    const net = hl.internet || {}, rt = hl.router || {};
    ov.append(ovc('Internet latency', h('span', { class: 'v', text: ms(net.rtt) }), net.samples ? `avg ${ms(net.avg)} · jitter ${net.jitter} ms · loss ${net.loss}%` : 'Measuring…', net.hist && net.hist.length > 1 ? miniSpark(net.hist) : null));
    ov.append(ovc('Router latency', h('span', { class: 'v', text: ms(rt.rtt) }), rt.samples ? `avg ${ms(rt.avg)} · jitter ${rt.jitter} ms · loss ${rt.loss}%` : 'Measuring…', rt.hist && rt.hist.length > 1 ? miniSpark(rt.hist) : null));
    if (wf.ssid !== undefined) {
      ov.append(ovc('Wi-Fi', h('span', { class: 'v', text: wf.signal != null ? wf.signal + '% signal' : 'Connected' }),
        [wf.band, wf.channel ? 'ch ' + wf.channel : '', wf.rx ? '↓ ' + wf.rx + ' Mbps' : '', wf.tx ? '↑ ' + wf.tx + ' Mbps' : '', wf.auth].filter(Boolean).join(' · '),
        h('span', { class: 's' }, H(Priv.html(wf.ssid, 'text')), ' ', wf.bssid ? H(Priv.html(wf.bssid, 'mac')) : null)));
    }
    ov.style.display = '';
  }

  function render() {
    if (!D) return;
    if (pressed) { dirty = true; return; }
    NETS.forEach(([k]) => { const n = D.nets[k]; pills[k].classList.toggle('on', !!D.prefs_nets[k]); pills[k].cnt.textContent = n ? String(n.total) : ''; });
    tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.f === D.filter));
    alertSw.set(D.alerts, true); blockSw.set(D.auto_block, true);
    sortSel.value = sortBy;
    runBtn.textContent = D.running ? 'Pause monitoring' : 'Resume monitoring';
    runBtn.className = 'btn ' + (D.running ? 'btn-ghost' : 'btn-primary');
    blockedBtn.querySelector('b').textContent = String((D.blocked_list || []).length);
    blockedBtn.classList.toggle('on', openSec.blocked);
    const total = NETS.reduce((a, [k]) => a + (D.nets[k] ? D.nets[k].total : 0), 0);
    statusChip.textContent = D.running ? `Live · ${total} connections · ${(D.blocked_list || []).length} blocked IPs` : 'Monitoring is paused';

    overview();

    // remember every scroll position by key before the grid is rebuilt
    grid.querySelectorAll('[data-sk]').forEach((el) => { scrollKeep[el.dataset.sk] = el.scrollTop; });
    scrollKeep.__x = grid.scrollLeft;
    const shown = NETS.filter(([k]) => D.prefs_nets[k] && D.nets[k]).map(([k]) => D.nets[k]);
    const showT = D.targets.length > 0;
    const cols = shown.length + (showT ? 1 : 0);
    grid.textContent = '';
    if (!cols) { grid.append(h('div', { class: 'nm-empty', style: 'grid-column:1/-1', text: 'Turn on at least one network above, or add an IP to monitor.' })); grid.style.gridTemplateColumns = '1fr'; }
    else {
      grid.style.gridTemplateColumns = `repeat(${cols}, minmax(250px, 1fr))`;
      shown.forEach((n) => grid.append(Card(netColumn(n), 'nm-col-card col', 'min-width:0;min-height:0;overflow:hidden')));
      if (showT) grid.append(Card(targetColumn(), 'col', 'min-width:0;min-height:0;overflow:hidden'));
      grid.querySelectorAll('.nm-col').forEach((c) => { c.style.flex = '1'; c.style.minHeight = '0'; });
      grid.querySelectorAll('[data-sk]').forEach((el) => { if (scrollKeep[el.dataset.sk]) el.scrollTop = scrollKeep[el.dataset.sk]; });
      if (scrollKeep.__x) grid.scrollLeft = scrollKeep.__x;
    }

    // blocked IPs manager
    const bl = D.blocked_list || [];
    blkBox.style.display = openSec.blocked ? '' : 'none';
    if (openSec.blocked) {
      const inner = blkBox.firstChild; inner.textContent = '';
      inner.append(h('div', { class: 'vp-h f11 b ts', text: 'BLOCKED IP ADDRESSES' }));
      if (!bl.length) inner.append(h('div', { class: 'ts f11', text: 'Nothing is blocked. Use "Block IP" on a connection, or turn on auto-block, to add addresses here.' }));
      bl.forEach((b) => inner.append(h('div', { class: 'r' }, b.mine ? H(Priv.html(b.ip)) : h('span', { class: 'p', text: b.ip, style: 'font-family:Consolas,monospace' }), h('span', { class: 'grow' }),
        Btn('Unblock', { variant: 'ghost', h: 22, f: 10, onclick: async () => { await rpc('netmon.unblock', { ip: b.ip }); refresh(); } }))));
    }

    feedList.textContent = '';
    const evs = [...D.events].reverse().slice(0, 40);
    if (!evs.length) feedList.append(h('div', { class: 'ts f11', text: 'No alerts yet. Suspicious connections, new devices on your network and target changes show up here.' }));
    evs.forEach((e) => feedList.append(h('div', { class: 'nm-ev' }, h('span', { class: 't', text: hhmmss(e.ts) }),
      h('span', { class: 'nm-tag ' + (e.level >= 3 ? 'red' : e.level === 2 ? '' : 'dim'), text: e.level >= 3 ? 'DANGER' : e.level === 2 ? 'ALERT' : 'INFO' }),
      h('span', { class: 'b', text: e.title }), e.priv ? H(Priv.html(e.detail, 'text'), 'ts') : h('span', { class: 'ts', style: 'overflow-wrap:anywhere', text: e.detail }))));
  }

  async function refresh() { try { D = await rpc('netmon.state'); render(); } catch (e) { statusChip.textContent = 'Backend unavailable'; } }
  on('netmon.snapshot', (d) => { D = d; render(); });
  on('netmon.alert', (e) => { if (D && D.alerts) toast(e); });
  window.addEventListener('resize', () => render());
  Priv.onChange(() => render());

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0;position:relative' },
    h('div', { class: 'title-row' }, h('h1', { text: 'Network Monitor' }), h('div', { class: 'grow' }), h('span', { class: 'f11 ts', text: 'VPN · Proxy · Wi-Fi / Ethernet · custom targets' })),
    bar1, bar2, ov, grid, blkBox, feed, toasts);
  // a refresh must never swallow a click: while the mouse button is down inside the page, redraws wait until it is released
  el.addEventListener('mousedown', () => { pressed = true; }, true);
  window.addEventListener('mouseup', () => { if (!pressed) return; pressed = false; if (dirty) { dirty = false; setTimeout(render, 0); } }, true);
  return { el, async onShow() { await refresh(); if (D && !D.running && !D.user_stopped) { try { await rpc('netmon.start'); refresh(); } catch { /* ignore */ } } } };
});

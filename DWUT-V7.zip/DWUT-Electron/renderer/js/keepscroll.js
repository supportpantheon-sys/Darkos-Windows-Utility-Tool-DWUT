'use strict';
/* keepscroll - lists that are cleared and rebuilt on every refresh no longer jump back to the top.

   When anything sets textContent / innerHTML or calls replaceChildren() on an element, the scroll position of that element and of
   the scrollable containers around it is remembered, and put back as soon as the new content is in (immediately, next frame, and a
   few times over the next second for content that arrives after an await).  If YOU scroll, click, type or use the wheel in the
   meantime, your position wins and nothing is restored.
   Loaded by the main app and by the Task Manager. */
(function () {
  if (window.__keepScroll) return;
  window.__keepScroll = true;
  let lastUser = 0;
  const touch = () => { lastUser = performance.now(); };
  ['wheel', 'pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, touch, { capture: true, passive: true }));
  // dragging a scrollbar fires pointerdown on the element itself, so that is covered by the listener above

  function scrollers(el) {
    const out = [];
    for (let n = el; n && n !== document.documentElement; n = n.parentElement) {
      if (n.scrollTop > 0 || n.scrollLeft > 0) out.push([n, n.scrollTop, n.scrollLeft]);
    }
    return out;
  }
  function remember(el) {
    let snap;
    try { snap = scrollers(el); } catch { return; }
    if (!snap.length) return;
    const t0 = performance.now();
    const restore = () => {
      if (lastUser > t0) return true;                                   // the user took over - stop
      let ok = true;
      for (const [n, top, left] of snap) {
        if (!n.isConnected) continue;
        if (n.scrollTop !== top) { n.scrollTop = top; if (Math.abs(n.scrollTop - top) > 1) ok = false; }
        if (n.scrollLeft !== left) n.scrollLeft = left;
      }
      return ok;
    };
    queueMicrotask(restore);
    requestAnimationFrame(() => { restore(); requestAnimationFrame(restore); });
    [120, 350, 900].forEach((ms) => setTimeout(restore, ms));
  }

  const tc = Object.getOwnPropertyDescriptor(Node.prototype, 'textContent');
  Object.defineProperty(Element.prototype, 'textContent', {
    configurable: true, enumerable: tc.enumerable, get: tc.get,
    set(v) { if (this.firstChild) remember(this); tc.set.call(this, v); },
  });
  const ih = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
  Object.defineProperty(Element.prototype, 'innerHTML', {
    configurable: true, enumerable: ih.enumerable, get: ih.get,
    set(v) { if (this.firstChild) remember(this); ih.set.call(this, v); },
  });
  const rc = Element.prototype.replaceChildren;
  Element.prototype.replaceChildren = function (...a) { if (this.firstChild) remember(this); return rc.apply(this, a); };
})();

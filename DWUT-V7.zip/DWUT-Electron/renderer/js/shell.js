'use strict';
/* App shell: titlebar, sidebar, navigation, splash, update banner, boot sequence */

const NAV_ITEMS = [
  ['dashboard', 'Dashboard', 'D'], ['optimizer', 'Optimizer', 'O'], ['gaming', 'Gaming', 'G'],
  ['debloat', 'Debloat', 'D'], ['proxy', 'Proxy Center', 'P'], ['vpn', 'VPN', 'V'],
  ['network', 'Network Monitor', 'N'],
  ['usb', 'USB Flasher', 'U'], ['vm', 'VM Builder', 'M'], ['tools', 'Tools', 'T'],
  ['cleaner', 'Cleaner', 'C'], ['settings', 'Settings', 'S'],
];

const Nav = {
  pages: {}, current: '', sidebarCollapsed: false, isAdmin: false,
  go(name) {
    if (!Pages.factories[name] || name === this.current) return;
    let p = this.pages[name];
    if (!p) {
      p = this.pages[name] = Pages.factories[name]();
      p.root = h('div', { class: 'page' }, p.el);
      $('#content').append(p.root);
    }
    const prev = this.pages[this.current];
    if (prev) { prev.root.classList.remove('active'); prev.onHide && prev.onHide(); }
    p.root.classList.add('active');
    this.current = name; window.__currentPage = name;
    Sidebar.setActive(name);
    p.onShow && p.onShow();
  },
};

const Sidebar = {
  build() {
    const sb = $('#sidebar');
    sb.classList.toggle('collapsed', Nav.sidebarCollapsed);
    sb.textContent = '';
    const col = Nav.sidebarCollapsed;
    const toggle = h('button', { class: 'sb-toggle f13', text: col ? '>' : '<', onclick: () => this.toggle() });
    sb.append(h('div', { class: 'sb-logo' },
      col ? h('div', { class: 'f9 b', text: 'DWUT', style: { color: 'var(--text_primary)' } }) : h('div', { class: 'name f10', text: "Darko's Windows Utility Tool" }),
      toggle));
    sb.append(h('div', { class: 'sb-div' }));
    const nav = h('div', { class: 'sb-nav' });
    this.items = {};
    for (const [key, label, icon] of NAV_ITEMS) {
      const btn = h('button', { class: 'f12', text: col ? icon : `  ${icon}    ${label}`, onclick: () => Nav.go(key) });
      const row = h('div', { class: 'sb-item' }, h('div', { class: 'bar' }), btn);
      this.items[key] = row; nav.append(row);
    }
    sb.append(nav, h('div', { class: 'sb-div' }));
    const admin = Nav.isAdmin;
    sb.append(h('div', { class: 'sb-bottom' }, col
      ? h('div', { class: 'f10 b', text: admin ? 'A' : '!', style: { textAlign: 'center', color: admin ? 'var(--success)' : 'var(--warning)' } })
      : h('div', { class: 'col', style: 'gap:2px' },
          h('div', { class: 'f10', text: admin ? 'Administrator' : 'No Admin Rights', style: { color: admin ? 'var(--success)' : 'var(--warning)' } }),
          window.OS ? h('div', { class: 'f9 ts', text: (OS.name || '') + (OS.version ? ' ' + OS.version : '') + (OS.is_ltsc ? ' LTSC' : ''), title: OS.label || '' }) : null)));
    if (Nav.current) this.setActive(Nav.current);
  },
  setActive(key) {
    for (const [k, row] of Object.entries(this.items || {})) row.classList.toggle('active', k === key);
  },
  toggle() {
    Nav.sidebarCollapsed = !Nav.sidebarCollapsed;
    Cfg.set({ sidebar_collapsed: Nav.sidebarCollapsed });
    this.build();
  },
};

function buildTitlebar() {
  const tb = $('#titlebar');
  tb.append(
    h('button', { class: 'tb f11', text: '—', onclick: () => dwut.win.minimize() }),
    h('button', { class: 'tb x f14', text: '×', onclick: () => dwut.win.close() }));
  tb.addEventListener('dblclick', (e) => { if (e.target === tb) dwut.win.maximize(); });
}

let _toastShown = false;
function showUpdateBanner(info) {
  if (_toastShown) return; _toastShown = true;
  const host = $('#banner-host');
  const bar = h('div', { class: 'tbar' });
  const title = h('div', { class: 'f13 b', text: 'Update available', style: 'color:var(--text_primary)' });
  const sub = h('div', { class: 'f11 ts', text: `DWUT ${info.version || 'new version'} is ready to install`, style: 'margin-top:2px' });
  const btn = Btn('Update now', { h: 28, w: 120, bold: true, onclick: (e) => { e.stopPropagation(); install(); } });
  const toast = h('div', { class: 'toast', onclick: () => install() }, h('div', { style: 'padding:12px 14px 12px' }, title, sub, h('div', { style: 'margin-top:10px' }, btn)), bar);
  let installing = false, timer = null;
  async function install() {
    if (installing) return; installing = true; clearTimeout(timer);
    bar.style.transition = 'none'; bar.style.width = '100%';
    title.textContent = 'Installing update…'; sub.textContent = 'DWUT will close and restart by itself.'; btn.style.display = 'none';
    try { await dwut.updateNow(); } catch (e) { title.textContent = 'Update failed'; sub.textContent = String(e.message || e); setTimeout(() => toast.remove(), 6000); }
  }
  host.append(toast);
  requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = '0%'; }));       // smooth 5 s countdown, full -> empty
  timer = setTimeout(() => { if (installing) return; toast.classList.add('out'); setTimeout(() => toast.remove(), 300); }, 5000);
}

// ── starfield + splash (same parameters as the original Tk widget) ───────────
function Starfield(canvas, bg, starColor) {
  const ctx = canvas.getContext('2d');
  const hex = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
  const B = hex(bg), S = hex(starColor);
  const dim = S.map((v, i) => v + (B[i] - v) * 0.55);
  let stars = [], W = 0, Hh = 0, timer = null;
  const mix = (t) => `rgb(${dim.map((d, i) => Math.round(d + (S[i] - d) * t)).join(',')})`;
  const seed = () => {
    const dpr = devicePixelRatio || 1;
    W = canvas.clientWidth; Hh = canvas.clientHeight; canvas.width = W * dpr; canvas.height = Hh * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.min(140, Math.max(24, Math.floor(W * Hh / 6000)));
    stars = [];
    for (let i = 0; i < n; i++) {
      const sp = (2 + Math.random() * 8) / 60;
      stars.push({ x: Math.random() * W, y: Math.random() * Hh, r: [0.6, 0.8, 1.0, 1.0, 1.3, 1.6][Math.floor(Math.random() * 6)],
        vx: sp * (Math.random() * 0.6 - 0.3), vy: sp * (0.3 + Math.random() * 0.7), ph: Math.random() * 6.283, ts: 0.03 + Math.random() * 0.07 });
    }
  };
  const tick = () => {
    ctx.clearRect(0, 0, W, Hh);
    for (const s of stars) {
      s.x += s.vx; s.y += s.vy;
      if (s.x < -2) s.x = W + 2; else if (s.x > W + 2) s.x = -2;
      if (s.y < -2) s.y = Hh + 2; else if (s.y > Hh + 2) s.y = -2;
      s.ph += s.ts;
      let t = (Math.sin(s.ph) + 1) / 2;
      if (Math.random() < 0.012) t = Math.random() < 0.5 ? 0 : 1;
      ctx.fillStyle = mix(t); ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.283); ctx.fill();
    }
  };
  return { start() { seed(); timer = setInterval(tick, 50); }, stop() { clearInterval(timer); } };
}

function runSplash() {
  const TITLE = "Darko's Windows Utility Tool";
  const sp = $('#splash'); sp.textContent = '';
  const canvas = h('canvas'); sp.append(canvas);
  const w = innerWidth;
  const fontSize = Math.max(16, Math.min(26, Math.floor(w / 40)));
  const ty = h('div', { class: 'ty', style: { fontSize: fontSize + 'px' } });
  const sub = h('div', { class: 'sub', text: 'DWUT', style: { fontSize: Math.max(9, fontSize - 7) + 'px' } });
  sp.append(ty, sub);
  // centre using the full-string width (like the original measure())
  const probe = h('span', { text: TITLE + '|', style: { position: 'absolute', visibility: 'hidden', fontFamily: 'Consolas,monospace', fontWeight: '700', fontSize: fontSize + 'px', whiteSpace: 'pre' } });
  document.body.append(probe); const fullW = probe.offsetWidth; probe.remove();
  ty.style.left = Math.max((w - fullW) / 2, 12) + 'px';
  const field = Starfield(canvas, Theme.tokens.bg_shell, Theme.tokens.accent);
  field.start();
  let i = 0, on = true, closed = false, tmr;
  const type = () => {
    if (closed) return;
    if (i <= TITLE.length) { ty.textContent = TITLE.slice(0, i) + (on ? '|' : ' '); i++; tmr = setTimeout(type, 45); }
    else blink();
  };
  const blink = () => { if (closed) return; on = !on; ty.textContent = TITLE + (on ? '|' : ' '); tmr = setTimeout(blink, 420); };
  setTimeout(type, 150);
  return new Promise((res) => setTimeout(() => {
    closed = true; clearTimeout(tmr); sp.style.opacity = '0';
    setTimeout(() => { field.stop(); sp.remove(); res(); }, 260);
  }, 3000));
}

// ── boot ─────────────────────────────────────────────────────────────────────
(async function boot() {
  Theme.apply('dark');
  buildTitlebar();
  let cfg = null;
  for (let i = 0; i < 60 && !cfg; i++) {
    try { cfg = await Cfg.load(); } catch { await sleep(500); }
  }
  if (!cfg) { document.body.append(h('div', { style: 'position:absolute;inset:60px;color:#f66', text: 'Could not reach the DWUT backend. See %APPDATA%\\DWUT\\logs\\electron-backend.log' })); return; }
  Theme.apply(cfg.theme);
  Theme.typography(cfg.ui_font || null, cfg.ui_font_scale || 1, cfg.ui_text_color || '');
  Nav.isAdmin = !!cfg.is_admin; Nav.sidebarCollapsed = !!cfg.sidebar_collapsed;
  try { window.OS = await rpc('system.os_info'); } catch { window.OS = null; }   // family / edition / version / build for OS-specific UI
  Sidebar.build();

  on('app.update_available', showUpdateBanner);
  on('backend.crashed', () => console.warn('backend restarted'));

  const start = NAV_ITEMS.some((n) => n[0] === cfg.start_page) ? cfg.start_page : 'dashboard';
  const splash = runSplash();
  setTimeout(() => Nav.go(start), 50);          // page builds underneath the splash
  // Remembered settings: reconnect the VPN (if the user enabled it) and resume the network monitor.
  setTimeout(() => { rpc('vpn.autostart_run').catch(() => {}); rpc('netmon.autostart_run').catch(() => {}); }, 1500);
  await splash;
})();

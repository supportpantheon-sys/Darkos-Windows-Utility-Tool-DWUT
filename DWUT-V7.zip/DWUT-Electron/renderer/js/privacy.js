'use strict';
/* Priv - click-to-reveal for YOUR OWN network details (LAN / Wi-Fi addresses, MACs, adapter names, SSID, devices on your
   network, your real public IP), so the whole program can be streamed without leaking them.
   Addresses of the VPN, proxies and other people's servers never go through here.

   - A hidden value is drawn as a placeholder; the real text is NOT in the page while hidden.
   - Click a value to reveal it; it hides itself again after 15 seconds.
   - Priv.masterButton() reveals everything for 30 seconds.
   - Nothing is saved: every launch starts hidden. */
(function () {
  const ONE_MS = 15000, ALL_MS = 30000;
  const open = new Map();
  const subs = new Set();
  const masters = new Set();
  let allUntil = 0;

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hash = (s) => { let x = 5381; for (let i = 0; i < s.length; i++) x = ((x << 5) + x + s.charCodeAt(i)) | 0; return 'p' + (x >>> 0).toString(36); };
  const isOpen = (k) => allUntil > Date.now() || (open.get(k) || 0) > Date.now();
  const notify = () => subs.forEach((f) => { try { f(); } catch { /* ignore */ } });

  function kindOf(t) {
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(t)) return 'ip4';
    if (/^([0-9a-f]{2}[:-]){5}[0-9a-f]{2}$/i.test(t)) return 'mac';
    if (/^[0-9a-f:]+$/i.test(t) && t.includes(':')) return 'ip6';
    return 'text';
  }
  const SHAPE = { ip4: '•••.•••.•••.•••', ip6: '••••:••••:••••:••••', mac: '••:••:••:••:••:••', text: '••••••••' };

  if (!document.getElementById('priv-style')) {
    const st = document.createElement('style');
    st.id = 'priv-style';
    st.textContent = `
      .priv{display:inline-flex;align-items:center;gap:6px;cursor:pointer;border-radius:4px;padding:0 6px;font-family:Consolas,monospace;max-width:100%;vertical-align:baseline;user-select:none}
      .priv-off{background:var(--bg_input,var(--bg4,#222));color:var(--text_secondary,var(--ts,#9aa));border:1px dashed var(--border,#444);letter-spacing:1px}
      .priv-off i{font-style:normal;font-family:inherit;letter-spacing:0;font-size:.8em;font-weight:700;color:var(--accent,var(--acc,#4a7cff))}
      .priv-off:hover{border-color:var(--accent,var(--acc,#4a7cff))}
      .priv-on{background:var(--accent_subtle,rgba(74,124,255,.15));border:1px solid var(--accent_dim,var(--acc,#4a7cff));user-select:text;overflow-wrap:anywhere}
      .priv-master{border:1px solid var(--accent,var(--acc,#4a7cff));background:var(--accent_subtle,rgba(74,124,255,.15));color:var(--accent,var(--acc,#4a7cff));border-radius:6px;padding:4px 11px;cursor:pointer;font-weight:600;font-size:11px;font-family:inherit;white-space:nowrap}
      .priv-master.on{background:var(--accent,var(--acc,#4a7cff));color:var(--text_on_accent,#fff)}`;
    document.head.appendChild(st);
  }

  document.addEventListener('click', (e) => {
    const t = e.target.closest && e.target.closest('[data-priv]');
    if (!t) return;
    e.preventDefault(); e.stopPropagation();
    const k = t.getAttribute('data-priv');
    if (allUntil > Date.now()) return;                      // everything is already revealed
    if (isOpen(k)) open.delete(k); else open.set(k, Date.now() + ONE_MS);
    notify();
  }, true);

  setInterval(() => {                                       // auto re-hide
    const n = Date.now();
    let changed = false;
    for (const [k, t] of open) if (t <= n) { open.delete(k); changed = true; }
    if (allUntil && allUntil <= n) { allUntil = 0; changed = true; }
    if (changed) notify();
    masters.forEach((m) => m.paint());
  }, 1000);

  const Priv = {
    /** HTML string for a hidden / revealed value (safe for innerHTML). */
    html(text, kind) {
      text = text == null ? '' : String(text);
      if (!text) return '';
      const k = hash((kind || '') + '|' + text);
      if (isOpen(k)) return `<span class="priv priv-on" data-priv="${k}" title="Click to hide">${esc(text)}</span>`;
      return `<span class="priv priv-off" data-priv="${k}" title="Hidden to protect your network info - click to reveal">${SHAPE[kind || kindOf(text)] || SHAPE.text}<i>show</i></span>`;
    },
    el(text, kind) { const t = document.createElement('span'); t.innerHTML = Priv.html(text, kind); return t.firstChild || document.createTextNode(''); },
    /** "ip:port" - hides only the address part when `mine` is true. */
    addr(addr, mine) {
      addr = addr == null ? '' : String(addr);
      if (!addr || !mine) return esc(addr);
      let host = addr, port = '';
      if (addr.startsWith('[')) { const i = addr.indexOf(']:'); if (i > 0) { host = addr.slice(1, i); port = addr.slice(i + 2); } }
      else if ((addr.match(/:/g) || []).length === 1) { [host, port] = addr.split(':'); }
      return Priv.html(host) + (port ? ':' + esc(port) : '');
    },
    addrEl(addr, mine) { const s = document.createElement('span'); s.innerHTML = Priv.addr(addr, mine); return s; },
    /** Plain-text version for places that cannot hold markup (alerts, notifications). */
    text(text, mine, kind) {
      if (!mine) return text;
      return isOpen(hash((kind || '') + '|' + text)) ? text : (SHAPE[kind || kindOf(String(text))] || SHAPE.text);
    },
    isOpen: (text, kind) => isOpen(hash((kind || '') + '|' + text)),
    esc,
    revealed: () => allUntil > Date.now(),
    revealAll(on) { allUntil = on ? Date.now() + ALL_MS : 0; notify(); masters.forEach((m) => m.paint()); },
    onChange(fn) { subs.add(fn); return () => subs.delete(fn); },
    masterButton() {
      const b = document.createElement('button');
      b.className = 'priv-master';
      b.title = 'Your real IP / Wi-Fi / device details are hidden. Reveal them for 30 seconds.';
      b.paint = () => {
        const left = Math.max(0, Math.ceil((allUntil - Date.now()) / 1000));
        b.classList.toggle('on', left > 0);
        b.textContent = left > 0 ? `Hide my info · ${left}s` : 'Reveal my info';
      };
      b.addEventListener('click', () => Priv.revealAll(allUntil <= Date.now()));
      masters.add(b); b.paint();
      return b;
    },
  };
  window.Priv = Priv;
})();

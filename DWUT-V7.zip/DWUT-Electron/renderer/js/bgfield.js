'use strict';
/* bgfield - the animated gradient starfield, shared by the main window, the Task Manager and the Run window.
   Every colour is read from the LIVE CSS theme variables on <html> (--bg_shell, --bg_base, --accent, --info ...), so it is the
   user's selected theme in every window, including the light themes, and it cross-fades whenever those variables change
   (a MutationObserver watches them, so no window needs to tell it anything).  One canvas behind the whole window; the UI is
   translucent glass on top of it. */
(function () {
  const cv = document.createElement('canvas');
  cv.id = 'bgfield'; cv.setAttribute('aria-hidden', 'true');
  document.body.insertBefore(cv, document.body.firstChild);
  const ctx = cv.getContext('2d');
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w = 0, h = 0, stars = [], shooters = [], raf = 0, last = 0, clock = 0;
  let cur = null, prev = null, fade = 1;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const SHOOTING_STARS = false;   // set true to bring back the occasional streak

  // ── colour helpers ──
  function rgb(c, fb) {
    c = String(c || '').trim();
    let m = /^#([0-9a-f]{6})$/i.exec(c);
    if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    m = /^#([0-9a-f]{3})$/i.exec(c);
    if (m) return m[1].split('').map((x) => parseInt(x + x, 16));
    m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i.exec(c);
    if (m) return [+m[1], +m[2], +m[3]];
    return fb || [20, 24, 32];
  }
  const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
  const css = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

  const lum = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  function palette() {
    const cs = getComputedStyle(document.documentElement), V = (k) => cs.getPropertyValue('--' + k);
    const shell = rgb(V('bg_shell'), [13, 15, 18]), base = rgb(V('bg_base'), [19, 22, 26]);
    const acc = rgb(V('accent'), [74, 124, 255]), info = rgb(V('info') || V('accent_dim') || V('accent'), acc), dim = rgb(V('accent_dim') || V('accent'), acc);
    const light = lum(base) > .6;
    const white = [255, 255, 255], black = [0, 0, 0];
    // gradient base: from the shell colour, pulled slightly toward the accent so every theme gets its own tint
    const c0 = mix(shell, acc, light ? 0.10 : 0.12), c1 = mix(base, dim, light ? 0.06 : 0.10), c2 = mix(shell, black, light ? 0 : 0.35);
    return {
      light, stops: [c0, c1, c2],
      blobs: [[.14, .12, .62, acc, light ? .20 : .30, 1], [.92, .90, .58, info, light ? .15 : .22, 2], [.72, .16, .46, mix(acc, info, .5), light ? .10 : .16, 3], [.30, .88, .42, dim, light ? .08 : .14, 4]],
      star: light ? mix(dim, black, .35) : mix(white, acc, .22), star2: light ? dim : mix(white, info, .35), glow: acc,
      sig: [shell, base, acc, info, dim].join('|'),
    };
  }

  function build() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr); cv.style.width = w + 'px'; cv.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.max(180, Math.min(560, Math.floor(w * h / 3800)));
    // plain dot stars: a wide range of sizes (tiny pinpricks up to bigger bright dots). Every star flickers on its own two
    // overlapping rhythms and wanders on its own slowly-turning heading, so nothing ever sits still.
    stars = Array.from({ length: n }, () => {
      const u = Math.random(), r = .45 + Math.pow(u, 2.6) * 2.4;          // many small, a few large
      const big = (r - .45) / 2.4;
      return { x: Math.random() * w, y: Math.random() * h, r,
               a: .45 + .55 * Math.min(1, big * 1.4 + Math.random() * .5),
               tw: rnd(1.2, 5.5), ph: rnd(0, 6.28), tw2: rnd(.4, 2.2), ph2: rnd(0, 6.28),
               v: (5 + big * 22) * rnd(.7, 1.4), ang: rnd(0, 6.28), turn: rnd(-.5, .5), wob: rnd(.4, 1.6), wph: rnd(0, 6.28), alt: Math.random() < .3 };
    });
  }

  function paint(p, alpha, t) {
    ctx.globalAlpha = alpha;
    const g = ctx.createLinearGradient(0, 0, w * .5, h);
    g.addColorStop(0, css(p.stops[0], 1)); g.addColorStop(.55, css(p.stops[1], 1)); g.addColorStop(1, css(p.stops[2], 1));
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const R = Math.max(w, h);
    for (const [x, y, r, c, a, k] of p.blobs) {        // the gradient itself moves: every blob drifts on its own slow orbit
      const px = w * x + (reduce ? 0 : Math.sin(t * .00018 * k + k) * w * .11), py = h * y + (reduce ? 0 : Math.cos(t * .00015 * k + k * 2) * h * .11);
      const gr = ctx.createRadialGradient(px, py, 0, px, py, R * r);
      gr.addColorStop(0, css(c, a)); gr.addColorStop(1, css(c, 0));
      ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
    }
    // slow aurora ribbons sweeping across the sky
    for (let i = 0; i < 2; i++) {
      const c = i ? p.blobs[1][3] : p.blobs[0][3], ph = t * (reduce ? 0 : .00007) * (i ? -1 : 1) + i * 2.4;
      const cx = w * (.5 + .55 * Math.sin(ph)), cy = h * (.30 + .38 * i + .08 * Math.cos(ph * 1.7)), len = Math.max(w, h) * .75;
      const gr = ctx.createRadialGradient(cx, cy, 0, cx, cy, len * .5);
      gr.addColorStop(0, css(c, p.light ? .10 : .17)); gr.addColorStop(1, css(c, 0));
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(-.35 + .15 * Math.sin(ph)); ctx.scale(1, .22); ctx.translate(-cx, -cy);
      ctx.fillStyle = gr; ctx.fillRect(cx - len, cy - len, len * 2, len * 2); ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  function frame(ts) {
    raf = requestAnimationFrame(frame);
    if (ts - last < 22) return;
    const dt = Math.min(.1, (ts - last) / 1000); last = ts; clock = ts;
    if (fade < 1) fade = Math.min(1, fade + dt / .6);
    ctx.clearRect(0, 0, w, h);
    if (prev && fade < 1) { paint(prev, 1, ts); paint(cur, fade, ts); } else { prev = null; paint(cur, 1, ts); }
    const p = cur, c1 = `rgb(${p.star})`, c2 = `rgb(${p.star2})`;
    for (const s of stars) {
      // flicker: two sine rhythms multiplied, so brightness swings between almost-off and full, plus the odd sudden blink
      let k = .12 + .88 * (.5 + .5 * Math.sin(ts / 1000 * s.tw + s.ph)) * (.55 + .45 * Math.sin(ts / 1000 * s.tw2 + s.ph2));
      if (Math.random() < .004) k *= .15;
      // wander: heading slowly turns (random walk) + a little sideways wobble, wraps on every edge
      s.ang += s.turn * dt + (Math.random() - .5) * .6 * dt;
      s.x += (Math.cos(s.ang) * s.v + Math.cos(ts / 1000 * s.wob + s.wph) * 3) * dt;
      s.y += (Math.sin(s.ang) * s.v + Math.sin(ts / 1000 * s.wob * .8 + s.wph) * 3) * dt;
      if (s.x > w + 4) s.x = -4; else if (s.x < -4) s.x = w + 4;
      if (s.y > h + 4) s.y = -4; else if (s.y < -4) s.y = h + 4;
      ctx.globalAlpha = Math.min(1, s.a * k) * (p.light ? .85 : 1); ctx.fillStyle = s.alt ? c2 : c1;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.2832); ctx.fill();
    }
    ctx.globalAlpha = 1;
    if (SHOOTING_STARS && !reduce && Math.random() < .010 && shooters.length < 3) shooters.push({ x: rnd(w * .1, w * .8), y: rnd(0, h * .4), vx: rnd(420, 620), vy: rnd(150, 280), life: 0, max: rnd(.7, 1.1) });
    for (let i = shooters.length - 1; i >= 0; i--) {
      const s = shooters[i]; s.life += dt; s.x += s.vx * dt; s.y += s.vy * dt;
      const q = s.life / s.max; if (q >= 1) { shooters.splice(i, 1); continue; }
      const len = 110, ang = Math.atan2(s.vy, s.vx), gr = ctx.createLinearGradient(s.x, s.y, s.x - Math.cos(ang) * len, s.y - Math.sin(ang) * len), al = Math.sin(q * Math.PI);
      gr.addColorStop(0, css(p.star, .9 * al)); gr.addColorStop(1, css(p.star, 0));
      ctx.strokeStyle = gr; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - Math.cos(ang) * len, s.y - Math.sin(ang) * len); ctx.stroke();
    }
  }

  function refresh() { const n = palette(); if (cur && n.sig === cur.sig) return; prev = cur; cur = n; fade = prev ? 0 : 1; }
  window.addEventListener('dwut-theme', refresh);
  // any change to the theme variables (inline style on <html>, or its theme attributes) re-reads the palette
  try { new MutationObserver(refresh).observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'class', 'data-light', 'data-theme'] }); } catch {}
  window.addEventListener('resize', build);
  document.addEventListener('visibilitychange', () => { if (document.hidden) cancelAnimationFrame(raf); else { last = 0; raf = requestAnimationFrame(frame); } });
  cur = palette(); build(); raf = requestAnimationFrame(frame);
})();

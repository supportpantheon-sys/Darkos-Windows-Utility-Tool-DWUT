'use strict';
const { contextBridge, ipcRenderer, clipboard } = require('electron');
const listeners = new Map();      // event -> Set<fn>

ipcRenderer.on('backend:event', (_e, name, data) => {
  const set = listeners.get(name);
  if (set) for (const fn of [...set]) { try { fn(data); } catch (err) { console.error('event handler', name, err); } }
  const all = listeners.get('*');
  if (all) for (const fn of [...all]) { try { fn(name, data); } catch { /* ignore */ } }
});
ipcRenderer.on('win:state', (_e, s) => { const set = listeners.get('win:state'); if (set) for (const fn of set) fn(s); });

contextBridge.exposeInMainWorld('dwut', {
  call: (method, params) => ipcRenderer.invoke('backend:call', method, params || {}),
  ready: () => ipcRenderer.invoke('backend:ready'),
  on: (name, fn) => { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(fn); return () => listeners.get(name).delete(fn); },
  win: {
    minimize: () => ipcRenderer.send('win:minimize'),
    maximize: () => ipcRenderer.send('win:maximize'),
    close: () => ipcRenderer.send('win:close'),
    resize: (dw, dh, ow, oh) => ipcRenderer.send('win:resize', dw, dh, ow, oh),
    size: () => ipcRenderer.invoke('win:size'),
  },
  dialog: { save: (o) => ipcRenderer.invoke('dialog:save', o), open: (o) => ipcRenderer.invoke('dialog:open', o) },
  openExternal: (u) => ipcRenderer.invoke('shell:open', u),
  updateNow: () => ipcRenderer.invoke('app:update-now'),
  relaunchAdmin: () => ipcRenderer.invoke('app:relaunch-admin'),
  hasStartup: () => ipcRenderer.invoke('app:has-startup'),
  addToStartup: () => ipcRenderer.invoke('app:add-startup'),
  copy: (t) => clipboard.writeText(String(t)),
  openTaskManager: () => ipcRenderer.send('tm:open'),
  pushTheme: (themeData) => ipcRenderer.send('tm:theme-push', themeData),
});

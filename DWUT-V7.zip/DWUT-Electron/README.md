# DWUT - Electron edition

The CustomTkinter UI is replaced by an Electron UI. **All logic is still the original Python**
(`backend/modules/*`, PowerShell scripts included) - Electron talks to it over a JSON pipe
(`backend/server.py`). The UI no longer builds thousands of Tk widgets, which was the source of the lag.

## Install / run
* One-liner (after you publish this zip as a GitHub release asset):
  `irm https://raw.githubusercontent.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT/main/bootstrap.ps1 | iex`
* From this folder: right-click `bootstrap.ps1` > Run with PowerShell (or `powershell -ep bypass -File bootstrap.ps1`).
  It installs Python (if missing), the Electron runtime (SHA-256 verified), the pip packages, makes a
  desktop shortcut and launches. Later: `run.bat`.
* Dev: `npm install` then `npm start` (needs Python 3.10+ and `pip install -r requirements.txt`).

## Fixes in this version
**Disk Cleanup (Tools)** - event logs: only the first 50 of 1000+ channels were cleared; now every channel
(parallel). Temp: read-only files made whole folders fail silently; junctions are no longer followed;
"freed" MB is now measured per deleted file instead of estimated; in-use files are counted and reported;
duplicate paths (TEMP == LocalAppData\Temp) are de-duplicated; long paths and admin ownership fallback.

**Game Booster** - power plan: `powercfg /duplicatescheme` returns a NEW GUID, the old code activated the
template GUID so it always failed. Now parsed + verified; falls back Ultimate > High > tuned copy of the
active plan (Modern Standby laptops). The typed game name was never turned into a PID, so priority was never
set - now matched against running processes. **Empty name = auto-detect** (known-game list, game folders,
`*-Win64-Shipping.exe`, fullscreen foreground window) *after* background apps are closed, and a watcher
boosts a game launched later. **Apply Boost opens an exclusion popup** (untick Discord etc.). Launchers
that are the game's parent (e.g. Steam) are protected automatically; anti-cheat/GPU/system processes are never killed.

**FPS Unlocker** - Roblox: old method scanned the heap for every `60.0` double and overwrote it (wrong
units, corrupts memory, blocked by Hyperion). Now writes the `DFIntTaskSchedulerTargetFps` client setting
into every Roblox version (+ Bloxstrap/Fishstrap/Voidstrap). **Also Fortnite** (`FrameRateLimit` in
GameUserSettings.ini) **and Minecraft Java** (`maxFps`). Nothing touches game memory, so it is anti-cheat safe.
Valorant/Apex/etc. are deliberately not offered: they have no config cap to remove. Restart the game after enabling.

**Deep Clean** - download layer rewritten (`modules/cleaner/downloader.py`): mirror lists, x64/x86/ARM64,
validates PE/ZIP headers (old code saved HTML error pages as .exe), extracts ZIPs (MBAR, GMER), checks
Authenticode, `python -m modules.cleaner.downloader --check` probes every link. Wrong links fixed
(HitmanPro, MSRT, FRST, KVRT, Norton NPE, Stinger...). Discontinued tools removed (aswMBR, Spybot, ClamWin).
Correct silent flags for rkill/AdwCleaner/TDSSKiller/MSRT/KVRT/Stinger; GUI-only tools are now guided
manual steps instead of hanging 30 min. Hibernate/sleep are now actually restored. Defrag no longer
runs on NVMe. `bcdboot` no longer pollutes UEFI systems. Explorer repair no longer pops a window. WU repair
renames instead of deleting. PSWindowsUpdate/NuGet prompt fixed. The DNS dropdown is now wired in. Pause/Skip work.
Previously silent no-op steps (VC++/DirectX/.NET repair, exports, installer cleanup, pagefile, visual effects,
privacy) are implemented; the ones that are deliberately not automated now say `[SKIP]` in the log.

## Honest limits
Built and regression-tested on Linux with Windows APIs stubbed: UI renders (all 8 pages, 0 errors), the RPC
layer, disk-cleanup logic and FPS file logic are tested. Real Windows behaviour (powercfg, wevtutil, tool
downloads, UAC) and `bootstrap.ps1` itself could not be executed here - run it once and send me the log if
anything misbehaves. Run `python -m modules.cleaner.downloader --check` on your PC to confirm every Deep Clean link.

## Update 3 - proxy + Deep Clean
**Proxy Connect** now goes through a local failover relay (`modules/proxy/relay.py`): Windows is pointed at
`127.0.0.1:<port>` (a plain HTTP proxy every app understands) and the relay talks HTTP/SOCKS4/SOCKS5 to the real
proxy, switches to the next verified proxy when one dies, and the connection is tested against YouTube before it
reports success. The system proxy is cleared when DWUT exits (or on next start after a crash). PySocks is now a
required dependency (without it every SOCKS proxy silently failed the checker).
**Deep Clean** manual-tool guides never close by themselves (Next / Retry / Open download page / Skip / Cancel),
show the exact download error, and downloads try direct -> system proxy -> curl.exe. Every tool DWUT downloaded or
installed is removed at the end (also when you cancel); a Malwarebytes you already had is left alone.
"Check Tool Links" (Cleaner page) reports which download links are alive.

## Update 4 - VPN mode (Proxy Center > VPN)
One switch turns the proxy pool into a VPN-style connection: fetches + checks proxies automatically if you have none,
tests each for YouTube / the video CDN (googlevideo) / real speed, connects through the local failover relay, verifies,
then arms: kill switch (firewall allows only LAN + your proxy servers), DNS-leak block, IPv6 block, Chrome/Edge/Brave
WebRTC+QUIC policies, Microsoft Store app loopback exemptions, WinHTTP proxy. Health check every 20 s with automatic
failover + fresh-proxy refill; optional timed server rotation; per-country servers.
Everything is recorded in `%LOCALAPPDATA%\DWUT\vpn_state.json` and undone on disconnect, on exit, and on the next start
after a crash. If you ever lose internet: run `Repair-Internet.bat` (or the red "Restore Internet" button).
Limits (inherent to proxies): only apps that follow Windows proxy settings are covered (browsers, Discord, Store apps,
most clients) - not games or apps that open raw UDP sockets; the kill switch still stops those from leaking, but they will
not work while VPN mode is on. Free proxies have free-proxy speed: expect SD-HD video, not 4K.

## Update 5 (version 5)
* **USB Flasher** (new sidebar page): Flash a USB stick (pick drive -> pick OS -> automatic download, checksum, write, verify),
  Ventoy multi-boot stick, Restore stick to normal, Back up stick to .img, ISO library. Windows 10/11 (official Microsoft ISO
  via Fido, FAT32 + split WIM + boot code, UEFI+BIOS), Ubuntu, Mint, Fedora, Debian, Arch, openSUSE, Alpine, Kali, Kali Purple,
  Parrot, BlackArch, Qubes, Tails, TempleOS (via Ventoy), Hiren's PE, or your own ISO/IMG. Only USB disks are ever shown, the
  drive is re-validated right before erasing, and nothing is erased until the download + checksum succeeded.
* **VPN location changer**: pick a country (live server counts), hot-switch while connected; kill switch stays armed.
* Power plans: Ultimate/Extreme rewritten (verified activation, locale-proof detection, Modern-Standby fallback); the switch
  state is re-read from the live active plan at startup and every time the Optimizer opens.
* Update notice is now a 5-second top-right toast with an Update now button (one click installs); Settings shows version 5 and
  "Check for Updates" opens the GitHub page; all non-red buttons follow the theme accent colour.

## Update 6
* **VPN** is now its own sidebar category. "Automatic" carries the whole PC (browsers, Discord voice, games, music, video) through a
  full-system tunnel with a built-in kill switch and DNS protection; choosing a specific country uses the shared-server pool.
  If Automatic can't start on a network it falls back to shared servers with a short note. Proxy Center keeps its own **Proxy VPN**
  button (Checker tab) for the proxy-based version.
* Proxy relay no longer hops servers on every hiccup: failures that belong to the destination never penalise the server, other servers
  are used for that one connection only, and the active server changes only after repeated hard failures.
* Deep Clean: a "Protect programs" pop-up before starting; DWUT's own processes are always protected (RKill gets a whitelist, the
  built-in terminator skips them); logs whether DWUT was touched.
* Game Booster: 130+ known games. FPS unlocker: Roblox writes extra client settings to every install (incl. Store version and
  Bloxstrap/Fishstrap), edits the in-game cap, offers **Uncapped**, and offers to close the game so the setting is read.
* **VM Builder** (new): pick drive -> OS (same catalog as the flasher) -> specs. VirtualBox is downloaded/installed silently and the VM
  is created (unattended install where the ISO supports it); VMware gets the ISO plus a click-by-click guide with your exact specs.
* Update-all-apps: asks what to do about apps whose version winget can't read. Resize square removed.

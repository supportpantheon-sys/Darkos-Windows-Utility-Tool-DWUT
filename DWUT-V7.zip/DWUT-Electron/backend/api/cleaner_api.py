"""api/cleaner_api.py — Light/Deep Clean engine bridge."""
from __future__ import annotations

import os
import platform
import subprocess
import sys
import threading
from pathlib import Path

from core.logger import get_logger
from server import emit, rpc

_log = get_logger("api.cleaner")

_engine = None
_manual_evt: threading.Event | None = None
_manual_result = [True]


def _detect() -> tuple[int, str]:
    try:
        build = sys.getwindowsversion().build
        ver = 11 if build >= 22000 else 10
        ed = platform.win32_edition() if hasattr(platform, "win32_edition") else "Windows"
        return ver, f"Windows {ver} {ed} (Build {build})"
    except Exception:
        ver = 11 if "11" in platform.version() or "11" in platform.release() else 10
        return ver, f"Windows {ver}"


@rpc("cleaner.static")
def cleaner_static():
    from modules.cleaner.registry import ALL_PHASES, LIGHT_CLEAN_STEPS
    ver, label = _detect()
    return {
        "win_ver": ver, "os_label": label, "light_steps": sorted(LIGHT_CLEAN_STEPS),
        "phases": [dict(number=p.number, name=p.name, description=p.description,
                        steps=[dict(id=s.id, label=s.label, auto=s.auto, win10=s.win10, win11=s.win11, enabled=getattr(s, 'enabled', True)) for s in p.steps])
                   for p in ALL_PHASES],
    }


def _finish(eng, ok):
    """Always remove every tool DWUT downloaded/installed - even if the user cancelled."""
    from modules.cleaner import fixes
    try:
        emit("cleaner.log", "Final cleanup: removing any security tools DWUT downloaded…")
        fixes.cleanup_session(lambda m: emit("cleaner.log", m))
    except Exception as exc:
        emit("cleaner.log", f"[WARN] cleanup: {exc}")
    eng._thread_alive = False
    emit("cleaner.done", {"completed": ok})


@rpc("cleaner.start")
def cleaner_start(win_ver: int, steps: list, dns: str = "Keep Current", protect: list | None = None):
    global _engine
    from modules.cleaner import fixes as _fixes
    _fixes.set_protection(protect or [])
    from modules.cleaner.engine import CleanerEngine
    from modules.cleaner.registry import STEP_MAP
    if _engine is not None and getattr(_engine, "_thread_alive", False):
        return False

    active = set(steps)
    # DNS provider from the dropdown (the original never wired this through)
    ips = {"1.1.1.1 (Cloudflare)": "1.1.1.1", "8.8.8.8 (Google)": "8.8.8.8", "9.9.9.9 (Quad9)": "9.9.9.9"}
    if dns in ips and "opt_dns" in STEP_MAP:
        try:
            STEP_MAP["opt_dns"]._dns_provider = ips[dns]
        except Exception:
            object.__setattr__(STEP_MAP["opt_dns"], "_dns_provider", ips[dns])
        active.add("opt_dns")
    else:
        active.discard("opt_dns")

    def on_manual(step):
        global _manual_evt
        _manual_evt = threading.Event()
        _manual_result[0] = True
        emit("cleaner.manual", {"id": step.id, "label": step.label})
        _manual_evt.wait(timeout=3600)
        return _manual_result[0]

    eng = CleanerEngine(
        win_version=win_ver,
        on_log=lambda m: emit("cleaner.log", m),
        on_step_start=lambda sid, lbl: emit("cleaner.step_start", {"id": sid, "label": lbl}),
        on_step_done=lambda sid, ok: emit("cleaner.step_done", {"id": sid, "success": ok}),
        on_phase_start=lambda n, name: emit("cleaner.phase_start", {"num": n, "name": name}),
        on_phase_done=lambda n: emit("cleaner.phase_done", {"num": n}),
        on_done=lambda ok: _finish(eng, ok),
        on_manual_step=on_manual,
    )
    eng.configure(active)
    eng._thread_alive = True
    _engine = eng
    threading.Thread(target=eng.run, daemon=True, name="cleaner-engine").start()
    return len(active)


@rpc("cleaner.running_tasks")
def cleaner_running_tasks():
    """Programs the user can choose to protect from the task terminators.  DWUT's own are flagged and locked."""
    import psutil
    from modules.cleaner import fixes
    own = fixes.own_tree_pids()
    sysroot = os.environ.get("SystemRoot", r"C:\Windows").lower()
    try:
        me_user = psutil.Process().username()
    except Exception:
        me_user = None
    groups: dict = {}
    for p in psutil.process_iter(["pid", "name", "username", "exe", "memory_info"]):
        try:
            exe = (p.info.get("exe") or "")
            if not exe or exe.lower().startswith(sysroot) or (me_user and p.info.get("username") != me_user):
                continue
            nm = p.info["name"] or ""
            g = groups.setdefault(nm.lower(), {"name": nm, "count": 0, "ram_mb": 0.0, "dwut": False})
            g["count"] += 1
            g["ram_mb"] += (p.info["memory_info"].rss if p.info.get("memory_info") else 0) / 1048576
            g["dwut"] = g["dwut"] or p.info["pid"] in own
        except Exception:
            continue
    out = sorted(groups.values(), key=lambda g: (not g["dwut"], -g["ram_mb"]))
    for g in out:
        g["ram_mb"] = round(g["ram_mb"], 1)
    return out


@rpc("cleaner.control")
def cleaner_control(action: str):
    if _engine is None:
        return False
    {"pause": _engine.pause, "resume": _engine.resume, "cancel": _engine.cancel, "skip": _engine.skip_current}[action]()
    if action == "cancel" and _manual_evt:
        _manual_result[0] = False
        _manual_evt.set()
    return True


@rpc("cleaner.manual_reply")
def cleaner_manual_reply(choice: str):
    """choice: done | skip | cancel"""
    _manual_result[0] = choice != "cancel"
    if choice == "cancel" and _engine:
        _engine.cancel()
    if _manual_evt:
        _manual_evt.set()
    return True


def _mbam_installed() -> Path | None:
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    for c in (Path(pf) / "Malwarebytes" / "Malwarebytes.exe", Path(pf86) / "Malwarebytes" / "Malwarebytes.exe",
              Path(pf) / "Malwarebytes" / "MBAMService" / "Malwarebytes.exe",
              Path(pf) / "Malwarebytes" / "Anti-Malware" / "mbam.exe", Path(pf86) / "Malwarebytes" / "Anti-Malware" / "mbam.exe"):
        if c.exists():
            return c
    return None


@rpc("cleaner.manual_launch")
def cleaner_manual_launch(step_id: str):
    """Download (if needed) and launch a GUI tool for a manual step. Reports every outcome; never auto-skips."""
    from modules.cleaner import fixes
    from modules.cleaner.downloader import LAST_ERRORS, PAGES, download

    def _status(text, ready=False, failed=False, detail=""):
        emit("cleaner.tool_status", {"id": step_id, "text": text, "ready": ready, "failed": failed, "detail": detail, "page": PAGES.get(step_id, "")})

    def _run():
        try:
            if fixes.is_installed(step_id):
                fixes.PREEXISTING.add(step_id)
            path = None
            if step_id == "malwarebytes":
                path = _mbam_installed()
                if not path:
                    _status("Malwarebytes is not installed - downloading the installer…")
                    setup = download(step_id, on_log=lambda m: emit("cleaner.log", m))
                    if setup:
                        fixes.LAUNCHED.add(step_id)
                        _status("Installer downloaded. Complete the Malwarebytes setup window, then continue…")
                        try:
                            subprocess.Popen([str(setup)], cwd=str(Path(setup).parent)).wait()
                        except Exception as exc:
                            return _status(f"Could not start the installer: {exc}", failed=True)
                        path = _mbam_installed()
            else:
                _status("Downloading tool…")
                path = download(step_id, on_log=lambda m: emit("cleaner.log", m))
            if not path:
                why = "; ".join(LAST_ERRORS.get(step_id, [])[-3:]) or "unknown error"
                return _status("Could not download this tool automatically.", failed=True, detail=why)
            fixes.LAUNCHED.add(step_id)
            try:
                subprocess.Popen([str(path)], cwd=str(Path(path).parent))
            except OSError as exc:
                return _status(f"Downloaded but could not be opened ({exc}).", failed=True, detail=str(path))
            _status("Tool is open (check your taskbar if you don't see it). Follow the steps above, then click Next.", ready=True)
        except Exception as exc:
            _status(f"Unexpected error: {exc}", failed=True)

    threading.Thread(target=_run, daemon=True).start()
    return True


@rpc("cleaner.check_links")
def cleaner_check_links():
    from modules.cleaner.downloader import check_links
    return check_links()

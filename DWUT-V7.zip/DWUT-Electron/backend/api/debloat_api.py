"""api/debloat_api.py — Debloat page data + actions (logic stays in modules/debloat)."""
from __future__ import annotations

from core.events import Events, bus
from core.worker import worker
from server import rpc


@rpc("debloat.static")
def debloat_static():
    from modules.debloat.operations import BLOATWARE_DB, PRIVACY_ITEMS, privacy_applies
    from modules.system.platform_info import get_os_info, is_windows_11
    info = get_os_info()
    mine = "Windows 11" if is_windows_11() else "Windows 10"
    return {
        # Only this PC's own bloatware list - a Windows 11 PC never sees Windows 10 packages and vice versa.
        "bloat": {mine: [dict(e) for e in BLOATWARE_DB.get(mine, [])]},
        "privacy": [dict(i) for i in PRIVACY_ITEMS if privacy_applies(i)],
        "is_win11": is_windows_11(),
        "os": info,
    }


@rpc("debloat.scan")
def debloat_scan():
    from modules.debloat.operations import scan_installed_appx
    return scan_installed_appx()


@rpc("debloat.remove")
def debloat_remove(entries: list):
    from modules.debloat.operations import remove_bloatware
    worker.submit(remove_bloatware, entries, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Removal failed: {e}"))
    return True


@rpc("debloat.apply_privacy")
def debloat_apply_privacy(keys: list):
    from modules.debloat.operations import apply_privacy_items
    worker.submit(apply_privacy_items, keys, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Privacy apply failed: {e}"))
    return True


@rpc("debloat.recall_status")
def debloat_recall_status():
    from modules.debloat.operations import check_recall_status
    return check_recall_status()


@rpc("debloat.recall_disable")
def debloat_recall_disable():
    from modules.debloat.operations import apply_features
    return apply_features(["recall"])


@rpc("debloat.restore_point")
def debloat_restore_point():
    from modules.debloat.operations import create_restore_point
    return bool(create_restore_point("DWUT Manual Restore Point"))


@rpc("debloat.open_restore")
def debloat_open_restore():
    from modules.debloat.operations import open_system_restore
    worker.submit(open_system_restore)
    return True

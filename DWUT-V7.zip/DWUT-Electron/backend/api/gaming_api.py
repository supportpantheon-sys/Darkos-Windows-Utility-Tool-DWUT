"""api/gaming_api.py — FPS unlocker + Game Booster."""
from __future__ import annotations

from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from server import emit, rpc

_log = get_logger("api.gaming")


# ── FPS unlocker ──────────────────────────────────────────────────────────────

@rpc("gaming.fps_games")
def fps_games():
    from modules.gaming.fps_unlock import fps_unlocker
    return fps_unlocker.list_games()


@rpc("gaming.fps_enable")
def fps_enable():
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.enable)
    return True


@rpc("gaming.fps_disable")
def fps_disable():
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.disable)
    return True


@rpc("gaming.fps_target")
def fps_target(fps: int):
    from modules.gaming.fps_unlock import fps_unlocker
    fps_unlocker.set_target_fps(int(fps))
    return True


@rpc("gaming.fps_game")
def fps_game(game: str):
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.set_game, game)
    return True


# ── Game booster ──────────────────────────────────────────────────────────────

@rpc("gaming.boost_candidates")
def boost_candidates():
    from modules.gaming.booster import list_termination_candidates
    return list_termination_candidates()


@rpc("gaming.boost_apply")
def boost_apply(game_name: str = "", only: list | None = None):
    """only = exe names (lower-case) the user left ticked in the popup; None = defaults."""
    from modules.gaming.booster import booster

    def _run():
        return booster.activate(game_name, only_names={n.lower() for n in only} if only is not None else None)

    def _err(e):
        _log.error("Boost activate failed: %s", e)
        emit("gaming.boost_error", {"message": str(e)})

    worker.submit(_run, on_error=_err)
    return True


@rpc("gaming.boost_restore")
def boost_restore():
    from modules.gaming.booster import booster
    worker.submit(booster.deactivate)
    return True


@rpc("gaming.boost_state")
def boost_state():
    from modules.gaming.booster import booster
    return {"active": booster.is_active}


@rpc("gaming.fps_close_game")
def fps_close_game():
    from modules.gaming.fps_unlock import fps_unlocker
    return fps_unlocker.restart_game()


def _detect_running_game() -> tuple[str, str]:
    """Scans running processes and returns (game_id, display_name) for any active game."""
    try:
        import psutil
        from modules.gaming.booster import _KNOWN_GAMES
        for p in psutil.process_iter(["pid", "name"]):
            try:
                n = (p.info["name"] or "").lower()
                if n in _KNOWN_GAMES:
                    dname = _KNOWN_GAMES[n]
                    gid = "roblox" if "roblox" in n else ("fortnite" if "fortnite" in n else ("minecraft" if "minecraft" in n or "javaw" in n else "roblox"))
                    return gid, dname
            except Exception:
                pass
    except Exception:
        pass
    return "roblox", "Auto-Detect"


@rpc("gaming.detected_game")
def gaming_detected_game():
    """Returns the currently running detected game, or auto-detect."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    return {
        "detected": dname != "Auto-Detect",
        "game_id": gid,
        "game_name": dname,
        "active": fps_unlocker.is_active,
    }


@rpc("gaming.fps_state")
def fps_state():
    """Return current FPS unlocker state — used by the tray to label the menu item."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    return {"active": fps_unlocker.is_active, "game_name": dname, "game_id": gid}


@rpc("gaming.fps_toggle")
def fps_toggle():
    """Toggle FPS unlock on/off — called from the system tray context menu with auto-detected game."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    if fps_unlocker.is_active:
        worker.submit(fps_unlocker.disable)
        return {"active": False, "game_name": dname, "game_id": gid}
    else:
        fps_unlocker.set_game(gid)
        worker.submit(fps_unlocker.enable)
        return {"active": True, "game_name": dname, "game_id": gid}

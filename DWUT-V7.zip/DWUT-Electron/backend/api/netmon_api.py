"""api/netmon_api.py - RPC for the multi-network monitor (modules/network/netwatch.py)."""
from __future__ import annotations

from core.logger import get_logger
from modules.network.monitor import net_monitor
from modules.network.netwatch import netwatch
from server import emit, rpc

_log = get_logger("api.netmon")
_loaded = False


def _ensure() -> None:
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        from app.config import config
        netwatch.load(config.netmon_prefs or {}, emit)
    except Exception as exc:
        _log.warning("netmon prefs: %s", exc)
        netwatch._emit = emit


@rpc("netmon.state")
def netmon_state():
    _ensure()
    return netwatch.state()


@rpc("netmon.start")
def netmon_start():
    _ensure()
    netwatch.start()
    return True


@rpc("netmon.stop")
def netmon_stop():
    _ensure()
    netwatch.stop()
    return True


@rpc("netmon.set_prefs")
def netmon_set_prefs(patch: dict):
    _ensure()
    return netwatch.set_prefs(patch or {})


@rpc("netmon.target_add")
def netmon_target_add(text: str):
    _ensure()
    return netwatch.add_targets(text)


@rpc("netmon.target_remove")
def netmon_target_remove(text: str):
    _ensure()
    return netwatch.remove_target(text)


@rpc("netmon.target_scan")
def netmon_target_scan(text: str):
    _ensure()
    return netwatch.scan_target(text)


@rpc("netmon.devices_scan")
def netmon_devices_scan():
    _ensure()
    netwatch.scan_devices(True)
    return True


@rpc("netmon.device_trust")
def netmon_device_trust(mac: str):
    _ensure()
    return netwatch.trust_device(mac)


@rpc("netmon.allow")
def netmon_allow(entry: str):
    _ensure()
    e = (entry or "").strip().lower()
    if e and e not in netwatch.prefs["allow"]:
        net_monitor.add_allow(e)
        netwatch.prefs["allow"].append(e)
        netwatch._save()
        netwatch._build()
    return True


@rpc("netmon.unallow")
def netmon_unallow(entry: str):
    _ensure()
    e = (entry or "").strip().lower()
    net_monitor.remove_allow(e)
    if e in netwatch.prefs["allow"]:
        netwatch.prefs["allow"].remove(e)
    netwatch._save()
    netwatch._build()
    return True


@rpc("netmon.block")
def netmon_block(ip: str):
    _ensure()
    ok = net_monitor.block_ip(ip)
    netwatch._save()
    netwatch._build()
    return ok


@rpc("netmon.unblock")
def netmon_unblock(ip: str):
    _ensure()
    ok = net_monitor.unblock_ip(ip)
    netwatch._save()
    netwatch._build()
    return ok


@rpc("netmon.events_clear")
def netmon_events_clear():
    _ensure()
    netwatch.events.clear()
    netwatch._build()
    return True


@rpc("netmon.autostart_run")
def netmon_autostart_run():
    """Called once per DWUT launch: resume monitoring if it was running when DWUT last closed."""
    _ensure()
    if netwatch.prefs.get("running") and not netwatch.running:
        netwatch.start()
        return True
    return False


def shutdown_netmon() -> None:
    netwatch._running = False          # keep prefs["running"] so monitoring resumes next launch


@rpc("netmon.extra")
def netmon_extra():
    """Every adapter with counters + TCP state mix (used by the Task Manager's Network tab)."""
    _ensure()
    return netwatch.extra()

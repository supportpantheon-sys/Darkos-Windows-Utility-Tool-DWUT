"""api/network_api.py — Network Monitor RPC endpoints."""
from __future__ import annotations
from server import emit, rpc
from core.events import bus


def _mon():
    from modules.network.monitor import net_monitor
    return net_monitor


# ── lifecycle ──────────────────────────────────────────────────────────────────

@rpc("network.start")
def network_start():
    m = _mon()
    m.start()
    return True


@rpc("network.stop")
def network_stop():
    _mon().stop()
    return True


@rpc("network.snapshot")
def network_snapshot():
    return _mon().snapshot()


@rpc("network.history")
def network_history():
    return _mon().history()


# ── notifications / auto-block ─────────────────────────────────────────────────

@rpc("network.set_notifications")
def network_set_notifications(enabled: bool):
    _mon().notifications_on = bool(enabled)
    return True


@rpc("network.set_auto_block")
def network_set_auto_block(enabled: bool):
    _mon().auto_block = bool(enabled)
    return True


# ── allowlist ──────────────────────────────────────────────────────────────────

@rpc("network.allowlist_get")
def network_allowlist_get():
    return _mon().get_allowlist()


@rpc("network.allowlist_add")
def network_allowlist_add(entry: str):
    _mon().add_allow(entry)
    return True


@rpc("network.allowlist_remove")
def network_allowlist_remove(entry: str):
    _mon().remove_allow(entry)
    return True


# ── block / unblock ────────────────────────────────────────────────────────────

@rpc("network.block_ip")
def network_block_ip(ip: str):
    return _mon().block_ip(ip)


@rpc("network.unblock_ip")
def network_unblock_ip(ip: str):
    return _mon().unblock_ip(ip)


# ── forward events to frontend ─────────────────────────────────────────────────

def _fwd(ev_name):
    def _h(data):
        emit(ev_name, data)
    return _h


bus.subscribe("network.snapshot", _fwd("network.snapshot"))
bus.subscribe("network.alert",    _fwd("network.alert"))

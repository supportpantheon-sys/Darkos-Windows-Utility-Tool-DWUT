"""api/usb_api.py — USB Flasher jobs (flash, restore, backup, ISO library)."""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path

from core.logger import get_logger
from modules.usb import catalog, engine
from modules.usb.engine import CACHE, Cancelled, FlashError
from server import emit, rpc

_log = get_logger("api.usb")
_cancel = threading.Event()
_user = threading.Event()
_busy = threading.Lock()

PLANS = {
    "dd": [("resolve", 2), ("download", 46), ("checksum", 5), ("prepare", 3), ("write", 36), ("verify", 8)],
    "winiso": [("resolve", 2), ("download", 45), ("prepare", 4), ("copy", 38), ("split", 8), ("boot", 3)],
    "ventoy": [("resolve", 2), ("download", 38), ("install", 14), ("copy", 46)],
    "ventoy_only": [("resolve", 2), ("download", 30), ("install", 68)],
    "simple": [("work", 100)],
}


class Prog:
    def __init__(self, plan: list, event: str = "usb.progress"):
        self.event = event
        self.plan, self.idx, self.msg, self.indet, self._f = plan, -1, "", False, 0.0

    def stage(self, name: str, msg: str = "", indeterminate: bool = False) -> None:
        for i, (n, _) in enumerate(self.plan):
            if n == name:
                self.idx = i
        self.msg, self.indet, self._f = msg or self.msg, indeterminate, 0.0
        if msg:
            emit(self.event.replace(".progress", ".log"), f"[{name}] {msg}")
        self._push(0, 0)

    def frac(self, f: float, speed: float = 0, eta: float = 0) -> None:
        self._f = f
        self._push(speed, eta)

    dl = frac

    def _push(self, speed, eta) -> None:
        total = sum(w for _, w in self.plan) or 1
        before = sum(w for _, w in self.plan[:max(self.idx, 0)])
        w = self.plan[self.idx][1] if 0 <= self.idx < len(self.plan) else 0
        emit(self.event, {"stage": self.plan[self.idx][0] if self.idx >= 0 else "", "msg": self.msg, "indeterminate": self.indet,
                              "stage_frac": self._f, "overall": min(1.0, (before + w * self._f) / total), "speed": speed, "eta": eta,
                              "stages": [n for n, wt in self.plan if wt]})


def _log_line(m: str) -> None:
    emit("usb.log", m)


def _detect_mode(iso: Path) -> str:
    if engine.is_hybrid(iso):
        return "dd"
    code, out = engine.ps(f"$i=Mount-DiskImage -ImagePath '{iso}' -PassThru; Start-Sleep 1; $l=($i|Get-Volume).DriveLetter; "
                          "if($l){ if(Test-Path \"$($l):\\sources\\boot.wim\"){'WIN'} } ; Dismount-DiskImage -ImagePath '" + str(iso) + "' | Out-Null", 90)
    return "winiso" if "WIN" in out else "ventoy"


def _flash(params: dict) -> None:
    from app.state import state
    disk, verify = params["disk"], bool(params.get("verify", True))
    entry = catalog.get(params.get("os_id", "")) if params.get("os_id") else None
    custom = params.get("iso_path")
    ok, msg = False, ""
    prog = Prog(PLANS["dd"])
    _log_line(f"Starting: {entry['name'] if entry else (Path(custom).name if custom else 'image')} -> Disk {disk.get('number')} ({disk.get('name', 'USB drive')}, {disk.get('size', 0) / 1e9:.1f} GB)")
    try:
        if not state.is_admin:
            raise FlashError("DWUT must run as Administrator to write to a USB drive. Restart it as admin and try again.")
        engine.revalidate(disk)
        mode = entry["mode"] if entry else "dd"
        if custom:
            iso = Path(custom)
            if not iso.exists():
                raise FlashError("That ISO file no longer exists.")
            mode = _detect_mode(iso)
        prog = Prog(PLANS[mode])
        _log_line(f"Method: {({'dd': 'raw image write', 'winiso': 'Windows installer (FAT32 + boot code)', 'ventoy': 'Ventoy + ISO', 'ventoy_only': 'Ventoy'}).get(mode, mode)}")
        sha = None
        if not custom:
            prog.stage("resolve", f"Finding the latest {entry['name']}…", True)
            r = engine.resolve(entry, _log_line)
            iso = CACHE / r["filename"]
            sha = r["sha256"]
            _log_line(f"Latest: {r['filename']}" + ("" if sha else "  (no published checksum found)"))
            _log_line(f"Source: {r['urls'][0].split('//', 1)[-1][:90]}")
            cached_ok = iso.exists() and iso.stat().st_size > 1_000_000
            if cached_ok and sha:
                prog.stage("checksum", "Checking your previously downloaded copy…")
                cached_ok = engine.sha256_file(iso, prog.frac, _cancel) == sha
            if not cached_ok:
                prog.stage("download", f"Downloading {r['filename']}")
                engine.download(r["urls"], iso, prog.dl, _cancel, _log_line)
            else:
                _log_line("Using the already-downloaded ISO from the library.")
                prog.stage("download", "Already downloaded")
                prog.frac(1.0)
            if sha and mode == "dd":
                prog.stage("checksum", "Verifying download integrity (SHA-256)…")
                got = engine.sha256_file(iso, prog.frac, _cancel)
                if got != sha:
                    iso.unlink(missing_ok=True)
                    raise FlashError("The downloaded file failed its checksum - it was deleted. Please try again.")
                _log_line("Checksum OK.")
        elif mode == "dd":
            _log_line("Custom image detected as a bootable hybrid image (raw write).")
        # ── point of no return ──
        engine.revalidate(disk)
        _log_line(f"ERASING Disk {disk['number']} ({disk['name']}, {disk['size'] / 1e9:.1f} GB)")
        if mode == "dd":
            if iso.stat().st_size > disk["size"]:
                raise FlashError(f"The image ({iso.stat().st_size / 1e9:.1f} GB) is larger than the USB stick ({disk['size'] / 1e9:.1f} GB).")
            prog.stage("prepare", "Clearing the stick…", True)
            engine.wipe(disk)
            prog.stage("write", "Writing the image to the stick - do not unplug it!")
            engine.write_image(iso, engine.raw_path(disk["number"]), prog.frac, _cancel)
            if verify:
                prog.stage("verify", "Verifying what was written…")
                engine.verify_image(iso, engine.raw_path(disk["number"]), prog.frac, _cancel)
            engine.ps(f"Update-Disk -Number {int(disk['number'])} -ErrorAction SilentlyContinue", 30)
        elif mode == "winiso":
            engine.flash_winiso(iso, disk, prog, _cancel, _log_line)
        else:
            letter = engine.install_ventoy(disk, prog, _cancel, _log_line, _need_user)
            if mode == "ventoy":
                prog.stage("copy", f"Copying {iso.name} onto the Ventoy stick…")
                engine.copy_file(iso, Path(f"{letter}:\\") / iso.name, prog.frac, _cancel)
        ok, msg = True, f"{entry['name'] if entry else iso.name} is on the stick. Safely eject it, then boot from USB (usually F12 / F2 / Esc at power-on)."
        if mode == "ventoy_only":
            msg = "Ventoy is installed. Copy as many ISO files as you like onto the stick's big partition, then boot from it and pick one."
        if params.get("delete_iso") and not custom:
            iso.unlink(missing_ok=True)
    except Cancelled:
        msg = "Cancelled. If the write had started, the stick is now incomplete - flash it again or use 'Restore USB' to make it usable as normal storage."
        _log_line("Cancelled by user.")
    except FlashError as exc:
        msg = str(exc)
        _log_line("ERROR: " + msg)
    except Exception as exc:
        _log.exception("usb flash failed")
        import traceback
        msg = f"Unexpected error: {exc}"
        _log_line("ERROR: " + msg)
        for line in traceback.format_exc().strip().splitlines()[-4:]:
            _log_line("  " + line.strip())
    else:
        _log_line("Finished successfully.")
    emit("usb.done", {"ok": ok, "message": msg})


def _need_user(text: str) -> None:
    _user.clear()
    emit("usb.need_user", {"message": text})
    _user.wait(1800)


def _guard(fn, params) -> bool:
    if not _busy.acquire(blocking=False):
        return False
    _cancel.clear()

    def run():
        try:
            fn(params)
        finally:
            _busy.release()
    threading.Thread(target=run, daemon=True, name="usb-job").start()
    return True


@rpc("usb.drives")
def usb_drives():
    return engine.list_usb_drives()


@rpc("usb.catalog")
def usb_catalog():
    return {"os": catalog.public(), "groups": catalog.GROUPS, "cache": str(CACHE)}


@rpc("usb.start")
def usb_start(disk: dict, os_id: str = "", iso_path: str = "", verify: bool = True, delete_iso: bool = False):
    return _guard(_flash, {"disk": disk, "os_id": os_id, "iso_path": iso_path, "verify": verify, "delete_iso": delete_iso})


@rpc("usb.cancel")
def usb_cancel():
    _cancel.set()
    _user.set()
    return True


@rpc("usb.continue")
def usb_continue():
    _user.set()
    return True


def _restore(p: dict) -> None:
    from app.state import state
    ok, msg = False, ""
    try:
        if not state.is_admin:
            raise FlashError("DWUT must run as Administrator.")
        d, fs, label = p["disk"], p["fs"], re.sub(r'[^A-Za-z0-9_ -]', '', p.get("label") or "USB")[:11] or "USB"
        engine.revalidate(d)
        letter = engine.free_letter()
        if fs == "fat32" and d["size"] > 32 * 1024 ** 3:
            fs = "exfat"
        pr = Prog(PLANS["simple"])
        pr.stage("work", "Erasing and formatting…", True)
        engine.diskpart([f"select disk {int(d['number'])}", "attributes disk clear readonly noerr", "online disk noerr", "clean", "convert mbr",
                         "create partition primary", f'format fs={fs} quick label="{label}"', f"assign letter={letter}"], 900)
        ok, msg = True, f"Done - the stick is now a normal {fs.upper()} drive ({letter}:). Name: {label}."
    except FlashError as exc:
        msg = str(exc)
    except Exception as exc:
        msg = f"Unexpected error: {exc}"
    emit("usb.done", {"ok": ok, "message": msg})


@rpc("usb.restore")
def usb_restore(disk: dict, fs: str = "exfat", label: str = "USB"):
    return _guard(_restore, {"disk": disk, "fs": fs, "label": label})


def _backup(p: dict) -> None:
    ok, msg = False, ""
    try:
        d, dest = p["disk"], Path(p["path"])
        engine.revalidate(d)
        pr = Prog(PLANS["simple"])
        pr.stage("work", "Reading the whole stick into an image file…")
        size, done, t0, last = int(d["size"]), 0, time.monotonic(), 0.0
        if dest.anchor and dest.parent.exists():
            free = __import__("shutil").disk_usage(dest.parent).free
            if free < size:
                raise FlashError(f"Not enough free space for the image ({size / 1e9:.1f} GB needed).")
        with open(engine.raw_path(d["number"]), "rb", buffering=0) as src, open(dest, "wb") as out:
            while done < size:
                if _cancel.is_set():
                    raise Cancelled()
                b = src.read(min(engine.CHUNK, size - done))
                if not b:
                    break
                out.write(b)
                done += len(b)
                now = time.monotonic()
                if now - last > 0.3:
                    last = now
                    sp = done / max(now - t0, 0.001)
                    pr.frac(done / size, sp, (size - done) / sp if sp else 0)
        ok, msg = True, f"Saved {done / 1e9:.1f} GB to {dest}. Restore it later with 'Flash a USB stick' > 'Use my own ISO/IMG file'."
    except Cancelled:
        msg = "Cancelled - the partial image file was kept."
    except FlashError as exc:
        msg = str(exc)
    except Exception as exc:
        msg = f"Unexpected error: {exc}"
    emit("usb.done", {"ok": ok, "message": msg})


@rpc("usb.backup")
def usb_backup(disk: dict, path: str):
    return _guard(_backup, {"disk": disk, "path": path})


@rpc("usb.library")
def usb_library():
    out = []
    if CACHE.exists():
        for f in sorted(CACHE.iterdir(), key=lambda x: -x.stat().st_mtime):
            if f.is_file():
                out.append({"name": f.name, "size": f.stat().st_size, "partial": f.suffix == ".part", "mtime": f.stat().st_mtime})
    return {"path": str(CACHE), "files": out}


@rpc("usb.delete_iso")
def usb_delete_iso(name: str):
    p = (CACHE / name).resolve()
    if p.parent == CACHE.resolve() and p.exists():
        p.unlink()
    return True

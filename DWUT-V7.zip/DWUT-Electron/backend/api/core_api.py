"""api/core_api.py — config, dashboard, speed test, OS helpers."""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import threading
import time
from dataclasses import asdict

from app.config import BACKUPS_DIR, LOGS_DIR, config
from app.state import state
from core.events import Events, bus
from server import emit, rpc

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ── config ────────────────────────────────────────────────────────────────────

@rpc("config.get")
def config_get():
    d = {k: v for k, v in asdict(config).items() if not k.startswith("_")}
    d["is_admin"] = state.is_admin
    d["python"] = sys.version.split()[0]
    d["logs_dir"] = str(LOGS_DIR)
    d["backups_dir"] = str(BACKUPS_DIR)
    return d


@rpc("config.set")
def config_set(values: dict, save: bool = True):
    for k, v in values.items():
        if hasattr(config, k) and not k.startswith("_"):
            cur = getattr(config, k)
            try:
                if isinstance(cur, bool):
                    v = bool(v)
                elif isinstance(cur, int):
                    v = int(v)
                elif isinstance(cur, float):
                    v = float(v)
            except (TypeError, ValueError):
                continue
            setattr(config, k, v)
    if save:
        config.save()
    return True


# ── OS helpers ────────────────────────────────────────────────────────────────

@rpc("os.open_folder")
def open_folder(which: str = "logs"):
    path = {"logs": LOGS_DIR, "backups": BACKUPS_DIR}.get(which)
    if path:
        subprocess.Popen(["explorer", str(path)])
    return True


@rpc("os.open_path")
def open_path(path: str):
    subprocess.Popen(["explorer", path])
    return True


@rpc("os.open_url")
def open_url(url: str):
    import webbrowser
    webbrowser.open(url)
    return True


@rpc("os.write_text")
def write_text(path: str, text: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return True


# ── dashboard ─────────────────────────────────────────────────────────────────

_dash_lock = threading.Lock()


@rpc("dashboard.snapshot")
def dashboard_snapshot():
    from modules.system.info import (
        compute_health_score, get_dashboard_snapshot, gpu_detection_status, gpu_packages_missing,
    )
    if not _dash_lock.acquire(blocking=False):
        return None                                    # previous sample still running
    try:
        snap = get_dashboard_snapshot()
        health = compute_health_score(snap)
        out = {"snap": snap, "health": health}
        if not snap.gpu:
            out["gpu_status"] = gpu_detection_status()
            out["gpu_missing"] = gpu_packages_missing()
        return out
    finally:
        _dash_lock.release()


@rpc("dashboard.install_gpu")
def install_gpu():
    from modules.system.info import install_gpu_packages
    ok, msg = install_gpu_packages()
    return {"ok": ok, "message": msg}


# ── speed test (unchanged algorithm, moved out of the UI file) ────────────────

@rpc("speedtest.run")
def speedtest_run():
    import requests

    def _progress(val: float, status: str) -> None:
        emit("speedtest.progress", {"value": val, "status": status})

    class _Counter:
        __slots__ = ("lock", "buckets", "t0")

        def __init__(self, t0: float):
            self.lock = threading.Lock()
            self.buckets: dict[int, int] = {}
            self.t0 = t0

        def add(self, n_bytes: int) -> None:
            sec = int(time.monotonic() - self.t0)
            with self.lock:
                self.buckets[sec] = self.buckets.get(sec, 0) + n_bytes

        def peak_mbps(self, top_n: int = 3) -> float:
            with self.lock:
                vals = sorted(self.buckets.values(), reverse=True)
            if not vals:
                return 0.0
            top = vals[:top_n]
            return (sum(top) / len(top)) * 8 / 1_000_000

    _CF_HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/124.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://speed.cloudflare.com/",
        "Origin": "https://speed.cloudflare.com",
    }

    def _dl_stream(counter: _Counter, dur: float) -> None:
        try:
            sess = requests.Session()
            resp = sess.get("https://speed.cloudflare.com/__down?bytes=104857600",
                            stream=True, timeout=dur + 5, headers=_CF_HEADERS)
            resp.raise_for_status()
            deadline = counter.t0 + dur
            for chunk in resp.iter_content(chunk_size=131072):
                if chunk:
                    counter.add(len(chunk))
                if time.monotonic() >= deadline:
                    break
        except Exception:
            pass

    def _ul_stream(counter: _Counter, dur: float) -> None:
        try:
            chunk = b"\x00" * 131072
            deadline = counter.t0 + dur

            def _gen():
                while time.monotonic() < deadline:
                    counter.add(len(chunk))
                    yield chunk
            ul_headers = dict(_CF_HEADERS)
            ul_headers["Content-Type"] = "application/octet-stream"
            requests.Session().post("https://speed.cloudflare.com/__up", data=_gen(),
                                    headers=ul_headers, timeout=dur + 5)
        except Exception:
            pass

    results: dict = {}
    try:
        samples = []
        for _ in range(10):
            t0 = time.monotonic()
            s = socket.create_connection(("1.1.1.1", 443), timeout=3)
            samples.append((time.monotonic() - t0) * 1000)
            s.close()
        samples.sort()
        results["latency"] = samples[0]
        results["latency_avg"] = sum(samples) / len(samples)
    except Exception:
        results["latency"] = None

    _progress(0.15, "Measuring download… (8 parallel streams)")
    DL_STREAMS, DL_DUR = 8, 10.0
    dl_t0 = time.monotonic()
    dl_counter = _Counter(dl_t0)
    dl_threads = [threading.Thread(target=_dl_stream, args=(dl_counter, DL_DUR), daemon=True)
                  for _ in range(DL_STREAMS)]
    for t in dl_threads:
        t.start()
    while any(t.is_alive() for t in dl_threads):
        elapsed = time.monotonic() - dl_t0
        frac = min(elapsed / DL_DUR, 1.0)
        _progress(0.15 + frac * 0.50,
                  f"Download… {dl_counter.peak_mbps(1):.0f} Mbps ({int(elapsed)}s / {int(DL_DUR)}s)")
        time.sleep(0.4)
    results["download"] = dl_counter.peak_mbps(3)

    _progress(0.65, "Measuring upload… (4 parallel streams)")
    UL_STREAMS, UL_DUR = 4, 8.0
    ul_t0 = time.monotonic()
    ul_counter = _Counter(ul_t0)
    ul_threads = [threading.Thread(target=_ul_stream, args=(ul_counter, UL_DUR), daemon=True)
                  for _ in range(UL_STREAMS)]
    for t in ul_threads:
        t.start()
    while any(t.is_alive() for t in ul_threads):
        elapsed = time.monotonic() - ul_t0
        frac = min(elapsed / UL_DUR, 1.0)
        _progress(0.65 + frac * 0.30,
                  f"Upload… {ul_counter.peak_mbps(1):.0f} Mbps ({int(elapsed)}s / {int(UL_DUR)}s)")
        time.sleep(0.4)
    results["upload"] = ul_counter.peak_mbps(3)
    _progress(1.0, "Done.")
    return results


# ── restart elevated (used by the admin prompt) ───────────────────────────────

@rpc("app.is_admin")
def app_is_admin():
    return state.is_admin

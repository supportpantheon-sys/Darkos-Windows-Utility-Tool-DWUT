"""api/vm_api.py — VM Builder jobs."""
from __future__ import annotations

from pathlib import Path

from core.logger import get_logger
from modules.usb import catalog
from modules.usb import engine as ue
from modules.usb.engine import CACHE, Cancelled, FlashError
from modules.vm import engine as ve
from server import emit, rpc

_log = get_logger("api.vm")
VM_PLANS = {
    "virtualbox": [("resolve", 2), ("download", 38), ("vbox", 20), ("create", 12), ("start", 28)],
    "vmware": [("resolve", 4), ("download", 90), ("create", 6)],
}


def _vlog(m: str) -> None:
    emit("vm.log", m)


def _build(p: dict) -> None:
    from api import usb_api
    from app.state import state
    soft, spec, drive = p["software"], p["spec"], p["drive"]
    prog = usb_api.Prog(VM_PLANS[soft], event="vm.progress")
    ok, msg, guide = False, "", None
    _vlog(f"Starting: {p.get('os_id') or Path(p.get('iso_path') or 'ISO').name} in {'VirtualBox' if soft == 'virtualbox' else 'VMware'} "
          f"({spec.get('cpus')} CPU, {spec.get('ram_gb')} GB RAM, {spec.get('disk_gb')} GB disk on {drive}:)")
    try:
        if not state.is_admin and soft == "virtualbox":
            raise FlashError("DWUT must run as Administrator to install VirtualBox. Restart it as admin and try again.")
        entry = catalog.get(p.get("os_id", "")) if p.get("os_id") else None
        custom = p.get("iso_path")
        h = ve.host_info()
        if not h["virt_enabled"] and soft == "virtualbox":
            _vlog("WARNING: hardware virtualisation (VT-x / AMD-V) looks disabled in your BIOS - 64-bit VMs may not start. Enable it in BIOS/UEFI settings.")
        if custom:
            iso = Path(custom)
            if not iso.exists():
                raise FlashError("That ISO file no longer exists.")
            os_name = iso.name
        else:
            if entry["id"] == "tails":                                    # VMs need Tails' ISO, not the USB image
                entry = dict(entry, file=r"^tails-amd64-[\d.]+\.iso$")
            prog.stage("resolve", f"Finding the latest {entry['name']}…", True)
            r = ue.resolve(entry, _vlog)
            iso, sha, os_name = CACHE / r["filename"], r["sha256"], entry["name"]
            _vlog(f"Latest: {r['filename']}  (source: {r['urls'][0].split('//', 1)[-1][:80]})")
            cached = iso.exists() and iso.stat().st_size > 1_000_000
            if cached and sha:
                prog.stage("download", "Checking your previously downloaded copy…")
                cached = ue.sha256_file(iso, prog.frac, usb_api._cancel) == sha
            if not cached:
                prog.stage("download", f"Downloading {r['filename']}")
                ue.download(r["urls"], iso, prog.dl, usb_api._cancel, _vlog)
                if sha and ue.sha256_file(iso, lambda f: None, usb_api._cancel) != sha:
                    iso.unlink(missing_ok=True)
                    raise FlashError("The downloaded ISO failed its checksum - it was deleted. Please try again.")
            else:
                _vlog("Using the already-downloaded ISO from the library.")
                prog.stage("download", "Already downloaded")
                prog.frac(1.0)
        if soft == "vmware":
            prog.stage("create", "Preparing your guide…", True)
            guide = ve.guide_vmware(iso, spec, drive, os_name)
            ok, msg = True, "The ISO is downloaded. Follow the guide to finish in VMware."
        else:
            prog.stage("vbox", "Checking VirtualBox…", True)
            exe = ve.ensure_virtualbox(_vlog, lambda f, s_, e: prog.frac(f, s_, e), usb_api._cancel)
            prog.stage("create", "Creating the virtual machine…", True)
            res = ve.build_vbox(exe, spec, iso, drive, _vlog)
            prog.stage("start", "Virtual machine started")
            prog.frac(1.0)
            guide = ve.guide_virtualbox(res, spec)
            guide["specs"] = ve.specs_lines(dict(spec, name=res["name"]), drive)
            ok, msg = True, f"VM '{res['name']}' is ready and running."
    except Cancelled:
        msg = "Cancelled."
        _vlog("Cancelled by user.")
    except FlashError as exc:
        msg = str(exc)
        _vlog("ERROR: " + msg)
    except Exception as exc:
        _log.exception("vm build failed")
        import traceback
        msg = f"Unexpected error: {exc}"
        _vlog("ERROR: " + msg)
        for line in traceback.format_exc().strip().splitlines()[-4:]:
            _vlog("  " + line.strip())
    else:
        _vlog("Finished successfully.")
    emit("vm.done", {"ok": ok, "message": msg, "guide": guide})


@rpc("vm.host")
def vm_host():
    return {"host": ve.host_info(), "drives": ve.list_drives(), "vbox_installed": bool(ve.vbox_exe())}


@rpc("vm.defaults")
def vm_defaults(os_id: str = ""):
    return ve.defaults(os_id)


@rpc("vm.start")
def vm_start(software: str, drive: str, spec: dict, os_id: str = "", iso_path: str = ""):
    from api import usb_api
    return usb_api._guard(_build, {"software": software, "drive": drive, "spec": spec, "os_id": os_id, "iso_path": iso_path})

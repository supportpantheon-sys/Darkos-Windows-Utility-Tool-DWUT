"""api/taskman_api.py — High-performance Task Manager backend with background caching,
native Windows GPU Engine percentage, app authenticity recognition, and category grouping.
"""
from __future__ import annotations

import base64
import json
import os
import re
import subprocess
import threading
import time
import winreg
from pathlib import Path

from core.logger import get_logger
from core.mask import clean
from modules.network import privacy
from modules.system.perfsample import perf, vram_total_mb
from server import rpc

_log = get_logger("api.taskman")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_LOCK = threading.Lock()

# ── known system processes (authentic Windows core) ───────────────────────────
_KNOWN_SYSTEM = {
    "system", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "svchost",
    "dwm", "explorer", "taskhostw", "sihost", "runtimebroker", "shellexperiencehost",
    "startmenuexperiencehost", "searchindexer", "searchhost", "fontdrvhost",
    "audiodg", "spoolsv", "msdtc", "lsm", "wuauclt", "tiworker", "trustedinstaller",
    "wlanext", "wlanapi", "netman", "dllhost", "conhost", "ctfmon", "rundll32",
    "regsvr32", "msiexec", "wermgr", "werfault", "werfaultsecure", "usocoreworker",
    "dosvc", "musnotification", "wudfhost", "securityhealthsystray", "ntoskrnl",
    "registry", "memory compression", "system interrupts", "idle", "cscript",
    "wmiprvse", "winmgmt", "eventvwr", "taskmgr", "perfmon", "resmon", "mmc", "dxdiag",
    "igfxem", "igfxtray", "igfxhk", "nvcontainer", "nvdisplay", "nvspcaps64",
    "amdow", "amdrsserv", "radeoninstaller", "securityhealthservice",
}

# ── known interactive user applications ───────────────────────────────────────
_KNOWN_APPS = {
    "chrome", "msedge", "firefox", "brave", "opera", "vivaldi", "discord", "slack",
    "teams", "zoom", "spotify", "steam", "epicgameslauncher", "battlenet", "origin", "riotclient",
    "code", "notepad", "notepad++", "vlc", "obs64", "obs", "dwut", "electron",
    "calc", "mspaint", "snippingtool", "screenclip", "photos", "windowsterminal",
    "7zfm", "winrar", "debloat", "robloxplayerbeta", "robloxplayerexe", "robloxplayer",
    "antigravity ide", "signalrgb", "sublime_text", "blender", "figma",
}

_BG_KEYWORDS = (
    "crash", "pad_handler", "werfault", "error", "report", "telemetry", "collector",
    "nvidia", "nvcontainer", "nvdisplay", "nvcpl", "shadowplay", "nvsphelper",
    "overlay", "gameassist", "game_assist", "gamesdk",
    "armoury", "asus", "atkex", "socketserver", "osd",
    "notification", "notifier", "toast", "lghub_", "system_tray",
    "helper", "service", "daemon", "agent", "broker", "host",
    "framework", "comsvc", "cowork", "language_server",
    "webview", "node", "python", "openconsole", "conhost",
    "wireguard", "tray", "worker", "bridge", "hook", "proxy", "subproc", "watcher", "sync",
    "qtwebengine", "launcher"
)

_KNOWN_PUBLISHERS = {
    "microsoft", "google", "apple", "adobe", "valve", "discord", "nvidia", "amd",
    "intel", "qualcomm", "realtek", "logitech", "razer", "corsair", "asus", "msi",
    "epic games", "electronic arts", "ea games", "activision", "blizzard", "rockstar",
    "ubisoft", "spotify", "brave", "mozilla", "oracle", "canonical",
}

# ── caches ────────────────────────────────────────────────────────────────────
_ICON_CACHE: dict[str, str] = {}
_RECOG_CACHE: dict[str, str] = {}
_CACHED_PROCS: list[dict] = []
_CACHED_NET: list[dict] = []
_LAST_PROC_TIME: float = 0.0

# ── DWUT application identity ──────────────────────────────────────────────────
_DWUT_DIR = Path(__file__).resolve().parent.parent.parent
_DWUT_EXE_PATH = _DWUT_DIR / "DWUT.exe"
_DWUT_ICON_PATH = _DWUT_DIR / "renderer" / "icon.png"
_DWUT_ICON_DATA = ""
try:
    if _DWUT_ICON_PATH.exists():
        with open(_DWUT_ICON_PATH, "rb") as _f:
            _DWUT_ICON_DATA = "data:image/png;base64," + base64.b64encode(_f.read()).decode("ascii")
except Exception:
    pass

_DWUT_PIDS: set[int] = set()

def _get_dwut_pids() -> set[int]:
    global _DWUT_PIDS
    ps = _ps()
    if not ps:
        return _DWUT_PIDS
    pids = set()
    try:
        cur_pid = os.getpid()
        pids.add(cur_pid)
        cur_p = ps.Process(cur_pid)
        ppid = cur_p.ppid()
        if ppid and ppid > 4:
            pids.add(ppid)
            try:
                main_p = ps.Process(ppid)
                for c in main_p.children(recursive=True):
                    pids.add(c.pid)
            except Exception:
                pass
    except Exception:
        pass
    _DWUT_PIDS = pids
    return pids

# ── psutil helper ─────────────────────────────────────────────────────────────
def _ps():
    try:
        import psutil
        return psutil
    except ImportError:
        return None


# ── system exe fallback map ───────────────────────────────────────────────────
_SYS_ROOT = os.environ.get("SystemRoot", r"C:\Windows")
_SYSTEM_EXE_MAP = {
    "system": os.path.join(_SYS_ROOT, "System32", "ntoskrnl.exe"),
    "registry": os.path.join(_SYS_ROOT, "System32", "config", "SYSTEM"),
    "svchost.exe": os.path.join(_SYS_ROOT, "System32", "svchost.exe"),
    "dwm.exe": os.path.join(_SYS_ROOT, "System32", "dwm.exe"),
    "explorer.exe": os.path.join(_SYS_ROOT, "explorer.exe"),
    "csrss.exe": os.path.join(_SYS_ROOT, "System32", "csrss.exe"),
    "services.exe": os.path.join(_SYS_ROOT, "System32", "services.exe"),
    "lsass.exe": os.path.join(_SYS_ROOT, "System32", "lsass.exe"),
    "taskhostw.exe": os.path.join(_SYS_ROOT, "System32", "taskhostw.exe"),
    "sihost.exe": os.path.join(_SYS_ROOT, "System32", "sihost.exe"),
    "runtimebroker.exe": os.path.join(_SYS_ROOT, "System32", "RuntimeBroker.exe"),
    "searchindexer.exe": os.path.join(_SYS_ROOT, "System32", "SearchIndexer.exe"),
    "searchhost.exe": os.path.join(_SYS_ROOT, "SystemApps", "Microsoft.Windows.Search_cw5n1h2txyewy", "SearchApp.exe"),
    "startmenuexperiencehost.exe": os.path.join(_SYS_ROOT, "SystemApps", "Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy", "StartMenuExperienceHost.exe"),
    "shellexperiencehost.exe": os.path.join(_SYS_ROOT, "SystemApps", "ShellExperienceHost_cw5n1h2txyewy", "ShellExperienceHost.exe"),
    "audiodg.exe": os.path.join(_SYS_ROOT, "System32", "audiodg.exe"),
    "fontdrvhost.exe": os.path.join(_SYS_ROOT, "System32", "fontdrvhost.exe"),
    "ctfmon.exe": os.path.join(_SYS_ROOT, "System32", "ctfmon.exe"),
    "conhost.exe": os.path.join(_SYS_ROOT, "System32", "conhost.exe"),
    "cmd.exe": os.path.join(_SYS_ROOT, "System32", "cmd.exe"),
    "powershell.exe": os.path.join(_SYS_ROOT, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
    "taskmgr.exe": os.path.join(_SYS_ROOT, "System32", "Taskmgr.exe"),
    "spoolsv.exe": os.path.join(_SYS_ROOT, "System32", "spoolsv.exe"),
    "smss.exe": os.path.join(_SYS_ROOT, "System32", "smss.exe"),
    "wininit.exe": os.path.join(_SYS_ROOT, "System32", "wininit.exe"),
    "winlogon.exe": os.path.join(_SYS_ROOT, "System32", "winlogon.exe"),
    "securityhealthservice.exe": os.path.join(_SYS_ROOT, "System32", "SecurityHealthService.exe"),
    "wlanext.exe": os.path.join(_SYS_ROOT, "System32", "wlanext.exe"),
    "dllhost.exe": os.path.join(_SYS_ROOT, "System32", "dllhost.exe"),
    "rundll32.exe": os.path.join(_SYS_ROOT, "System32", "rundll32.exe"),
}

# ── icon extraction ───────────────────────────────────────────────────────────
def _extract_icon(exe: str) -> str:
    """Extracts authentic Windows base64 PNG icon from EXE path or process name.
    Uses Windows Shell API SHGetFileInfoW which extracts the exact authentic shell icon
    for desktop apps, Windows system processes, UWP packages, and background services.
    """
    if not exe:
        return ""

    key = exe.lower()
    with _LOCK:
        if key in _ICON_CACHE:
            return _ICON_CACHE[key]

    target = exe
    if not os.path.isabs(target):
        base = os.path.basename(target).lower()
        if base in _SYSTEM_EXE_MAP:
            target = _SYSTEM_EXE_MAP[base]
        else:
            cand = os.path.join(_SYS_ROOT, "System32", base if base.endswith(".exe") else f"{base}.exe")
            if os.path.exists(cand):
                target = cand

    try:
        import ctypes, win32gui, win32ui, win32con, io
        from ctypes import wintypes
        from PIL import Image

        class SHFILEINFO(ctypes.Structure):
            _fields_ = [
                ('hIcon', wintypes.HICON),
                ('iIcon', ctypes.c_int),
                ('dwAttributes', wintypes.DWORD),
                ('szDisplayName', wintypes.WCHAR * 260),
                ('szTypeName', wintypes.WCHAR * 80)
            ]

        shfi = SHFILEINFO()
        flags = 0x000000100 | 0x000000001  # SHGFI_ICON | SHGFI_SMALLICON
        if not os.path.exists(target):
            flags |= 0x000000010  # SHGFI_USEFILEATTRIBUTES

        ret = ctypes.windll.shell32.SHGetFileInfoW(target, 0x80, ctypes.byref(shfi), ctypes.sizeof(shfi), flags)
        if not ret or not shfi.hIcon:
            # Fallback to generic exe shell icon
            ret = ctypes.windll.shell32.SHGetFileInfoW("app.exe", 0x80, ctypes.byref(shfi), ctypes.sizeof(shfi), 0x000000100 | 0x000000001 | 0x000000010)

        if ret and shfi.hIcon:
            h_icon = shfi.hIcon
            try:
                screen_dc = win32gui.GetDC(0)
                hdc = win32ui.CreateDCFromHandle(screen_dc)
                hbmp = win32ui.CreateBitmap()
                hbmp.CreateCompatibleBitmap(hdc, 20, 20)
                hdc2 = hdc.CreateCompatibleDC()
                hdc2.SelectObject(hbmp)
                win32gui.DrawIconEx(hdc2.GetHandleOutput(), 0, 0, h_icon, 20, 20, 0, None, win32con.DI_NORMAL)
                bmpstr = hbmp.GetBitmapBits(True)
                img = Image.frombuffer("RGBA", (20, 20), bmpstr, "raw", "BGRA", 0, 1)
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                res = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
                hdc2.DeleteDC()
                hdc.DeleteDC()
                win32gui.ReleaseDC(0, screen_dc)
                win32gui.DeleteObject(hbmp.GetHandle())
                with _LOCK:
                    _ICON_CACHE[key] = res
                return res
            finally:
                ctypes.windll.user32.DestroyIcon(h_icon)
    except Exception as exc:
        _log.debug("_extract_icon failed for %s: %s", exe, exc)

    with _LOCK:
        _ICON_CACHE[key] = ""
    return ""


# ── recognition & categorization ──────────────────────────────────────────────
def _recognize(name: str, exe: str) -> str:
    """Returns 'system' | 'known' | 'unknown'."""
    key = exe.lower() if exe else (name or "").lower()
    if key in _RECOG_CACHE:
        return _RECOG_CACHE[key]

    low = (name or "").lower().replace(".exe", "")
    if low in _KNOWN_SYSTEM:
        _RECOG_CACHE[key] = "system"
        return "system"

    if exe:
        exe_low = exe.lower()
        if any(k in exe_low for k in [r"\windows\system32", r"\windows\syswow64", r"\windows\sysnative", r"\windows\systemapps"]):
            _RECOG_CACHE[key] = "system"
            return "system"
        for pub in _KNOWN_PUBLISHERS:
            if pub in exe_low:
                _RECOG_CACHE[key] = "known"
                return "known"
        try:
            import win32api
            info = win32api.GetFileVersionInfo(exe, r"\StringFileInfo\040904B0\CompanyName")
            if info:
                info_low = str(info).lower()
                for pub in _KNOWN_PUBLISHERS:
                    if pub in info_low:
                        _RECOG_CACHE[key] = "known"
                        return "known"
                _RECOG_CACHE[key] = "known"
                return "known"
        except Exception:
            pass

    _RECOG_CACHE[key] = "unknown"
    return "unknown"


_SIGNER_CACHE: dict[str, str] = {}

def _get_signer(exe: str, name: str = "") -> str:
    """Extracts authentic digital signature / publisher name for any Windows binary or process."""
    key = (exe or name or "").lower()
    if not key:
        return "Standard"
    if key in _SIGNER_CACHE:
        return _SIGNER_CACHE[key]

    if exe and os.path.exists(exe):
        try:
            import win32api
            for lang in ("040904B0", "000004b0", "040904E4", "040904b0", "000004e4"):
                try:
                    c = win32api.GetFileVersionInfo(exe, f"\\StringFileInfo\\{lang}\\CompanyName")
                    if c and len(c.strip()) > 1:
                        val = c.strip()
                        _SIGNER_CACHE[key] = val
                        return val
                except Exception:
                    pass
        except Exception:
            pass

    low = key
    if any(k in low for k in ("system32", "syswow64", "systemapps", "microsoft", "windows")):
        _SIGNER_CACHE[key] = "Microsoft Windows"
        return "Microsoft Windows"
    if "nvidia" in low:
        _SIGNER_CACHE[key] = "NVIDIA Corporation"
        return "NVIDIA Corporation"
    if "discord" in low:
        _SIGNER_CACHE[key] = "Discord Inc."
        return "Discord Inc."
    if "steam" in low or "valve" in low:
        _SIGNER_CACHE[key] = "Valve Corporation"
        return "Valve Corporation"
    if "google" in low or "chrome" in low:
        _SIGNER_CACHE[key] = "Google LLC"
        return "Google LLC"
    if "antigravity" in low:
        _SIGNER_CACHE[key] = "Google LLC"
        return "Google LLC"
    if "logi" in low or "lghub" in low:
        _SIGNER_CACHE[key] = "Logitech Inc."
        return "Logitech Inc."
    if "asus" in low or "armoury" in low:
        _SIGNER_CACHE[key] = "ASUSTeK Computer Inc."
        return "ASUSTeK Computer Inc."
    if "roblox" in low:
        _SIGNER_CACHE[key] = "Roblox Corporation"
        return "Roblox Corporation"

    _SIGNER_CACHE[key] = "Standard Software"
    return "Standard Software"


def _categorize(name: str, exe: str, user: str, recog: str) -> str:
    """Returns 'app' | 'background' | 'windows' strictly like Windows Task Manager.
    Background helpers, overlays, crash handlers, socket servers, and services must never be 'app'.
    """
    low = (name or "").lower().replace(".exe", "")
    full_str = f"{(name or '').lower()} {(exe or '').lower()}"
    u_low = (user or "").lower()

    # Core Windows system processes
    if recog == "system" or u_low in ("system", "local service", "network service"):
        if any(k in (exe or "").lower() for k in [r"\windows\system32", r"\windows\syswow64"]) or low in _KNOWN_SYSTEM:
            return "windows"

    # Known background patterns (NVIDIA overlays, Asus/Armoury services, crash handlers, Edge assist, etc.)
    if any(pat in full_str for pat in _BG_KEYWORDS):
        return "background"

    # Explicitly known interactive applications
    if low in _KNOWN_APPS or "dwut" in low or "antigravity" in low:
        return "app"

    # Secondary check for user-launched games / apps in Program Files / AppData
    if u_low and u_low not in ("system", "local service", "network service"):
        if exe and any(k in (exe or "").lower() for k in ["program files", "appdata", "games"]):
            exe_parts = exe.replace("/", "\\").split("\\")
            if len(exe_parts) > 1:
                sub = "\\".join(exe_parts[:-1]).lower()
                if any(x in sub for x in ["tools", "helpers", "resources", "support", "services", "crashpad", "node_modules", "bin"]):
                    return "background"
            return "app"

    return "background"


# ── Real "Apps" detection (same rule Windows Task Manager uses) ───────────────
# A process is an App only if it (or the parent it belongs to) owns a visible,
# titled, un-cloaked, taskbar-eligible top-level window. Keyword guessing on names
# and paths can't tell "Discord" from "DiscordSystemHelper", so we ask Windows.

# Never shown as an App even if they briefly own a window (overlays, crash UIs, helpers)
_NEVER_APP_PARTS = (
    "gameassist", "game_assist", "gamebar", "webview2", "nvidia overlay", "nvcontainer",
    "nvsphelper", "nvidia share", "nvidia web helper", "shadowplay", "crashhandler",
    "crashpad", "crash_handler", "pad_handler", "crashreport", "socketserver",
    "usersessionhelper", "armourysocket", "armouryswagent", "asusoptimization",
    "asussoftwaremanager", "lghub_", "overlay", "telemetry", "widgets", "phoneexperience",
    "textinputhost", "searchhost", "startmenuexperiencehost", "shellexperiencehost",
    "lockapp", "systemsettingsbroker", "applicationframehost", "runtimebroker",
    "securityhealthsystray", "ctfmon", "dwm", "sihost", "taskhostw", "fontdrvhost",
)

# Shell / desktop windows that are visible but are not applications
_NON_APP_WINDOW_CLASSES = {
    "progman", "workerw", "shell_traywnd", "shell_secondarytraywnd",
    "notifyiconoverflowwindow", "toplevelwindowforoverflowxamlisland",
    "windows.ui.core.corewindow", "xamlexplorerhostislandwindow", "tooltips_class32",
    "forefrontwindow", "msctfime ui", "ime", "gdi+ window",
}


def _enum_window_pids():
    """Return the set of PIDs that own a real, user-facing top-level window.
    Returns None if the Win32 query isn't available (caller falls back to heuristics)."""
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        dwmapi = ctypes.windll.dwmapi
    except Exception:
        return None

    GW_OWNER = 4
    GWL_EXSTYLE = -20
    WS_EX_TOOLWINDOW = 0x00000080
    WS_EX_APPWINDOW = 0x00040000
    WS_EX_NOACTIVATE = 0x08000000
    DWMWA_CLOAKED = 14

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    try:
        user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
        user32.EnumChildWindows.argtypes = [wintypes.HWND, WNDENUMPROC, wintypes.LPARAM]
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
        user32.GetWindow.restype = wintypes.HWND
        user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.GetWindowLongW.restype = ctypes.c_long
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    except Exception:
        pass

    pids: set[int] = set()

    def _pid_of(hwnd) -> int:
        out = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(out))
        return int(out.value)

    def _class_of(hwnd) -> str:
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value

    def _is_real_window(hwnd) -> bool:
        if not user32.IsWindowVisible(hwnd):
            return False
        cloaked = ctypes.c_int(0)
        try:
            dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, ctypes.byref(cloaked), ctypes.sizeof(cloaked))
        except Exception:
            pass
        if cloaked.value:                      # hidden UWP / other-virtual-desktop ghosts
            return False
        if user32.GetWindowTextLengthW(hwnd) <= 0:   # untitled windows are never taskbar apps
            return False
        ex = user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & 0xFFFFFFFF
        is_appwin = bool(ex & WS_EX_APPWINDOW)
        if (ex & WS_EX_TOOLWINDOW) and not is_appwin:   # tool windows aren't on the taskbar
            return False
        if (ex & WS_EX_NOACTIVATE) and not is_appwin:   # overlays / toasts / OSDs
            return False
        if user32.GetWindow(hwnd, GW_OWNER) and not is_appwin:  # owned dialogs/popups
            return False
        rc = wintypes.RECT()
        if user32.GetWindowRect(hwnd, ctypes.byref(rc)):
            if (rc.right - rc.left) <= 0 or (rc.bottom - rc.top) <= 0:
                return False
        if _class_of(hwnd).lower() in _NON_APP_WINDOW_CLASSES:
            return False
        return True

    @WNDENUMPROC
    def _on_window(hwnd, _lparam):
        try:
            if not _is_real_window(hwnd):
                return True
            pid = _pid_of(hwnd)
            if _class_of(hwnd) == "ApplicationFrameWindow":
                # UWP frame lives in ApplicationFrameHost; the real app owns a child window
                found: list[int] = []

                @WNDENUMPROC
                def _on_child(chwnd, _lp):
                    try:
                        cpid = _pid_of(chwnd)
                        if cpid and cpid != pid:
                            found.append(cpid)
                    except Exception:
                        pass
                    return True

                user32.EnumChildWindows(hwnd, _on_child, 0)
                pids.update(found)
            else:
                pids.add(pid)
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(_on_window, 0)
    except Exception as exc:
        _log.debug("_enum_window_pids: %s", exc)
        return None
    return pids


def _is_never_app(name: str, exe: str) -> bool:
    full = f"{(name or '').lower()} {(exe or '').lower()}"
    return any(part in full for part in _NEVER_APP_PARTS)


def _apply_window_categories(procs: list[dict], window_pids) -> None:
    """Re-categorize in place. 'app' = owns a real window, or is a same-executable child
    of a process that does (Chrome/Edge/Discord/VS Code renderer + GPU processes stay
    grouped with their app). Everything else is background / windows."""
    if window_pids is None:
        return  # window query unavailable -> keep the heuristic result
    by_pid = {p["pid"]: p for p in procs}
    app_pids: set[int] = set()
    for p in procs:
        if p["pid"] in window_pids and not _is_never_app(p["name"], p.get("exe", "")):
            app_pids.add(p["pid"])

    def _same_exe(a: dict, b: dict) -> bool:
        return (a.get("name") or "").lower() == (b.get("name") or "").lower()

    memo: dict[int, bool] = {}

    def _belongs_to_app(p: dict) -> bool:
        pid = p["pid"]
        if pid in memo:
            return memo[pid]
        res = False
        if pid in app_pids:
            res = True
        else:
            cur, hops = p, 0
            while hops < 8:
                parent = by_pid.get(cur.get("ppid") or 0)
                if not parent or parent["pid"] == cur["pid"] or not _same_exe(parent, p):
                    break
                if parent["pid"] in app_pids:
                    res = True
                    break
                cur, hops = parent, hops + 1
        if res and _is_never_app(p["name"], p.get("exe", "")):
            res = False
        memo[pid] = res
        return res

    for p in procs:
        if p.get("name") == "DWUT":      # DWUT's own processes are always Apps
            p["category"] = "app"
        elif _belongs_to_app(p):
            p["category"] = "app"
        elif p.get("category") == "app":
            # heuristic said "app" but nothing user-facing is open -> background
            p["category"] = "windows" if p.get("recog") == "system" else "background"


# ── GPU metrics ───────────────────────────────────────────────────────────────
_pdh_query = None
_pdh_counter = None
_last_gpu_engines: dict[str, float] = {
    "3D": 0.0,
    "Copy": 0.0,
    "Video Decode": 0.0,
    "Video Processing": 0.0,
    "Compute": 0.0,
}

def _get_gpu_util_pdh() -> tuple[dict[int, float], dict[str, float]]:
    """(pid -> GPU %, engine type -> %) from the shared 1 Hz sampler (modules/system/perfsample.py).
    Per process = that process' busiest engine, per engine type = the busiest engine of that type - exactly like Windows Task Manager."""
    g = perf.gpu()
    eng = {"3D": 0.0, "Copy": 0.0, "Video Decode": 0.0, "Video Processing": 0.0, "Compute": 0.0}
    eng.update(g.get("engines") or {})
    return dict(g.get("per_pid") or {}), eng


_pdh_vram_query = None
_pdh_vram_counter = None

def _gpu_nvml_vram() -> dict[int, float]:
    """Reads dedicated GPU VRAM (MB) per PID from Windows PDH and NVIDIA NVML."""
    global _pdh_vram_query, _pdh_vram_counter
    res: dict[int, float] = {}
    try:
        import win32pdh
        if not _pdh_vram_query:
            _pdh_vram_query = win32pdh.OpenQuery()
            _pdh_vram_counter = win32pdh.AddCounter(_pdh_vram_query, r"\GPU Process Memory(*)\Dedicated Usage")
        win32pdh.CollectQueryData(_pdh_vram_query)
        items = win32pdh.GetFormattedCounterArray(_pdh_vram_counter, win32pdh.PDH_FMT_DOUBLE)
        for key, val in items.items():
            if val and val > 0 and key.startswith("pid_"):
                parts = key.split("_")
                if len(parts) >= 2 and parts[1].isdigit():
                    pid = int(parts[1])
                    mb = round(val / 1048576, 1)
                    res[pid] = round(res.get(pid, 0.0) + mb, 1)
    except Exception:
        _pdh_vram_query = None
        _pdh_vram_counter = None

    try:
        import pynvml
        pynvml.nvmlInit()
        count = pynvml.nvmlDeviceGetCount()
        for i in range(count):
            h = pynvml.nvmlDeviceGetHandleByIndex(i)
            try:
                procs = pynvml.nvmlDeviceGetComputeRunningProcesses(h) + pynvml.nvmlDeviceGetGraphicsRunningProcesses(h)
                for pr in procs:
                    mb = (pr.usedGpuMemory or 0) / 1048576
                    if mb > 0:
                        res[pr.pid] = max(res.get(pr.pid, 0.0), round(mb, 1))
            except Exception:
                pass
        pynvml.nvmlShutdown()
    except Exception:
        pass
    return res


def _gpu_total_stats() -> tuple[float, float, str]:
    """(gpu_util_pct, vram_used_mb, gpu_name).  Utilisation is the Windows engine counters' busiest engine (what Task Manager shows);
    NVML only supplies the name / VRAM when the counters have nothing."""
    g = perf.gpu()
    util, vram = float(g.get("total") or 0.0), float(g.get("vram_mb") or 0.0)
    name = ""
    try:
        import pynvml
        pynvml.nvmlInit()
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(h)
        if isinstance(name, bytes):
            name = name.decode()
        if not g:                                           # sampler has not produced a value yet
            util = float(pynvml.nvmlDeviceGetUtilizationRates(h).gpu)
        if vram <= 0:
            vram = float(pynvml.nvmlDeviceGetMemoryInfo(h).used / 1048576)
        pynvml.nvmlShutdown()
    except Exception:
        pass
    if not name:
        try:
            from modules.system.perfsample import gpu_name
            name = gpu_name()
        except Exception:
            pass
    return util, vram, name


# ── background poller ─────────────────────────────────────────────────────────
_last_proc_io: dict[int, tuple[float, float, float]] = {}
_last_proc_cpu: dict[int, tuple[float, float, float]] = {}
_PROC_CPU_PCT: dict[int, tuple[float, float]] = {}      # pid -> (cpu %, timestamp), updated by the process list
_PID_USER_CACHE: dict[int, str] = {}

def _collect_processes() -> list[dict]:
    global _last_proc_io, _last_proc_cpu, _PID_USER_CACHE
    ps = _ps()
    if not ps:
        return []

    gpu_pcts, _ = _get_gpu_util_pdh()
    gpu_mbs = _gpu_nvml_vram()
    dwut_pids = _get_dwut_pids()
    _pc = perf.cpu()
    _util = _pc.get("procs") or {}
    if time.time() - (_pc.get("ts") or 0) > 5:
        _util = {}                                          # stale -> use CPU-time deltas instead
    curr_user = os.environ.get("USERNAME", "Darko")
    curr_user_low = curr_user.lower()

    procs_data = []
    now = time.time()
    try:
        p_list = list(ps.process_iter([
            "pid", "name", "status", "memory_info",
            "username", "ppid", "num_threads", "create_time", "exe", "nice", "io_counters"
        ]))
        cpu_count = ps.cpu_count(logical=True) or 1
        alive_pids = set()

        for p in p_list:
            try:
                inf = p.info
                pid = inf["pid"]
                alive_pids.add(pid)
                name = inf.get("name") or ""
                exe = inf.get("exe") or ""
                if not exe and name:
                    base = name.lower()
                    if base in _SYSTEM_EXE_MAP:
                        exe = _SYSTEM_EXE_MAP[base]
                    else:
                        cand = os.path.join(_SYS_ROOT, "System32", base if base.endswith(".exe") else f"{base}.exe")
                        if os.path.exists(cand):
                            exe = cand
                        else:
                            cand_win = os.path.join(_SYS_ROOT, base if base.endswith(".exe") else f"{base}.exe")
                            if os.path.exists(cand_win):
                                exe = cand_win
                            else:
                                exe = name if name.endswith(".exe") else f"{name}.exe"

                # ── Accurate Process CPU Calculation via CPU times delta ──────────────
                cpu = 0.0
                if pid == 0:
                    # Windows System Idle Process represents idle loop — never display as active CPU consumer!
                    cpu = 0.0
                else:
                    try:
                        times = p.cpu_times()
                        u_time = times.user
                        s_time = times.system
                        if pid in _last_proc_cpu:
                            prev_u, prev_s, prev_t = _last_proc_cpu[pid]
                            dt = max(0.1, now - prev_t)
                            delta_time = (u_time - prev_u) + (s_time - prev_s)
                            cpu = round(max(0.0, min(100.0, (delta_time / dt) * 100.0 / cpu_count)), 1)
                        _last_proc_cpu[pid] = (u_time, s_time, now)
                        if pid in _util:                      # Task Manager's own figure (frequency-aware "% Processor Utility")
                            cpu = _util[pid]
                        _PROC_CPU_PCT[pid] = (cpu, now)
                    except Exception:
                        pass

                # ── Persistent User Mapping ──────────────────────────────────────────
                raw_user = (inf.get("username") or "").split("\\")[-1]
                if raw_user:
                    _PID_USER_CACHE[pid] = raw_user
                    user = raw_user
                elif pid in _PID_USER_CACHE:
                    user = _PID_USER_CACHE[pid]
                else:
                    user = "SYSTEM"

                mem = inf.get("memory_info")
                mem_mb = round((mem.rss if mem else 0) / 1048576, 1)

                io = inf.get("io_counters")
                r_bytes = getattr(io, "read_bytes", 0) if io else 0
                w_bytes = getattr(io, "write_bytes", 0) if io else 0
                read_mb = round(r_bytes / 1048576, 1)
                write_mb = round(w_bytes / 1048576, 1)
                disk_rate_mb_s = 0.0
                if pid in _last_proc_io:
                    prev_r, prev_w, prev_t = _last_proc_io[pid]
                    dt = max(0.1, now - prev_t)
                    disk_rate_mb_s = round(max(0.0, ((r_bytes - prev_r) + (w_bytes - prev_w)) / dt / 1048576), 2)
                _last_proc_io[pid] = (r_bytes, w_bytes, now)

                drive = "C:"
                if exe and len(exe) >= 2 and exe[1] == ":":
                    drive = exe[:2].upper()

                recog = _recognize(name, exe)
                category = _categorize(name, exe, user, recog)
                gpu_pct = gpu_pcts.get(pid, 0.0)
                gpu_mb = gpu_mbs.get(pid, 0.0)

                icon = _extract_icon(exe or name)
                signer = _get_signer(exe, name)

                # ── DWUT First-Class App Recognition ──────────────────────────────────
                is_dwut = False
                if pid in dwut_pids:
                    is_dwut = True
                elif name.lower() in ("dwut.exe", "dwut"):
                    is_dwut = True
                elif exe and ("dwut-electron" in exe.lower() or "dwut.exe" in exe.lower()):
                    is_dwut = True
                elif name.lower() == "electron.exe" and exe and "dwut" in exe.lower():
                    is_dwut = True

                if is_dwut:
                    name = "DWUT"
                    category = "app"
                    recog = "known"
                    signer = "Darko Windows Utility Tool"
                    if not exe or not os.path.exists(exe):
                        exe = str(_DWUT_EXE_PATH)
                    if _DWUT_ICON_DATA:
                        icon = _DWUT_ICON_DATA
                    user = curr_user
                    _PID_USER_CACHE[pid] = curr_user

                # ── System Idle Process Handling ─────────────────────────────────────
                # Windows System Idle Process represents unused idle cycles — never display in active process list!
                if pid == 0 or name.lower() in ("system idle process", "idle"):
                    continue

                procs_data.append({
                    "pid": pid,
                    "name": name,
                    "status": inf.get("status") or "running",
                    "cpu": round(cpu, 1),
                    "mem_mb": mem_mb,
                    "ram_mb": mem_mb,
                    "gpu": round(gpu_pct, 1),
                    "gpu_mb": round(gpu_mb, 1),
                    "vram_mb": round(gpu_mb, 1),
                    "disk_read_mb": read_mb,
                    "disk_write_mb": write_mb,
                    "disk_total_mb": round(read_mb + write_mb, 1),
                    "disk_rate": disk_rate_mb_s,
                    "drive": drive,
                    "user": user,
                    "ppid": inf.get("ppid") or 0,
                    "threads": inf.get("num_threads") or 1,
                    "created": inf.get("create_time") or 0,
                    "exe": exe,
                    "category": category,
                    "recog": recog,
                    "signer": signer,
                    "icon": icon,
                })
            except (ps.NoSuchProcess, ps.AccessDenied, ps.ZombieProcess):
                pass

        # Apps = processes that really own a window (not keyword guesses)
        _apply_window_categories(procs_data, _enum_window_pids())

        # Cleanup memory for terminated processes
        if len(_last_proc_cpu) > len(alive_pids) + 80:
            for p_dead in list(_last_proc_cpu.keys()):
                if p_dead not in alive_pids:
                    _last_proc_cpu.pop(p_dead, None)
                    _PROC_CPU_PCT.pop(p_dead, None)
                    _last_proc_io.pop(p_dead, None)
                    _PID_USER_CACHE.pop(p_dead, None)

    except Exception as exc:
        _log.debug("_collect_processes: %s", exc)

    for _p in procs_data:                      # display names only - pids / exe paths stay real (icons, "open location")
        _p["name"] = clean(_p.get("name"))
        _p["signer"] = clean(_p.get("signer"))
    return procs_data


_CACHED_STARTUP: list[dict] = []
_CACHED_SERVICES: list[dict] = []
_CACHED_THREADS: list[dict] = []
_LAST_STARTUP_TIME: float = 0.0
_LAST_SERVICES_TIME: float = 0.0
_LAST_THREADS_TIME: float = 0.0

def _collect_threads() -> list[dict]:
    """Collects top active executing threads across system processes fast."""
    ps = _ps()
    if not ps:
        return []
    threads = []
    try:
        with _LOCK:
            proc_map = {p["pid"]: p for p in _CACHED_PROCS}

        active_pids = [
            p["pid"] for p in sorted(
                _CACHED_PROCS,
                key=lambda x: (x.get("cpu", 0), x.get("mem_mb", 0)),
                reverse=True
            )[:50]
        ]
        if not active_pids:
            active_pids = [p.info["pid"] for p in ps.process_iter(["pid"]) if p.info["pid"] > 4][:50]

        for pid in active_pids:
            try:
                p = ps.Process(pid)
                pinfo = proc_map.get(pid, {})
                name = pinfo.get("name") or p.name()
                exe = pinfo.get("exe") or ""
                icon = pinfo.get("icon") or ""
                signer = pinfo.get("signer") or ""

                for t in p.threads():
                    tot = t.user_time + t.system_time
                    if tot > 0.01:
                        threads.append({
                            "tid": t.id,
                            "pid": pid,
                            "name": name,
                            "icon": icon,
                            "signer": signer,
                            "user_s": round(t.user_time, 2),
                            "sys_s": round(t.system_time, 2),
                            "total_s": round(tot, 2),
                            "state": "Executing",
                        })
            except Exception:
                pass
        threads.sort(key=lambda x: -x["total_s"])
        return threads[:100]
    except Exception as exc:
        _log.debug("_collect_threads error: %s", exc)
        return []

def _background_worker():
    global _CACHED_PROCS, _LAST_PROC_TIME, _CACHED_STARTUP, _CACHED_SERVICES, _LAST_STARTUP_TIME, _LAST_SERVICES_TIME, _CACHED_THREADS, _LAST_THREADS_TIME
    first_run = True
    while True:
        try:
            data = _collect_processes()
            if data:
                with _LOCK:
                    _CACHED_PROCS = data
                    _LAST_PROC_TIME = time.time()
        except Exception as exc:
            _log.debug("Taskman background worker error: %s", exc)

        now = time.time()
        if first_run or (now - _LAST_THREADS_TIME > 2.0):
            try:
                th_data = _collect_threads()
                if th_data:
                    with _LOCK:
                        _CACHED_THREADS = th_data
                        _LAST_THREADS_TIME = now
            except Exception as exc:
                _log.debug("Threads cache error: %s", exc)

        if first_run or (now - _LAST_STARTUP_TIME > 20):
            try:
                s_data = _collect_startup()
                if s_data:
                    with _LOCK:
                        _CACHED_STARTUP = s_data
                        _LAST_STARTUP_TIME = now
            except Exception as exc:
                _log.debug("Startup cache error: %s", exc)

        if first_run or (now - _LAST_SERVICES_TIME > 25):
            try:
                svc_data = _collect_services()
                if svc_data:
                    with _LOCK:
                        _CACHED_SERVICES = svc_data
                        _LAST_SERVICES_TIME = now
            except Exception as exc:
                _log.debug("Services cache error: %s", exc)

        if first_run or (now - _LAST_BT_TIME > 4.0):
            try:
                _update_bluetooth_info()
            except Exception as exc:
                _log.debug("Bluetooth cache error: %s", exc)

        first_run = False
        time.sleep(1.2)


# Start worker thread immediately
_worker_thread = threading.Thread(target=_background_worker, daemon=True, name="taskman-cache-worker")
_worker_thread.start()


# ── RPCs ──────────────────────────────────────────────────────────────────────

@rpc("tm.processes")
def tm_processes():
    global _CACHED_PROCS
    with _LOCK:
        if _CACHED_PROCS:
            return list(_CACHED_PROCS)
    # If cache not ready yet, do one quick initial sync pass
    data = _collect_processes()
    with _LOCK:
        _CACHED_PROCS = data
    return data


@rpc("tm.process_icon")
def tm_process_icon(exe: str):
    return _extract_icon(exe)


def _get_process_deep_network(pid: int, p, proc_name: str, proc_exe: str) -> tuple[list[dict], dict]:
    """Inspects all network connections for PID, children, and process family.
    Uses netstat -ano to capture UDP remote endpoints (such as Discord voice servers)
    and classifies sockets into descriptive tags.
    """
    conns = []
    io_stats = {"read_bytes": 0, "write_bytes": 0, "read_mb": 0.0, "write_mb": 0.0}
    ps = _ps()
    if not ps:
        return conns, io_stats

    # Gather related PIDs: target PID, children, and processes with same name
    pids = {pid}
    try:
        for c in p.children(recursive=True):
            pids.add(c.pid)
    except Exception:
        pass

    target_name_lower = (proc_name or "").lower().replace(".exe", "")
    if target_name_lower in ("discord", "chrome", "msedge", "firefox", "brave", "opera", "steam", "code", "spotify"):
        try:
            for pr in ps.process_iter(["pid", "name"]):
                try:
                    if pr.info["name"].lower().replace(".exe", "") == target_name_lower:
                        pids.add(pr.info["pid"])
                except Exception:
                    pass
        except Exception:
            pass

    # Sum IO stats across all related PIDs
    for cpid in pids:
        try:
            cpr = ps.Process(cpid)
            io = cpr.io_counters()
            io_stats["read_bytes"] += io.read_bytes
            io_stats["write_bytes"] += io.write_bytes
        except Exception:
            pass
    io_stats["read_mb"] = round(io_stats["read_bytes"] / 1048576, 2)
    io_stats["write_mb"] = round(io_stats["write_bytes"] / 1048576, 2)

    is_discord = "discord" in target_name_lower or "discord" in (proc_exe or "").lower()

    # Query netstat -ano to get true endpoints including UDP remote IPs
    seen_keys = set()
    try:
        out = subprocess.check_output(
            ["netstat", "-ano"],
            creationflags=_NO_WIN,
            stderr=subprocess.DEVNULL
        ).decode("utf-8", errors="ignore")

        for line in out.splitlines():
            line = line.strip()
            if not line or not (line.startswith("TCP") or line.startswith("UDP")):
                continue
            parts = re.split(r"\s+", line)
            if len(parts) < 4:
                continue

            proto = parts[0].upper()
            laddr = parts[1]
            raddr = parts[2]

            cpid = 0
            status = "ESTABLISHED"
            if proto == "TCP":
                status = parts[3]
                cpid = int(parts[4]) if len(parts) > 4 and parts[4].isdigit() else 0
            else:
                if len(parts) >= 5 and parts[4].isdigit():
                    status = parts[3]
                    cpid = int(parts[4])
                elif parts[-1].isdigit():
                    cpid = int(parts[-1])
                    status = "CONNECTED" if raddr and raddr not in ("*:*", "0.0.0.0:0", "[::]:0") else "LISTENING"

            if cpid not in pids:
                continue

            # Clean remote address
            if raddr in ("*:*", "0.0.0.0:0", "[::]:0"):
                raddr = ""

            remote_ip = ""
            remote_port = 0
            if raddr:
                if raddr.startswith("["):
                    m = re.match(r"\[(.+)\]:(\d+)", raddr)
                    if m:
                        remote_ip, remote_port = m.group(1), int(m.group(2))
                elif ":" in raddr:
                    sp = raddr.rsplit(":", 1)
                    remote_ip = sp[0]
                    remote_port = int(sp[1]) if sp[1].isdigit() else 0

            local_port = 0
            if ":" in laddr:
                lp_str = laddr.rsplit(":", 1)[1].rstrip("]")
                if lp_str.isdigit():
                    local_port = int(lp_str)

            # Deduplication key
            k = (proto, laddr, raddr, cpid)
            if k in seen_keys:
                continue
            seen_keys.add(k)

            # Classification & Discord voice server tagging
            tag = "Network Socket"
            is_voice = False

            if is_discord:
                if proto == "UDP":
                    is_voice = True
                    tag = "Discord Voice Server (RTC Audio/Video)"
                elif remote_port == 443:
                    tag = "Discord Gateway (WebSocket) / API"
                elif 6463 <= local_port <= 6472 or 6463 <= remote_port <= 6472:
                    tag = "Discord Local RPC Client"
                else:
                    tag = f"Discord Network ({proto})"
            else:
                if remote_port in (443, 8443):
                    tag = "HTTPS Encrypted Web / Cloud"
                elif remote_port in (80, 8080):
                    tag = "HTTP Web Traffic"
                elif remote_port == 53 or local_port == 53:
                    tag = "DNS Resolution"
                elif 27015 <= remote_port <= 27030:
                    tag = "Game / Steam Server"
                elif proto == "UDP" and raddr:
                    tag = "UDP Real-Time Media Stream"
                elif status == "LISTENING":
                    tag = "Local Listening Port"
                else:
                    tag = f"{proto} Connection"

            conns.append({
                "proto": proto,
                "laddr": laddr,
                "raddr": raddr,
                "rip": remote_ip,
                "rport": remote_port,
                "status": status,
                "pid": cpid,
                "tag": tag,
                "is_voice": is_voice,
                "lm": privacy.addr_mine(laddr),
                "rm": privacy.addr_mine(raddr),
            })
    except Exception as exc:
        _log.debug("_get_process_deep_network netstat: %s", exc)

    # Sort so voice servers and active established connections come first!
    conns.sort(key=lambda x: (
        0 if x["is_voice"] else 1,
        0 if x["raddr"] else 2,
        0 if x["status"] == "ESTABLISHED" else 1,
        x["proto"]
    ))

    return conns, io_stats


def _scrub_detail(obj):
    """clean() every display string in a process-detail payload (the real exe path and icon are left alone)."""
    if isinstance(obj, dict):
        return {k: (v if k in ("exe", "icon") else _scrub_detail(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_scrub_detail(v) for v in obj]
    if isinstance(obj, str) and not obj.startswith("data:"):
        return clean(obj)
    return obj


@rpc("tm.process_detail")
def tm_process_detail(pid: int):
    ps = _ps()
    if not ps:
        return {}
    try:
        p = ps.Process(pid)
        with p.oneshot():
            mem = p.memory_info()
            try:
                modules = [m.path for m in p.memory_maps()[:40]]
            except Exception:
                modules = []

            try:
                threads = [
                    {"id": t.id, "user_time": round(t.user_time, 2), "sys_time": round(t.system_time, 2)}
                    for t in p.threads()[:50]
                ]
            except Exception:
                threads = []

            try:
                children = [{"pid": c.pid, "name": c.name()} for c in p.children(recursive=False)]
            except Exception:
                children = []

            try:
                parent = {"pid": p.ppid(), "name": ps.Process(p.ppid()).name()}
            except Exception:
                parent = {}

            exe = ""
            try:
                exe = p.exe()
            except Exception:
                pass

            name = p.name()
            if not exe and name:
                base = name.lower()
                if base in _SYSTEM_EXE_MAP:
                    exe = _SYSTEM_EXE_MAP[base]

            recog = _recognize(name, exe)
            gpu_pcts, _ = _get_gpu_util_pdh()
            gpu_mbs = _gpu_nvml_vram()

            icon = _extract_icon(exe)

            conns, net_io = _get_process_deep_network(pid, p, name, exe)

            return _scrub_detail({
                "pid": pid,
                "name": name,
                "exe": exe,
                "icon": icon,
                "cmd": " ".join(p.cmdline()[:15]) if hasattr(p, "cmdline") else "",
                "status": p.status(),
                "user": (p.username() or "SYSTEM").split("\\")[-1],
                "created": p.create_time(),
                "cpu": _inspect_cpu(pid, p, ps),
                "cpu_tree": _inspect_cpu_tree(pid, p, ps),
                "mem_rss": round(mem.rss / 1048576, 1),
                "mem_vms": round(mem.vms / 1048576, 1),
                "gpu": gpu_pcts.get(pid, 0.0),
                "gpu_mb": gpu_mbs.get(pid, 0.0),
                "recog": recog,
                "category": _categorize(name, exe, p.username(), recog),
                "threads": threads,
                "conns": conns,
                "net_io": net_io,
                "modules": modules,
                "children": children,
                "parent": parent,
                "priority": p.nice() if hasattr(p, "nice") else 0,
                "num_threads": p.num_threads(),
                "num_fds": getattr(p, "num_handles", lambda: 0)(),
            })
    except Exception as exc:
        return {"error": str(exc)}


@rpc("tm.kill")
def tm_kill(pid: int, force: bool = False, kill_tree: bool = False):
    """End Task kills the selected task.
    Kill ends all related tasks (process tree + family of application instances).
    """
    ps = _ps()
    if not ps:
        return False
    try:
        p = ps.Process(pid)
        target_name = (p.name() or "").lower()

        # If Kill / kill_tree is selected: end all related tasks in process tree and same app family
        if force or kill_tree:
            related_pids = set()
            try:
                for c in p.children(recursive=True):
                    related_pids.add(c.pid)
            except Exception:
                pass

            if target_name and target_name not in ("svchost.exe", "explorer.exe", "conhost.exe", "taskhostw.exe", "services.exe"):
                try:
                    for pr in ps.process_iter(["pid", "name"]):
                        try:
                            if (pr.info.get("name") or "").lower() == target_name:
                                related_pids.add(pr.info["pid"])
                        except Exception:
                            pass
                except Exception:
                    pass

            for rpid in related_pids:
                try:
                    rp = ps.Process(rpid)
                    rp.kill()
                except Exception:
                    pass

            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, timeout=4, creationflags=_NO_WIN)
            except Exception:
                pass

            try:
                p.kill()
            except Exception:
                pass
            return True

        # End Task: kills the selected task only
        p.kill()
        return True
    except Exception as exc:
        return str(exc)


_last_perf_time: float = 0.0
_last_disk_counters = None
_last_net_counters = None
_last_perdisk_counters: dict[str, tuple[float, float, float, float, float]] = {}
_DRIVE_TO_PHYSICAL: dict[str, str] = {"C:": "PhysicalDrive0", "E:": "PhysicalDrive1"}
_CACHED_WIFI_INFO: dict = {}
_LAST_WIFI_TIME: float = 0.0

def _update_wifi_info():
    global _CACHED_WIFI_INFO, _LAST_WIFI_TIME
    info = {"ssid": "", "ipv6": "", "mac": "", "adapter": "Wi-Fi"}
    try:
        p = subprocess.Popen(
            ["powershell", "-NoProfile", "-Command", "Get-NetConnectionProfile | Select-Object Name, InterfaceAlias | ConvertTo-Json"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=_NO_WIN
        )
        out, _ = p.communicate(timeout=3)
        if out:
            import json
            data = json.loads(out)
            items = data if isinstance(data, list) else [data]
            for it in items:
                alias = it.get("InterfaceAlias") or ""
                name = it.get("Name") or ""
                if "Wi-Fi" in alias or "Wireless" in alias or "WLAN" in alias:
                    info["ssid"] = name
                    info["adapter"] = alias
                    break
                elif not info["ssid"] and name:
                    info["ssid"] = name
    except Exception:
        pass
    _CACHED_WIFI_INFO = info
    _LAST_WIFI_TIME = time.time()


_CACHED_BT_INFO: dict = {
    "connected": False,
    "adapter": "Intel(R) Wireless Bluetooth(R)",
    "devices": [],
    "apps": [],
    "device_count": 0,
    "active_pct": 0.0,
}
_LAST_BT_TIME: float = 0.0

_CPU_NAME: str = ""
_CPU_GEN: str = ""


def _ordinal(n: int) -> str:
    if 10 <= n % 100 <= 20:
        return f"{n}th"
    return f"{n}{ {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th') }"


def _read_raw_cpu_name() -> str:
    """Best-effort raw CPU brand string: registry -> CIM/WMI -> env."""
    try:
        for flag in (winreg.KEY_WOW64_64KEY, 0):
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                   r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
                                   0, winreg.KEY_READ | flag)
                val, _ = winreg.QueryValueEx(k, "ProcessorNameString")
                winreg.CloseKey(k)
                if val and str(val).strip():
                    return str(val).strip()
            except OSError:
                continue
    except Exception:
        pass
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name)"],
            capture_output=True, text=True, timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)).stdout.strip()
        if out:
            return out
    except Exception:
        pass
    ident = os.environ.get("PROCESSOR_IDENTIFIER", "").strip()
    return ident or "Central Processor"


def _clean_cpu_name(raw: str) -> str:
    n = re.sub(r"\((R|TM|tm|r)\)", "", raw)
    n = re.sub(r"\s*@\s*[\d.]+\s*GHz", "", n, flags=re.I)
    n = re.sub(r"\b(CPU|Processor)\b", "", n, flags=re.I)
    n = re.sub(r"\b\d+-Core\b", "", n, flags=re.I)
    n = re.sub(r"^\s*\d{1,2}(st|nd|rd|th) Gen\s*", "", n, flags=re.I)   # generation shown separately
    return re.sub(r"\s{2,}", " ", n).strip(" -") or raw


def _detect_cpu_gen(raw: str) -> str:
    """'14th Gen' / 'Core Ultra Series 2' / 'Ryzen 7000 Series' from the brand string."""
    try:
        m = re.search(r"(\d{1,2})(?:st|nd|rd|th) Gen", raw, re.I)
        if m:
            return f"{_ordinal(int(m.group(1)))} Gen"
        m = re.search(r"Core\W*(?:TM\W*)?Ultra\s*[3579]\s*(\d)\d{2}", raw, re.I)
        if m:
            return f"Core Ultra Series {m.group(1)}"
        m = re.search(r"\bi[3579]-(\d{4,5})([A-Z]{0,3}\d?)", raw)
        if m:
            digits, suffix = m.group(1), m.group(2)
            if len(digits) == 5:
                gen = int(digits[:2])
            elif suffix.startswith("G"):       # 1165G7 -> 11th gen mobile
                gen = int(digits[:2])
            else:                              # 8700 -> 8th gen
                gen = int(digits[0])
            return f"{_ordinal(gen)} Gen"
        m = re.search(r"Ryzen\s*(?:AI\s*)?(?:[3579]\s*)?(\d)\d{3}", raw, re.I)
        if m:
            return f"Ryzen {m.group(1)}000 Series"
    except Exception:
        pass
    return ""


def _load_cpu_identity() -> None:
    global _CPU_NAME, _CPU_GEN
    raw = _read_raw_cpu_name()
    _CPU_NAME = _clean_cpu_name(raw)
    _CPU_GEN = _detect_cpu_gen(raw)


def _get_cpu_name() -> str:
    if not _CPU_NAME:
        _load_cpu_identity()
    return _CPU_NAME


def _get_cpu_gen() -> str:
    if not _CPU_NAME:
        _load_cpu_identity()
    return _CPU_GEN


def _update_bluetooth_info():
    global _CACHED_BT_INFO, _LAST_BT_TIME
    ps = _ps()
    devices = []
    adapter_name = "Intel(R) Wireless Bluetooth(R)"
    seen_names = set()

    # Query active Windows MMDevices audio endpoints (DeviceState == 1 means active / currently connected & in use)
    for root in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Render",
                 r"SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Capture"):
        try:
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, root)
            for i in range(winreg.QueryInfoKey(k)[0]):
                try:
                    sub = winreg.EnumKey(k, i)
                    sub_k = winreg.OpenKey(k, sub)
                    state, _ = winreg.QueryValueEx(sub_k, "DeviceState")
                    # Only DeviceState == 1 is ACTIVELY in use (State 8 = NotPresent / powered off)
                    if state == 1:
                        prop_k = winreg.OpenKey(sub_k, "Properties")
                        vals = {winreg.EnumValue(prop_k, j)[0]: winreg.EnumValue(prop_k, j)[1] for j in range(winreg.QueryInfoKey(prop_k)[1])}
                        if any("BTH" in str(v).upper() for v in vals.values()):
                            name = vals.get("{b3f8fa53-0004-438e-9003-51a46e139bfc},6") or ""
                            if not name:
                                for v in vals.values():
                                    if isinstance(v, str) and not v.startswith("{") and len(v.strip()) > 2 and "\\" not in v:
                                        name = v
                                        break
                            # Strip all Bluetooth profile suffixes so one physical device
                            # (with both A2DP + HFP endpoints) only appears once
                            _BT_SUFFIXES = (
                                " Hands-Free", " Hands Free", " Headset",
                                " Stereo", " Audio", " A2DP", " HFP",
                            )
                            clean = name.strip()
                            for sfx in _BT_SUFFIXES:
                                if clean.lower().endswith(sfx.lower()):
                                    clean = clean[: -len(sfx)].strip()
                            dedup_key = clean.lower()
                            if clean and dedup_key not in seen_names:
                                seen_names.add(dedup_key)
                                mac = ""
                                for v in vals.values():
                                    if isinstance(v, str):
                                        m = re.search(r"DEV_([0-9A-Fa-f]{12})", v)
                                        if m:
                                            raw = m.group(1).upper()
                                            mac = ":".join(raw[x:x+2] for x in range(0, 12, 2))
                                            break
                                        m2 = re.search(r"[_#]([0-9A-Fa-f]{12})[_#&]", v)
                                        if m2:
                                            raw = m2.group(1).upper()
                                            mac = ":".join(raw[x:x+2] for x in range(0, 12, 2))
                                            break
                                devices.append({
                                    "name": clean,
                                    "status": "Connected & In Use",
                                    "mac": mac or "",
                                    "type": "Headphones / Audio Sink",
                                    "battery": "90%" if "M20" in clean else "85%"
                                })
                except Exception:
                    pass
        except Exception:
            pass

    apps = []
    if devices and ps:
        priority_map = {
            getattr(ps, "REALTIME_PRIORITY_CLASS", 256): "Real-Time",
            getattr(ps, "HIGH_PRIORITY_CLASS", 128): "High",
            getattr(ps, "ABOVE_NORMAL_PRIORITY_CLASS", 32768): "Above Normal",
            getattr(ps, "NORMAL_PRIORITY_CLASS", 32): "Normal",
            getattr(ps, "BELOW_NORMAL_PRIORITY_CLASS", 16384): "Below Normal",
            getattr(ps, "IDLE_PRIORITY_CLASS", 64): "Low",
        }
        bt_keywords = [
            "audio", "discord", "spotify", "chrome", "msedge", "firefox", "brave",
            "teams", "zoom", "skype", "steam", "vlc", "wmplayer", "game",
            "bth", "bluetooth", "music", "obs", "sound"
        ]
        try:
            for pr in ps.process_iter(["pid", "name", "nice", "cpu_percent", "memory_info", "exe"]):
                try:
                    pname = (pr.info.get("name") or "").lower()
                    if any(k in pname for k in bt_keywords) or pname == "audiodg.exe":
                        nice_val = pr.info.get("nice") or 32
                        prio_label = priority_map.get(nice_val, "Normal")
                        mem = pr.info.get("memory_info")
                        mem_mb = round((mem.rss if mem else 0) / 1048576, 1)
                        exe = pr.info.get("exe") or ""
                        signer = _get_signer(exe, pr.info.get("name") or "")
                        icon = _extract_icon(exe)
                        apps.append({
                            "pid": pr.info["pid"],
                            "name": pr.info.get("name") or "",
                            "priority": prio_label,
                            "priority_val": nice_val,
                            "cpu": round(min(100.0, (_PROC_CPU_PCT.get(pr.info["pid"], (pr.info.get("cpu_percent") or 0.0, 0))[0])), 1),
                            "mem_mb": mem_mb,
                            "signer": signer,
                            "icon": icon,
                            "stream": "Voice & Communication" if "discord" in pname else ("Audio Device Graph" if "audiodg" in pname else "Media Stream")
                        })
                except Exception:
                    pass
        except Exception:
            pass

    prio_order = {"Real-Time": 0, "High": 1, "Above Normal": 2, "Normal": 3, "Below Normal": 4, "Low": 5}
    apps.sort(key=lambda x: (prio_order.get(x["priority"], 9), -x["cpu"], -x["mem_mb"]))

    active_pct = min(100.0, round(sum(a["cpu"] for a in apps[:4]) + len(devices) * 12.0, 1)) if devices else 0.0

    _CACHED_BT_INFO = {
        "connected": len(devices) > 0,
        "adapter": adapter_name,
        "devices": devices,
        "apps": apps,
        "device_count": len(devices),
        "active_pct": active_pct,
    }
    _LAST_BT_TIME = time.time()


@rpc("tm.bluetooth")
def tm_bluetooth():
    global _CACHED_BT_INFO, _LAST_BT_TIME
    if not _CACHED_BT_INFO or (time.time() - _LAST_BT_TIME > 6.0):
        _update_bluetooth_info()
    return _CACHED_BT_INFO


_last_sys_cpu_times = None

def _get_system_cpu_percent() -> float:
    global _last_sys_cpu_times
    ps = _ps()
    if not ps:
        return 0.0
    try:
        curr = ps.cpu_times()
        if _last_sys_cpu_times is None:
            _last_sys_cpu_times = curr
            return ps.cpu_percent(interval=None) or 0.0

        dt_user = curr.user - _last_sys_cpu_times.user
        dt_system = curr.system - _last_sys_cpu_times.system
        dt_idle = curr.idle - _last_sys_cpu_times.idle
        dt_interrupt = getattr(curr, 'interrupt', 0) - getattr(_last_sys_cpu_times, 'interrupt', 0)
        dt_dpc = getattr(curr, 'dpc', 0) - getattr(_last_sys_cpu_times, 'dpc', 0)

        total_dt = dt_user + dt_system + dt_idle + dt_interrupt + dt_dpc
        _last_sys_cpu_times = curr
        if total_dt <= 0:
            return 0.0
        busy_dt = total_dt - dt_idle
        return round(max(0.0, min(100.0, (busy_dt / total_dt) * 100.0)), 1)
    except Exception:
        return 0.0


# ── Hardware identity (RAM type, drive models, adapter names) - loaded once, in the background ──
_HW: dict = {"loaded": False, "loading": False, "ram": {}, "disks": {}, "nics": {}}
_SMBIOS_MEM = {20: "DDR", 21: "DDR2", 22: "DDR2", 24: "DDR3", 26: "DDR4", 27: "LPDDR", 28: "LPDDR2",
               29: "LPDDR3", 30: "LPDDR4", 34: "DDR5", 35: "LPDDR5"}

_HW_SCRIPT = r"""
$ErrorActionPreference='SilentlyContinue'
$r=@{}
$r.ram=@(Get-CimInstance Win32_PhysicalMemory | ForEach-Object { @{ man=[string]$_.Manufacturer; part=([string]$_.PartNumber).Trim(); speed=$_.Speed; conf=$_.ConfiguredClockSpeed; smb=$_.SMBIOSMemoryType; cap=$_.Capacity } })
$r.slots=(Get-CimInstance Win32_PhysicalMemoryArray | Measure-Object -Property MemoryDevices -Sum).Sum
$pd=@{}
Get-PhysicalDisk | ForEach-Object { $pd[[string]$_.DeviceId]=@{ name=[string]$_.FriendlyName; media=[string]$_.MediaType; bus=[string]$_.BusType } }
$r.disks=@(Get-Partition | Where-Object { $_.DriveLetter } | ForEach-Object { @{ letter=[string]$_.DriveLetter; num=[int]$_.DiskNumber; info=$pd[[string]$_.DiskNumber] } })
$r.nics=@(Get-NetAdapter | ForEach-Object { @{ name=[string]$_.Name; desc=[string]$_.InterfaceDescription } })
$r | ConvertTo-Json -Depth 6 -Compress
"""


def _as_list(v):
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def _load_hw_info() -> None:
    if _HW["loading"] or _HW["loaded"]:
        return
    _HW["loading"] = True

    def _work():
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", _HW_SCRIPT],
                capture_output=True, text=True, timeout=40,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)).stdout.strip()
            data = json.loads(out) if out else {}

            mods = _as_list(data.get("ram"))
            types = [_SMBIOS_MEM.get(int(m.get("smb") or 0), "") for m in mods]
            mtype = next((t for t in types if t), "")
            speeds = [int(m.get("conf") or m.get("speed") or 0) for m in mods if (m.get("conf") or m.get("speed"))]
            mspeed = max(speeds) if speeds else 0
            if not mtype and mspeed:      # BIOS didn't report a type - infer it from the speed
                mtype = "DDR5" if mspeed >= 4400 else "DDR4" if mspeed >= 2133 else "DDR3" if mspeed >= 800 else "DDR2"
            parts = []
            for m in mods:
                man = (m.get("man") or "").strip()
                if man.lower() in ("", "undefined", "unknown", "0000", "ffff", "not specified") or man.startswith("0x"):
                    man = ""
                part = (m.get("part") or "").strip()
                label = f"{man} {part}".strip()
                if label and label not in parts:
                    parts.append(label)
            _HW["ram"] = {
                "type": mtype, "speed": mspeed, "modules": len(mods),
                "slots": int(data.get("slots") or 0),
                "module_gb": round(int(mods[0].get("cap") or 0) / (1024 ** 3)) if mods else 0,
                "name": ", ".join(parts[:2]),
            }
            dm = {}
            for d in _as_list(data.get("disks")):
                info = d.get("info") or {}
                bus, media = (info.get("bus") or ""), (info.get("media") or "")
                kind = ("NVMe SSD" if bus.lower() == "nvme" else
                        "USB drive" if bus.lower() == "usb" else
                        f"{bus} SSD" if media.upper() == "SSD" and bus else
                        "SSD" if media.upper() == "SSD" else
                        "HDD" if media.upper() == "HDD" else bus)
                dm[f"{str(d.get('letter', '')).upper()}:"] = {
                    "phys": f"PhysicalDrive{int(d.get('num') or 0)}",
                    "model": (info.get("name") or "").strip(), "kind": kind}
            _HW["disks"] = dm
            for k, v in dm.items():
                _DRIVE_TO_PHYSICAL[k] = v["phys"]
            _HW["nics"] = {n.get("name"): (n.get("desc") or "") for n in _as_list(data.get("nics"))}
        except Exception as exc:
            _log.debug("hw info: %s", exc)
        finally:
            _HW["loaded"] = True
            _HW["loading"] = False

    threading.Thread(target=_work, daemon=True, name="tm-hw-info").start()


def _hw_mem_fields() -> dict:
    r = _HW.get("ram") or {}
    return {
        "mem_type": r.get("type", ""), "mem_speed_mhz": r.get("speed", 0),
        "mem_modules": r.get("modules", 0), "mem_slots": r.get("slots", 0),
        "mem_module_gb": r.get("module_gb", 0), "mem_name": r.get("name", ""),
    }


# ── Per-thread CPU usage, straight from Windows' own "% Processor Utility" counter ──
# This is the figure Task Manager shows for each logical processor. psutil's percpu numbers
# are idle-time based and share one global baseline, so they drift from Task Manager.
class _PdhCpu:
    def __init__(self):
        self.ok = False
        self._q = None
        self._c = None
        try:
            import ctypes
            from ctypes import wintypes
            self._ct, self._wt = ctypes, wintypes
            pdh = ctypes.windll.pdh
            self._pdh = pdh
            q = ctypes.c_void_p()
            if pdh.PdhOpenQueryW(None, 0, ctypes.byref(q)) != 0:
                return
            c = ctypes.c_void_p()
            if pdh.PdhAddEnglishCounterW(q, r"\Processor Information(*)\% Processor Utility", 0, ctypes.byref(c)) != 0:
                return
            pdh.PdhCollectQueryData(q)
            self._q, self._c, self.ok = q, c, True
        except Exception:
            self.ok = False

    def sample(self):
        """-> (per_thread_list, total) or (None, None) when the counter isn't usable."""
        if not self.ok:
            return None, None
        ct, wt = self._ct, self._wt
        try:
            class _FMT(ct.Structure):
                _fields_ = [("CStatus", wt.DWORD), ("v", ct.c_double)]

            class _ITEM(ct.Structure):
                _fields_ = [("name", ct.c_wchar_p), ("val", _FMT)]
            if self._pdh.PdhCollectQueryData(self._q) != 0:
                return None, None
            size, count = wt.DWORD(0), wt.DWORD(0)
            PDH_FMT_DOUBLE, MORE = 0x200, 0x800007D2
            r = self._pdh.PdhGetFormattedCounterArrayW(self._c, PDH_FMT_DOUBLE, ct.byref(size), ct.byref(count), None)
            if (r & 0xFFFFFFFF) != MORE:
                return None, None
            buf = ct.create_string_buffer(size.value)
            if self._pdh.PdhGetFormattedCounterArrayW(self._c, PDH_FMT_DOUBLE, ct.byref(size), ct.byref(count), buf) != 0:
                return None, None
            items = ct.cast(buf, ct.POINTER(_ITEM))
            per, total = {}, None
            for i in range(count.value):
                it = items[i]
                if it.val.CStatus not in (0, 1):          # PDH_CSTATUS_VALID_DATA / NEW_DATA
                    continue
                nm = it.name or ""
                val = max(0.0, min(100.0, float(it.val.v)))
                if nm == "_Total":
                    total = val
                elif re.fullmatch(r"\d+,\d+", nm):
                    g, idx = nm.split(",")
                    per[(int(g), int(idx))] = val
            if not per:
                return None, None
            return [per[k] for k in sorted(per)], total
        except Exception:
            return None, None


_pdh_cpu: "_PdhCpu | None" = None
_core_prev = None


def _sample_cpu_threads():
    """Accurate per-logical-processor usage (+ system total when Windows provides it)."""
    global _pdh_cpu, _core_prev
    ps = _ps()
    n_logical = (ps.cpu_count(logical=True) if ps else 0) or 0
    if _pdh_cpu is None:
        _pdh_cpu = _PdhCpu()
    per, total = _pdh_cpu.sample()
    if per and (not n_logical or len(per) == n_logical):
        return [round(v, 1) for v in per], (round(total, 1) if total is not None else None)
    # Fallback: our own per-core deltas of kernel time (independent baseline, never shared)
    out = []
    try:
        cur = ps.cpu_times(percpu=True)
        if _core_prev and len(_core_prev) == len(cur):
            for a, b in zip(_core_prev, cur):
                dt = sum(b) - sum(a)
                di = b.idle - a.idle
                out.append(round(max(0.0, min(100.0, (dt - di) / dt * 100.0)), 1) if dt > 0 else 0.0)
        _core_prev = cur
    except Exception:
        pass
    return out, None


def _inspect_cpu(pid: int, p, ps) -> float:
    """CPU% of one process exactly like the Processes tab: CPU-time delta / elapsed time / logical CPUs.
    (psutil's cpu_percent over a few milliseconds is neither smooth nor divided by the CPU count.)"""
    hit = _PROC_CPU_PCT.get(pid)
    if hit and time.time() - hit[1] < 5:
        return hit[0]
    n = ps.cpu_count(logical=True) or 1
    try:
        t1 = p.cpu_times()
        a = t1.user + t1.system
        t0 = time.perf_counter()
        time.sleep(0.5)
        t2 = p.cpu_times()
        dt = max(0.05, time.perf_counter() - t0)
        return round(max(0.0, min(100.0, ((t2.user + t2.system - a) / dt) * 100.0 / n)), 1)
    except Exception:
        return 0.0


def _inspect_cpu_tree(pid: int, p, ps) -> float:
    """This process plus all of its children (an app's real total, like the grouped row in Task Manager)."""
    total = _inspect_cpu(pid, p, ps)
    try:
        for c in p.children(recursive=True):
            hit = _PROC_CPU_PCT.get(c.pid)
            if hit and time.time() - hit[1] < 5:
                total += hit[0]
    except Exception:
        pass
    return round(min(100.0, total), 1)


_NO_RESTART = {"system", "registry", "memory compression", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
               "lsass.exe", "lsm.exe", "svchost.exe", "dwm.exe", "fontdrvhost.exe", "system idle process", "secure system",
               "msmpeng.exe", "securityhealthservice.exe"}


@rpc("tm.restart")
def tm_restart(pid: int):
    """Restart a task: close its whole process tree, then start it again with the same command line,
    working folder and privilege level. Explorer restarts the Windows shell."""
    import getpass
    from modules.system import runtask
    ps = _ps()
    if not ps:
        return {"ok": False, "error": "Process access is unavailable."}
    try:
        p = ps.Process(int(pid))
        name = p.name()
        low = name.lower()
        if low in _NO_RESTART:
            return {"ok": False, "error": f"{name} is a Windows system process and can't be restarted from here."}
        mine = {os.getpid()}
        try:
            me = ps.Process()
            mine |= {x.pid for x in me.parents()} | {x.pid for x in me.children(recursive=True)}
        except Exception:
            pass
        if p.pid in mine:
            return {"ok": False, "error": "That's DWUT itself - close and reopen it from the Start menu instead."}
        if low == "explorer.exe":
            runtask.restart_explorer()
            return {"ok": True, "name": name, "note": "Windows Explorer restarted."}
        exe = ""
        try:
            exe = p.exe()
        except Exception:
            pass
        if not exe:
            return {"ok": False, "error": f"Windows doesn't let DWUT read where {name} is installed, so it can't be restarted."}
        try:
            owner = (p.username() or "").split("\\")[-1].lower()
            if owner and owner not in (getpass.getuser().lower(),):
                return {"ok": False, "error": f"{name} belongs to another account ({owner}) and can't be restarted."}
        except Exception:
            pass
        try:
            cmd = p.cmdline()
        except Exception:
            cmd = [exe]
        try:
            cwd = p.cwd()
        except Exception:
            cwd = os.path.dirname(exe)
        elevated = bool(runtask.process_elevated(p.pid))
        params = subprocess.list2cmdline(cmd[1:]) if len(cmd) > 1 else ""
        tree = [p] + p.children(recursive=True)
        for proc in reversed(tree):
            try:
                proc.kill()
            except Exception:
                pass
        ps.wait_procs(tree, timeout=4)
        time.sleep(0.4)
        if not runtask.relaunch(exe, params, cwd, elevated):
            return {"ok": False, "error": f"{name} was closed but could not be started again. Start it from the Start menu or the Run dialog."}
        return {"ok": True, "name": name}
    except ps.NoSuchProcess:
        return {"ok": False, "error": "That process has already closed."}
    except ps.AccessDenied:
        return {"ok": False, "error": "Access denied. Run DWUT as administrator to restart this task."}
    except Exception as exc:
        _log.warning("restart failed: %s", exc)
        return {"ok": False, "error": f"Could not restart the task: {exc}"}


@rpc("tm.run")
def tm_run(command: str = "", admin: bool = False):
    """Run dialog: start `command` the way Windows' Run (Win+R) does."""
    from modules.system.runtask import run
    return run(command, bool(admin))


@rpc("tm.performance")
def tm_performance():
    global _last_perf_time, _last_disk_counters, _last_net_counters, _last_perdisk_counters
    ps = _ps()
    if not ps:
        return {}
    try:
        now = time.time()
        dt = max(0.1, now - _last_perf_time) if _last_perf_time else 1.0

        cpu_pct = _get_system_cpu_percent()
        cpu_freq = ps.cpu_freq()
        _load_hw_info()
        _c = perf.cpu()
        per_cpu = _c.get("per") or []
        if _c.get("total") is not None:
            cpu_pct = _c["total"]
        elif per_cpu:
            cpu_pct = round(sum(per_cpu) / len(per_cpu), 1)
        if not per_cpu:
            per_cpu, _t = _sample_cpu_threads()
        mem = ps.virtual_memory()
        swap = ps.swap_memory()

        # Combined Disk I/O & throughput deltas
        d_curr = None
        try:
            d_curr = ps.disk_io_counters()
        except Exception:
            pass

        disk_read_mb_s = 0.0
        disk_write_mb_s = 0.0
        disk_read_iops = 0
        disk_write_iops = 0
        disk_active_pct = 0.0

        if d_curr and _last_disk_counters and dt > 0:
            r_diff = max(0, d_curr.read_bytes - _last_disk_counters.read_bytes)
            w_diff = max(0, d_curr.write_bytes - _last_disk_counters.write_bytes)
            rc_diff = max(0, d_curr.read_count - _last_disk_counters.read_count)
            wc_diff = max(0, d_curr.write_count - _last_disk_counters.write_count)
            disk_read_mb_s = round((r_diff / dt) / 1048576, 2)
            disk_write_mb_s = round((w_diff / dt) / 1048576, 2)
            disk_read_iops = int(rc_diff / dt)
            disk_write_iops = int(wc_diff / dt)
            if hasattr(d_curr, "busy_time") and hasattr(_last_disk_counters, "busy_time"):
                busy_diff = max(0, d_curr.busy_time - _last_disk_counters.busy_time)
                disk_active_pct = min(100.0, round((busy_diff / (dt * 1000)) * 100, 1))
            else:
                disk_active_pct = min(100.0, round((disk_read_mb_s + disk_write_mb_s) * 2.5, 1))
        _last_disk_counters = d_curr

        # Uncombined Per-Disk Physical I/O counters
        perdisk_deltas = {}
        try:
            curr_perdisk = ps.disk_io_counters(perdisk=True)
            if curr_perdisk and _last_perdisk_counters and dt > 0:
                for dname, c in curr_perdisk.items():
                    if dname in _last_perdisk_counters:
                        pr_c = _last_perdisk_counters[dname]
                        r_diff = max(0, c.read_bytes - pr_c[0])
                        w_diff = max(0, c.write_bytes - pr_c[1])
                        rc_diff = max(0, c.read_count - pr_c[2])
                        wc_diff = max(0, c.write_count - pr_c[3])
                        busy_diff = max(0, getattr(c, "busy_time", c.read_time + c.write_time) - pr_c[4])
                        r_mb = round((r_diff / dt) / 1048576, 2)
                        w_mb = round((w_diff / dt) / 1048576, 2)
                        act_pct = min(100.0, round((busy_diff / (dt * 1000)) * 100, 1)) if dt > 0 else round((r_mb + w_mb) * 2.5, 1)
                        perdisk_deltas[dname] = {
                            "read_mb_s": r_mb,
                            "write_mb_s": w_mb,
                            "read_iops": int(rc_diff / dt),
                            "write_iops": int(wc_diff / dt),
                            "active_pct": act_pct,
                        }
            if curr_perdisk:
                for dname, c in curr_perdisk.items():
                    _last_perdisk_counters[dname] = (
                        c.read_bytes, c.write_bytes, c.read_count, c.write_count,
                        getattr(c, "busy_time", c.read_time + c.write_time)
                    )
        except Exception:
            pass

        # Network I/O & throughput deltas
        n_curr = None
        try:
            n_curr = ps.net_io_counters()
        except Exception:
            pass

        net_send_mbps = 0.0
        net_recv_mbps = 0.0
        net_pkts_sent_s = 0
        net_pkts_recv_s = 0

        if n_curr and _last_net_counters and dt > 0:
            s_diff = max(0, n_curr.bytes_sent - _last_net_counters.bytes_sent)
            r_diff = max(0, n_curr.bytes_recv - _last_net_counters.bytes_recv)
            ps_diff = max(0, n_curr.packets_sent - _last_net_counters.packets_sent)
            pr_diff = max(0, n_curr.packets_recv - _last_net_counters.packets_recv)
            net_send_mbps = round(((s_diff * 8) / dt) / 1000000, 2)
            net_recv_mbps = round(((r_diff * 8) / dt) / 1000000, 2)
            net_pkts_sent_s = int(ps_diff / dt)
            net_pkts_recv_s = int(pr_diff / dt)
        _last_net_counters = n_curr
        _last_perf_time = now

        # Active Network & Wi-Fi Details (IPv6, IPv4, MAC, SSID)
        active_adapter = "Wi-Fi"
        ipv4_addr = "127.0.0.1"
        ipv6_addr = ""
        mac_addr = ""
        wifi_ssid = ""
        link_speed = 1000
        try:
            addrs = ps.net_if_addrs()
            stats = ps.net_if_stats()
            candidates = []
            for iface, s in stats.items():
                if s.isup and iface in addrs:
                    v4 = [a.address for a in addrs[iface] if a.family.name == "AF_INET" and not a.address.startswith("127.") and not a.address.startswith("169.254.")]
                    v6 = [a.address for a in addrs[iface] if a.family.name == "AF_INET6" and not a.address.startswith("fe80") and not a.address == "::1"]
                    mac = [a.address for a in addrs[iface] if a.family.name == "AF_LINK" and a.address]
                    if v4 or v6:
                        candidates.append((iface, s.speed or 1000, v4[0] if v4 else "", v6[0] if v6 else "", mac[0] if mac else ""))

            if candidates:
                chosen = next((c for c in candidates if "Wi-Fi" in c[0]), candidates[0])
                active_adapter = chosen[0]
                link_speed = chosen[1]
                ipv4_addr = chosen[2] or "127.0.0.1"
                ipv6_addr = chosen[3]
                mac_addr = chosen[4]
                if not ipv6_addr:
                    for c in candidates:
                        if c[3]:
                            ipv6_addr = c[3]
                            break

            if not _CACHED_WIFI_INFO or (now - _LAST_WIFI_TIME > 10.0):
                _update_wifi_info()
            wifi_ssid = _CACHED_WIFI_INFO.get("ssid", "")
            if not wifi_ssid and "Wi-Fi" in active_adapter:
                wifi_ssid = active_adapter
        except Exception:
            pass

        # Disks drives with uncombined physical stats
        disks = []
        try:
            for dp in ps.disk_partitions(all=False):
                try:
                    u = ps.disk_usage(dp.mountpoint)
                    drive_let = dp.mountpoint[:2].upper()
                    phys_name = _DRIVE_TO_PHYSICAL.get(drive_let, "PhysicalDrive0" if drive_let == "C:" else "PhysicalDrive1")
                    p_st = perdisk_deltas.get(phys_name, {})
                    disks.append({
                        "mount": dp.mountpoint,
                        "drive": drive_let,
                        "fs": dp.fstype,
                        "total_gb": round(u.total / 1e9, 1),
                        "used_gb": round(u.used / 1e9, 1),
                        "free_gb": round(u.free / 1e9, 1),
                        "pct": u.percent,
                        "read_mb_s": p_st.get("read_mb_s", 0.0),
                        "write_mb_s": p_st.get("write_mb_s", 0.0),
                        "active_pct": p_st.get("active_pct", 0.0),
                        "read_iops": p_st.get("read_iops", 0),
                        "write_iops": p_st.get("write_iops", 0),
                        "model": (_HW.get("disks") or {}).get(drive_let, {}).get("model", ""),
                        "kind": (_HW.get("disks") or {}).get(drive_let, {}).get("kind", ""),
                    })
                except Exception:
                    pass
        except Exception:
            pass

        # GPU metrics
        gpu_pct, gpu_vram_mb, gpu_name = _gpu_total_stats()
        pdh_gpu, pdh_eng = _get_gpu_util_pdh()
        if gpu_pct <= 0 and pdh_gpu:
            gpu_pct = min(100.0, round(max(pdh_gpu.values()), 1))

        gpu_vram_total_mb = 0.0
        try:
            import pynvml
            pynvml.nvmlInit()
            h = pynvml.nvmlDeviceGetHandleByIndex(0)
            gpu_vram_total_mb = round(pynvml.nvmlDeviceGetMemoryInfo(h).total / 1048576, 1)
            pynvml.nvmlShutdown()
        except Exception:
            pass
        if gpu_vram_total_mb <= 0:
            gpu_vram_total_mb = round(vram_total_mb(), 1)          # not a made-up 8 GB: 0 means "unknown" and the UI says so

        # Memory composition breakdown
        mem_total_gb = round(mem.total / 1e9, 2)
        mem_used_gb = round(mem.used / 1e9, 2)
        mem_avail_gb = round(mem.available / 1e9, 2)
        mem_free_gb = round(getattr(mem, "free", 0) / 1e9, 2)
        mem_cached_gb = round(getattr(mem, "cached", 0) / 1e9, 2) or round(max(0.0, mem_avail_gb - mem_free_gb), 2)
        committed_gb = round((getattr(swap, "used", 0) + mem.used) / 1e9, 2)
        commit_limit_gb = round((getattr(swap, "total", 0) + mem.total) / 1e9, 2)
        paged_pool_mb = round(getattr(mem, "paged", 0) / 1048576, 0) or 480
        nonpaged_pool_mb = round(getattr(mem, "nonpaged", 0) / 1048576, 0) or 320

        # System totals
        uptime_s = round(now - ps.boot_time(), 0) if hasattr(ps, "boot_time") else 0
        proc_count = len(ps.pids())

        if not _CACHED_BT_INFO.get("apps"):
            _update_bluetooth_info()

        return {
            "cpu_pct": round(cpu_pct, 1),
            "cpu_cores": ps.cpu_count(logical=False) or 0,
            "cpu_threads": ps.cpu_count(logical=True) or 0,
            "cpu_freq_mhz": _c.get("freq_mhz") or (round(cpu_freq.current, 0) if cpu_freq else 0),
            "cpu_freq_max": (cpu_freq.max if cpu_freq and cpu_freq.max else 0) or _c.get("base_mhz") or 0,
            "per_cpu": [round(c, 1) for c in (per_cpu or [])],
            "uptime_s": uptime_s,
            "proc_count": proc_count,
            "mem_total_gb": mem_total_gb,
            "mem_used_gb": mem_used_gb,
            "mem_avail_gb": mem_avail_gb,
            "mem_free_gb": mem_free_gb,
            "mem_cached_gb": mem_cached_gb,
            "mem_pct": round(mem.percent, 1),
            "mem_committed_gb": committed_gb,
            "mem_commit_limit_gb": commit_limit_gb,
            **_hw_mem_fields(),
            "mem_paged_pool_mb": paged_pool_mb,
            "mem_nonpaged_pool_mb": nonpaged_pool_mb,
            "disk_read_mb_s": disk_read_mb_s,
            "disk_write_mb_s": disk_write_mb_s,
            "disk_read_iops": disk_read_iops,
            "disk_write_iops": disk_write_iops,
            "disk_active_pct": disk_active_pct,
            "disks": disks,
            "net_send_mbps": net_send_mbps,
            "net_recv_mbps": net_recv_mbps,
            "net_pkts_sent_s": net_pkts_sent_s,
            "net_pkts_recv_s": net_pkts_recv_s,
            "net_adapter": active_adapter,
            "net_adapter_desc": (_HW.get("nics") or {}).get(active_adapter, ""),
            "net_ipv4": ipv4_addr,
            "net_ipv6": ipv6_addr,
            "net_mac": mac_addr,
            "net_ssid": wifi_ssid,
            "net_speed_mbps": link_speed,
            "gpu_pct": round(gpu_pct, 1),
            "gpu_vram_mb": round(gpu_vram_mb, 1),
            "gpu_vram_total_mb": round(gpu_vram_total_mb, 1),
            "gpu_name": gpu_name or "Graphics Engine",
            "gpu_engines": pdh_eng,
            "cpu_name": _get_cpu_name(),
            "cpu_gen": _get_cpu_gen(),
            "bt_adapter": _CACHED_BT_INFO.get("adapter", "Intel(R) Wireless Bluetooth(R)"),
            "bt_devices": _CACHED_BT_INFO.get("devices", []),
            "bt_device_count": _CACHED_BT_INFO.get("device_count", 0),
            "bt_connected": _CACHED_BT_INFO.get("connected", False),
            "bt_apps": _CACHED_BT_INFO.get("apps", []),
            "bt_active_pct": _CACHED_BT_INFO.get("active_pct", 0.0),
            "ts": now,
        }
    except Exception as exc:
        _log.debug("tm_performance: %s", exc)
        return {}


_NET_FIRST: dict = {}                      # connection key -> first time we saw it (for "age")
_RDNS: dict = {}                           # ip -> hostname ("" = none)
_RDNS_PENDING: set = set()
_RDNS_POOL = None


def _rdns(ip: str) -> str:
    """Reverse DNS without ever blocking the refresh: the first call starts the lookup, later calls return the answer."""
    global _RDNS_POOL
    if ip in _RDNS:
        return _RDNS[ip]
    if ip in _RDNS_PENDING or len(_RDNS_PENDING) > 40:
        return ""
    import socket
    from concurrent.futures import ThreadPoolExecutor
    if _RDNS_POOL is None:
        _RDNS_POOL = ThreadPoolExecutor(max_workers=8, thread_name_prefix="tm-rdns")
    _RDNS_PENDING.add(ip)

    def work():
        try:
            _RDNS[ip] = clean(socket.gethostbyaddr(ip)[0])
        except Exception:
            _RDNS[ip] = ""
        finally:
            _RDNS_PENDING.discard(ip)
    _RDNS_POOL.submit(work)
    return ""


@rpc("tm.network")
def tm_network():
    ps = _ps()
    if not ps:
        return []
    try:
        from modules.network.monitor import Connection, net_monitor
        from modules.network.netwatch import _SERVICES
    except Exception:
        Connection = net_monitor = None
        _SERVICES = {}

    pid_info = {}
    try:
        with _LOCK:
            for p in _CACHED_PROCS:
                pid_info[p["pid"]] = (p["name"], p["exe"], p.get("icon", ""), p.get("signer", ""))
    except Exception:
        pass

    now = time.time()
    seen = set()
    out = []
    try:
        for c in ps.net_connections(kind="inet"):
            lip = privacy.strip(c.laddr.ip) if c.laddr else ""
            rip = privacy.strip(c.raddr.ip) if c.raddr else ""
            lport = c.laddr.port if c.laddr else 0
            rport = c.raddr.port if c.raddr else 0
            la = f"{lip}:{lport}" if c.laddr else ""
            ra = f"{rip}:{rport}" if c.raddr else ""
            pid = c.pid or 0
            pname, pexe, picon, psign = pid_info.get(pid, ("", "", "", ""))
            if not pname and pid:
                try:
                    pr = ps.Process(pid)
                    pname = clean(pr.name())
                    pexe = pr.exe()
                    picon = _extract_icon(pexe)
                    psign = clean(_get_signer(pexe, pname))
                except Exception:
                    pass
            proto = "UDP" if c.type and "DGRAM" in str(c.type) else "TCP"
            status = c.status if c.status and c.status != "NONE" else ("LISTEN" if not c.raddr and proto == "TCP" else ("OPEN" if not c.raddr else "ESTABLISHED"))
            key = (pid, la, ra, proto)
            seen.add(key)
            first = _NET_FIRST.setdefault(key, now)
            if not ra:
                scope = "listen"
            elif lip.startswith("127.") or lip == "::1" or rip.startswith("127.") or rip == "::1":
                scope = "loopback"
            elif privacy.is_mine(rip):
                scope = "lan"
            else:
                scope = "internet"
            threat, reason = 0, ""
            if Connection is not None and ra and scope != "loopback":
                try:
                    cn = Connection(pid=pid, proc=pname or "", laddr=lip, lport=lport, raddr=rip, rport=rport, status=status, proto=proto, first_seen=first)
                    threat, reason = net_monitor._score(cn)
                except Exception:
                    pass
            out.append({
                "pid": pid,
                "proc": clean(pname) or ("System" if pid == 4 else "Idle"),
                "exe": pexe,
                "icon": picon,
                "signer": clean(psign) if psign else clean(_get_signer(pexe, pname)),
                "laddr": la,
                "raddr": ra,
                "lm": privacy.is_mine(lip),                # YOUR address -> hidden behind a click in the UI
                "rm": bool(rip) and privacy.is_mine(rip),
                "lport": lport,
                "rport": rport,
                "status": status,
                "proto": proto,
                "scope": scope,
                "service": _SERVICES.get(rport) or _SERVICES.get(lport) or "",
                "threat": threat,
                "reason": reason,
                "rdns": _rdns(rip) if rip and scope == "internet" else "",
                "age": int(now - first),
            })
    except Exception as exc:
        _log.debug("tm_network: %s", exc)
    for k in [k for k in _NET_FIRST if k not in seen]:
        del _NET_FIRST[k]
    return out


@rpc("tm.network_info")
def tm_network_info():
    """Adapters with live counters, TCP state mix, latency / Wi-Fi / public IP (for the Network tab's overview)."""
    from modules.network.netwatch import netwatch
    return netwatch.extra()


@rpc("tm.network_block")
def tm_network_block(ip: str, block: bool = True):
    from modules.network.monitor import net_monitor
    from modules.network.netwatch import netwatch
    ok = net_monitor.block_ip(ip) if block else net_monitor.unblock_ip(ip)
    try:
        netwatch._save()
    except Exception:
        pass
    return bool(ok)


@rpc("tm.network_blocked")
def tm_network_blocked():
    from modules.network.monitor import net_monitor
    return [{"ip": ip, "mine": privacy.is_mine(ip)} for ip in sorted(net_monitor._blocked_ips)]


def _is_startup_enabled(hive_key, sub: str, name: str) -> bool:
    for h in (hive_key, winreg.HKEY_CURRENT_USER):
        try:
            k = winreg.OpenKey(h, rf"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\{sub}")
            val, _ = winreg.QueryValueEx(k, name)
            winreg.CloseKey(k)
            if isinstance(val, (bytes, bytearray)) and len(val) > 0:
                return (val[0] % 2 == 0)
        except Exception:
            pass
    return True


def _collect_startup() -> list[dict]:
    entries = []
    seen_cmds = set()
    locations = [
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "Registry (User)"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "Registry (System)"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "Registry (RunOnce)"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "Registry (RunOnce)"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run", "Registry (32-bit)"),
    ]
    for hive, path, src_name in locations:
        try:
            k = winreg.OpenKey(hive, path, 0, winreg.KEY_READ)
            i = 0
            while True:
                try:
                    name, raw_val, _ = winreg.EnumValue(k, i)
                    val = os.path.expandvars(raw_val or "").strip()
                    if val and val not in seen_cmds:
                        seen_cmds.add(val)
                        exe_guess = val.split('"')[1] if '"' in val else val.split()[0]
                        recog = _recognize(name, exe_guess)
                        icon = _extract_icon(exe_guess)
                        signer = _get_signer(exe_guess, name)
                        enabled = _is_startup_enabled(hive, "Run", name)
                        entries.append({
                            "name": name,
                            "cmd": val,
                            "source": src_name,
                            "hive": "HKCU" if hive == winreg.HKEY_CURRENT_USER else "HKLM",
                            "recog": recog,
                            "signer": signer,
                            "icon": icon,
                            "status": "Enabled" if enabled else "Disabled",
                        })
                    i += 1
                except OSError:
                    break
            winreg.CloseKey(k)
        except OSError:
            pass

    folders = [
        (Path(os.environ.get("APPDATA", "")) / r"Microsoft\Windows\Start Menu\Programs\Startup", "Startup Folder (User)"),
        (Path(os.environ.get("PROGRAMDATA", "")) / r"Microsoft\Windows\Start Menu\Programs\Startup", "Startup Folder (All Users)"),
    ]
    for folder, src_name in folders:
        try:
            if folder.exists():
                for f in folder.iterdir():
                    if f.name.lower() in ("desktop.ini", "thumbs.db"):
                        continue
                    if f.suffix.lower() in (".lnk", ".bat", ".cmd", ".exe", ".url"):
                        f_str = str(f)
                        if f_str not in seen_cmds:
                            seen_cmds.add(f_str)
                            icon = _extract_icon(f_str)
                            signer = _get_signer(f_str, f.stem)
                            enabled = _is_startup_enabled(winreg.HKEY_CURRENT_USER, "StartupFolder", f.name)
                            entries.append({
                                "name": f.stem,
                                "raw_name": f.name,
                                "cmd": f_str,
                                "source": src_name,
                                "hive": "Folder",
                                "recog": _recognize(f.stem, f_str),
                                "signer": signer,
                                "icon": icon,
                                "status": "Enabled" if enabled else "Disabled",
                            })
        except Exception:
            pass
    for _e in entries:
        _e["signer"] = clean(_e.get("signer"))
        _e["cmd"] = clean(_e.get("cmd"))
    return entries


@rpc("tm.startup")
def tm_startup():
    global _CACHED_STARTUP
    with _LOCK:
        if _CACHED_STARTUP:
            return list(_CACHED_STARTUP)
    data = _collect_startup()
    with _LOCK:
        _CACHED_STARTUP = data
    return data


@rpc("tm.startup_toggle")
def tm_startup_toggle(name: str, hive: str, enable: bool):
    """Toggles startup application enabled/disabled state using Windows native StartupApproved registry keys."""
    try:
        val_data = b"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" if enable else b"\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        sub = "StartupFolder" if "Folder" in hive else "Run"
        key_path = rf"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\{sub}"

        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
        winreg.SetValueEx(k, name, 0, winreg.REG_BINARY, val_data)
        winreg.CloseKey(k)

        if "HKLM" in hive:
            try:
                k2 = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                winreg.SetValueEx(k2, name, 0, winreg.REG_BINARY, val_data)
                winreg.CloseKey(k2)
            except Exception:
                pass

        global _CACHED_STARTUP
        with _LOCK:
            _CACHED_STARTUP = _collect_startup()
        return True
    except Exception as exc:
        _log.error("tm_startup_toggle error: %s", exc)
        return str(exc)


@rpc("tm.thread_breakdown")
def tm_thread_breakdown(thread_idx: int = None):
    """thread_idx None -> top threads system-wide (old list).
    thread_idx = N    -> what is really running on logical CPU N (dict: source, usage, rows ...)."""
    if thread_idx is None:
        with _LOCK:
            if _CACHED_THREADS:
                return [dict(t, name=clean(t.get("name")), signer=clean(t.get("signer"))) for t in _CACHED_THREADS]
        return _collect_threads()
    from modules.system.cputrace import cpu_trace
    with _LOCK:
        procs = list(_CACHED_PROCS)
    return cpu_trace.breakdown(int(thread_idx), procs)


@rpc("tm.thread_trace_stop")
def tm_thread_trace_stop():
    from modules.system.cputrace import cpu_trace
    cpu_trace.stop()
    return True


def _collect_services() -> list[dict]:
    ps = _ps()
    if not ps:
        return []
    out = []
    try:
        for s in ps.win_service_iter():
            try:
                d = s.as_dict()
                binpath = d.get("binpath") or ""
                clean_bin = binpath.split('"')[1] if '"' in binpath else binpath.split()[0] if binpath else ""
                icon = _extract_icon(clean_bin)
                raw_start = str(d.get("start_type") or "manual").lower()
                if "auto" in raw_start:
                    start_mode = "Automatic"
                elif "disabled" in raw_start:
                    start_mode = "Disabled"
                else:
                    start_mode = "Manual"

                raw_status = str(d.get("status") or "stopped").lower()
                status = "Running" if raw_status == "running" else "Stopped"
                pid = d.get("pid")
                pid_str = str(pid) if (pid and status == "Running") else "Stopped"

                out.append({
                    "name": clean(d.get("name") or ""),
                    "raw": d.get("name") or "",              # real service name - only used to start / stop it
                    "display": clean(d.get("display_name") or d.get("name") or ""),
                    "state": status,
                    "start": start_mode,
                    "pid": pid_str,
                    "path": clean(binpath),
                    "icon": icon,
                    "signer": clean(_get_signer(clean_bin, d.get("name") or "")),
                    "desc": clean((d.get("description") or "Windows system service")[:220]),
                })
            except Exception:
                pass
        out.sort(key=lambda x: (0 if x["state"] == "Running" else 1, x["display"].lower()))
        return out
    except Exception as exc:
        _log.debug("_collect_services error: %s", exc)
        return []


@rpc("tm.services")
def tm_services():
    global _CACHED_SERVICES
    with _LOCK:
        if _CACHED_SERVICES:
            return list(_CACHED_SERVICES)
    data = _collect_services()
    with _LOCK:
        _CACHED_SERVICES = data
    return data


@rpc("tm.service_action")
def tm_service_action(name: str, action: str):
    global _CACHED_SERVICES
    if action not in ("start", "stop", "restart"):
        return "invalid action"
    with _LOCK:                                              # the UI shows scrubbed names - map back to the real service name
        for _s in _CACHED_SERVICES:
            if _s.get("name") == name and _s.get("raw"):
                name = _s["raw"]
                break
    try:
        if action == "restart":
            subprocess.run(["net", "stop", name], capture_output=True, timeout=30, creationflags=_NO_WIN)
            subprocess.run(["net", "start", name], capture_output=True, timeout=30, creationflags=_NO_WIN)
        else:
            subprocess.run(["net", action, name], capture_output=True, timeout=30, creationflags=_NO_WIN)
        with _LOCK:
            _CACHED_SERVICES = _collect_services()
        return True
    except Exception as exc:
        return str(exc)


_CACHED_USERS: list[dict] = []
_LAST_USERS_TIME: float = 0.0

@rpc("tm.users")
def tm_users():
    global _CACHED_USERS, _LAST_USERS_TIME
    ps = _ps()
    if not ps:
        return _CACHED_USERS
    try:
        curr_user = os.environ.get("USERNAME", "Darko")
        computer_name = os.environ.get("COMPUTERNAME", "PC")

        with _LOCK:
            proc_list = list(_CACHED_PROCS) if _CACHED_PROCS else []

        if not proc_list:
            proc_list = _collect_processes()

        mem_info = ps.virtual_memory()
        total_sys_mem_mb = round(mem_info.total / 1048576, 1)

        users = {}
        # 1. Primary logged-in user session (guaranteed stable)
        users[curr_user] = {
            "user": curr_user,
            "domain": computer_name,
            "is_current": True,
            "status": "Active",
            "session_id": 1,
            "cpu": 0.0,
            "mem_mb": 0.0,
            "mem_pct": 0.0,
            "total_mem_mb": total_sys_mem_mb,
            "procs": 0,
            "proc_list": []
        }

        # 2. System service accounts
        sys_group_name = "System Services"
        users[sys_group_name] = {
            "user": sys_group_name,
            "domain": "NT AUTHORITY",
            "is_current": False,
            "status": "Background",
            "session_id": 0,
            "cpu": 0.0,
            "mem_mb": 0.0,
            "mem_pct": 0.0,
            "total_mem_mb": total_sys_mem_mb,
            "procs": 0,
            "proc_list": []
        }

        curr_user_low = curr_user.lower()
        for p in proc_list:
            if p.get("pid") == 0:
                continue

            u_raw = (p.get("user") or "").strip()
            u_clean = u_raw.split("\\")[-1]
            p_cat = p.get("category") or "background"

            is_user_proc = (
                u_clean.lower() == curr_user_low or
                p_cat == "app" or
                p.get("name") == "DWUT" or
                (p.get("exe") and "users" in p.get("exe", "").lower() and curr_user_low in p.get("exe", "").lower())
            )

            target_user = curr_user if is_user_proc else sys_group_name
            entry = users[target_user]

            entry["cpu"] += p.get("cpu", 0.0)
            entry["mem_mb"] += p.get("mem_mb", 0.0)
            entry["procs"] += 1
            entry["proc_list"].append({
                "pid": p["pid"],
                "name": p["name"],
                "cpu": p.get("cpu", 0.0),
                "mem_mb": p.get("mem_mb", 0.0),
                "gpu": p.get("gpu", 0.0),
                "disk_rate": p.get("disk_rate", 0.0),
                "icon": p.get("icon", ""),
                "signer": p.get("signer", "Standard"),
                "exe": p.get("exe", "")
            })

        out = [users[curr_user], users[sys_group_name]]
        for u in out:
            u["cpu"] = round(min(100.0, u["cpu"]), 1)
            u["mem_mb"] = round(u["mem_mb"], 1)
            u["mem_pct"] = round(min(100.0, (u["mem_mb"] / total_sys_mem_mb) * 100.0), 1)
            u["proc_list"].sort(key=lambda x: (-(x.get("cpu") or 0), -(x.get("mem_mb") or 0)))

        _CACHED_USERS = out
        _LAST_USERS_TIME = time.time()
        return out
    except Exception as exc:
        _log.error("tm_users: %s", exc)
        return _CACHED_USERS

"""api/vpn_api.py - free full-system VPN (DWUTVPN) over Cloudflare WARP.

100% free, no account. WARP protects your traffic (public Wi-Fi, ISP snooping) but Cloudflare picks the exit near
you, so it does not change your location. Privacy options (kill switch, DNS, IPv6, browser leaks) are real and applied
when connecting.
"""
from __future__ import annotations

import ipaddress
import json
import re
import subprocess
import threading
import time
import winreg

from core.events import Events, bus
from core.mask import clean
from core.logger import get_logger
from server import emit, rpc
from modules.vpn import tunconf, tunnel

_log = get_logger("api.vpn")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

DEFAULT_OPTS = {
    "kill_switch": True,        # block all traffic outside the tunnel (tunnel service firewall rules)
    "dns_protect": True,        # DNS only through the tunnel, using Cloudflare's resolvers
    "ipv6_block": True,         # IPv6 can't leak around the tunnel
    "browser_protect": True,    # Chrome/Edge/Brave: stop WebRTC + QUIC leaking your real IP
    "auto_reconnect": True,     # bring the tunnel back if it drops
}

_st = {
    "on": False, "busy": False, "status": "off", "since": 0.0, "server": None, "ip": "", "country": "",
    "country_code": "", "city": "", "provider": "warp", "opts": dict(DEFAULT_OPTS), "notes": [],
}
_stop = threading.Event()
_ctx = {"conf": "", "real_ip": ""}                      # what the running tunnel was built from
_autostart_done = False
_POLICY_BACKUP = tunnel.BASE / "browser_policy_backup.json"


# ── helpers ───────────────────────────────────────────────────────────────────

def _is_admin() -> bool:
    try:
        from app.state import state
        return bool(state.is_admin)
    except Exception:
        import ctypes
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False


def _push() -> None:
    emit("vpn.state", dict(_st))


def _prog(msg: str, pct: float | None = None) -> None:
    emit("vpn.progress", {"msg": re.sub(r"[\U00010000-\U0010ffff]|[\u2600-\u27bf]", "", msg), "pct": pct})


def _run_cmd(cmd: list[str], timeout: int = 30) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WIN, stdin=subprocess.DEVNULL)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return -1, str(exc)


def _cfg():
    from app.config import config
    return config


def _load_prefs() -> None:
    try:
        pr = _cfg().vpn_prefs or {}
        _st["opts"] = {**DEFAULT_OPTS, **{k: v for k, v in (pr.get("opts") or {}).items() if k in DEFAULT_OPTS}}
    except Exception:
        pass


def _save_prefs() -> None:
    try:
        c = _cfg()
        c.vpn_prefs = {"opts": dict(_st["opts"])}
        c.save()
    except Exception as exc:
        _log.debug("save prefs: %s", exc)


def _adopt_running() -> None:
    """DWUT was restarted while the tunnel kept running: pick the session back up."""
    if _st["on"] or _st["busy"]:
        return
    try:
        if tunnel.service_exists() and tunnel.is_up():
            info = tunnel.exit_info()
            _st.update(on=True, status="connected", since=time.time(), ip=info["ip"],
                       country=info["country"] or info["cc"], country_code=info["cc"], city=info["city"])
            _stop.clear()
            threading.Thread(target=_tunnel_monitor, daemon=True, name="vpn-monitor").start()
    except Exception:
        pass


# ── browser leak protection (Chrome / Edge / Brave policies) ──────────────────

_BROWSERS = {
    "Chrome": r"SOFTWARE\Policies\Google\Chrome",
    "Edge": r"SOFTWARE\Policies\Microsoft\Edge",
    "Brave": r"SOFTWARE\Policies\BraveSoftware\Brave",
}
_POLICIES = [("WebRtcIPHandling", winreg.REG_SZ, "disable_non_proxied_udp"),     # WebRTC may not reveal real/LAN IPs
             ("WebRtcLocalhostIpHandling", winreg.REG_SZ, "DisableNonProxiedUdp"),
             ("QuicAllowed", winreg.REG_DWORD, 0)]                               # QUIC/HTTP3 is UDP: keep it inside the tunnel


def _apply_browser_policies() -> list[str]:
    done, backup = [], {}
    for browser, path in _BROWSERS.items():
        try:
            key = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ | winreg.KEY_WRITE | winreg.KEY_WOW64_64KEY)
            for name, typ, val in _POLICIES:
                if browser != "Edge" and name == "WebRtcLocalhostIpHandling":
                    continue
                try:
                    old = winreg.QueryValueEx(key, name)
                    backup[f"{path}|{name}"] = [old[0], old[1]]
                except OSError:
                    backup[f"{path}|{name}"] = None
                winreg.SetValueEx(key, name, 0, typ, val)
            winreg.CloseKey(key)
            done.append(browser)
        except OSError:
            continue
    try:
        if not _POLICY_BACKUP.exists():            # keep the ORIGINAL values if we get applied twice
            _POLICY_BACKUP.write_text(json.dumps(backup), encoding="utf-8")
    except Exception:
        pass
    return done


def _restore_browser_policies() -> None:
    try:
        backup = json.loads(_POLICY_BACKUP.read_text(encoding="utf-8"))
    except Exception:
        return
    for k, old in backup.items():
        path, name = k.split("|", 1)
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_WRITE | winreg.KEY_WOW64_64KEY)
            if old is None:
                try:
                    winreg.DeleteValue(key, name)
                except OSError:
                    pass
            else:
                winreg.SetValueEx(key, name, 0, old[1], old[0])
            winreg.CloseKey(key)
        except OSError:
            continue
    try:
        _POLICY_BACKUP.unlink()
    except Exception:
        pass


# ── building the tunnel config ────────────────────────────────────────────────

def _system_public_dns() -> list[str]:
    """The user's own non-router DNS servers (e.g. 8.8.8.8 they set on their adapter)."""
    code, out = _run_cmd(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                          "Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch 'DWUTVPN|Loopback|vEthernet' } | ForEach-Object { $_.ServerAddresses }"], 20)
    found: list[str] = []
    for line in out.split():
        try:
            ip = ipaddress.ip_address(line.strip())
            if not (ip.is_private or ip.is_loopback or ip.is_link_local) and line.strip() not in found:
                found.append(line.strip())
        except ValueError:
            continue
    return found[:2]


def _dns_for(opts: dict) -> list[str]:
    v6 = not opts.get("ipv6_block", True)
    cloudflare = ["1.1.1.1", "1.0.0.1"] + (["2606:4700:4700::1111", "2606:4700:4700::1001"] if v6 else [])
    if opts.get("dns_protect", True):
        return cloudflare
    return _system_public_dns() or cloudflare    # "off" = keep the DNS servers you chose yourself (a router-only setup can't resolve inside a full tunnel)


def _prepare(opts: dict) -> str:
    """The exact tunnel config text for the free Cloudflare WARP profile, with the user's privacy options applied."""
    tunnel.ensure_profile(lambda m: _log.info(m), lambda f: _prog("Preparing your free profile…", 0.2 + 0.15 * f))
    profile = tunconf.parse_conf(tunnel.WARP_PROFILE.read_text(encoding="utf-8"))
    return tunconf.render_conf(profile, kill_switch=opts.get("kill_switch", True), ipv6_block=opts.get("ipv6_block", True),
                              dns=_dns_for(opts), mtu=profile.get("mtu") or 1280)


# ── connect / disconnect ──────────────────────────────────────────────────────

def _connect(opts: dict) -> None:
    notes: list[str] = []
    try:
        _st.update(busy=True, status="connecting", notes=[], opts=opts)
        _push()
        if not _is_admin():
            raise RuntimeError("Administrator rights are required to run the VPN tunnel.")
        _prog("Preparing…", 0.05)
        tunnel.migrate_legacy(lambda m: _log.info(m))
        tunnel.ensure_client(lambda m: _log.info(m), lambda f: _prog("Installing the VPN component…", 0.05 + 0.25 * f))
        _prog("Building your connection…", 0.4)
        try:
            real_ip = tunnel.trace().get("ip", "") if not tunnel.service_exists() else _ctx["real_ip"]
        except Exception:
            real_ip = _ctx["real_ip"]
        conf = _prepare(opts)
        _prog("Connecting…", 0.65)
        t = tunnel.connect(conf, lambda m: _log.info(m), expect_warp=True, real_ip=real_ip)
        _ctx.update(conf=conf, real_ip=real_ip or _ctx["real_ip"])
        _stop.clear()
        if opts.get("browser_protect", True):
            done = _apply_browser_policies()
            if done:
                notes.append("Browser protection on for " + ", ".join(done) + " - restart the browser to apply.")
        else:
            _restore_browser_policies()
        info = tunnel.exit_info()
        _st.update(on=True, busy=False, status="connected", since=time.time(), ip=info["ip"] or t.get("ip", ""),
                   country=info["country"] or info["cc"] or "Cloudflare WARP", country_code=info["cc"], city=info["city"],
                   server={"hostname": "Cloudflare WARP", "ip": "", "port": 2408, "protocol": "DWUT Tunnel"}, notes=notes)
        _prog("Connected", 1.0)
        _push()
        threading.Thread(target=_tunnel_monitor, daemon=True, name="vpn-monitor").start()
    except Exception as exc:
        _log.error("VPN connect failed: %s", exc)
        try:
            tunnel.disconnect()
        except Exception:
            pass
        _st.update(on=False, busy=False, status="off", server=None, notes=[clean(f"Connection failed: {exc}")])
        _prog("", None)
        _push()


def _tunnel_monitor() -> None:
    bad = 0
    while not _stop.wait(15):
        if not _st["on"]:
            return
        up = tunnel.is_up()
        if up:
            try:
                t = tunnel.trace()
                up = t["on"]
                if up and t["ip"] and t["ip"] != _st.get("ip"):
                    _st["ip"] = t["ip"]
                    _push()
            except Exception:
                up = False
        if up:
            bad = 0
            if _st["status"] != "connected":
                _st["status"] = "connected"
                _push()
            continue
        bad += 1
        if bad < 2:
            continue
        if not _st["opts"].get("auto_reconnect", True):
            _st.update(status="degraded", notes=["Connection lost - the kill switch keeps your traffic blocked. Reconnect when ready."])
            _push()
            continue
        _st["status"] = "reconnecting"
        _push()
        try:
            t = tunnel.connect(_ctx["conf"], lambda m: None, expect_warp=True, real_ip=_ctx["real_ip"])
            _st.update(status="connected", ip=t.get("ip", ""), notes=[])
            bad = 0
        except Exception:
            _st.update(status="degraded", notes=["Connection lost - kill switch active. Retrying..."])
        _push()


def _disconnect() -> None:
    _stop.set()
    _st.update(busy=True, status="off")
    _push()
    try:
        tunnel.disconnect()
    except Exception as exc:
        _log.warning("disconnect: %s", exc)
    try:
        _restore_browser_policies()
    except Exception:
        pass
    _st.update(on=False, busy=False, status="off", server=None, notes=[], ip="", country="", country_code="", city="")
    _prog("", None)
    _push()


def shutdown_vpn() -> None:
    """DWUT is closing. The tunnel is left as the user had it (it is a normal Windows service)."""
    _stop.set()


# ── RPC ───────────────────────────────────────────────────────────────────────

@rpc("vpn.state")
def vpn_state():
    return dict(_st)


@rpc("vpn.connect")
def vpn_connect(opts: dict | None = None):
    if _st["busy"]:
        return False
    o = {**_st["opts"], **{k: v for k, v in (opts or {}).items() if k in DEFAULT_OPTS}}
    _st["opts"] = o
    _save_prefs()
    threading.Thread(target=_connect, args=(o,), daemon=True, name="vpn-connect").start()
    return True


@rpc("vpn.disconnect")
def vpn_disconnect():
    threading.Thread(target=_disconnect, daemon=True, name="vpn-disconnect").start()
    return True


@rpc("vpn.panic")
def vpn_panic():
    """Emergency: remove every tunnel + browser rule and restore normal internet right now."""
    _disconnect()
    return True


@rpc("vpn.ip")
@rpc("vpn.check_ip")
def vpn_check_ip():
    try:
        info = tunnel.exit_info()
        if info["ip"] and _st["on"]:
            _st["ip"] = info["ip"]
            _push()
        return info
    except Exception as exc:
        return {"ip": _st.get("ip", ""), "cc": "", "country": "", "city": "", "error": str(exc)}


@rpc("vpn.set_opts")
def vpn_set_opts(opts: dict):
    """Remember privacy options; they take effect on the next connect (use Reconnect if already on)."""
    _st["opts"] = {**_st["opts"], **{k: v for k, v in (opts or {}).items() if k in DEFAULT_OPTS}}
    _save_prefs()
    _push()
    return dict(_st["opts"])


@rpc("vpn.reconnect")
def vpn_reconnect():
    """Apply changed options to a running tunnel."""
    if _st["busy"]:
        return False
    threading.Thread(target=_connect, args=(dict(_st["opts"]),), daemon=True, name="vpn-reconnect").start()
    return True


# ── auto-connect at DWUT start ───────────────────────────────────────────────

@rpc("vpn.autostart_get")
def vpn_autostart_get():
    try:
        return bool(_cfg().vpn_autostart)
    except Exception:
        return False


@rpc("vpn.autostart_set")
def vpn_autostart_set(on: bool):
    c = _cfg()
    c.vpn_autostart = bool(on)
    c.save()
    return True


@rpc("vpn.autostart_run")
def vpn_autostart_run():
    """Called once per DWUT launch by the UI: reconnect if the user turned auto-connect on."""
    global _autostart_done
    if _autostart_done:
        return False
    _autostart_done = True
    _load_prefs()
    _adopt_running()
    if _cfg().vpn_autostart and not _st["on"] and not _st["busy"]:
        if not _is_admin():
            _st["notes"] = ["Auto-connect needs Administrator rights - restart DWUT as administrator."]
            _push()
            return False
        threading.Thread(target=_connect, args=(dict(_st["opts"]),), daemon=True, name="vpn-autostart").start()
        return True
    return False


@rpc("vpn.startup_status")
def vpn_startup_status():
    """Is DWUT already set to start with Windows? (checks Run keys, Startup folder and Task Scheduler)."""
    try:
        from modules.system.startup import get_startup_entries
        for e in get_startup_entries():
            blob = " ".join(str(getattr(e, a, "")) for a in ("name", "command", "path", "target")).lower()
            if "dwut" in blob or "darko" in blob:
                return {"registered": True, "enabled": bool(getattr(e, "enabled", True)), "where": str(getattr(e, "location", "") or getattr(e, "source", ""))}
    except Exception as exc:
        _log.debug("startup scan: %s", exc)
    return {"registered": False, "enabled": False, "where": ""}


@rpc("vpn.startup_enable_existing")
def vpn_startup_enable_existing():
    try:
        from modules.system.startup import get_startup_entries, enable_startup_entry
        for e in get_startup_entries():
            blob = " ".join(str(getattr(e, a, "")) for a in ("name", "command", "path", "target")).lower()
            if ("dwut" in blob or "darko" in blob) and not getattr(e, "enabled", True):
                return bool(enable_startup_entry(e))
    except Exception:
        pass
    return False


@rpc("vpn.connect_stacked")
def vpn_connect_stacked():
    if not _st["on"]:
        return vpn_connect()
    return True


_load_prefs()

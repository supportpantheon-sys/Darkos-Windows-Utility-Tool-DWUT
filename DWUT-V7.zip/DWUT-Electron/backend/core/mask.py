"""
core/mask.py - display scrubbing.

Anything the UI shows that came from the operating system (process names, service names, publisher names,
adapter descriptions, file paths ...) goes through clean() first, so the tunnel engine DWUTVPN uses is always shown
as plain "DWUT Tunnel".  Only DISPLAYED text is changed - real names are still used internally to start/stop things.
"""
from __future__ import annotations

import re

_PAT = re.compile(r"wire[\s_\-]?guard(?:[\s_\-]?windows)?(?:[\s_\-]?(?:llc|tunnel|client|manager))?(?P<exe>\.exe)?", re.I)
_LABEL = "DWUT Tunnel"


def _sub(m):
    return "dwut-tunnel.exe" if m.group("exe") else _LABEL


def clean(text):
    if not isinstance(text, str) or not text:
        return text
    return _PAT.sub(_sub, text)

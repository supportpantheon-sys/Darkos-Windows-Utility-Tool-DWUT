"""
app/updater.py — DWUT auto-updater.

Checks GitHub Releases for a newer version tag on startup (background
thread) and shows an update-available banner in the UI if one is found.
Completely non-blocking — silently swallows all network errors.

Repo: https://github.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT

HOW RELEASING A NEW VERSION WORKS
──────────────────────────────────
1. Make your code changes.
2. Bump CURRENT_VERSION below (e.g. "v3.8.0" → "v3.9.0").
3. Push to GitHub (see GITHUB_GUIDE.md for the exact commands).
4. On GitHub → go to Releases → Draft a new release.
5. Set the tag to match CURRENT_VERSION exactly (e.g. "v3.9.0").
6. Attach the zip of the new version as a release asset.
7. Publish.

The next time any running copy of DWUT starts, it will detect the
new tag, show the update banner, and link to the release page.
"""

from __future__ import annotations

import threading
from typing import Callable, Optional

from core.logger import get_logger

_log = get_logger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
#  ↓↓ ONLY THING YOU EVER NEED TO CHANGE ↓↓
#  Bump this string every time you push a new release to GitHub.
#  Must match the tag you create on the GitHub Releases page exactly.
CURRENT_VERSION = "v7.0.0"
# ─────────────────────────────────────────────────────────────────────────────

GITHUB_OWNER = "supportpantheon-sys"
GITHUB_REPO  = "Darkos-Windows-Utility-Tool-DWUT"

_API_URL = (
    f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/latest"
)
_RELEASES_URL = (
    f"https://github.com/{GITHUB_OWNER}/{GITHUB_REPO}/releases"
)


def _parse_version(tag: str) -> tuple[int, ...]:
    """'v1.2.3' → (1, 2, 3).  Non-numeric segments → 0."""
    clean = tag.lstrip("vV").split("-")[0]
    parts = []
    for seg in clean.split("."):
        try:
            parts.append(int(seg))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _do_check() -> Optional[dict]:
    """Blocking check — always runs on a background thread."""
    try:
        import requests
        resp = requests.get(
            _API_URL,
            headers={"Accept": "application/vnd.github+json"},
            timeout=8,
        )
        if resp.status_code == 404:
            # No releases published yet — not an error
            _log.debug("No GitHub releases found yet for %s/%s", GITHUB_OWNER, GITHUB_REPO)
            return None
        if resp.status_code != 200:
            _log.debug("GitHub API returned %s", resp.status_code)
            return None

        data = resp.json()
        latest_tag = data.get("tag_name", "")
        if not latest_tag:
            return None

        if _parse_version(latest_tag) <= _parse_version(CURRENT_VERSION):
            _log.debug("Up to date (%s >= %s)", CURRENT_VERSION, latest_tag)
            return None

        # Find the zip asset (the one you upload to the release)
        download_url = ""
        for asset in data.get("assets", []):
            name: str = asset.get("name", "")
            if name.lower().endswith(".zip"):
                download_url = asset.get("browser_download_url", "")
                break
        # Fall back to GitHub's auto-generated source zip
        if not download_url:
            download_url = data.get("zipball_url", "")

        notes_raw = (data.get("body") or "").strip()
        notes = notes_raw[:512] + ("…" if len(notes_raw) > 512 else "")

        return {
            "version":  latest_tag,
            "url":      data.get("html_url", _RELEASES_URL),
            "notes":    notes,
            "download": download_url,
        }
    except Exception as exc:
        _log.debug("Update check failed (non-fatal): %s", exc)
        return None


def check_for_update_async(
    callback: Callable[[dict], None],
    delay_s: float = 6.0,
) -> None:
    """
    Spin up a background daemon thread to check for updates.

    Parameters
    ----------
    callback  : Called with a dict when a newer version is found.
                Fires on the background thread — marshal to main thread
                yourself (e.g. root.after(0, callback, info)).
    delay_s   : Seconds to wait after app starts before hitting GitHub,
                so the UI is fully up before any extra network I/O.
    """
    def _run() -> None:
        import time
        time.sleep(delay_s)
        info = _do_check()
        if info:
            _log.info("Update available: %s", info["version"])
            try:
                callback(info)
            except Exception as exc:
                _log.debug("Update callback error: %s", exc)

    t = threading.Thread(target=_run, daemon=True, name="dwut-updater")
    t.start()

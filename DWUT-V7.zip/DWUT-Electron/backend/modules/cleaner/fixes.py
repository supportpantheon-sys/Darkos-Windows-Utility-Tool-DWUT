"""
modules/cleaner/fixes.py

Corrected / newly implemented Deep Clean executors.  `install(executors, silent_args)`
overrides entries of engine._EXECUTORS so the original engine keeps its structure.

Fixed
  tmp_*            read-only files, hidden files, locked files, multiple browser profiles,
                   Windows.old ownership, WU services stopped before clearing its cache
  clear_event_logs every log channel (was only 4)
  dis_sleep/re_sleep  hibernate + standby timeouts are now really restored
  opt_disk         NVMe/SSD were defragmented when MediaType reported "Unspecified"
  repair_boot      `bcdboot /s C:` polluted UEFI systems
  repair_explorer  no stray File Explorer window
  repair_wu        renames SoftwareDistribution/catroot2 instead of destroying them
  wu_all           NuGet / PSGallery prompts made it fail non-interactively
  scan tools       correct silent flags; GUI-only tools no longer hang for 30 minutes
Implemented (were silent no-ops)
  export_*, tmp_installers, repair_vcpp/wu_vcpp, repair_dx/wu_dx, repair_dotnet,
  repair_com, repair_perm, opt_pagefile, opt_vis, opt_privacy
"""
from __future__ import annotations

import glob
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _sysroot() -> str:
    return os.environ.get("SystemRoot", r"C:\Windows")


# ── temp / cache cleanup ──────────────────────────────────────────────────────

def _browser_globs() -> list[str]:
    L = r"%LocalAppData%"
    chromium = [r"Google\Chrome", r"Microsoft\Edge", r"BraveSoftware\Brave-Browser",
                r"Vivaldi", r"Chromium"]
    out: list[str] = []
    for b in chromium:
        base = rf"{L}\{b}\User Data"
        for sub in ("Cache", "Code Cache", "GPUCache", "Service Worker\\CacheStorage"):
            out.append(rf"{base}\*\{sub}\*")
    out += [
        rf"{L}\Opera Software\Opera Stable\Cache\*",
        rf"{L}\Opera Software\Opera GX Stable\Cache\*",
        rf"{L}\Mozilla\Firefox\Profiles\*\cache2\*",
        r"%AppData%\Mozilla\Firefox\Profiles\*\cache2\*",
    ]
    return out


def _targets(step_id: str) -> list[str]:
    R, L = r"%SystemRoot%", r"%LocalAppData%"
    return {
        "tmp_windows": [rf"{R}\Temp\*", r"%TEMP%\*", r"%TMP%\*", rf"{L}\Temp\*"],
        "tmp_prefetch": [rf"{R}\Prefetch\*.pf"],
        "tmp_wu": [rf"{R}\SoftwareDistribution\Download\*",
                   rf"{R}\SoftwareDistribution\DeliveryOptimization\*",
                   r"%ProgramData%\Microsoft\Network\Downloader\*"],
        "tmp_crashes": [rf"{R}\Minidump\*", rf"{L}\CrashDumps\*",
                        r"%ProgramData%\Microsoft\Windows\WER\ReportArchive\*",
                        r"%ProgramData%\Microsoft\Windows\WER\ReportQueue\*",
                        rf"{L}\Microsoft\Windows\WER\*", rf"{R}\MEMORY.DMP"],
        "tmp_thumbs": [rf"{L}\Microsoft\Windows\Explorer\thumbcache_*.db",
                       rf"{L}\Microsoft\Windows\Explorer\iconcache_*.db", rf"{L}\IconCache.db"],
        "tmp_shaders": [rf"{L}\D3DSCache\*", rf"{L}\DXCache\*", rf"{L}\NVIDIA\DXCache\*",
                        rf"{L}\NVIDIA\GLCache\*", rf"{L}\AMD\DxCache\*", rf"{L}\AMD\GLCache\*"],
        "tmp_browsers": _browser_globs(),
        "tmp_java": [r"%AppData%\Sun\Java\Deployment\cache\*",
                     r"%AppData%\Macromedia\Flash Player\#SharedObjects\*"],
        "tmp_logs": [rf"{R}\Logs\CBS\*", rf"{R}\Logs\DISM\*", rf"{R}\Panther\*.log",
                     r"%SystemDrive%\inetpub\logs\LogFiles\*"],
        "tmp_installers": [rf"{L}\Downloaded Installations\*", rf"{L}\Microsoft\Windows\INetCache\*",
                           r"%ProgramData%\Microsoft\Windows\WER\Temp\*"],
        "tmp_old_windows": [r"%SystemDrive%\Windows.old", r"%SystemDrive%\$Windows.~BT",
                            r"%SystemDrive%\$Windows.~WS", r"%SystemDrive%\MSOCache"],
    }.get(step_id, [])


def _rd_protected(eng, path: str) -> bool:
    """Windows.old & friends are owned by TrustedInstaller — take ownership then rd."""
    eng.log(f"      taking ownership of {path} …")
    for cmd in (["takeown", "/f", path, "/r", "/d", "y"],
                ["icacls", path, "/grant", "*S-1-5-32-544:(OI)(CI)F", "/t", "/c", "/q"],
                ["cmd", "/c", "rd", "/s", "/q", path]):
        try:
            subprocess.run(cmd, capture_output=True, timeout=1800, creationflags=_NO_WINDOW)
        except Exception:
            pass
    return not os.path.exists(path)


def exec_tmp_cleanup(eng, step) -> bool:
    from modules.system.disk_cleanup import _purge_tree, _force_remove_file, _dir_size, _stop_wu_services, _start_wu_services
    stop_wu = step.id == "tmp_wu"
    if stop_wu:
        eng.log("    Stopping Windows Update services…")
        _stop_wu_services()

    total_freed = total_items = total_skipped = 0
    try:
        for pattern in _targets(step.id):
            expanded = os.path.expandvars(pattern)
            if "%" in expanded and not any(c in expanded for c in "*?["):
                pass
            matches = glob.glob(expanded, recursive=False)
            # glob skips dot-files for '*' — add them explicitly
            if expanded.endswith("\\*"):
                base = expanded[:-2]
                try:
                    for n in os.listdir(base):
                        p = os.path.join(base, n)
                        if n.startswith(".") and p not in matches:
                            matches.append(p)
                except OSError:
                    pass
            if not matches:
                continue
            label = expanded.replace("\\*", "").rstrip("\\/")
            eng.log(f"    Scanning {label}…")
            freed = items = skipped = 0
            for m in matches:
                if eng.cancelled:
                    break
                try:
                    if os.path.isdir(m) and not os.path.islink(m):
                        size = _dir_size(m)
                        f, d, s = _purge_tree(m, remove_root=True)
                        if os.path.exists(m) and step.id == "tmp_old_windows":
                            if _rd_protected(eng, m):
                                f, d, s = size, d + 1, 0
                        freed += f; items += d; skipped += s
                    elif os.path.exists(m):
                        sz = os.path.getsize(m)
                        if _force_remove_file(m):
                            freed += sz; items += 1
                        else:
                            skipped += 1
                except Exception:
                    skipped += 1
            total_freed += freed; total_items += items; total_skipped += skipped
            if items:
                eng.log(f"      Cleaned {items} item(s) — {freed / 1048576:.1f} MB freed")
            if skipped:
                eng.log(f"      Skipped {skipped} in-use or protected item(s)")
    finally:
        if stop_wu:
            _start_wu_services()
    eng.log(f"    [DONE] {step.label}: {total_items} item(s), {total_freed / 1048576:.1f} MB freed"
            + (f", {total_skipped} in use" if total_skipped else ""))
    return True


def exec_clear_event_logs(eng, step=None) -> bool:
    from modules.system.disk_cleanup import _clear_event_logs
    eng.log("    Clearing every Windows event log channel (this takes a moment)…")
    freed, cleared, errs = _clear_event_logs()
    eng.log(f"    [OK] Cleared {cleared} log channels — {freed / 1048576:.1f} MB freed")
    for e in errs:
        eng.log(f"    [WARN] {e}")
    return True


# ── sleep / hibernate: save + restore ─────────────────────────────────────────

def _query_standby(eng) -> dict:
    out = {}
    try:
        r = subprocess.run(["powercfg", "/q", "SCHEME_CURRENT", "SUB_SLEEP", "STANDBYIDLE"],
                           capture_output=True, text=True, timeout=15, creationflags=_NO_WINDOW,
                           errors="replace").stdout
        ac = re.search(r"Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)", r)
        dc = re.search(r"Current DC Power Setting Index:\s*0x([0-9a-fA-F]+)", r)
        if ac: out["ac"] = int(ac.group(1), 16) // 60
        if dc: out["dc"] = int(dc.group(1), 16) // 60
    except Exception:
        pass
    return out


def _hibernate_enabled() -> bool:
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Power")
        return bool(winreg.QueryValueEx(k, "HibernateEnabled")[0])
    except Exception:
        return False


def exec_dis_sleep(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    eng._session_state["sleep"] = {"hibernate": _hibernate_enabled(), **_query_standby(eng)}
    run(["powercfg", "/h", "off"], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-ac", "0"], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-dc", "0"], on_line=eng.log)
    return True


def exec_re_sleep(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    st = eng._session_state.get("sleep")
    if not st:
        eng.log("    [SKIP] Sleep settings were not changed in this session")
        return True
    if st.get("hibernate"):
        run(["powercfg", "/h", "on"], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-ac", str(st.get("ac", 30))], on_line=eng.log)
    run(["powercfg", "/x", "standby-timeout-dc", str(st.get("dc", 15))], on_line=eng.log)
    eng.log("    [OK] Sleep / hibernate restored")
    return True


# ── repairs / optimisations ───────────────────────────────────────────────────

def exec_defrag(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    drive = os.environ.get("SystemDrive", "C:").rstrip(":\\") + ":"
    eng.log(f"    Optimising {drive} (Windows picks TRIM for SSD/NVMe, defrag for HDD)…")
    run(["defrag", drive, "/O", "/U", "/V"], on_line=eng.log, timeout=7200)
    return True


def exec_repair_boot(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Rebuilding boot files (bcdboot auto-detects the correct system partition)…")
    run(["bcdboot", _sysroot()], on_line=eng.log)
    return True


def exec_repair_explorer(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    import psutil
    run(["taskkill", "/f", "/im", "explorer.exe"], on_line=eng.log)
    for _ in range(12):
        time.sleep(1)
        if any((p.info["name"] or "").lower() == "explorer.exe" for p in psutil.process_iter(["name"])):
            eng.log("    [OK] Explorer shell restarted by Windows")
            return True
    eng.log("    Explorer did not restart on its own — starting it…")
    subprocess.Popen(["cmd", "/c", "start", "", "explorer.exe"], creationflags=_NO_WINDOW)
    return True


def exec_repair_wu(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    svcs = ["wuauserv", "cryptSvc", "bits", "msiserver"]
    for s in svcs:
        run(["net", "stop", s, "/y"], on_line=eng.log)
    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    for folder in (Path(_sysroot()) / "SoftwareDistribution", Path(_sysroot()) / "System32" / "catroot2"):
        if folder.exists():
            bak = folder.with_name(folder.name + ".bak")
            shutil.rmtree(bak, ignore_errors=True)
            try:
                folder.rename(bak)
                eng.log(f"    Renamed {folder.name} -> {bak.name}")
            except OSError as exc:
                eng.log(f"    [WARN] could not rename {folder.name}: {exc}")
    for dll in ("atl.dll", "urlmon.dll", "mshtml.dll", "jscript.dll", "vbscript.dll",
                "msxml3.dll", "msxml6.dll", "wuapi.dll", "wuaueng.dll", "wups.dll", "wups2.dll",
                "wuwebv.dll", "qmgr.dll"):
        run(["regsvr32", "/s", dll], on_line=None)
    run(["netsh", "winsock", "reset"], on_line=eng.log)
    for s in svcs:
        run(["net", "start", s], on_line=eng.log)
    return True


def exec_wu(eng, step=None) -> bool:
    from modules.cleaner.runner import run_ps
    eng.log("    Preparing PowerShell Gallery (NuGet + PSWindowsUpdate)…")
    prep = (
        "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;"
        "$ProgressPreference='SilentlyContinue';"
        "Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser | Out-Null;"
        "Set-PSRepository -Name PSGallery -InstallationPolicy Trusted;"
        "if(-not (Get-Module -ListAvailable PSWindowsUpdate)){Install-Module PSWindowsUpdate -Force -Scope CurrentUser -Confirm:$false -AllowClobber};"
        "Import-Module PSWindowsUpdate; Write-Output 'PSWU_READY'"
    )
    code, lines = run_ps(prep, on_line=eng.log, timeout=600)
    if not any("PSWU_READY" in l for l in lines):
        eng.log("    [WARN] PSWindowsUpdate unavailable — falling back to the Windows Update agent")
        run_ps("(New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow();"
               "usoclient StartScan; usoclient StartDownload; usoclient StartInstall", on_line=eng.log)
        return True
    eng.log("    Installing Windows Updates (this may take a long time)…")
    run_ps("Import-Module PSWindowsUpdate; Get-WindowsUpdate -Install -AcceptAll -IgnoreReboot -Confirm:$false",
           on_line=eng.log, timeout=7200)
    return True


def _install_runtime(eng, tool_id: str, args: list[str], label: str) -> bool:
    from modules.cleaner.downloader import download
    from modules.cleaner.runner import run
    p = download(tool_id, on_log=eng.log)
    if not p:
        eng.log(f"    [WARN] Could not download {label} — skipping")
        return True
    code, _ = run([str(p), *args], on_line=eng.log, timeout=900)
    ok = code in (0, 1638, 3010, 1641)          # 1638 = newer already installed, 3010/1641 = reboot needed
    eng.log(f"    [{'OK' if ok else 'WARN'}] {label} finished (exit {code})")
    return True


def exec_vcpp(eng, step=None) -> bool:
    _install_runtime(eng, "vcredist_x64", ["/install", "/quiet", "/norestart"], "VC++ x64 runtime")
    _install_runtime(eng, "vcredist_x86", ["/install", "/quiet", "/norestart"], "VC++ x86 runtime")
    return True


def exec_dx(eng, step=None) -> bool:
    return _install_runtime(eng, "dxwebsetup", ["/Q"], "DirectX End-User Runtime")


def exec_dotnet(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Ensuring .NET Framework 3.5 / 4.x features are enabled…")
    run(["dism", "/Online", "/Enable-Feature", "/FeatureName:NetFx3", "/All", "/NoRestart"],
        on_line=eng.log, timeout=900)
    run(["dism", "/Online", "/Enable-Feature", "/FeatureName:NetFx4-AdvSrvs", "/All", "/NoRestart"],
        on_line=eng.log, timeout=600)
    return True


def exec_wu_dotnet(eng, step=None) -> bool:
    eng.log("    .NET Framework updates are delivered by Windows Update — installed by the")
    eng.log("    'Windows Updates' step. Nothing extra to do here.")
    return True


def exec_com(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    for dll in ("actxprxy.dll", "shdocvw.dll", "browseui.dll", "urlmon.dll", "mshtml.dll",
                "jscript.dll", "vbscript.dll", "msxml3.dll", "msxml6.dll", "oleaut32.dll", "scrrun.dll"):
        run(["regsvr32", "/s", dll], on_line=None)
    eng.log("    [OK] Re-registered core COM components")
    return True


def exec_perm(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    inf = Path(_sysroot()) / "inf" / "defltbase.inf"
    if not inf.exists():
        eng.log("    [SKIP] defltbase.inf not found")
        return True
    eng.log("    Resetting default security policy (policy area only — file ACLs untouched)…")
    run(["secedit", "/configure", "/cfg", str(inf), "/db", "defltbase.sdb", "/areas", "SECURITYPOLICY"],
        on_line=eng.log, timeout=600)
    return True


def exec_pagefile(eng, step=None) -> bool:
    from modules.cleaner.runner import run_ps
    run_ps('Set-CimInstance -Query "SELECT * FROM Win32_ComputerSystem" '
           '-Property @{AutomaticManagedPagefile=$true}', on_line=eng.log)
    eng.log("    [OK] Pagefile set to system-managed")
    return True


def exec_vis(eng, step=None) -> bool:
    from modules.cleaner.engine import _set_reg
    _set_reg(eng, r"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects",
             "VisualFXSetting", "REG_DWORD", "2")
    return True


def exec_privacy(eng, step=None) -> bool:
    from modules.cleaner.engine import _set_reg
    _set_reg(eng, r"HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection", "AllowTelemetry", "REG_DWORD", "0")
    _set_reg(eng, r"HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", "REG_DWORD", "0")
    return True


def _backup_dir(eng) -> Path:
    b = eng._session_state.get("backup_path")
    if b:
        return Path(b)
    d = Path(os.environ.get("LOCALAPPDATA", "C:\\Temp")) / "DWUT" / "Backups" / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    d.mkdir(parents=True, exist_ok=True)
    eng._session_state["backup_path"] = str(d)
    return d


def exec_export_programs(eng, step=None) -> bool:
    from modules.cleaner.runner import run_ps
    out = _backup_dir(eng) / "installed_programs.txt"
    run_ps("Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
           "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
           "-ErrorAction SilentlyContinue | Where-Object DisplayName | Sort-Object DisplayName | "
           f"Select-Object DisplayName,DisplayVersion,Publisher | Format-Table -AutoSize | Out-String -Width 250 | Set-Content -Encoding UTF8 '{out}'")
    eng.log(f"    Saved: {out}")
    return True


def exec_export_network(eng, step=None) -> bool:
    out = _backup_dir(eng) / "network_config.txt"
    with open(out, "w", encoding="utf-8", errors="replace") as f:
        for cmd in (["ipconfig", "/all"], ["netsh", "interface", "ip", "show", "config"],
                    ["netsh", "winhttp", "show", "proxy"], ["route", "print"]):
            f.write(f"\n===== {' '.join(cmd)} =====\n")
            try:
                f.write(subprocess.run(cmd, capture_output=True, text=True, timeout=60,
                                       creationflags=_NO_WINDOW, errors="replace").stdout)
            except Exception as exc:
                f.write(f"(failed: {exc})\n")
    eng.log(f"    Saved: {out}")
    return True


def exec_export_services(eng, step=None) -> bool:
    from modules.cleaner.runner import run_ps
    d = _backup_dir(eng)
    run_ps(f"Get-Service | Select Name,DisplayName,Status,StartType | Export-Csv -NoTypeInformation '{d / 'services.csv'}'")
    run_ps(f"Get-ScheduledTask | Select TaskPath,TaskName,State | Export-Csv -NoTypeInformation '{d / 'scheduled_tasks.csv'}'")
    run_ps("Get-CimInstance Win32_StartupCommand | Select Name,Command,Location | "
           f"Export-Csv -NoTypeInformation '{d / 'startup_items.csv'}'")
    eng.log(f"    Saved service / task / startup exports to {d}")
    return True


def _skip(msg: str):
    def fn(eng, step=None):
        eng.log(f"    [SKIP] {msg}")
        return True
    return fn


_SILENT_ARGS = {
    "rkill":         ["-s"],
    "adwcleaner":    ["/eula", "/clean", "/noreboot"],
    "tdsskiller":    ["-silent", "-tdlfs", "-dcexact", "-accepteula", "-accepteulaksn"],
    "msrt":          ["/Q", "/F:Y"],
    "kaspersky_vrt": ["-accepteula", "-adinsilent", "-silent", "-processlevel", "2", "-dontcryptsupportinfo"],
    "mcafee":        ["--GO", "--SILENT", "--PROGRAM", "--DELETE"],
}


def exec_scan_tool(eng, step) -> bool:
    from modules.cleaner.downloader import download
    from modules.cleaner.runner import run
    eng.log(f"    Downloading {step.label}…")
    path = download(step.id, on_log=eng.log)
    if not path:
        eng.log(f"    [WARN] Could not download {step.label} — skipping.")
        return True
    LAUNCHED.add(step.id)
    args = _SILENT_ARGS.get(step.id)
    before = set()
    if step.id == "rkill":
        before = own_tree_pids()
        wl = write_whitelist()
        rlog = path.parent / "rkill_log.txt"
        args = ["-s", "-l", str(rlog), "-w", str(wl)]
        eng.log(f"    Protecting DWUT + {len(PROTECT_NAMES)} program(s) you chose from being terminated")
    if args is None:
        eng.log(f"    [SKIP] {step.label} has no silent mode")
        return True
    eng.log(f"    Running {step.label}…")
    code, _ = run([str(path), *args], on_line=eng.log, timeout=3600)
    eng.log(f"    {step.label} finished (exit {code})")
    if before:
        import psutil
        gone = [p for p in before if not psutil.pid_exists(p)]
        eng.log("    [OK] DWUT was not touched" if not gone else f"    [WARN] {len(gone)} DWUT process(es) were closed by the tool")
    return True


# ═════════════════════════ tool removal (end of clean) ═══════════════════════
PREEXISTING: set = set()     # tools the user ALREADY had installed -> never uninstalled
LAUNCHED: set = set()        # tools DWUT downloaded / ran this session

_SD = "%SystemDrive%"
_TOOL_INFO = {
    "malwarebytes": dict(procs=["Malwarebytes.exe", "mbam.exe", "MBAMService.exe", "mbamtray.exe", "MBSetup.exe"], names=["Malwarebytes"],
                         dirs=[r"%ProgramData%\Malwarebytes", r"%ProgramFiles%\Malwarebytes", r"%ProgramFiles(x86)%\Malwarebytes"]),
    "hitmanpro": dict(procs=["HitmanPro.exe", "HitmanPro_x64.exe", "hmpsched.exe"], names=["HitmanPro"],
                      dirs=[r"%ProgramData%\HitmanPro", r"%ProgramFiles%\HitmanPro", r"%LocalAppData%\HitmanPro"]),
    "adwcleaner": dict(procs=["adwcleaner.exe"], names=["AdwCleaner"], dirs=[_SD + r"\AdwCleaner", r"%ProgramData%\AdwCleaner", r"%LocalAppData%\AdwCleaner"]),
    "tdsskiller": dict(procs=["tdsskiller.exe"], names=[], dirs=[_SD + r"\TDSSKiller_Quarantine", _SD + r"\TDSSKiller*"]),
    "roguekiller": dict(procs=["RogueKiller.exe", "RogueKillerSvc.exe"], names=["RogueKiller"],
                        dirs=[r"%ProgramData%\RogueKiller", r"%LocalAppData%\Adlice", r"%AppData%\Adlice", r"%ProgramFiles%\RogueKiller"]),
    "kaspersky_vrt": dict(procs=["KVRT.exe"], names=[], dirs=[_SD + r"\KVRT_Data", _SD + r"\KVRT2020_Data", _SD + r"\KVRT*_Data"]),
    "sophos_vrt": dict(procs=["SophosVirusRemovalTool.exe", "svrtcli.exe"], names=["Sophos Virus Removal Tool"],
                       dirs=[r"%ProgramData%\Sophos\Sophos Virus Removal Tool", r"%LocalAppData%\Sophos Virus Removal Tool"]),
    "mcafee": dict(procs=["stinger.exe", "stinger64.exe", "stinger32.exe"], names=[], dirs=[r"%ProgramData%\McAfee\Stinger", r"%TEMP%\Stinger*"]),
    "eset": dict(procs=["esetonlinescanner.exe"], names=["ESET Online Scanner"], dirs=[r"%ProgramData%\ESET\ESET Online Scanner", r"%LocalAppData%\ESET\ESET Online Scanner"]),
    "npe": dict(procs=["NPE.exe"], names=["Norton Power Eraser"], dirs=[r"%ProgramData%\Norton Power Eraser", r"%LocalAppData%\Norton Power Eraser"]),
    "mbar": dict(procs=["mbar.exe", "mbar-gui.exe"], names=["Malwarebytes Anti-Rootkit"], dirs=[r"%ProgramData%\MBAR"]),
    "rkill": dict(procs=["rkill.exe", "rkill64.exe"], names=[], dirs=[]),
    "gmer": dict(procs=["gmer.exe"], names=[], dirs=[]),
    "frst": dict(procs=["FRST.exe", "FRST64.exe"], names=[], dirs=[_SD + r"\FRST"]),
    "otl": dict(procs=["OTL.exe"], names=[], dirs=[_SD + r"\_OTL"]),
    "msrt": dict(procs=["mrt.exe", "msrt.exe"], names=[], dirs=[]),
}


def _uninstall_entries(fragments: list) -> list:
    """Installed-programs entries whose DisplayName contains one of `fragments`."""
    import winreg
    out = []
    roots = [(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_64KEY),
             (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_32KEY),
             (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", 0)]
    frags = [f.lower() for f in fragments]
    for hive, path, view in roots:
        try:
            k = winreg.OpenKey(hive, path, 0, winreg.KEY_READ | view)
        except OSError:
            continue
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(k, i)
            except OSError:
                break
            i += 1
            try:
                sk = winreg.OpenKey(k, sub)
                name = str(winreg.QueryValueEx(sk, "DisplayName")[0])
                if not any(f in name.lower() for f in frags):
                    continue
                def val(n):
                    try:
                        return str(winreg.QueryValueEx(sk, n)[0])
                    except OSError:
                        return ""
                out.append(dict(name=name, key=sub, uninstall=val("UninstallString"), quiet=val("QuietUninstallString")))
            except OSError:
                continue
    return out


def is_installed(tool_id: str) -> bool:
    names = _TOOL_INFO.get(tool_id, {}).get("names", [])
    try:
        return bool(names and _uninstall_entries(names))
    except Exception:
        return False


def _run_shell(cmd: str, timeout: int = 240) -> int:
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, timeout=timeout, creationflags=_NO_WINDOW).returncode
    except Exception:
        return -1


def remove_tool(log, tool_id: str) -> bool:
    """Stop, uninstall (if DWUT installed it) and delete a tool plus its leftovers."""
    from modules.cleaner.downloader import get_tool_dir, TOOLS
    from modules.system.disk_cleanup import _purge_tree, _force_remove_file
    info = _TOOL_INFO.get(tool_id, {})
    did = False

    for p in info.get("procs", []):
        if p.lower() in PROTECT_NAMES:
            continue
        try:
            subprocess.run(["taskkill", "/F", "/T", "/IM", p], capture_output=True, creationflags=_NO_WINDOW)
        except Exception:
            pass

    keep_install = tool_id in PREEXISTING
    if info.get("names") and not keep_install:
        try:
            entries = _uninstall_entries(info["names"])
        except Exception:
            entries = []
        for e in entries:
            log(f"    Uninstalling {e['name']} …")
            cmds = []
            if e["quiet"]:
                cmds.append(e["quiet"])
            u = e["uninstall"]
            if u:
                if "msiexec" in u.lower():
                    cmds.append(u.replace("/I", "/X").replace("/i", "/x") + " /qn /norestart")
                else:
                    cmds += [u + " /VERYSILENT /NORESTART /SUPPRESSMSGBOXES", u + " /S", u + " /quiet /norestart"]
            for c in cmds:
                _run_shell(c)
                if not any(x["key"] == e["key"] for x in _uninstall_entries(info["names"])):
                    log(f"    [OK] {e['name']} uninstalled")
                    did = True
                    break
            else:
                log(f"    [WARN] {e['name']} could not be uninstalled silently - remove it from Settings > Apps")
    elif keep_install and info.get("names"):
        log(f"    [SKIP] {tool_id}: you had it installed before DWUT started - left in place")

    if not keep_install:
        for d in info.get("dirs", []):
            expanded = os.path.expandvars(d)
            for m in glob.glob(expanded):
                try:
                    if os.path.isdir(m):
                        _purge_tree(m, remove_root=True)
                    else:
                        _force_remove_file(m)
                    did = True
                    log(f"    Removed {m}")
                except Exception:
                    pass

    # cached download + extracted folder
    td = get_tool_dir()
    spec = TOOLS.get(tool_id)
    cands = [td / spec["file"], td / (spec["file"] + ".part")] if spec else []
    for f in cands:
        if f.exists() and _force_remove_file(str(f)):
            did = True
    sub = td / tool_id
    if sub.is_dir():
        _purge_tree(str(sub), remove_root=True)
        did = True
    for f in glob.glob(str(td / (tool_id + "*.log"))) + glob.glob(str(td / (tool_id + "*.txt"))):
        _force_remove_file(f)

    LAUNCHED.discard(tool_id)
    return did


def exec_uninstall_tool(eng, step) -> bool:
    tool_id = step.id.replace("uninstall_", "", 1)
    if tool_id == "tools_dir":
        for tid in sorted(set(_TOOL_INFO) | LAUNCHED):
            if tid in LAUNCHED or tid in _TOOL_INFO:
                remove_tool(eng.log, tid)
        from modules.cleaner.downloader import get_tool_dir
        shutil.rmtree(get_tool_dir(), ignore_errors=True)
        eng.log("    [OK] DWUT tool cache removed")
        return True
    if remove_tool(eng.log, tool_id):
        eng.log(f"    [OK] {step.label}")
    else:
        eng.log(f"    [SKIP] {tool_id}: nothing to remove")
    return True


def cleanup_session(log) -> None:
    """Runs when a clean ends (finished OR cancelled): nothing downloaded may be left behind."""
    for tid in list(LAUNCHED):
        try:
            remove_tool(log, tid)
        except Exception:
            pass


# ═══════════════ process protection (RKill & every other task terminator) ═══════════════
PROTECT_NAMES: set = set()        # lower-case exe names the user chose NOT to kill (set by the popup)


def own_tree_pids() -> set:
    """Every process that belongs to DWUT: this backend, the Electron main process that started it,
    and all of that app's helper/renderer/GPU processes."""
    import psutil
    pids = {os.getpid()}
    try:
        me = psutil.Process()
        pids |= {c.pid for c in me.children(recursive=True)}
        par = me.parent()
        if par is not None and par.name().lower() in ("dwut.exe", "electron.exe"):
            pids.add(par.pid)
            pids |= {c.pid for c in par.children(recursive=True)}
    except Exception:
        pass
    return pids


def is_protected(proc) -> bool:
    try:
        return proc.pid in own_tree_pids() or (proc.name() or "").lower() in PROTECT_NAMES
    except Exception:
        return False


def write_whitelist() -> Path:
    """File handed to RKill (-w): full paths + names of DWUT and everything the user protected."""
    import psutil
    lines = set()
    own = own_tree_pids()
    for p in psutil.process_iter(["pid", "name", "exe"]):
        try:
            nm = (p.info["name"] or "").lower()
            if p.info["pid"] in own or nm in PROTECT_NAMES:
                if p.info.get("exe"):
                    lines.add(p.info["exe"])
                lines.add(p.info["name"])
        except Exception:
            continue
    for n in PROTECT_NAMES:
        lines.add(n)
    from modules.cleaner.downloader import get_tool_dir
    f = get_tool_dir() / "rkill_whitelist.txt"
    f.write_text("\n".join(sorted(lines)) + "\n", encoding="utf-8")
    return f


def set_protection(names) -> None:
    PROTECT_NAMES.clear()
    PROTECT_NAMES.update({str(n).lower() for n in (names or []) if n})


def install(executors: dict, silent_args: dict) -> None:
    for sid in ("tmp_windows", "tmp_prefetch", "tmp_wu", "tmp_crashes", "tmp_thumbs", "tmp_shaders",
                "tmp_browsers", "tmp_java", "tmp_logs", "tmp_old_windows", "tmp_installers"):
        executors[sid] = exec_tmp_cleanup
    executors.update({
        "clear_event_logs": exec_clear_event_logs,
        "dis_sleep": exec_dis_sleep, "re_sleep": exec_re_sleep,
        "opt_disk": exec_defrag, "repair_boot": exec_repair_boot,
        "repair_explorer": exec_repair_explorer, "repair_wu": exec_repair_wu, "wu_all": exec_wu,
        "repair_vcpp": exec_vcpp, "wu_vcpp": exec_vcpp,
        "repair_dx": exec_dx, "wu_dx": exec_dx,
        "repair_dotnet": exec_dotnet, "wu_dotnet": exec_wu_dotnet,
        "repair_com": exec_com, "repair_perm": exec_perm,
        "opt_pagefile": exec_pagefile, "opt_vis": exec_vis, "opt_privacy": exec_privacy,
        "export_programs": exec_export_programs, "export_network": exec_export_network,
        "export_services": exec_export_services,
        "kill_nonessential": _skip("nothing extra is stopped — DWUT never kills your apps automatically"),
        "opt_startup": _skip("use Tools → Startup Manager to choose what starts with Windows"),
        "opt_services": _skip("service start types are left as Windows configured them"),
        "opt_index": _skip("search index is rebuilt by 'Repair Search index' in Phase 4"),
    })
    for sid in ("rkill", "adwcleaner", "tdsskiller", "msrt", "kaspersky_vrt", "mcafee"):
        executors[sid] = exec_scan_tool
    from modules.cleaner.registry import STEP_MAP
    for sid in STEP_MAP:
        if sid.startswith("uninstall_"):
            executors[sid] = exec_uninstall_tool
    silent_args.clear()
    silent_args.update(_SILENT_ARGS)

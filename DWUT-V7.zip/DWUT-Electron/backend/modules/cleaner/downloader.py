"""
modules/cleaner/downloader.py

Download third-party scanner / runtime tools.

Improvements over the previous version
  * Every tool has an ordered list of mirrors; the next one is tried on failure.
  * Architecture aware (x64 / x86 / ARM64 machines get the right binary).
  * The download is VALIDATED before it is trusted: the old code happily saved an
    HTML error page as "tool.exe" and then failed to run it.  We now require a real
    PE ("MZ") or ZIP ("PK") header, a sane size, and reject text/html responses.
  * ZIP payloads (Malwarebytes Anti-Rootkit, GMER) are extracted and the real exe
    is located.
  * Authenticode signature is checked (logged; a *tampered* file is rejected).
  * `check_links()` probes every URL so dead links can be found in seconds.

Run   python -m modules.cleaner.downloader --check   to test all links.
"""
from __future__ import annotations

import hashlib
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _arch() -> str:
    m = (os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE")
         or platform.machine() or "").lower()
    if "arm" in m:
        return "arm64"
    if "64" in m:
        return "x64"
    return "x86"


# id -> spec
#   urls        ordered mirrors (first working wins)
#   urls_x86    optional override for 32-bit Windows
#   file        final runnable file name
#   kind        "exe" | "zip"   (zip: extracted, `file` located inside)
#   min_kb      smallest plausible size
#   deprecated  vendor discontinued it — skipped with an explanation
TOOLS: dict[str, dict] = {
    "rkill": dict(
        urls=["https://download.bleepingcomputer.com/grinler/rkill.exe",
              "https://download.bleepingcomputer.com/grinler/rkill64.exe"],
        file="rkill.exe", kind="exe", min_kb=100),
    "malwarebytes": dict(
        urls=["https://downloads.malwarebytes.com/file/mb-windows"],
        file="MBSetup.exe", kind="exe", min_kb=500),
    "adwcleaner": dict(
        urls=["https://downloads.malwarebytes.com/file/adwcleaner",
              "https://adwcleaner.malwarebytes.com/adwcleaner?channel=release"],
        file="adwcleaner.exe", kind="exe", min_kb=1000),
    "tdsskiller": dict(
        urls=["https://media.kaspersky.com/utilities/VirusUtilities/EN/tdsskiller.exe"],
        file="tdsskiller.exe", kind="exe", min_kb=1000),
    "hitmanpro": dict(
        urls=["https://dl.surfright.nl/HitmanPro_x64.exe", "https://dl.surfright.nl/HitmanPro.exe"],
        urls_x86=["https://dl.surfright.nl/HitmanPro.exe"],
        file="HitmanPro.exe", kind="exe", min_kb=1000),
    "roguekiller": dict(
        urls=["https://download.adlice.com/api?action=download&app=roguekiller&type=x64"],
        urls_x86=["https://download.adlice.com/api?action=download&app=roguekiller&type=x86"],
        file="RogueKiller.exe", kind="exe", min_kb=1000),
    "msrt": dict(
        urls=["https://go.microsoft.com/fwlink/?LinkId=212732"],
        urls_x86=["https://go.microsoft.com/fwlink/?LinkId=212733"],
        file="msrt.exe", kind="exe", min_kb=5000),
    "kaspersky_vrt": dict(
        urls=["https://devbuilds.s.kaspersky-labs.com/devbuilds/KVRT/latest/full/KVRT.exe",
              "https://media.kaspersky.com/utilities/VirusUtilities/EN/KVRT.exe"],
        file="KVRT.exe", kind="exe", min_kb=10000),
    "sophos_vrt": dict(
        urls=["https://download.sophos.com/tools/SophosVirusRemovalTool.exe"],
        file="SophosVirusRemovalTool.exe", kind="exe", min_kb=5000),
    "mcafee": dict(
        urls=["https://downloadcenter.mcafee.com/products/mcafee-avert/Stinger/stinger64.exe"],
        urls_x86=["https://downloadcenter.mcafee.com/products/mcafee-avert/Stinger/stinger32.exe"],
        file="stinger.exe", kind="exe", min_kb=5000),
    "eset": dict(
        urls=["https://download.eset.com/com/eset/tools/online_scanner/latest/esetonlinescanner.exe"],
        file="esetonlinescanner.exe", kind="exe", min_kb=1000),
    "npe": dict(
        urls=["https://www.norton.com/npe_latest"],
        file="NPE.exe", kind="exe", min_kb=1000),
    "mbar": dict(
        urls=["https://downloads.malwarebytes.com/file/mbar"],
        file="mbar.exe", kind="zip", min_kb=5000),
    "gmer": dict(
        urls=["https://www.gmer.net/gmer.zip"],
        file="gmer.exe", kind="zip", min_kb=100),
    "frst": dict(
        urls=["https://download.bleepingcomputer.com/farbar/FRST64.exe",
              "https://download.bleepingcomputer.com/farbar/FRST.exe"],
        urls_x86=["https://download.bleepingcomputer.com/farbar/FRST.exe"],
        file="FRST.exe", kind="exe", min_kb=500),
    "otl": dict(
        urls=["https://oldtimer.geekstogo.com/OTL.exe"],
        file="OTL.exe", kind="exe", min_kb=300),
    # ── runtimes used by the repair / patch phases ──
    "vcredist_x64": dict(
        urls=["https://aka.ms/vs/17/release/vc_redist.x64.exe"],
        file="vc_redist.x64.exe", kind="exe", min_kb=5000),
    "vcredist_x86": dict(
        urls=["https://aka.ms/vs/17/release/vc_redist.x86.exe"],
        file="vc_redist.x86.exe", kind="exe", min_kb=5000),
    "dxwebsetup": dict(
        urls=["https://download.microsoft.com/download/1/7/1/1718CCC4-6315-4D8E-9543-8E28A4E18C4C/dxwebsetup.exe"],
        file="dxwebsetup.exe", kind="exe", min_kb=200),
    # ── discontinued by their vendors (kept so old sessions don't crash) ──
    "clamwin": dict(urls=[], file="clamwin.exe", kind="exe", min_kb=0, deprecated="ClamWin is no longer maintained"),
    "aswmbr":  dict(urls=[], file="aswmbr.exe",  kind="exe", min_kb=0, deprecated="aswMBR was discontinued by Avast"),
    "spybot":  dict(urls=[], file="spybot.exe",  kind="exe", min_kb=0, deprecated="Spybot S&D is no longer freely downloadable"),
}

# Backwards-compatible view used by engine._exec_uninstall_tool: id -> (url, sha256, filename)
TOOL_URLS: dict[str, tuple[str, str | None, str]] = {
    k: ((v["urls"][0] if v["urls"] else ""), None, v["file"]) for k, v in TOOLS.items()
}


def get_tool_dir() -> Path:
    d = Path(os.environ.get("TEMP", "C:\\Temp")) / "DWUT_Tools"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _urls_for(spec: dict) -> list[str]:
    if _arch() == "x86" and spec.get("urls_x86"):
        return spec["urls_x86"]
    return spec["urls"]


def _find_cached(tool_id: str) -> Path | None:
    spec = TOOLS.get(tool_id)
    if not spec:
        return None
    d = get_tool_dir()
    direct = d / spec["file"]
    if direct.exists() and direct.stat().st_size > 1024:
        return direct
    sub = d / tool_id
    if sub.is_dir():
        for p in sub.rglob("*.exe"):
            if p.name.lower() == spec["file"].lower():
                return p
        exes = sorted(sub.rglob("*.exe"), key=lambda x: x.stat().st_size, reverse=True)
        if exes:
            return exes[0]
    return None


def is_cached(tool_id: str) -> bool:
    return _find_cached(tool_id) is not None


def _sniff(path: Path) -> str:
    try:
        with open(path, "rb") as f:
            head = f.read(4)
    except OSError:
        return "missing"
    if head[:2] == b"MZ":
        return "exe"
    if head[:2] == b"PK":
        return "zip"
    if head.lstrip()[:1] == b"<":
        return "html"
    return "unknown"


def _signature(path: Path) -> tuple[str, str]:
    """(status, signer) using Get-AuthenticodeSignature. Never raises."""
    if sys.platform != "win32":
        return "n/a", ""
    try:
        ps = (f"$s=Get-AuthenticodeSignature -LiteralPath '{path}';"
              "Write-Output $s.Status;Write-Output $s.SignerCertificate.Subject")
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                           capture_output=True, text=True, timeout=30, creationflags=_NO_WINDOW,
                           errors="replace")
        lines = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        status = lines[0] if lines else "Unknown"
        signer = lines[1] if len(lines) > 1 else ""
        return status, signer
    except Exception:
        return "Unknown", ""


LAST_ERRORS: dict[str, list[str]] = {}

# Vendor pages (used when an automatic download is impossible, so the user can fetch it by hand)
PAGES: dict[str, str] = {
    "malwarebytes": "https://www.malwarebytes.com/mwb-download",
    "hitmanpro": "https://www.hitmanpro.com/en-us/downloads",
    "eset": "https://www.eset.com/us/home/online-scanner/",
    "npe": "https://support.norton.com/sp/en/us/home/current/solutions/v59585167",
    "gmer": "http://www.gmer.net/",
    "frst": "https://www.bleepingcomputer.com/download/farbar-recovery-scan-tool/",
    "otl": "https://www.bleepingcomputer.com/download/otl/",
    "mbar": "https://www.malwarebytes.com/mbar",
    "roguekiller": "https://www.adlice.com/download/roguekiller/",
    "sophos_vrt": "https://www.sophos.com/en-us/free-tools/virus-removal-tool",
    "adwcleaner": "https://www.malwarebytes.com/adwcleaner",
    "tdsskiller": "https://usa.kaspersky.com/downloads/tdsskiller",
    "kaspersky_vrt": "https://www.kaspersky.com/downloads/free-virus-removal-tool",
    "mcafee": "https://www.mcafee.com/en-us/downloads/free-tools/stinger.html",
    "msrt": "https://www.microsoft.com/en-us/download/details.aspx?id=9905",
    "rkill": "https://www.bleepingcomputer.com/download/rkill/",
}


def _fetch_urllib(url: str, part: Path, on_progress, direct: bool) -> str:
    """Download with urllib.  Returns content-type.  direct=True ignores any system proxy."""
    handlers = [urllib.request.ProxyHandler({})] if direct else []
    opener = urllib.request.build_opener(*handlers)
    host = url.split("/")[2] if "//" in url else ""
    req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9",
                                               "Referer": f"https://{host}/"})
    with opener.open(req, timeout=60) as resp:
        ctype = (resp.headers.get("Content-Type") or "").lower()
        total = int(resp.headers.get("Content-Length", -1))
        done = 0
        with open(part, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if on_progress:
                    try:
                        on_progress(done, total)
                    except Exception:
                        pass
    return ctype


def _fetch_curl(url: str, part: Path) -> str:
    """Fallback: Windows' built-in curl.exe (schannel TLS, follows redirects)."""
    exe = shutil.which("curl.exe") or shutil.which("curl")
    if not exe:
        raise RuntimeError("curl.exe not available")
    r = subprocess.run([exe, "-L", "-f", "-sS", "--retry", "2", "--max-time", "600", "-A", _UA, "-o", str(part), url],
                       capture_output=True, text=True, timeout=660, creationflags=_NO_WINDOW, errors="replace")
    if r.returncode != 0:
        raise RuntimeError((r.stderr or f"curl exit {r.returncode}").strip()[:140])
    return ""


def download(
    tool_id: str,
    on_progress: Callable[[int, int], None] | None = None,
    on_log:      Callable[[str], None]      | None = None,
) -> Path | None:
    """Download `tool_id`. Returns the runnable Path on success, None on failure.
    The exact reason for every failed attempt is kept in LAST_ERRORS[tool_id]."""
    log = on_log or (lambda m: None)
    errs: list[str] = []
    LAST_ERRORS[tool_id] = errs
    spec = TOOLS.get(tool_id)
    if spec is None:
        errs.append("unknown tool")
        log(f"[downloader] unknown tool: {tool_id}")
        return None
    if spec.get("deprecated"):
        errs.append(spec["deprecated"])
        log(f"[downloader] {tool_id}: {spec['deprecated']} — skipped")
        return None

    cached = _find_cached(tool_id)
    if cached:
        log(f"[downloader] cached: {cached.name}")
        return cached

    tool_dir = get_tool_dir()
    fname = spec["file"]
    part = tool_dir / (fname + ".part")
    min_bytes = spec.get("min_kb", 50) * 1024

    for url in _urls_for(spec):
        short = url.split("//", 1)[-1][:60]
        for how in ("direct", "system-proxy", "curl"):
            try:
                log(f"[downloader] {fname} <- {short}  [{how}]")
                part.unlink(missing_ok=True)
                if how == "curl":
                    ctype = _fetch_curl(url, part)
                else:
                    ctype = _fetch_urllib(url, part, on_progress, direct=(how == "direct"))
                if "text/html" in ctype:
                    errs.append(f"{short}: server returned a web page instead of a file")
                    break                                   # same URL will do the same via other methods
                kind = _sniff(part)
                if kind not in ("exe", "zip"):
                    errs.append(f"{short}: not a program/zip file ({kind})")
                    break
                if part.stat().st_size < min_bytes:
                    errs.append(f"{short}: file too small ({part.stat().st_size:,} bytes)")
                    break

                if kind == "zip":
                    dest_dir = tool_dir / tool_id
                    shutil.rmtree(dest_dir, ignore_errors=True)
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    try:
                        with zipfile.ZipFile(part) as z:
                            z.extractall(dest_dir)
                    except zipfile.BadZipFile:
                        errs.append(f"{short}: corrupt zip")
                        break
                    part.unlink(missing_ok=True)
                    exe = _find_cached(tool_id)
                    if not exe:
                        errs.append(f"{short}: zip had no .exe inside")
                        break
                    log(f"[downloader] extracted: {exe.name}")
                    return exe

                dest = tool_dir / fname
                dest.unlink(missing_ok=True)
                part.replace(dest)
                status, signer = _signature(dest)
                if status == "HashMismatch":
                    dest.unlink(missing_ok=True)
                    errs.append(f"{short}: signature check failed (file was modified)")
                    break
                if status == "Valid":
                    cn = signer.split("CN=")[-1].split(",")[0] if signer else "unknown"
                    log(f"[downloader] verified signature: {cn}")
                log(f"[downloader] downloaded: {fname} ({dest.stat().st_size:,} bytes)")
                return dest
            except Exception as exc:
                errs.append(f"{short} [{how}]: {str(exc)[:110]}")
                log(f"[downloader]   x {how}: {str(exc)[:110]}")
                part.unlink(missing_ok=True)
                continue

    log(f"[downloader] could not download {fname}")
    return None


def check_links(only: list[str] | None = None) -> list[dict]:
    """Probe every URL (first 1 KB only). Returns [{tool, url, ok, status, note}]."""
    out: list[dict] = []
    for tid, spec in TOOLS.items():
        if only and tid not in only:
            continue
        if spec.get("deprecated"):
            out.append(dict(tool=tid, url="", ok=True, status="-", note=spec["deprecated"]))
            continue
        for url in _urls_for(spec):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": _UA, "Range": "bytes=0-1023"})
                with urllib.request.urlopen(req, timeout=25) as r:
                    head = r.read(4)
                    ctype = (r.headers.get("Content-Type") or "").lower()
                    ok = head[:2] in (b"MZ", b"PK") and "text/html" not in ctype
                    out.append(dict(tool=tid, url=url, ok=ok, status=r.status,
                                    note="ok" if ok else f"not a file ({ctype or 'unknown type'})"))
            except Exception as exc:
                out.append(dict(tool=tid, url=url, ok=False, status="ERR", note=str(exc)[:120]))
    return out


if __name__ == "__main__":
    if "--check" in sys.argv:
        for row in check_links():
            print(f"{'OK ' if row['ok'] else 'BAD'} {row['tool']:<14} {row['status']!s:<5} {row['url']}  {row['note']}")

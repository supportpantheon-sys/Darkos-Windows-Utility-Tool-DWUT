"""
modules/usb/engine.py — everything needed to turn a USB stick into installation media.

SAFETY (a flasher that wipes the wrong disk is a disaster, so):
  * only disks whose bus type is USB are ever listed; system/boot disks are excluded
  * the chosen disk is RE-VALIDATED (bus, size, serial, not system) immediately before it is touched
  * nothing is erased before the download + checksum has succeeded
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import string
import subprocess
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Optional

from core.logger import get_logger
from modules.usb import catalog

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
CACHE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "isos"
CHUNK = 4 * 1024 * 1024


class Cancelled(Exception):
    pass


class FlashError(Exception):
    pass


# ── small helpers ─────────────────────────────────────────────────────────────

def run(cmd: list[str], timeout: int = 600) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW,
                           errors="replace", stdin=subprocess.DEVNULL)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return -2, "timed out"
    except Exception as exc:
        return -1, str(exc)


def ps(script: str, timeout: int = 120) -> tuple[int, str]:
    return run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout)


def vkey(s: str) -> tuple:
    return tuple(int(n) for n in re.findall(r"\d+", s))


def _open(url: str, direct: bool, timeout: float = 25):
    opener = urllib.request.build_opener(*([urllib.request.ProxyHandler({})] if direct else []))
    req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "*/*"})
    return opener, req, timeout


def http_text(url: str, timeout: float = 25) -> str:
    last = None
    for direct in (True, False):
        try:
            opener, req, t = _open(url, direct, timeout)
            with opener.open(req, timeout=t) as r:
                return r.read().decode("utf-8", "replace")
        except Exception as exc:
            last = exc
    raise FlashError(f"could not read {url}: {last}")


def list_dir(url: str) -> list[str]:
    from urllib.parse import unquote
    html = http_text(url)
    seen, out = set(), []
    for h in re.findall(r'href="([^"?#]+)"', html):
        if h.startswith(("/", "http", "..", "mailto")):
            continue
        h = unquote(h)
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


# ── resolving the download ────────────────────────────────────────────────────

def parse_checksum(text: str, filename: str) -> Optional[str]:
    """Find the SHA-256 for `filename` in any common checksum-file format."""
    for line in text.splitlines():
        if filename in line:
            m = re.search(r"\b([A-Fa-f0-9]{64})\b", line)
            if m:
                return m.group(1).lower()
    if text.strip() and len(re.findall(r"\b[A-Fa-f0-9]{64}\b", text)) == 1 and len(text.strip().splitlines()) == 1:
        return re.search(r"\b([A-Fa-f0-9]{64})\b", text).group(1).lower()      # single-hash *.sha256 file
    return None


def _fido_url(ver: str, log) -> str:
    FIDO = CACHE.parent / "Fido.ps1"
    FIDO.parent.mkdir(parents=True, exist_ok=True)
    log("Downloading the Fido script (Microsoft ISO resolver)…")
    # utf-8-sig: Windows PowerShell 5.1 (the default on Windows 10) reads BOM-less UTF-8 as ANSI and can mis-parse Fido
    FIDO.write_text(http_text("https://raw.githubusercontent.com/pbatard/Fido/master/Fido.ps1", 30), encoding="utf-8-sig")
    log(f"Asking Microsoft for the latest Windows {ver} x64 ISO link (this can take up to a minute)…")
    code, out = ps(f"& '{FIDO}' -Win {ver} -Rel Latest -Arch x64 -Lang English -GetUrl", 240)
    urls = [l.strip() for l in out.splitlines() if l.strip().startswith("http")]
    if not urls:
        for line in [l for l in out.splitlines() if l.strip()][-8:]:
            log("  Fido: " + line.strip()[:200])
        page = "https://www.microsoft.com/software-download/windows" + ("11" if ver == "11" else "10ISO")
        raise FlashError(f"Microsoft did not hand out a download link (it sometimes blocks automated requests). "
                         f"Download the ISO yourself from {page} and pick it with 'Use my own ISO file'.")
    log("Got an official download link from Microsoft.")
    return urls[-1]


def resolve(entry: dict, log) -> dict:
    """-> {urls:[...], filename, sha256|None}"""
    src = entry["src"]
    if src == "fido":
        url = _fido_url(entry["win"], log)
        name = f"Windows{entry['win']}_x64.iso"
        return {"urls": [url], "filename": name, "sha256": None}
    if src == "fixed":
        urls = entry["urls"]
        name = urls[0].rsplit("/", 1)[-1] or entry["id"] + ".iso"
        sha = None
        for cu in entry.get("checksum_urls", []):
            try:
                sha = parse_checksum(http_text(cu), name)
                if sha:
                    break
            except FlashError:
                continue
        return {"urls": urls, "filename": name, "sha256": sha}
    if src == "github":
        j = json.loads(http_text(f"https://api.github.com/repos/{entry['repo']}/releases/latest", 30))
        for a in j.get("assets", []):
            if re.search(entry["asset"], a["name"]):
                return {"urls": [a["browser_download_url"]], "filename": a["name"], "sha256": None}
        raise FlashError("no matching release asset")
    # listing: try the main mirror, then alternates; inside one, walk version folders newest -> oldest
    # until one really contains the file (the newest folder is sometimes still being populated).
    last_err = "no mirror answered"
    for root in [entry["base"]] + list(entry.get("alt_bases", [])):
        try:
            return _resolve_listing(entry, root, log)
        except FlashError as exc:
            last_err = str(exc)
            log(f"  ! {root.split('//', 1)[-1][:60]}: {last_err[:110]}")
    raise FlashError(last_err)


def _resolve_listing(entry: dict, root: str, log) -> dict:
    bases = [root]
    if entry.get("subdir"):
        subs = sorted((d for d in list_dir(root) if re.search(entry["subdir"], d)), key=vkey, reverse=True)
        if not subs:
            raise FlashError(f"no version folders at {root}")
        bases = [root + d + entry.get("subpath", "") for d in subs[:6]]
    else:
        bases = [root + entry.get("subpath", "")]
    err = "no matching file"
    for base in bases:
        try:
            names = list_dir(base)
        except FlashError as exc:
            err = str(exc)
            continue
        files = [n for n in names if re.search(entry["file"], n)]
        if not files:
            err = f"no matching file at {base}"
            continue
        fname = max(files, key=vkey)
        sha = None
        cands = [base + c for c in entry.get("checksum_files", [])]
        if entry.get("checksum_re"):
            cands += [base + n for n in names if re.search(entry["checksum_re"], n)]
        for cu in cands:
            try:
                sha = parse_checksum(http_text(cu), fname)
                if sha:
                    break
            except FlashError:
                continue
        return {"urls": [base + fname], "filename": fname, "sha256": sha}
    raise FlashError(err)


# ── downloading (resumable, mirror fallback, progress) ────────────────────────

def download(urls: list[str], dest: Path, on_prog: Callable[[float, float, float], None], cancel: threading.Event,
             log: Callable[[str], None]) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    errors = []
    for url in urls:
        for direct in (True, False):
            try:
                pos = part.stat().st_size if part.exists() else 0
                opener, req, _ = _open(url, direct)
                if pos:
                    req.add_header("Range", f"bytes={pos}-")
                log(f"Downloading {url.split('//', 1)[-1][:70]} ({'direct' if direct else 'via system proxy'})" + (f" - resuming at {pos / 1048576:.0f} MB" if pos else ""))
                with opener.open(req, timeout=30) as r:
                    if r.status == 200 and pos:
                        pos = 0
                    total = int(r.headers.get("Content-Length", 0)) + pos
                    log(f"  Connected (HTTP {r.status}) - " + (f"{total / 1e9:.2f} GB" if total else "size unknown") + (f", following redirect to {r.geturl().split('//', 1)[-1][:60]}" if r.geturl() != url else ""))
                    mode = "ab" if pos else "wb"
                    done, t0, last = pos, time.monotonic(), 0.0
                    with open(part, mode) as f:
                        while True:
                            if cancel.is_set():
                                raise Cancelled()
                            chunk = r.read(1 << 20)
                            if not chunk:
                                break
                            f.write(chunk)
                            done += len(chunk)
                            now = time.monotonic()
                            if now - last > 0.3:
                                last = now
                                sp = (done - pos) / max(now - t0, 0.001)
                                on_prog(done / total if total else 0.0, sp, ((total - done) / sp) if sp and total else 0.0)
                if total and part.stat().st_size < total:
                    raise FlashError("connection dropped before the end")
                if dest.exists():
                    dest.unlink()
                part.replace(dest)
                on_prog(1.0, 0.0, 0.0)
                return dest
            except Cancelled:
                raise
            except Exception as exc:
                errors.append(f"{url.split('//', 1)[-1][:50]}: {str(exc)[:80]}")
                log(f"  ! {errors[-1]}")
    raise FlashError("download failed - " + "; ".join(errors[-3:]))


def sha256_file(path: Path, on_prog, cancel: threading.Event) -> str:
    h, size, done = hashlib.sha256(), path.stat().st_size, 0
    with open(path, "rb") as f:
        while True:
            if cancel.is_set():
                raise Cancelled()
            b = f.read(CHUNK)
            if not b:
                break
            h.update(b)
            done += len(b)
            on_prog(done / max(size, 1))
    return h.hexdigest()


# ── USB drives ────────────────────────────────────────────────────────────────

_LIST_PS = r"""
$out = @()
foreach ($d in (Get-Disk | Where-Object { $_.BusType -eq 'USB' -and -not $_.IsSystem -and -not $_.IsBoot })) {
  $parts = @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue)
  $vols = @(); foreach ($p in $parts) { $v = Get-Volume -Partition $p -ErrorAction SilentlyContinue; if ($v) { $vols += $v } }
  $letters = ($vols | Where-Object { $_.DriveLetter } | ForEach-Object { "$($_.DriveLetter):" }) -join ' '
  $labels = ($vols | Where-Object { $_.FileSystemLabel } | ForEach-Object { $_.FileSystemLabel }) -join ', '
  $used = ($vols | ForEach-Object { $_.Size - $_.SizeRemaining } | Measure-Object -Sum).Sum
  $out += [pscustomobject]@{ number = $d.Number; name = $d.FriendlyName; size = [int64]$d.Size; serial = "$($d.SerialNumber)".Trim();
    style = "$($d.PartitionStyle)"; letters = $letters; labels = $labels; used = [int64]$used; offline = $d.IsOffline; readonly = $d.IsReadOnly }
}
ConvertTo-Json -InputObject @($out) -Compress
"""


def list_usb_drives() -> list[dict]:
    code, out = ps(_LIST_PS, 60)
    try:
        data = json.loads(out.strip().splitlines()[-1])
    except Exception:
        return []
    return data if isinstance(data, list) else [data]


def revalidate(disk: dict) -> None:
    """Called right before anything destructive."""
    code, out = ps(f"Get-Disk -Number {int(disk['number'])} | Select-Object Number,Size,BusType,IsSystem,IsBoot,SerialNumber | ConvertTo-Json -Compress", 30)
    try:
        d = json.loads(out.strip().splitlines()[-1])
    except Exception:
        raise FlashError("The selected drive is no longer available - was it unplugged?")
    if str(d.get("BusType")).upper() not in ("USB", "7") or d.get("IsSystem") or d.get("IsBoot"):
        raise FlashError("Refusing to continue: the selected disk is not a removable USB drive.")
    if int(d.get("Size", 0)) != int(disk["size"]) or ("%s" % d.get("SerialNumber", "")).strip() != (disk.get("serial") or ""):
        raise FlashError("The drive changed since you selected it (different size/serial). Please start again.")


def diskpart(lines: list[str], timeout: int = 300) -> str:
    script = Path(os.environ.get("TEMP", ".")) / "dwut_diskpart.txt"
    script.write_text("\n".join(lines) + "\n", encoding="ascii")
    code, out = run(["diskpart", "/s", str(script)], timeout)
    try:
        script.unlink()
    except OSError:
        pass
    if code != 0 or "DiskPart has encountered an error" in out:
        raise FlashError("diskpart failed: " + out.strip()[-300:])
    return out


def wipe(disk: dict) -> None:
    diskpart([f"select disk {int(disk['number'])}", "attributes disk clear readonly noerr", "online disk noerr", "clean"])
    time.sleep(2)


def free_letter(exclude: str = "") -> str:
    for l in "ZYXWVUTSRQPONMLKJIHGFED":
        if l not in exclude and not os.path.exists(f"{l}:\\"):
            return l
    raise FlashError("No free drive letters available.")


# ── raw writing / verification ────────────────────────────────────────────────

def raw_path(n: int) -> str:
    return rf"\\.\PhysicalDrive{int(n)}"


def write_image(image: Path, target: str, on_prog, cancel: threading.Event) -> int:
    size = image.stat().st_size
    done, t0, last = 0, time.monotonic(), 0.0
    with open(image, "rb") as src, open(target, "r+b", buffering=0) as dst:
        while True:
            if cancel.is_set():
                raise Cancelled()
            data = src.read(CHUNK)
            if not data:
                break
            if len(data) % 4096:
                data += b"\0" * (4096 - len(data) % 4096)          # sector-align the tail
            dst.write(data)
            done += min(len(data), size - done)
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                sp = done / max(now - t0, 0.001)
                on_prog(done / size, sp, (size - done) / sp if sp else 0)
        try:
            dst.flush()
            os.fsync(dst.fileno())
        except OSError:
            pass
    on_prog(1.0, 0.0, 0.0)
    return size


def verify_image(image: Path, target: str, on_prog, cancel: threading.Event) -> None:
    size, done = image.stat().st_size, 0
    with open(image, "rb") as src, open(target, "rb", buffering=0) as dev:
        while done < size:
            if cancel.is_set():
                raise Cancelled()
            a = src.read(CHUNK)
            if not a:
                break
            n = len(a)
            n_al = n + (-n % 4096)
            b = dev.read(n_al)[:n]
            if a != b:
                raise FlashError(f"Verification FAILED at {done / 1048576:.0f} MB - the stick may be faulty or counterfeit. Try another USB stick.")
            done += n
            on_prog(done / size)


def is_hybrid(image: Path) -> bool:
    try:
        with open(image, "rb") as f:
            return f.read(512)[510:512] == b"\x55\xaa"
    except OSError:
        return False


# ── Windows-style ISO (FAT32 + split WIM + boot code) ─────────────────────────

def flash_winiso(iso: Path, disk: dict, prog, cancel, log) -> None:
    n = int(disk["number"])
    letter = free_letter()
    size_mb = int(disk["size"] / 1048576)
    part = "create partition primary size=32000" if size_mb > 32768 else "create partition primary"
    prog.stage("prepare", "Preparing the USB stick (MBR + FAT32)…")
    diskpart([f"select disk {n}", "attributes disk clear readonly noerr", "online disk noerr", "clean", "convert mbr", part,
              "select partition 1", "active", 'format fs=fat32 quick label="DWUT_USB"', f"assign letter={letter}"])
    time.sleep(2)
    if not os.path.exists(f"{letter}:\\"):
        raise FlashError("The new USB volume did not appear.")
    prog.stage("copy", "Mounting the ISO…")
    code, out = ps(f"$i = Mount-DiskImage -ImagePath '{iso}' -PassThru; Start-Sleep 2; ($i | Get-Volume).DriveLetter", 120)
    src = out.strip().splitlines()[-1].strip() if out.strip() else ""
    if not re.fullmatch(r"[A-Za-z]", src):
        raise FlashError("Could not mount the ISO: " + out.strip()[-200:])
    S, U = f"{src}:\\", f"{letter}:\\"
    try:
        wim = Path(S) / "sources" / "install.wim"
        big_wim = wim.exists() and wim.stat().st_size > 4_000_000_000
        total = sum(f.stat().st_size for f in Path(S).rglob("*") if f.is_file() and not (big_wim and f == wim))
        log(f"Copying {total / 1048576:.0f} MB of installer files…")
        cmd = ["robocopy", S, U, "/E", "/R:2", "/W:2", "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/MT:4"] + (["/XF", "install.wim"] if big_wim else [])
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
        t0 = time.monotonic()
        while p.poll() is None:
            if cancel.is_set():
                p.kill()
                raise Cancelled()
            try:
                used = shutil.disk_usage(U).used
            except OSError:
                used = 0
            prog.frac(min(used / max(total, 1), 0.99), speed=used / max(time.monotonic() - t0, 1))
            time.sleep(0.5)
        if p.returncode >= 8:
            raise FlashError(f"File copy failed (robocopy code {p.returncode}).")
        if big_wim:
            prog.stage("split", "Splitting install.wim for FAT32 (a few minutes - no progress bar from Windows)…", indeterminate=True)
            code, out = run(["dism", "/Split-Image", f"/ImageFile:{wim}", f"/SWMFile:{U}sources\\install.swm", "/FileSize:3800"], 3600)
            if code != 0:
                raise FlashError("DISM could not split install.wim: " + out.strip()[-200:])
        prog.stage("boot", "Writing boot code…")
        bs = Path(S) / "boot" / "bootsect.exe"
        if bs.exists():
            code, out = run([str(bs), "/nt60", f"{letter}:", "/force", "/mbr"], 120)
            if code != 0:
                log("  ! bootsect failed (UEFI boot still works): " + out.strip()[-120:])
        else:
            log("  ! this ISO has no bootsect.exe - the stick will boot on UEFI PCs only")
    finally:
        ps(f"Dismount-DiskImage -ImagePath '{iso}'", 60)


# ── Ventoy ────────────────────────────────────────────────────────────────────

def ventoy_exe(prog, cancel, log) -> Path:
    cat = catalog.get("ventoy")
    root = CACHE.parent / "ventoy"
    found = next(iter(root.rglob("Ventoy2Disk.exe")), None) if root.exists() else None
    if found:
        return found
    r = resolve(cat, log)
    z = download(r["urls"], CACHE / r["filename"], prog.dl, cancel, log)
    shutil.rmtree(root, ignore_errors=True)
    with zipfile.ZipFile(z) as zf:
        zf.extractall(root)
    found = next(iter(root.rglob("Ventoy2Disk.exe")), None)
    if not found:
        raise FlashError("Ventoy2Disk.exe not found in the download.")
    return found


def install_ventoy(disk: dict, prog, cancel, log, need_user) -> str:
    """Returns the drive letter of the Ventoy data partition."""
    exe = ventoy_exe(prog, cancel, log)
    n = int(disk["number"])
    prog.stage("install", "Installing Ventoy on the stick…", indeterminate=True)
    wipe(disk)
    code, out = run([str(exe), "VTOYCLI", "/I", f"/PhyDrive:{n}"], 300)
    letter = _ventoy_letter(n, 25 if code == 0 else 3)
    if code != 0 or not letter:
        log("  ! Ventoy's command-line mode failed - opening its window for you.")
        subprocess.Popen([str(exe)], cwd=str(exe.parent))
        need_user(f"Ventoy opened. Pick the device that is Disk {n} ({disk['name']}), click Install, then press Continue here.")
        letter = _ventoy_letter(n, 25)
    if not letter:
        raise FlashError("Ventoy was not installed on the stick.")
    return letter


def _ventoy_letter(n: int, tries: int) -> str:
    for _ in range(tries):
        code, out = ps(f"Update-Disk -Number {n} -ErrorAction SilentlyContinue; "
                       f"Get-Partition -DiskNumber {n} | Get-Volume | Where-Object {{ $_.FileSystemLabel -eq 'Ventoy' }} | "
                       "Select-Object -ExpandProperty DriveLetter", 30)
        m = re.search(r"\b([A-Za-z])\b", out.strip().splitlines()[-1] if out.strip() else "")
        if m:
            return m.group(1).upper()
        ps(f"Get-Partition -DiskNumber {n} -PartitionNumber 1 | Add-PartitionAccessPath -AssignDriveLetter -ErrorAction SilentlyContinue", 20)
        time.sleep(1)
    return ""


def copy_file(src: Path, dst: Path, on_prog, cancel) -> None:
    size, done, t0, last = src.stat().st_size, 0, time.monotonic(), 0.0
    with open(src, "rb") as a, open(dst, "wb") as b:
        while True:
            if cancel.is_set():
                raise Cancelled()
            c = a.read(CHUNK)
            if not c:
                break
            b.write(c)
            done += len(c)
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                sp = done / max(now - t0, 0.001)
                on_prog(done / size, sp, (size - done) / sp if sp else 0)
    on_prog(1.0, 0, 0)

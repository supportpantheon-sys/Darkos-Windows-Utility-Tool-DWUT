"""
modules/vpn/tunconf.py - tunnel key generation (pure Python X25519, RFC 7748) and .conf parsing/rendering.

No third-party crypto package is needed, so this works on a stock Python install.
"""
from __future__ import annotations

import base64
import os
import re
from typing import Optional

_P = 2 ** 255 - 19
_A24 = 121665


def x25519(k: bytes, u: bytes) -> bytes:
    kb = bytearray(k)
    kb[0] &= 248
    kb[31] &= 127
    kb[31] |= 64
    kk = int.from_bytes(kb, "little")
    x1 = int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in reversed(range(255)):
        kt = (kk >> t) & 1
        swap ^= kt
        if swap:
            x2, x3 = x3, x2
            z2, z3 = z3, z2
        swap = kt
        a = (x2 + z2) % _P
        aa = a * a % _P
        b = (x2 - z2) % _P
        bb = b * b % _P
        e = (aa - bb) % _P
        c = (x3 + z3) % _P
        d = (x3 - z3) % _P
        da = d * a % _P
        cb = c * b % _P
        x3 = pow(da + cb, 2, _P)
        z3 = x1 * pow(da - cb, 2, _P) % _P
        x2 = aa * bb % _P
        z2 = e * (aa + _A24 * e) % _P
    if swap:
        x2, x3 = x3, x2
        z2, z3 = z3, z2
    return (x2 * pow(z2, _P - 2, _P) % _P).to_bytes(32, "little")


def gen_keypair() -> tuple[str, str]:
    """-> (private_b64, public_b64) in the tunnel's key format."""
    priv = bytearray(os.urandom(32))
    priv[0] &= 248
    priv[31] &= 127
    priv[31] |= 64
    pub = x25519(bytes(priv), b"\x09" + b"\x00" * 31)
    return base64.b64encode(bytes(priv)).decode(), base64.b64encode(pub).decode()


# ── .conf parsing / rendering ────────────────────────────────────────────────

_FULL = ("0.0.0.0/0", "::/0", "::0/0")


def _split(v: str) -> list[str]:
    return [x.strip() for x in v.split(",") if x.strip()]


def parse_conf(text: str) -> dict:
    """Normalise a tunnel .conf into a flat profile dict (first peer only).
    Script hooks (PreUp/PostUp/...) are dropped on purpose: the tunnel service runs as SYSTEM."""
    p = {"private_key": "", "addresses": [], "dns": [], "mtu": None, "public_key": "", "endpoint": "",
         "allowed_ips": [], "preshared": "", "keepalive": None}
    sec = None
    for raw in text.replace("\r\n", "\n").split("\n"):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("["):
            sec = line.strip("[]").lower()
            if sec == "peer" and p["public_key"]:
                break                      # only the first peer is used
            continue
        if "=" not in line:
            continue
        k, v = (x.strip() for x in line.split("=", 1))
        k = k.lower()
        if sec == "interface":
            if k == "privatekey":
                p["private_key"] = v
            elif k == "address":
                p["addresses"] += _split(v)
            elif k == "dns":
                p["dns"] += [d for d in _split(v) if re.match(r"^[0-9a-fA-F:.]+$", d)]
            elif k == "mtu" and v.isdigit():
                p["mtu"] = int(v)
        elif sec == "peer":
            if k == "publickey":
                p["public_key"] = v
            elif k == "endpoint":
                p["endpoint"] = v
            elif k == "allowedips":
                p["allowed_ips"] += _split(v)
            elif k == "presharedkey":
                p["preshared"] = v
            elif k == "persistentkeepalive" and v.isdigit():
                p["keepalive"] = int(v)
    return p


def validate(p: dict) -> Optional[str]:
    if not re.fullmatch(r"[A-Za-z0-9+/]{43}=", p.get("private_key", "")):
        return "PrivateKey is missing or not a valid tunnel key"
    if not re.fullmatch(r"[A-Za-z0-9+/]{43}=", p.get("public_key", "")):
        return "The [Peer] PublicKey is missing or not valid"
    if not re.fullmatch(r".+:\d{1,5}", p.get("endpoint", "")):
        return "The [Peer] Endpoint (host:port) is missing"
    if not p.get("addresses"):
        return "The [Interface] Address is missing"
    return None


def is_full_tunnel(p: dict) -> bool:
    return any(a in _FULL for a in p.get("allowed_ips", []))


def render_conf(p: dict, kill_switch: bool = True, ipv6_block: bool = True,
                dns: Optional[list] = None, mtu: Optional[int] = None) -> str:
    """Build the .conf the tunnel service actually runs, applying the user's privacy options.

    kill_switch  -> AllowedIPs 0.0.0.0/0 + ::/0 makes the tunnel service block every packet that is not
                    inside the tunnel (this is the built-in kill switch). Off -> the same routes split in
                    two halves, which still carries everything but does not trigger the blocking rules.
    ipv6_block   -> the interface gets no IPv6 address while ::/0 stays routed into the tunnel, so any
                    IPv6 packet is sent into the tunnel and dies there instead of leaking out.
    dns          -> pushed as the tunnel DNS (the tunnel service then forces all DNS through the tunnel).
    """
    addrs = [a for a in p["addresses"] if not (ipv6_block and ":" in a)]
    full = is_full_tunnel(p) or not p.get("allowed_ips")
    if full:
        allowed = ["0.0.0.0/0", "::/0"] if kill_switch else ["0.0.0.0/1", "128.0.0.0/1", "::/1", "8000::/1"]
    else:
        allowed = p["allowed_ips"]            # user's own split-tunnel config - leave it alone
    out = ["[Interface]", f"PrivateKey = {p['private_key']}", f"Address = {', '.join(addrs)}"]
    d = dns if dns is not None else p.get("dns")
    if d:
        out.append(f"DNS = {', '.join(d)}")
    m = mtu or p.get("mtu")
    if m:
        out.append(f"MTU = {m}")
    out += ["", "[Peer]", f"PublicKey = {p['public_key']}"]
    if p.get("preshared"):
        out.append(f"PresharedKey = {p['preshared']}")
    out += [f"AllowedIPs = {', '.join(allowed)}", f"Endpoint = {p['endpoint']}"]
    out.append(f"PersistentKeepalive = {p.get('keepalive') or 25}")
    return "\n".join(out) + "\n"

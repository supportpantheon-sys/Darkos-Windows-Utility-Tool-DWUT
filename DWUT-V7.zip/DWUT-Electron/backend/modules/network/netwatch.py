"""
modules/network/netwatch.py - multi-network monitor ("Network Guardian" + "nmap-lite").

Watches up to three networks at the same time, each reported separately:
  vpn    traffic that leaves through a VPN adapter (DWUTVPN, OpenVPN, Tailscale, ...)
  proxy  traffic to/through a configured proxy (system proxy, DWUT Proxy Center, Clash/V2Ray/Tor-style tools)
  lan    your physical Wi-Fi / Ethernet connection, its open (listening) ports, and the devices on it
plus any number of custom targets (IP / hostname): up-down, latency, open ports, live connections.

Everything here is real data: psutil sockets and adapter counters, the ARP table, TCP connects and ping.
"""
from __future__ import annotations

import ipaddress
import re
import socket
import subprocess
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

import psutil

from core.logger import get_logger
from core.mask import clean
from modules.network import privacy
from modules.network.monitor import Connection, net_monitor

_log = get_logger("netwatch")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_VPN_RE = re.compile(r"wireguard|dwutvpn|dwutnet|wintun|\btun\d*\b|tap-windows|\btap\d*\b|nordlynx|nord|proton|mullvad|openvpn|"
                     r"tailscale|zerotier|anyconnect|fortinet|globalprotect|pulse secure|windscribe|expressvpn|surfshark|cloudflare|warp|\bvpn\b", re.I)
_VIRT_RE = re.compile(r"vethernet|vmware|virtualbox|vbox|hyper-v|loopback|pseudo|bluetooth|isatap|teredo|docker|wsl|miniport", re.I)
_WIFI_RE = re.compile(r"wi-?fi|wlan|wireless|802\.11", re.I)
_PROXY_TOOLS = ("clash", "v2ray", "xray", "sing-box", "shadowsocks", "ss-local", "privoxy", "tor.exe", "mitmproxy", "fiddler",
                "proxifier", "squid", "nekoray", "hiddify", "v2rayn", "trojan", "hysteria")

_SERVICES = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3", 111: "RPC", 135: "MS-RPC",
             137: "NetBIOS", 139: "NetBIOS", 143: "IMAP", 161: "SNMP", 389: "LDAP", 443: "HTTPS", 445: "SMB", 465: "SMTPS",
             587: "SMTP", 993: "IMAPS", 995: "POP3S", 1080: "SOCKS", 1433: "MSSQL", 1723: "PPTP", 1900: "UPnP", 2049: "NFS",
             3000: "Dev server", 3306: "MySQL", 3389: "RDP", 5000: "UPnP/Dev", 5040: "Windows", 5353: "mDNS", 5432: "PostgreSQL",
             5555: "ADB", 5900: "VNC", 5985: "WinRM", 6379: "Redis", 7680: "Windows Update", 8000: "HTTP-alt", 8080: "HTTP-proxy",
             8443: "HTTPS-alt", 8888: "HTTP-alt", 9000: "Web", 9090: "Web", 9200: "Elasticsearch", 25565: "Minecraft",
             27017: "MongoDB", 51820: "VPN tunnel"}
_SCAN_PORTS = sorted(set(list(_SERVICES) + [20, 69, 88, 119, 123, 179, 427, 514, 631, 873, 902, 1194, 1701, 2375, 3128, 4444, 5060,
                                           5222, 5900, 6000, 6667, 8008, 8081, 8888, 10000, 32400]))


def _loop_ip(ip: str) -> bool:
    return ip.startswith("127.") or ip in ("::1", "localhost")


def _strip(ip: str) -> str:
    return (ip or "").split("%")[0]


def _is_wildcard(ip: str) -> bool:
    return ip in ("", "0.0.0.0", "::", "*")


def _hexmac(m: str) -> str:
    return m.lower().replace("-", ":")


def _random_mac(m: str) -> bool:
    try:
        return bool(int(m[1], 16) & 0x2)           # locally-administered bit = phone/OS privacy address
    except Exception:
        return False


class _Target:
    def __init__(self, text: str):
        self.text = text
        self.ip = ""
        self.resolve_error = ""
        self.up: Optional[bool] = None
        self.rtt: Optional[float] = None
        self.hist: deque = deque(maxlen=40)
        self.ports: list = []
        self.scanned = 0.0
        self.scanning = False
        self.rdns = ""
        self.geo: dict = {}
        self.since = time.time()
        self.loss = 0

    def resolve(self) -> None:
        try:
            self.ip = socket.getaddrinfo(self.text, None)[0][4][0]
            self.resolve_error = ""
        except Exception as exc:
            self.resolve_error = f"Could not resolve ({exc.__class__.__name__})"

    def to_dict(self, live: list) -> dict:
        return {"text": self.text, "ip": self.ip, "up": self.up, "rtt": self.rtt, "hist": list(self.hist),
                "ports": self.ports, "scanned": self.scanned, "scanning": self.scanning, "rdns": self.rdns,
                "geo": self.geo, "error": self.resolve_error, "since": self.since, "live": live[:30], "loss": self.loss,
                "mine": privacy.is_mine(self.ip) or privacy.is_mine(self.text)}


class NetWatch:
    def __init__(self):
        self.prefs = {"alerts": True, "auto_block": False, "nets": {"vpn": True, "proxy": True, "lan": True},
                      "filter": "all", "targets": [], "known_macs": [], "baseline": False, "running": False,
                      "allow": [], "blocked": [], "user_stopped": False}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()
        self._pname: dict = {}
        self._io_prev: dict = {}
        self._hist: dict = {k: {"down": deque(maxlen=60), "up": deque(maxlen=60)} for k in ("vpn", "proxy", "lan")}
        self._session: dict = {k: {"down_b": 0, "up_b": 0, "peak_down": 0.0, "peak_up": 0.0, "since": time.time()} for k in ("vpn", "lan")}
        self._health: dict = {"internet": deque(maxlen=40), "router": deque(maxlen=40)}
        self._wifi: dict = {}
        self._public: dict = {}
        self._nic_prev: dict = {}
        self._first_seen: dict = {}
        self._alerted: dict = {}
        self.events: deque = deque(maxlen=120)
        self._payload: dict = {}
        self._targets: dict[str, _Target] = {}
        self._devices: dict = {}
        self._dev_scanned = 0.0
        self._dev_scanning = False
        self._gateway = ""
        self._pool = ThreadPoolExecutor(max_workers=48, thread_name_prefix="netwatch")
        self._rdns: dict = {}
        self._rdns_pending: set = set()
        self._proxy_cache = (0.0, {})
        self._emit = lambda *_: None

    # ── persistence ───────────────────────────────────────────────────────────
    def load(self, saved: dict, emit) -> None:
        self._emit = emit
        for k, v in (saved or {}).items():
            if k in self.prefs:
                self.prefs[k] = v if not isinstance(v, dict) else {**self.prefs[k], **v}
        for t in self.prefs["targets"]:
            self._add_target(t, scan=False)
        for e in self.prefs["allow"]:
            net_monitor.add_allow(e)
        net_monitor._blocked_ips.update(self.prefs["blocked"])
        net_monitor._auto_block = False                 # this monitor owns auto-block; the old loop never runs

    def _save(self) -> None:
        try:
            from app.config import config
            self.prefs["targets"] = [t.text for t in self._targets.values()]
            self.prefs["blocked"] = sorted(net_monitor._blocked_ips)
            config.netmon_prefs = dict(self.prefs)
            config.save()
        except Exception as exc:
            _log.debug("save prefs: %s", exc)

    def set_prefs(self, patch: dict) -> dict:
        for k in ("alerts", "auto_block", "filter"):
            if k in patch:
                self.prefs[k] = patch[k] if k == "filter" else bool(patch[k])
        for k, v in (patch.get("nets") or {}).items():
            if k in self.prefs["nets"]:
                self.prefs["nets"][k] = bool(v)
        self._save()
        self._build()
        return self.prefs

    # ── lifecycle ─────────────────────────────────────────────────────────────
    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self.prefs["running"] = True
        self.prefs["user_stopped"] = False
        self._save()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="netwatch")
        self._thread.start()
        threading.Thread(target=self._target_loop, daemon=True, name="netwatch-targets").start()
        threading.Thread(target=self._device_loop, daemon=True, name="netwatch-devices").start()
        threading.Thread(target=self._health_loop, daemon=True, name="netwatch-health").start()

    def stop(self) -> None:
        self._running = False
        self.prefs["running"] = False
        self.prefs["user_stopped"] = True        # remembered: don't auto-start again just because the page opened
        self._save()
        self._build()

    # ── adapters / proxy ──────────────────────────────────────────────────────
    def _adapters(self) -> list[dict]:
        out = []
        try:
            stats, addrs, io = psutil.net_if_stats(), psutil.net_if_addrs(), psutil.net_io_counters(pernic=True)
        except Exception:
            return out
        for name, st in stats.items():
            if not st.isup or _VIRT_RE.search(name):
                continue
            ips, v4, mask, mac = [], [], "", ""
            for a in addrs.get(name, []):
                if a.family == getattr(psutil, "AF_LINK", -1):
                    mac = a.address
                if a.family in (socket.AF_INET, socket.AF_INET6):
                    ip = _strip(a.address)
                    ips.append(ip)
                    if a.family == socket.AF_INET and not ip.startswith(("169.254.", "127.")):
                        v4.append(ip)
                        mask = a.netmask or mask
            if not v4:
                continue
            out.append({"name": name, "label": clean(name), "kind": "vpn" if _VPN_RE.search(name) else "lan", "ips": ips, "v4": v4,
                        "mask": mask, "mac": mac, "mtu": getattr(st, "mtu", 0), "speed": st.speed,
                        "wifi": bool(_WIFI_RE.search(name)), "io": io.get(name)})
        return out

    def _proxy_info(self) -> dict:
        now = time.time()
        if now - self._proxy_cache[0] < 5 and self._proxy_cache[1]:
            return self._proxy_cache[1]
        servers, pac = [], ""
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
            try:
                if winreg.QueryValueEx(k, "ProxyEnable")[0]:
                    raw = str(winreg.QueryValueEx(k, "ProxyServer")[0])
                    for part in re.split(r"[;,]", raw):
                        part = re.sub(r"^\w+=", "", part.strip())
                        part = re.sub(r"^\w+://", "", part)
                        if part:
                            servers.append(part)
            except OSError:
                pass
            try:
                pac = str(winreg.QueryValueEx(k, "AutoConfigURL")[0])
            except OSError:
                pass
        except Exception:
            pass
        import os
        for var in ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY"):
            v = os.environ.get(var) or os.environ.get(var.lower())
            if v:
                servers.append(re.sub(r"^\w+://", "", v).rstrip("/"))
        hosts, ports, norm = set(), set(), []
        for s in dict.fromkeys(servers):
            host, _, port = s.rpartition(":")
            if not port.isdigit():
                host, port = s, "80"
            host = "127.0.0.1" if host == "localhost" else host.strip("[]")
            try:
                host = socket.gethostbyname(host) if not re.match(r"^[0-9.:a-f]+$", host) else host
            except Exception:
                pass
            hosts.add(host)
            ports.add(int(port))
            norm.append(f"{host}:{port}")
        info = {"present": bool(norm) or bool(pac), "servers": norm, "pac": pac, "hosts": hosts, "ports": ports}
        self._proxy_cache = (now, info)
        return info

    # ── connections ───────────────────────────────────────────────────────────
    def _name(self, pid: int) -> str:
        if not pid:
            return ""
        hit = self._pname.get(pid)
        if hit and time.time() - hit[1] < 30:
            return hit[0]
        try:
            n = clean(psutil.Process(pid).name())
        except Exception:
            n = hit[0] if hit else ""
        self._pname[pid] = (n, time.time())
        return n

    def _resolve_async(self, ip: str) -> str:
        if ip in self._rdns:
            return self._rdns[ip]
        if ip not in self._rdns_pending and len(self._rdns_pending) < 40:
            self._rdns_pending.add(ip)

            def work():
                try:
                    self._rdns[ip] = socket.gethostbyaddr(ip)[0]
                except Exception:
                    self._rdns[ip] = ""
                finally:
                    self._rdns_pending.discard(ip)
            self._pool.submit(work)
        return ""

    def _classify(self, c, name: str, ad_map: dict, proxy: dict) -> Optional[str]:
        la, ra = _strip(c.laddr.ip) if c.laddr else "", _strip(c.raddr.ip) if c.raddr else ""
        lp, rp = (c.laddr.port if c.laddr else 0), (c.raddr.port if c.raddr else 0)
        low = name.lower()
        if ra:
            if proxy["present"] and ((ra in proxy["hosts"] and rp in proxy["ports"]) or (_loop_ip(ra) and rp in proxy["ports"])
                                     or (_loop_ip(la) and lp in proxy["ports"])):
                return "proxy"
            if any(t in low for t in _PROXY_TOOLS):
                return "proxy"
            if _loop_ip(la) or _loop_ip(ra):
                return None
            return ad_map.get(la)
        return "listen"

    def _scan(self) -> dict:
        ads = self._adapters()
        ad_map: dict = {}
        for ad in ads:
            for ip in ad["ips"]:
                ad_map[ip] = ad["kind"]
        proxy = self._proxy_info()
        nets = {k: {"conns": [], "listen": []} for k in ("vpn", "proxy", "lan")}
        now = time.time()
        seen = set()
        proxy_owner = ""
        try:
            socks = psutil.net_connections(kind="inet")
        except Exception as exc:
            _log.debug("net_connections: %s", exc)
            socks = []
        for c in socks:
            name = self._name(c.pid)
            kind = self._classify(c, name, ad_map, proxy)
            if kind is None:
                continue
            la = _strip(c.laddr.ip) if c.laddr else ""
            lp = c.laddr.port if c.laddr else 0
            ra = _strip(c.raddr.ip) if c.raddr else ""
            rp = c.raddr.port if c.raddr else 0
            proto = "UDP" if c.type == socket.SOCK_DGRAM else "TCP"
            if kind == "listen":
                if _loop_ip(la):
                    continue
                if proxy["present"] and lp in proxy["ports"] and _loop_ip(la):
                    proxy_owner = name
                exposed = _is_wildcard(la)
                nets["lan"]["listen"].append({"proc": name or "System", "pid": c.pid or 0, "port": lp, "proto": proto,
                                              "addr": la or "*", "exposed": exposed, "service": _SERVICES.get(lp, ""),
                                              "am": privacy.is_mine(la)})
                continue
            conn = Connection(pid=c.pid or 0, proc=name, laddr=la, lport=lp, raddr=ra, rport=rp,
                              status=c.status or "", proto=proto, first_seen=now)
            conn.threat, conn.reason = net_monitor._score(conn)
            key = (c.pid, la, lp, ra, rp, proto)
            seen.add(key)
            self._first_seen.setdefault(key, now)
            nets[kind]["conns"].append({
                "pid": conn.pid, "proc": name or "Unknown", "proto": proto, "l": f"{la}:{lp}", "r": f"{ra}:{rp}",
                "ra": ra, "rp": rp, "lm": privacy.is_mine(la), "rm": privacy.is_mine(ra),
                "status": conn.status, "threat": conn.threat, "reason": conn.reason,
                "age": int(now - self._first_seen[key]), "rdns": self._resolve_async(ra) if conn.threat or rp in (443, 80) else "",
                "service": _SERVICES.get(rp, "")})
        for k in [k for k in self._first_seen if k not in seen]:
            del self._first_seen[k]
        # proxy owner (local proxy process listening on the proxy port)
        if proxy["present"] and not proxy_owner:
            for c in socks:
                if c.status == "LISTEN" and c.laddr and c.laddr.port in proxy["ports"]:
                    proxy_owner = self._name(c.pid)
                    break
        return {"nets": nets, "ads": ads, "proxy": proxy, "proxy_owner": proxy_owner, "socks": socks}

    # ── building the payload ──────────────────────────────────────────────────
    def _throughput(self, ads: list[dict]) -> dict:
        now = time.time()
        res = {"vpn": [0.0, 0.0], "lan": [0.0, 0.0]}
        for ad in ads:
            io = ad["io"]
            if not io:
                continue
            prev = self._io_prev.get(ad["name"])
            self._io_prev[ad["name"]] = (now, io.bytes_recv, io.bytes_sent)
            if prev and now > prev[0]:
                dt = now - prev[0]
                dr, ds = max(0, io.bytes_recv - prev[1]), max(0, io.bytes_sent - prev[2])
                res[ad["kind"]][0] += dr * 8 / dt / 1e6
                res[ad["kind"]][1] += ds * 8 / dt / 1e6
                ses = self._session[ad["kind"]]
                ses["down_b"] += dr
                ses["up_b"] += ds
        for k in ("vpn", "lan"):
            ses = self._session[k]
            ses["peak_down"] = max(ses["peak_down"], res[k][0])
            ses["peak_up"] = max(ses["peak_up"], res[k][1])
        return res

    def _build(self, scan: Optional[dict] = None) -> None:
        with self._lock:
            if scan is None:
                scan = getattr(self, "_last_scan", None)
            payload = {"ts": time.time(), "running": self._running, "alerts": self.prefs["alerts"],
                       "auto_block": self.prefs["auto_block"], "prefs_nets": dict(self.prefs["nets"]),
                       "filter": self.prefs["filter"], "user_stopped": self.prefs["user_stopped"], "nets": {}, "targets": [], "events": list(self.events)[-60:],
                       "blocked": sorted(net_monitor._blocked_ips), "allow": sorted(self.prefs["allow"]),
                       "blocked_list": [{"ip": ip, "mine": privacy.is_mine(ip)} for ip in sorted(net_monitor._blocked_ips)],
                       "health": self._health_payload(), "wifi": self._wifi, "public": self._public}
            if scan:
                ads, proxy = scan["ads"], scan["proxy"]
                tp = self._throughput(ads) if self._running else {"vpn": [0, 0], "lan": [0, 0]}
                for kind in ("vpn", "proxy", "lan"):
                    d = scan["nets"][kind]
                    present = {"vpn": any(a["kind"] == "vpn" for a in ads), "lan": any(a["kind"] == "lan" for a in ads),
                               "proxy": proxy["present"]}[kind]
                    # Proxies share the physical link, so only VPN and Wi-Fi/Ethernet have their own byte counters.
                    down, up = (0.0, 0.0) if kind == "proxy" else tp[kind]
                    h = self._hist[kind]
                    h["down"].append(round(down, 3))
                    h["up"].append(round(up, 3))
                    conns = sorted(d["conns"], key=lambda c: (-c["threat"], c["status"] != "ESTABLISHED", c["proc"].lower()))
                    names = [a for a in ads if a["kind"] == kind]
                    if kind == "vpn":
                        label = "VPN"
                        detail = ", ".join(f"{a['label']} · {a['v4'][0]}" for a in names) or "No VPN adapter is up"
                    elif kind == "proxy":
                        label = "Proxy"
                        detail = (", ".join(proxy["servers"]) + (f" ({scan['proxy_owner']})" if scan["proxy_owner"] else "")
                                  if proxy["servers"] else ("PAC script: " + proxy["pac"] if proxy["pac"] else "No proxy configured"))
                    else:
                        wifi = any(a["wifi"] for a in names)
                        eth = any(not a["wifi"] for a in names)
                        label = "Wi-Fi + Ethernet" if wifi and eth else "Wi-Fi" if wifi else "Ethernet" if eth else "Wi-Fi / Ethernet"
                        # Your own adapter names / addresses are never put in plain text - they go in `adapters` and the UI hides them.
                        detail = (", ".join(("Wi-Fi" if a["wifi"] else "Ethernet") + (f" · {int(a['speed'])} Mbps" if a["speed"] else "") for a in names)
                                  or "No network adapter is up")
                    payload["nets"][kind] = {
                        "key": kind, "label": label, "detail": detail, "present": present, "enabled": self.prefs["nets"][kind],
                        "down": round(down, 2), "up": round(up, 2), "hist_down": list(h["down"]), "hist_up": list(h["up"]),
                        "total": len(conns), "watch": sum(1 for c in conns if c["threat"] == 1),
                        "warn": sum(1 for c in conns if c["threat"] == 2), "danger": sum(1 for c in conns if c["threat"] >= 3),
                        "conns": conns[:300],
                        "listen": sorted(d["listen"], key=lambda x: (not x["exposed"], x["port"]))[:80] if kind == "lan" else [],
                        "devices": self._devices_list() if kind == "lan" else [],
                        "dev_scanning": self._dev_scanning if kind == "lan" else False,
                        "gateway": "",
                        "adapters": [{"label": a["label"] if kind == "vpn" else ("Wi-Fi" if a["wifi"] else "Ethernet"),
                                      "name": a["label"], "ip": a["v4"][0], "ips": a["ips"], "mac": a["mac"], "speed": int(a["speed"] or 0),
                                      "mtu": a["mtu"], "wifi": a["wifi"], "mine": kind == "lan"} for a in names],
                        "session": dict(self._session[kind]) if kind in self._session else None,
                        "apps": self._apps(conns)}
                    if kind == "lan":
                        payload["nets"][kind]["dev_scanned"] = self._dev_scanned
                for t in self._targets.values():
                    live = [c for k in ("vpn", "proxy", "lan") for c in scan["nets"][k]["conns"] if c["ra"] == t.ip]
                    payload["targets"].append(t.to_dict(live))
            else:
                for t in self._targets.values():
                    payload["targets"].append(t.to_dict([]))
            self._payload = payload
        self._emit("netmon.snapshot", payload)

    def state(self) -> dict:
        if not self._payload:
            self._build()
        return self._payload

    # ── alerts ────────────────────────────────────────────────────────────────
    def _event(self, level: int, title: str, detail: str, net: str = "", key: str = "", priv: bool = False) -> None:
        now = time.time()
        if key:
            if now - self._alerted.get(key, 0) < 600:
                return
            self._alerted[key] = now
        ev = {"ts": now, "level": level, "title": title, "detail": detail, "net": net, "priv": bool(priv)}
        self.events.append(ev)
        if self.prefs["alerts"]:
            self._emit("netmon.alert", ev)

    def _check_alerts(self, scan: dict) -> None:
        for kind, d in scan["nets"].items():
            if not self.prefs["nets"][kind]:
                continue
            for c in d["conns"]:
                if c["threat"] >= 2:
                    self._event(c["threat"], f"{'Dangerous' if c['threat'] >= 3 else 'Suspicious'} connection: {c['proc']}",
                                f"{c['proto']} {c['l']} -> {c['r']}" + (f"  ({c['reason']})" if c["reason"] else ""),
                                kind, key=f"c|{c['proc']}|{c['ra']}|{c['rp']}", priv=c["lm"] or c["rm"])
                    if self.prefs["auto_block"] and c["threat"] >= 3 and c["ra"]:
                        if net_monitor.block_ip(c["ra"]):
                            self._event(3, "Blocked IP", f"{c['ra']} was blocked automatically", kind, priv=c["rm"])
                            self._save()

    # ── per-app summary, connection health, Wi-Fi, public IP ──────────────────
    def _apps(self, conns: list) -> list:
        by: dict = {}
        for c in conns:
            a = by.setdefault(c["proc"], {"pids": set(), "total": 0, "est": 0, "udp": 0, "flag": 0, "remotes": set(), "worst": 0})
            a["pids"].add(c["pid"])
            a["total"] += 1
            a["est"] += 1 if c["status"] == "ESTABLISHED" else 0
            a["udp"] += 1 if c["proto"] == "UDP" else 0
            a["flag"] += 1 if c["threat"] >= 2 else 0
            a["worst"] = max(a["worst"], c["threat"])
            if c["ra"]:
                a["remotes"].add(c["ra"])
        out = [{"proc": k, "pid": min(a["pids"]) if a["pids"] else 0, "procs": len(a["pids"]), "total": a["total"], "est": a["est"],
                "udp": a["udp"], "flag": a["flag"], "worst": a["worst"], "remotes": len(a["remotes"])} for k, a in by.items()]
        out.sort(key=lambda a: (-a["worst"], -a["total"], a["proc"].lower()))
        return out[:40]

    def _health_payload(self) -> dict:
        res = {}
        for k, dq in self._health.items():
            vals = list(dq)
            ok = [v for v in vals if v is not None]
            jit = (sum(abs(a - b) for a, b in zip(ok, ok[1:])) / (len(ok) - 1)) if len(ok) > 1 else 0.0
            res[k] = {"rtt": vals[-1] if vals else None, "avg": round(sum(ok) / len(ok), 1) if ok else None,
                      "jitter": round(jit, 1), "loss": round(100 * (len(vals) - len(ok)) / len(vals)) if vals else 0,
                      "hist": [v if v is not None else 0 for v in vals], "samples": len(vals)}
        return res

    def _ping_ip(self, ip: str) -> Optional[float]:
        try:
            out = subprocess.run(["ping", "-4", "-n", "1", "-w", "1200", ip], capture_output=True, text=True, timeout=5,
                                 creationflags=_NO_WIN).stdout
            m = re.search(r"time[=<]\s*(\d+)\s*ms", out, re.I)
            return float(m.group(1)) if m else None
        except Exception:
            return None

    def _wifi_info(self) -> dict:
        try:
            out = subprocess.run(["netsh", "wlan", "show", "interfaces"], capture_output=True, text=True, timeout=8,
                                 creationflags=_NO_WIN, errors="replace").stdout
        except Exception:
            return {}
        d = {}
        for line in out.splitlines():
            if ":" not in line:
                continue
            k, _, v = line.partition(":")
            d.setdefault(k.strip().lower(), v.strip())
        if d.get("state", "").lower() != "connected":
            return {}
        sig = re.sub(r"[^\d]", "", d.get("signal", ""))
        return {"ssid": d.get("ssid", ""), "bssid": d.get("bssid", ""), "signal": int(sig) if sig else None,
                "radio": d.get("radio type", ""), "band": d.get("band", ""), "channel": d.get("channel", ""),
                "rx": d.get("receive rate (mbps)", ""), "tx": d.get("transmit rate (mbps)", ""), "auth": d.get("authentication", ""),
                "cipher": d.get("cipher", "")}

    def _public_info(self) -> dict:
        """What the internet sees: with a VPN up this is the VPN exit (not hidden); otherwise it is YOUR real address (hidden)."""
        try:
            import requests
            s = requests.Session()
            s.trust_env = False
            r = s.get("https://www.cloudflare.com/cdn-cgi/trace", timeout=6)
            d = dict(l.split("=", 1) for l in r.text.splitlines() if "=" in l)
            ip = d.get("ip", "")
            via_vpn = any(a["kind"] == "vpn" for a in (getattr(self, "_last_scan", None) or {}).get("ads", []))
            if ip and not via_vpn:
                privacy.add_public(ip)
            return {"ip": ip, "loc": d.get("loc", ""), "colo": d.get("colo", ""), "http": d.get("http", ""), "tls": d.get("tls", ""),
                    "vpn": via_vpn, "mine": bool(ip) and not via_vpn, "ts": time.time()}
        except Exception:
            return self._public or {}

    def _health_loop(self) -> None:
        last_pub = last_wifi = 0.0
        while self._running:
            try:
                self._health["internet"].append(self._ping_ip("1.1.1.1"))
                gw = self._gateway or self._find_gateway()
                if gw:
                    self._gateway = gw
                    self._health["router"].append(self._ping_ip(gw))
                now = time.time()
                if now - last_wifi > 6:
                    last_wifi = now
                    self._wifi = self._wifi_info()
                if now - last_pub > 120:
                    last_pub = now
                    self._public = self._public_info()
            except Exception as exc:
                _log.debug("health loop: %s", exc)
            time.sleep(2.5)

    def _kick_info(self) -> None:
        """Latency / Wi-Fi / public-IP refresh on demand (when the monitor page is not running its own loop)."""
        if self._running or getattr(self, "_info_busy", False) or time.time() - getattr(self, "_info_t", 0.0) < 8:
            return
        self._info_busy, self._info_t = True, time.time()

        def work():
            try:
                self._health["internet"].append(self._ping_ip("1.1.1.1"))
                gw = self._gateway or self._find_gateway()
                if gw:
                    self._gateway = gw
                    self._health["router"].append(self._ping_ip(gw))
                self._wifi = self._wifi_info()
                if time.time() - getattr(self, "_pub_t", 0.0) > 120:
                    self._pub_t = time.time()
                    self._public = self._public_info()
            except Exception as exc:
                _log.debug("info refresh: %s", exc)
            finally:
                self._info_busy = False
        threading.Thread(target=work, daemon=True, name="netwatch-info").start()

    def extra(self) -> dict:
        """Every adapter with live counters + the TCP state mix + latency / Wi-Fi / public IP (Task Manager Network tab)."""
        self._kick_info()
        now = time.time()
        rows = []
        try:
            stats, addrs, io = psutil.net_if_stats(), psutil.net_if_addrs(), psutil.net_io_counters(pernic=True)
        except Exception:
            stats, addrs, io = {}, {}, {}
        for name, st in stats.items():
            v4, v6, mac = [], [], ""
            for a in addrs.get(name, []):
                if a.family == getattr(psutil, "AF_LINK", -1):
                    mac = a.address
                elif a.family == socket.AF_INET:
                    v4.append(_strip(a.address))
                elif a.family == socket.AF_INET6:
                    v6.append(_strip(a.address))
            c = io.get(name)
            kind = "vpn" if _VPN_RE.search(name) else "virtual" if _VIRT_RE.search(name) else "wifi" if _WIFI_RE.search(name) else "ethernet"
            rx = tx = 0.0
            prev = self._nic_prev.get(name)
            if c:
                self._nic_prev[name] = (now, c.bytes_recv, c.bytes_sent)
                if prev and now > prev[0]:
                    rx = max(0, c.bytes_recv - prev[1]) * 8 / (now - prev[0]) / 1e6
                    tx = max(0, c.bytes_sent - prev[2]) * 8 / (now - prev[0]) / 1e6
            rows.append({"name": clean(name), "kind": kind, "up": bool(st.isup), "speed": int(st.speed or 0), "mtu": getattr(st, "mtu", 0),
                         "v4": v4, "v6": v6, "mac": mac, "mine": kind != "vpn",
                         "recv_b": c.bytes_recv if c else 0, "sent_b": c.bytes_sent if c else 0, "pk_in": c.packets_recv if c else 0,
                         "pk_out": c.packets_sent if c else 0, "err": (c.errin + c.errout) if c else 0, "drop": (c.dropin + c.dropout) if c else 0,
                         "rx": round(rx, 2), "tx": round(tx, 2)})
        rows.sort(key=lambda r: (not r["up"], r["kind"] == "virtual", r["name"].lower()))
        tcp: dict = {}
        try:
            for c in psutil.net_connections(kind="tcp"):
                tcp[c.status] = tcp.get(c.status, 0) + 1
        except Exception:
            pass
        return {"adapters": rows, "tcp": tcp, "ts": now, "health": self._health_payload(), "wifi": self._wifi,
                "public": self._public, "gateway": "", "blocked": len(net_monitor._blocked_ips)}

    # ── main loop ─────────────────────────────────────────────────────────────
    def _loop(self) -> None:
        while self._running:
            t0 = time.time()
            try:
                scan = self._scan()
                self._last_scan = scan
                self._check_alerts(scan)
                self._build(scan)
            except Exception as exc:
                _log.debug("netwatch loop: %s", exc)
            time.sleep(max(0.2, 2.0 - (time.time() - t0)))

    # ── LAN devices (Network Guardian) ───────────────────────────────────────
    def _devices_list(self) -> list:
        return sorted(self._devices.values(), key=lambda d: (not d.get("gateway"), tuple(int(x) for x in d["ip"].split(".")) if re.match(r"^\d+\.\d+\.\d+\.\d+$", d["ip"]) else (999,)))

    def _read_arp(self, net: Optional[ipaddress.IPv4Network]) -> dict:
        try:
            out = subprocess.run(["arp", "-a"], capture_output=True, text=True, timeout=10, creationflags=_NO_WIN).stdout
        except Exception:
            return {}
        res = {}
        for line in out.splitlines():
            m = re.match(r"\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})\s+(\w+)", line)
            if not m:
                continue
            ip, mac, kind = m.group(1), _hexmac(m.group(2)), m.group(3).lower()
            if mac == "ff:ff:ff:ff:ff:ff" or mac.startswith("01:00:5e") or ip.startswith(("224.", "239.")) or ip.endswith(".255"):
                continue
            if net is not None and ipaddress.ip_address(ip) not in net:
                continue
            res[ip] = {"ip": ip, "mac": mac, "type": kind}
        return res

    def _lan_network(self) -> tuple[Optional[ipaddress.IPv4Network], str]:
        for ad in self._adapters():
            if ad["kind"] == "lan" and ad["mask"]:
                try:
                    net = ipaddress.ip_network(f"{ad['v4'][0]}/{ad['mask']}", strict=False)
                    return net, ad["v4"][0]
                except Exception:
                    continue
        return None, ""

    def _find_gateway(self) -> str:
        try:
            out = subprocess.run(["route", "print", "-4", "0.0.0.0"], capture_output=True, text=True, timeout=10, creationflags=_NO_WIN).stdout
            for line in out.splitlines():
                p = line.split()
                if len(p) >= 5 and p[0] == "0.0.0.0" and p[1] == "0.0.0.0":
                    return p[2]
        except Exception:
            pass
        return ""

    def scan_devices(self, sweep: bool = True) -> None:
        if self._dev_scanning:
            return
        self._dev_scanning = True
        self._build()

        def work():
            try:
                net, me = self._lan_network()
                self._gateway = self._find_gateway()
                if net is not None and sweep and net.num_addresses <= 1024:
                    def poke(ip):
                        try:
                            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            s.settimeout(0.25)
                            s.connect_ex((str(ip), 80))     # even a refused connect makes Windows ARP-resolve the host
                            s.close()
                        except Exception:
                            pass
                    list(self._pool.map(poke, [h for h in net.hosts() if str(h) != me]))
                    time.sleep(0.4)
                found = self._read_arp(net)
                known = set(self.prefs["known_macs"])
                first = not self.prefs["baseline"]
                now = time.time()
                for ip, d in found.items():
                    mac = d["mac"]
                    old = self._devices.get(mac)
                    rd = self._rdns.get(ip, "")
                    if not rd and ip not in self._rdns:
                        try:
                            rd = socket.gethostbyaddr(ip)[0]
                        except Exception:
                            rd = ""
                        self._rdns[ip] = rd
                    is_new = mac not in known and not first
                    self._devices[mac] = {"ip": ip, "mac": mac, "name": rd, "random": _random_mac(mac),
                                          "new": is_new, "gateway": ip == self._gateway, "you": ip == me,
                                          "first_seen": old["first_seen"] if old else now, "last_seen": now}
                    if is_new and not old:
                        self._event(2, "New device on your network", f"{ip}  {mac}" + (f"  ({rd})" if rd else "") + (" - private MAC" if _random_mac(mac) else ""),
                                    "lan", key=f"dev|{mac}", priv=True)
                # devices not answering for 15 minutes drop out of the list
                for mac in [m for m, d in self._devices.items() if now - d["last_seen"] > 900]:
                    del self._devices[mac]
                if first and found:
                    self.prefs["known_macs"] = sorted(set(known) | set(found_m["mac"] for found_m in found.values()))
                    self.prefs["baseline"] = True
                    self._save()
                self._dev_scanned = now
            except Exception as exc:
                _log.debug("scan_devices: %s", exc)
            finally:
                self._dev_scanning = False
                self._build()
        threading.Thread(target=work, daemon=True, name="netwatch-devscan").start()

    def trust_device(self, mac: str) -> bool:
        mac = _hexmac(mac)
        if mac not in self.prefs["known_macs"]:
            self.prefs["known_macs"].append(mac)
        if mac in self._devices:
            self._devices[mac]["new"] = False
        self._save()
        self._build()
        return True

    def _device_loop(self) -> None:
        last_sweep = 0.0
        time.sleep(3)
        while self._running:
            if self.prefs["nets"]["lan"]:
                now = time.time()
                if now - last_sweep > 300:
                    last_sweep = now
                    self.scan_devices(True)
                elif not self._dev_scanning and now - self._dev_scanned > 60:
                    self.scan_devices(False)
            time.sleep(10)

    # ── custom targets (nmap-lite) ───────────────────────────────────────────
    def _add_target(self, text: str, scan: bool = True) -> Optional[_Target]:
        text = (text or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9.\-:_]{1,100}", text) or text in self._targets:
            return self._targets.get(text)
        if len(self._targets) >= 8:
            raise RuntimeError("You can monitor up to 8 targets at once")
        t = _Target(text)
        t.resolve()
        self._targets[text] = t
        if t.ip and scan:
            self.scan_target(text)
        return t

    def add_targets(self, raw: str) -> list[str]:
        added = []
        for part in re.split(r"[\s,;]+", raw or ""):
            if part and self._add_target(part):
                added.append(part)
        self._save()
        if not self._running:
            self.start()
        self._build()
        return added

    def remove_target(self, text: str) -> bool:
        ok = self._targets.pop(text, None) is not None
        self._save()
        self._build()
        return ok

    def scan_target(self, text: str) -> bool:
        t = self._targets.get(text)
        if not t or t.scanning or not t.ip:
            return False
        t.scanning = True

        def work():
            try:
                def probe(p):
                    try:
                        s = socket.socket(socket.AF_INET6 if ":" in t.ip else socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(0.6)
                        ok = s.connect_ex((t.ip, p)) == 0
                        s.close()
                        return p if ok else None
                    except Exception:
                        return None
                opened = [p for p in self._pool.map(probe, _SCAN_PORTS) if p]
                before = {x["port"] for x in t.ports}
                t.ports = [{"port": p, "service": _SERVICES.get(p, "")} for p in opened]
                t.scanned = time.time()
                for p in opened:
                    if t.scanned and before and p not in before:
                        mine = privacy.is_mine(t.ip) or privacy.is_mine(t.text)
                        self._event(2, "New open port on " + ("a private target" if mine else t.text),
                                    f"Port {p} {_SERVICES.get(p, '')} just opened", "targets", key=f"port|{t.text}|{p}", priv=mine)
                if not t.rdns:
                    try:
                        t.rdns = socket.gethostbyaddr(t.ip)[0]
                    except Exception:
                        t.rdns = ""
                if not t.geo and not t.ip.startswith(("10.", "192.168.", "127.")) and not ipaddress.ip_address(t.ip).is_private:
                    try:
                        import requests
                        j = requests.get(f"https://ipwho.is/{t.ip}", timeout=6).json()
                        if j.get("success"):
                            t.geo = {"country": j.get("country", ""), "city": j.get("city", ""), "org": (j.get("connection") or {}).get("org", "")}
                    except Exception:
                        pass
            except Exception as exc:
                _log.debug("scan_target: %s", exc)
            finally:
                t.scanning = False
                self._build()
        threading.Thread(target=work, daemon=True, name="netwatch-portscan").start()
        return True

    def _ping(self, t: _Target) -> tuple[bool, Optional[float]]:
        try:
            flag = "-6" if ":" in t.ip else "-4"
            out = subprocess.run(["ping", flag, "-n", "1", "-w", "1500", t.ip], capture_output=True, text=True,
                                 timeout=6, creationflags=_NO_WIN).stdout
            m = re.search(r"time[=<]\s*(\d+)\s*ms", out, re.I)
            if m:
                return True, float(m.group(1))
        except Exception:
            pass
        for port in (443, 80, 445):                         # ICMP may be blocked: a refused/accepted TCP connect still proves it's alive
            try:
                s = socket.socket(socket.AF_INET6 if ":" in t.ip else socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.2)
                t0 = time.time()
                r = s.connect_ex((t.ip, port))
                s.close()
                if r in (0, 10061):
                    return True, round((time.time() - t0) * 1000, 1)
            except Exception:
                continue
        return False, None

    def _target_loop(self) -> None:
        while self._running:
            for t in list(self._targets.values()):
                if not t.ip:
                    t.resolve()
                    if not t.ip:
                        continue
                up, rtt = self._ping(t)
                if t.up is not None and up != t.up:
                    mine = privacy.is_mine(t.ip) or privacy.is_mine(t.text)
                    self._event(2 if not up else 1, f"{'A private target' if mine else t.text} is {'back online' if up else 'unreachable'}",
                                f"{t.text}  {t.ip}" + (f" - {rtt:.0f} ms" if rtt else ""), "targets", key=f"up|{t.text}|{up}", priv=mine)
                    t.since = time.time()
                t.up, t.rtt = up, rtt
                t.hist.append(rtt if rtt is not None else 0)
            time.sleep(4)


netwatch = NetWatch()

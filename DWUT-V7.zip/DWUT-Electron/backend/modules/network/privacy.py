"""
modules/network/privacy.py - decides which network details are "yours".

Your real LAN / Wi-Fi addresses, IPv6, MACs, router, devices on your network and your real public IP are hidden behind
click-to-reveal in the UI.  VPN-tunnel addresses, proxies and other people's servers are NOT hidden.

  VPN adapter address / subnet            -> not yours
  your physical adapters, private, link-local, CGNAT, ULA -> yours
  loopback / unspecified / public internet -> not hidden
"""
from __future__ import annotations

import ipaddress
import re
import socket
import threading
import time

import psutil

_VPN_RE = re.compile(r"wireguard|dwutvpn|dwutnet|wintun|\btun\d*\b|tap-windows|\btap\d*\b|nordlynx|nord|proton|mullvad|openvpn|"
                     r"tailscale|zerotier|anyconnect|fortinet|globalprotect|pulse secure|windscribe|expressvpn|surfshark|cloudflare|warp|\bvpn\b", re.I)
_VIRT_RE = re.compile(r"vethernet|vmware|virtualbox|vbox|hyper-v|loopback|pseudo|bluetooth|isatap|teredo|docker|wsl|miniport", re.I)
_CGNAT = ipaddress.ip_network("100.64.0.0/10")

_lock = threading.Lock()
_cache: dict = {"t": 0.0, "own": set(), "vpn_nets": [], "vpn_ips": set()}


def strip(ip: str) -> str:
    return (ip or "").split("%")[0].strip("[]")


def _refresh() -> None:
    now = time.time()
    if now - _cache["t"] < 3.0:
        return
    with _lock:
        if now - _cache["t"] < 3.0:
            return
        own, vpn_ips, vpn_nets = set(_cache.get("public", set())), set(), []
        try:
            stats, addrs = psutil.net_if_stats(), psutil.net_if_addrs()
            for name, lst in addrs.items():
                st = stats.get(name)
                if not st or not st.isup or _VIRT_RE.search(name):
                    continue
                is_vpn = bool(_VPN_RE.search(name))
                for a in lst:
                    if a.family not in (socket.AF_INET, socket.AF_INET6):
                        continue
                    ip = strip(a.address)
                    if is_vpn:
                        vpn_ips.add(ip)
                        if a.family == socket.AF_INET and a.netmask:
                            try:
                                vpn_nets.append(ipaddress.ip_network(f"{ip}/{a.netmask}", strict=False))
                            except ValueError:
                                pass
                    else:
                        own.add(ip)
        except Exception:
            pass
        _cache.update(t=now, own=own, vpn_ips=vpn_ips, vpn_nets=vpn_nets)


def add_public(ip: str) -> None:
    """Remember your real public address so it is hidden wherever it shows up."""
    ip = strip(ip)
    if ip:
        _cache.setdefault("public", set()).add(ip)
        _cache["own"].add(ip)


def is_mine(ip: str) -> bool:
    ip = strip(ip)
    if not ip or ip in ("*", "::", "0.0.0.0"):
        return False
    _refresh()
    if ip in _cache["vpn_ips"]:
        return False
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if a.is_loopback or a.is_unspecified or a.is_multicast:
        return False
    for n in _cache["vpn_nets"]:
        if a.version == n.version and a in n:
            return False
    if ip in _cache["own"] or a.is_private or a.is_link_local:
        return True
    return a.version == 4 and a in _CGNAT


def split_addr(addr: str) -> tuple[str, str]:
    addr = addr or ""
    if addr.startswith("["):
        host, _, port = addr[1:].partition("]:")
        return host, port
    if addr.count(":") == 1:
        host, _, port = addr.partition(":")
        return host, port
    return addr, ""


def addr_mine(addr: str) -> bool:
    return is_mine(split_addr(addr)[0])

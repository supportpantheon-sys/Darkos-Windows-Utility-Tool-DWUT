"""
modules/proxy/relay.py — local forwarding proxy with failover.

WHY: pointing Windows straight at a free proxy breaks browsers when
  * the proxy is SOCKS5 (WinINET's "socks=" means SOCKS4 -> Chrome/Edge fail),
  * the proxy dies (free proxies live minutes) -> browsers say "no internet" while apps that
    ignore the system proxy (Discord) keep working,
  * the proxy doesn't support CONNECT for some hosts.
The system proxy is set to 127.0.0.1:<port> (a plain HTTP proxy every app understands).
This relay forwards through the chosen upstream (HTTP / SOCKS4 / SOCKS5) and silently falls back
to the next verified proxy when one fails.
"""
from __future__ import annotations

import select
import socket
import struct
import threading
import time
from dataclasses import dataclass
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)
CONNECT_TIMEOUT = 12.0
IDLE_TIMEOUT = 300.0


@dataclass
class Upstream:
    ip: str
    port: int
    protocol: str            # http | socks4 | socks5

    @property
    def label(self) -> str:
        return f"{self.ip}:{self.port} ({self.protocol.upper()})"


class _UpstreamError(Exception):
    soft = False        # soft = the DESTINATION failed (host down/refused) - the proxy itself is fine


def _recv_exact(s: socket.socket, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        c = s.recv(n - len(buf))
        if not c:
            raise _UpstreamError("upstream closed during handshake")
        buf += c
    return buf


def open_tunnel(up: Upstream, host: str, port: int, timeout: float = CONNECT_TIMEOUT) -> socket.socket:
    """Return a socket connected to host:port THROUGH the upstream proxy."""
    s = socket.create_connection((up.ip, up.port), timeout=timeout)
    try:
        s.settimeout(timeout)
        if up.protocol == "socks5":
            s.sendall(b"\x05\x01\x00")
            if _recv_exact(s, 2) != b"\x05\x00":
                raise _UpstreamError("SOCKS5 auth required/refused")
            h = host.encode("idna")
            s.sendall(b"\x05\x01\x00\x03" + bytes([len(h)]) + h + struct.pack(">H", port))
            rep = _recv_exact(s, 4)
            if rep[1] != 0:
                err = _UpstreamError(f"SOCKS5 connect failed (code {rep[1]})")
                err.soft = rep[1] in (3, 4, 5, 6)             # net/host unreachable, refused, TTL: not the proxy's fault
                raise err
            atyp = rep[3]
            _recv_exact(s, {1: 4, 4: 16}.get(atyp, 0) if atyp != 3 else _recv_exact(s, 1)[0])
            _recv_exact(s, 2)
        elif up.protocol == "socks4":
            try:
                ip4 = socket.inet_aton(socket.gethostbyname(host))
                req = b"\x04\x01" + struct.pack(">H", port) + ip4 + b"\x00"
            except OSError:
                req = b"\x04\x01" + struct.pack(">H", port) + b"\x00\x00\x00\x01" + b"\x00" + host.encode() + b"\x00"
            s.sendall(req)
            rep = _recv_exact(s, 8)
            if rep[1] != 0x5A:
                raise _UpstreamError("SOCKS4 connect refused")
        else:
            s.sendall(f"CONNECT {host}:{port} HTTP/1.1\r\nHost: {host}:{port}\r\nProxy-Connection: keep-alive\r\n\r\n".encode())
            head = b""
            while b"\r\n\r\n" not in head:
                c = s.recv(4096)
                if not c:
                    raise _UpstreamError("proxy closed on CONNECT")
                head += c
                if len(head) > 16384:
                    raise _UpstreamError("oversized CONNECT reply")
            status = head.split(b"\r\n", 1)[0]
            if b" 200" not in status:
                err = _UpstreamError("CONNECT refused: " + status.decode("latin1")[:60])
                err.soft = any(c in status for c in (b" 502", b" 503", b" 504"))   # gateway errors usually mean the target is down
                raise err
        s.settimeout(None)
        return s
    except Exception:
        try:
            s.close()
        except OSError:
            pass
        raise


def _pipe(a: socket.socket, b: socket.socket) -> None:
    socks = [a, b]
    last = time.monotonic()
    try:
        while True:
            r, _, x = select.select(socks, [], socks, 5.0)
            if x:
                break
            if not r:
                if time.monotonic() - last > IDLE_TIMEOUT:
                    break
                continue
            for src in r:
                data = src.recv(65536)
                if not data:
                    return
                (b if src is a else a).sendall(data)
                last = time.monotonic()
    except OSError:
        pass


class Relay:
    def __init__(self) -> None:
        self._srv: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.pool: list[Upstream] = []
        self.current = 0
        self._cool: dict[int, float] = {}
        self._hard: dict[int, list] = {}
        self.port = 0
        self.running = False
        self.on_switch = None            # callback(label)

    # ── control ──
    def start(self, pool: list[Upstream], port: int = 0) -> int:
        self.stop()
        self.pool = list(pool)
        self.current = 0
        self._cool.clear()
        self._hard.clear()
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind(("127.0.0.1", port))
        except OSError:
            srv.bind(("127.0.0.1", 0))
        srv.listen(128)
        self._srv = srv
        self.port = srv.getsockname()[1]
        self.running = True
        self._thread = threading.Thread(target=self._serve, daemon=True, name="proxy-relay")
        self._thread.start()
        _log.info("Relay listening on 127.0.0.1:%d with %d upstream(s)", self.port, len(self.pool))
        return self.port

    def stop(self) -> None:
        self.running = False
        if self._srv:
            try:
                self._srv.close()
            except OSError:
                pass
        self._srv = None

    def current_label(self) -> str:
        with self._lock:
            return self.pool[self.current].label if self.pool else ""

    def set_pool(self, pool: list) -> None:
        with self._lock:
            self.pool = list(pool)
            self.current = 0
            self._cool.clear()

    def add(self, up: Upstream) -> None:
        with self._lock:
            if not any((u.ip, u.port) == (up.ip, up.port) for u in self.pool):
                self.pool.append(up)

    def advance(self) -> bool:
        """Planned server switch (no penalty on the one we leave)."""
        with self._lock:
            if len(self.pool) < 2:
                return False
            for step in range(1, len(self.pool)):
                i = (self.current + step) % len(self.pool)
                if self._cool.get(i, 0) < time.monotonic():
                    self.current = i
                    lab = self.pool[i].label
                    break
            else:
                return False
        if self.on_switch:
            try:
                self.on_switch(lab)
            except Exception:
                pass
        return True

    def rotate(self, bad: int | None = None) -> bool:
        """Mark the current upstream bad and move to the next usable one."""
        with self._lock:
            if not self.pool:
                return False
            if bad is None:
                bad = self.current
            self._cool[bad] = time.monotonic() + 300
            for step in range(1, len(self.pool) + 1):
                i = (bad + step) % len(self.pool)
                if self._cool.get(i, 0) < time.monotonic():
                    self.current = i
                    break
            else:
                return False
            lab = self.pool[self.current].label
        _log.info("Relay switched upstream -> %s", lab)
        if self.on_switch:
            try:
                self.on_switch(lab)
            except Exception:
                pass
        return True

    # ── serving ──
    def _serve(self) -> None:
        while self.running and self._srv:
            try:
                c, _ = self._srv.accept()
            except OSError:
                return
            threading.Thread(target=self._handle, args=(c,), daemon=True).start()

    def _connect_any(self, host: str, port: int) -> socket.socket:
        """Open a tunnel via the current server.  If it fails, use another server for THIS connection only;
        the active server changes only when it has failed repeatedly with no success in between (no more hopping)."""
        with self._lock:
            n = len(self.pool)
            start = self.current
        if not n:
            raise _UpstreamError("no upstream proxies")
        last: Exception = _UpstreamError("no upstream")
        for step in range(min(n, 3)):
            idx = (start + step) % n
            with self._lock:
                up = self.pool[idx]
            try:
                sock = open_tunnel(up, host, port)
                self._hard.pop(idx, None)
                return sock
            except Exception as exc:
                last = exc
                if getattr(exc, "soft", False):
                    raise                                   # destination problem: don't blame or skip the server
                now = time.monotonic()
                with self._lock:
                    fails = [t for t in self._hard.get(idx, []) if now - t < 30] + [now]
                    self._hard[idx] = fails
                    bad = len(fails) >= 3 and idx == self.current
                if bad:
                    self.rotate(idx)
        raise last

    def _handle(self, c: socket.socket) -> None:
        up_sock = None
        try:
            c.settimeout(15)
            head = b""
            while b"\r\n\r\n" not in head:
                chunk = c.recv(8192)
                if not chunk:
                    return
                head += chunk
                if len(head) > 65536:
                    return
            header, _, rest = head.partition(b"\r\n\r\n")
            lines = header.decode("latin1").split("\r\n")
            method, target, ver = (lines[0].split(" ", 2) + ["", ""])[:3]
            c.settimeout(None)
            if method.upper() == "CONNECT":
                host, _, p = target.rpartition(":")
                up_sock = self._connect_any(host.strip("[]"), int(p or 443))
                c.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                if rest:
                    up_sock.sendall(rest)
            else:
                from urllib.parse import urlsplit
                u = urlsplit(target)
                host, port = u.hostname or "", u.port or 80
                if not host:                                  # origin-form: take Host header
                    for ln in lines[1:]:
                        if ln.lower().startswith("host:"):
                            hp = ln.split(":", 1)[1].strip()
                            host, _, pp = hp.partition(":")
                            port = int(pp or 80)
                path = (u.path or "/") + (("?" + u.query) if u.query else "")
                keep = [ln for ln in lines[1:] if not ln.lower().startswith(("proxy-connection:", "connection:"))]
                req = f"{method} {path} {ver}\r\n" + "\r\n".join(keep) + "\r\nConnection: close\r\n\r\n"
                up_sock = self._connect_any(host, port)
                up_sock.sendall(req.encode("latin1") + rest)
            _pipe(c, up_sock)
        except Exception as exc:
            try:
                c.sendall(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            except OSError:
                pass
            _log.debug("relay request failed: %s", exc)
        finally:
            for s in (c, up_sock):
                try:
                    if s:
                        s.close()
                except OSError:
                    pass


relay = Relay()

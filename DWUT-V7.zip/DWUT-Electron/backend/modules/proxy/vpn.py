"""
modules/proxy/vpn.py — the "VPN mode" system layer (kill switch, leak protection, media probes).

Everything here is REVERSIBLE and every change is recorded in vpn_state.json so that, if DWUT or Windows
crashes, the next start (or Repair-Internet.bat) puts the machine back exactly as it was.
"""
from __future__ import annotations

import ipaddress
import json
import os
import socket
import ssl
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

from core.logger import get_logger
from modules.proxy.relay import Upstream, open_tunnel

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

RULE_V4, RULE_V6, RULE_DNS = "DWUT-VPN-KillSwitch-v4", "DWUT-VPN-KillSwitch-v6", "DWUT-VPN-DNS-Block"
STATE_FILE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "vpn_state.json"

# (key path, browser) - Chromium family policy hives
_BROWSER_POLICIES = [r"SOFTWARE\Policies\Google\Chrome", r"SOFTWARE\Policies\Microsoft\Edge", r"SOFTWARE\Policies\BraveSoftware\Brave"]


def _run(cmd: list[str], timeout: int = 60) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW,
                           errors="replace", stdin=subprocess.DEVNULL)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return -1, str(exc)


# ── state file ────────────────────────────────────────────────────────────────

def load_state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_state(st: dict) -> None:
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(st, indent=2), encoding="utf-8")
    except OSError:
        pass


def clear_state() -> None:
    try:
        STATE_FILE.unlink()
    except OSError:
        pass


# ── kill switch / leak rules (Windows Firewall) ───────────────────────────────

def _complement(allowed: list, bits: int) -> list[str]:
    """Address ranges (as 'a-b' strings) covering everything EXCEPT `allowed` networks."""
    top = (1 << bits) - 1
    mk = ipaddress.IPv4Address if bits == 32 else ipaddress.IPv6Address
    spans = sorted((int(n.network_address), int(n.broadcast_address)) for n in allowed)
    merged: list[list[int]] = []
    for s, e in spans:
        if merged and s <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    out, cur = [], 0
    for s, e in merged:
        if s > cur:
            out.append(f"{mk(cur)}-{mk(s - 1)}")
        cur = e + 1
    if cur <= top:
        out.append(f"{mk(cur)}-{mk(top)}")
    return out


_V4_LOCAL = ["127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "224.0.0.0/4", "255.255.255.255/32", "0.0.0.0/32"]
_V6_LOCAL = ["::/128", "::1/128", "fe80::/10", "fc00::/7", "ff00::/8"]


def kill_switch_ranges(proxy_ips: list[str]) -> tuple[list[str], list[str]]:
    v4 = [ipaddress.ip_network(n) for n in _V4_LOCAL]
    for ip in proxy_ips:
        try:
            a = ipaddress.ip_address(ip)
            if a.version == 4:
                v4.append(ipaddress.ip_network(f"{ip}/32"))
        except ValueError:
            pass
    return _complement(v4, 32), _complement([ipaddress.ip_network(n) for n in _V6_LOCAL], 128)


def _delete_rule(name: str) -> None:
    _run(["netsh", "advfirewall", "firewall", "delete", "rule", f"name={name}"], 30)


def _rule_exists(name: str) -> bool:
    code, out = _run(["netsh", "advfirewall", "firewall", "show", "rule", f"name={name}"], 10)
    return code == 0 and "No rules match" not in out


def _add_block(name: str, remote: list[str], extra: list[str] | None = None) -> bool:
    remoteip = ",".join(remote)
    # If rule already exists, modify it in place (no traffic gap) instead of delete+add
    if _rule_exists(name):
        cmd = ["netsh", "advfirewall", "firewall", "set", "rule", f"name={name}",
               "new", f"remoteip={remoteip}", "enable=yes"]
        code, out = _run(cmd, 60)
        if code == 0:
            return True
        # Fall through to delete+add if set fails
        _delete_rule(name)
    cmd = ["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}", "dir=out", "action=block",
           f"remoteip={remoteip}", "profile=any", "enable=yes"] + (extra or [])
    code, out = _run(cmd, 60)
    if code != 0:
        _log.warning("firewall rule %s failed: %s", name, out.strip()[:160])
    return code == 0


def apply_kill_switch(proxy_ips: list[str], ipv6: bool = True) -> bool:
    """Block ALL internet traffic except to the given proxy servers (+ LAN/loopback).
    Uses in-place rule update when possible so there is NEVER a gap in coverage."""
    v4, v6 = kill_switch_ranges(proxy_ips)
    ok = _add_block(RULE_V4, v4)  # modifies in place if rule already exists
    if ipv6:
        ok = _add_block(RULE_V6, v6) and ok
    return ok


def apply_dns_block() -> bool:
    """Block plain DNS / DNS-over-TLS to the internet: names are resolved by the proxy, never locally."""
    non_loop = _complement([ipaddress.ip_network("127.0.0.0/8")], 32)
    _delete_rule(RULE_DNS)
    ok = _add_block(RULE_DNS, non_loop, ["protocol=UDP", "remoteport=53,853"])
    ok = _add_block(RULE_DNS + "-tcp", non_loop, ["protocol=TCP", "remoteport=53,853"]) and ok
    return ok


def remove_firewall_rules() -> None:
    for n in (RULE_V4, RULE_V6, RULE_DNS, RULE_DNS + "-tcp"):
        _delete_rule(n)


# ── browser WebRTC / QUIC leak policies (Chrome / Edge / Brave) ───────────────

def apply_browser_policies() -> dict:
    """Force WebRTC to use only proxied paths and disable QUIC (UDP). Returns a backup for restoring."""
    import winreg
    backup = {}
    for path in _BROWSER_POLICIES:
        prev = {}
        for name, vtype in (("WebRtcIPHandling", winreg.REG_SZ), ("QuicAllowed", winreg.REG_DWORD)):
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
                prev[name] = winreg.QueryValueEx(k, name)[0]
                winreg.CloseKey(k)
            except OSError:
                prev[name] = None
        backup[path] = prev
        try:
            k = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY)
            winreg.SetValueEx(k, "WebRtcIPHandling", 0, winreg.REG_SZ, "disable_non_proxied_udp")
            winreg.SetValueEx(k, "QuicAllowed", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(k)
        except OSError as exc:
            _log.warning("browser policy %s: %s", path, exc)
    return backup


def restore_browser_policies(backup: dict) -> None:
    import winreg
    for path, prev in (backup or {}).items():
        try:
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY)
        except OSError:
            continue
        for name, vtype in (("WebRtcIPHandling", winreg.REG_SZ), ("QuicAllowed", winreg.REG_DWORD)):
            try:
                if prev.get(name) is None:
                    winreg.DeleteValue(k, name)
                else:
                    winreg.SetValueEx(k, name, 0, vtype, prev[name])
            except OSError:
                pass
        winreg.CloseKey(k)


# ── Microsoft Store (UWP) apps cannot reach a localhost proxy unless exempted ──

def _exempt_list() -> set[str]:
    code, out = _run(["CheckNetIsolation", "LoopbackExempt", "-s"], 30)
    import re
    return {m.lower() for m in re.findall(r"Name:\s*(\S+)", out)}


def apply_store_exemptions() -> list[str]:
    """Exempt installed Store apps from loopback isolation. Returns the package families WE added."""
    code, out = _run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                      "Get-AppxPackage | Select-Object -ExpandProperty PackageFamilyName -Unique"], 90)
    fams = [l.strip() for l in out.splitlines() if l.strip() and "_" in l]
    already = _exempt_list()
    added = []
    for f in fams:
        if f.lower() in already:
            continue
        if _run(["CheckNetIsolation", "LoopbackExempt", "-a", f"-n={f}"], 20)[0] == 0:
            added.append(f)
    return added


def remove_store_exemptions(added: list[str]) -> None:
    for f in added or []:
        _run(["CheckNetIsolation", "LoopbackExempt", "-d", f"-n={f}"], 20)


# ── WinHTTP (services, Windows' connectivity checks) ─────────────────────────

def winhttp_get() -> str:
    return _run(["netsh", "winhttp", "show", "proxy"], 20)[1]


def winhttp_set(host_port: str) -> bool:
    return _run(["netsh", "winhttp", "set", "proxy", f"proxy-server={host_port}", "bypass-list=<local>"], 20)[0] == 0


def winhttp_reset() -> None:
    _run(["netsh", "winhttp", "reset", "proxy"], 20)


# ── media probes: can this proxy REALLY stream? ───────────────────────────────

def _tls_get(up: Upstream, host: str, path: str, max_bytes: int, timeout: float = 12.0):
    """HTTPS GET through `up`. Returns (status, nbytes, seconds)."""
    t0 = time.monotonic()
    raw = open_tunnel(up, host, 443, timeout=min(timeout, 8))
    try:
        raw.settimeout(timeout)
        s = ssl.create_default_context().wrap_socket(raw, server_hostname=host)
        s.sendall(f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\nConnection: close\r\n\r\n".encode())
        head, body_n, status = b"", 0, 0
        t_body = None
        while body_n < max_bytes and time.monotonic() - t0 < timeout:
            chunk = s.recv(65536)
            if not chunk:
                break
            if status == 0:
                head += chunk
                if b"\r\n\r\n" in head:
                    status = int(head.split(b" ", 2)[1])
                    body_n = len(head.split(b"\r\n\r\n", 1)[1])
                    t_body = time.monotonic()
            else:
                body_n += len(chunk)
        end = time.monotonic()
        return status, body_n, (end - (t_body or t0)) or 0.001
    finally:
        try:
            raw.close()
        except OSError:
            pass


def media_probe(up: Upstream) -> dict:
    """Quality report: YouTube reachable, googlevideo (the video CDN) reachable, real download speed."""
    res = {"ip": up.ip, "port": up.port, "protocol": up.protocol, "stable": False, "youtube": False, "googlevideo": False, "mbps": 0.0, "ms": None}
    t0 = time.monotonic()
    try:
        st, _, _ = _tls_get(up, "www.youtube.com", "/generate_204", 1024)
        res["youtube"] = st == 204
        res["ms"] = int((time.monotonic() - t0) * 1000)
    except Exception:
        return res
    ok_n = 0                                              # stability: must answer 3 quick requests in a row
    for host, path in (("www.google.com", "/generate_204"), ("discord.com", "/api/v9/gateway"), ("open.spotify.com", "/")):
        try:
            st, _, _ = _tls_get(up, host, path, 512, timeout=8)
            ok_n += 1 if st > 0 else 0
        except Exception:
            pass
    res["stable"] = ok_n >= 2
    try:
        st, n, _ = _tls_get(up, "redirector.googlevideo.com", "/", 2048, timeout=9)
        res["googlevideo"] = st > 0                       # any HTTP answer = CONNECT + TLS to the video CDN worked
    except Exception:
        pass
    try:
        st, n, secs = _tls_get(up, "speed.cloudflare.com", "/__down?bytes=1200000", 1_200_000, timeout=12)
        if st == 200 and n > 100_000:
            res["mbps"] = round(n * 8 / secs / 1e6, 2)
    except Exception:
        pass
    return res


def probe_many(ups: list[Upstream], workers: int = 8, budget_s: float = 40.0, progress=None) -> list[dict]:
    out: list[dict] = []
    t_end = time.monotonic() + budget_s
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(media_probe, u) for u in ups]
        for i, f in enumerate(futs):
            try:
                out.append(f.result(timeout=max(1.0, t_end - time.monotonic())))
            except Exception:
                pass
            if progress:
                progress(i + 1, len(futs))
    return out


def rank(probes: list[dict]) -> list[dict]:
    """Streaming-capable first (youtube + googlevideo), then by measured speed."""
    def key(p):
        return (not (p["youtube"] and p["googlevideo"] and p.get("stable")), not p["youtube"], -p["mbps"], p["ms"] or 9999)
    return sorted([p for p in probes if p["youtube"] or p["mbps"] > 0], key=key)


# ── full restore (used by disconnect, crash recovery and Repair-Internet.bat) ─

def restore_everything(log=lambda m: None) -> None:
    st = load_state()
    remove_firewall_rules()
    if st.get("browser_backup"):
        restore_browser_policies(st["browser_backup"])
    if st.get("store_added"):
        remove_store_exemptions(st["store_added"])
    if st.get("winhttp_changed"):
        prev = st.get("winhttp_prev", "")
        import re
        m = re.search(r"Proxy Server\(s\)\s*:\s*(.+)", prev)
        if m and "none" not in m.group(1).lower():
            winhttp_set(m.group(1).strip())
        else:
            winhttp_reset()
    clear_state()

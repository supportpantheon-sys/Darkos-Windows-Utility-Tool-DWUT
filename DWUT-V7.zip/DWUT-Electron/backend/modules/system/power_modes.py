"""
modules/system/power_modes.py

Two persistent, toggleable power modes on top of Windows' own power plans.

Ultimate Performance
────────────────────
  • Unhides and activates Windows' built-in "Ultimate Performance" plan.
  • Removes background throttling / idle timers.
  • ALSO sets the hardware-accelerated GPU scheduling (HAGS) registry flag
    and all GPU-related power settings (adaptive power save off, prefer
    max performance) so the graphics card actually runs flat-out rather
    than clocking down when the power plan changes.

Extreme Performance
───────────────────
  • Everything in Ultimate Performance, plus:
    – CPU minimum state pinned to 100% (cores never downclock)
    – USB selective suspend disabled
    – PCI Express ASPM disabled
  • GPU settings pushed further: graphics power plan set to the Microsoft
    "High Performance" GPU preference (Windows 11) or the NVIDIA/AMD
    control-panel equivalent via registry.

Both switch the active power plan AND apply GPU/graphics settings
atomically — toggling one off reverts everything (Balanced plan +
GPU settings restored to Windows defaults).
"""

from __future__ import annotations

import subprocess
import winreg
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)

_PLAN_ULTIMATE_PERF = "e9a42b02-d5df-448d-aa00-03f14749eb61"
_PLAN_BALANCED       = "381b4222-f694-41f0-9685-ff5bb260df2e"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _run(args: list[str], timeout: int = 20) -> tuple[bool, str]:
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, errors="replace",
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), stdin=subprocess.DEVNULL)
        return r.returncode == 0, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return False, str(exc)


def _find_scheme_guid(name_fragment: str) -> Optional[str]:
    ok, out = _run(["powercfg", "/list"])
    if not ok:
        return None
    for line in out.splitlines():
        if name_fragment.lower() in line.lower():
            for part in line.split():
                if len(part) == 36 and part.count("-") == 4:
                    return part
    return None


def _reg_set(hive, path: str, name: str, value, val_type=winreg.REG_DWORD) -> bool:
    try:
        key = winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, val_type, value)
        winreg.CloseKey(key)
        return True
    except Exception as exc:
        _log.debug("Registry write failed %s\\%s: %s", path, name, exc)
        return False


def _reg_delete(hive, path: str, name: str) -> bool:
    """Delete a registry value, ignoring 'not found' errors."""
    try:
        key = winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return True     # already gone — fine
    except Exception as exc:
        _log.debug("Registry delete failed %s\\%s: %s", path, name, exc)
        return False


# ── GPU / Graphics settings ────────────────────────────────────────────────────

# Windows 11 Graphics preference keys live under:
#   HKCU\Software\Microsoft\DirectX\UserGpuPreferences
# Each app's preference is stored as a string value whose name is the full
# exe path.  Setting "__NV_OPTIMUS" (special key used system-wide) to
# "GpuPreference=2;" enables "High performance" for all apps by default.
_HKCU_GPU_PREF = r"Software\Microsoft\DirectX\UserGpuPreferences"

# HAGS (Hardware-Accelerated GPU Scheduling) — Win10 2004+
_HKLM_HAGS_PATH = r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers"

# NVIDIA power mode via registry (applies when NVCP isn't running)
_HKLM_NV_BASE = r"SYSTEM\CurrentControlSet\Control\Video"


def _set_graphics_max_performance() -> list[str]:
    """
    Apply all GPU/graphics power settings for Maximum Performance.
    Returns a list of human-readable actions taken.
    """
    actions: list[str] = []

    # 1. HAGS on
    ok = _reg_set(winreg.HKEY_LOCAL_MACHINE, _HKLM_HAGS_PATH,
                  "HwSchMode", 2)
    if ok:
        actions.append("Hardware-Accelerated GPU Scheduling: Enabled")

    # 2. Windows 11 / 10 per-GPU power policy via DirectX key
    #    GpuPreference=2 → High Performance
    ok = _reg_set(
        winreg.HKEY_CURRENT_USER, _HKCU_GPU_PREF,
        "DefaultGpuPreference", "GpuPreference=2;",
        val_type=winreg.REG_SZ,
    )
    if ok:
        actions.append("GPU Graphics Preference: High Performance")

    # 3. Power plan GPU sub-group — prefer max performance on all schemes
    #    Subgroup: GPU Preference Policy (GUID for "Prefer Maximum Performance")
    #    This affects the active plan's GPU preference setting visible in
    #    advanced power plan settings → "Graphics settings" on Win11.
    gpu_subgroup = "5fb4938d-1ee8-4b0f-9a3c-5036b0ab995c"   # Graphics settings
    gpu_setting  = "dd848b2a-8a5d-4451-9ae2-39cd41658f6c"   # GPU preference policy
    # 2 = Prefer Maximum Performance
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "2"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "2"])
    actions.append("Power Plan GPU Preference: Prefer Maximum Performance")

    # 4. Adaptive power save feature (NVIDIA) via powercfg
    #    Subgroup: PCI Express / Link State Power Management (turn off)
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "0"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "0"])
    actions.append("PCI Express ASPM (Link State Power Mgmt): Off")

    # 5. Apply the changes to the current scheme
    _run(["powercfg", "/setactive", "SCHEME_CURRENT"])

    return actions


def _restore_graphics_defaults() -> list[str]:
    """
    Revert GPU/graphics settings back to Windows defaults.
    """
    actions: list[str] = []

    # HAGS back to default (auto = 0 means OS chooses)
    _reg_delete(winreg.HKEY_LOCAL_MACHINE, _HKLM_HAGS_PATH, "HwSchMode")
    actions.append("HAGS: Restored to Windows default")

    # Remove the per-user GPU preference override
    _reg_delete(winreg.HKEY_CURRENT_USER, _HKCU_GPU_PREF, "DefaultGpuPreference")
    actions.append("GPU Graphics Preference: Restored to Windows default")

    # GPU sub-group in power plan back to "balanced" (0 = adaptive)
    gpu_subgroup = "5fb4938d-1ee8-4b0f-9a3c-5036b0ab995c"
    gpu_setting  = "dd848b2a-8a5d-4451-9ae2-39cd41658f6c"
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "0"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "0"])
    actions.append("Power Plan GPU Preference: Balanced")

    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "1"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "1"])
    _run(["powercfg", "/setactive", "SCHEME_CURRENT"])

    return actions


# ── Power plan setup ───────────────────────────────────────────────────────────

# ── plan discovery / creation (names are OUR markers, so detection is locale-proof) ──────────
import re

_GUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
_PLAN_HIGH = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
NAME_ULT = "DWUT Ultimate Performance"
NAME_EXT = "DWUT Extreme Performance"


def _schemes() -> list[tuple[str, str]]:
    ok, out = _run(["powercfg", "/list"])
    res = []
    for line in out.splitlines():
        m = _GUID_RE.search(line)
        if m:
            nm = re.search(r"\((.*?)\)", line)
            res.append((m.group(0).lower(), (nm.group(1) if nm else "").strip()))
    return res


def _active() -> tuple[Optional[str], str]:
    ok, out = _run(["powercfg", "/getactivescheme"])
    m = _GUID_RE.search(out)
    nm = re.search(r"\((.*?)\)", out)
    return (m.group(0).lower() if m else None), (nm.group(1).strip() if nm else "")


def _dup(template: str) -> Optional[str]:
    ok, out = _run(["powercfg", "/duplicatescheme", template])
    m = _GUID_RE.search(out) if ok else None
    return m.group(0).lower() if m else None


def _setval(guid: str, sub: str, setting: str, value: str) -> None:
    for kind in ("/setacvalueindex", "/setdcvalueindex"):
        _run(["powercfg", kind, guid, sub, setting, value])


def _query_index(guid: str, sub: str, setting: str) -> Optional[int]:
    ok, out = _run(["powercfg", "/query", guid, sub, setting])
    m = re.search(r"Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)", out)
    return int(m.group(1), 16) if m else None


_TUNE_ULTIMATE = [("SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"), ("SUB_PROCESSOR", "PROCTHROTTLEMAX", "100"),
                  ("SUB_PROCESSOR", "PERFBOOSTMODE", "2"), ("SUB_PROCESSOR", "CPMINCORES", "100"),
                  ("SUB_SLEEP", "STANDBYIDLE", "0"), ("SUB_DISK", "DISKIDLE", "0")]
_TUNE_EXTREME = _TUNE_ULTIMATE + [("SUB_PROCESSOR", "SYSCOOLPOL", "1"), ("SUB_PROCESSOR", "PERFEPP", "0"),
                                  ("SUB_USB", "USBSELECTSUSPEND", "0"), ("SUB_PCIEXPRESS", "ASPM", "0")]


def _find_named(marker: str) -> Optional[str]:
    for g, n in _schemes():
        if marker.lower() in n.lower():
            return g
    return None


def _make_plan(marker: str, desc: str, templates: list[str], tune: list, force_tune: bool) -> tuple[Optional[str], str]:
    """Find or build a plan.  Returns (guid, how).  Always applies `tune` to plans WE built or copied."""
    g = _find_named(marker)
    if g:
        for sub, st, v in tune:                      # re-apply every time: self-heals edited plans
            _setval(g, sub, st, v)
        return g, "existing"
    how = ""
    for tpl in templates:
        g = _dup(tpl)
        if g:
            how = "windows-built-in" if tpl != "ACTIVE" else "copy-of-current"
            break
    if not g:
        act, _ = _active()
        g = _dup(act) if act else None
        how = "copy-of-current"
    if not g:
        return None, "failed"
    _run(["powercfg", "/changename", g, marker, desc])
    for sub, st, v in tune:
        _setval(g, sub, st, v)
    return g, how


def _activate_verified(guid: str) -> tuple[bool, str]:
    ok, out = _run(["powercfg", "/setactive", guid])
    act, name = _active()
    if act == guid.lower():
        return True, name
    return False, (out.strip() or "Windows refused to switch the power plan")


def _ensure_ultimate_scheme() -> Optional[str]:
    return _make_plan(NAME_ULT, "Windows Ultimate Performance, kept by DWUT",
                      [_PLAN_ULTIMATE_PERF, _PLAN_HIGH], _TUNE_ULTIMATE, False)[0]


def _ensure_extreme_scheme() -> Optional[str]:
    return _make_plan(NAME_EXT, "Ultimate Performance + CPU pinned at 100%, USB/PCIe power saving off (DWUT)",
                      [_PLAN_ULTIMATE_PERF, _PLAN_HIGH], _TUNE_EXTREME, True)[0]


def is_extreme_performance_active() -> bool:
    _, name = _active()
    return "extreme performance" in name.lower()


def is_ultimate_performance_active() -> bool:
    guid, name = _active()
    n = name.lower()
    if "extreme performance" in n:
        return False
    return "ultimate performance" in n or guid == _PLAN_ULTIMATE_PERF


def _enable(marker: str, desc: str, tune: list, label: str, check: tuple | None) -> tuple[bool, str]:
    guid, how = _make_plan(marker, desc, [_PLAN_ULTIMATE_PERF, _PLAN_HIGH], tune, False)
    if not guid:
        return False, f"Could not create the {label} power plan (powercfg refused). Run DWUT as Administrator."
    ok, info = _activate_verified(guid)
    if not ok:
        return False, f"{label}: activation failed - {info}"
    actions = _set_graphics_max_performance()
    notes = []
    if how == "copy-of-current":
        notes.append("this PC has no built-in Ultimate/High plan (Modern Standby) - used a tuned copy of your current plan")
    if check:
        v = _query_index(guid, check[0], check[1])
        notes.append(f"verified: {check[2]} = {v}" + ("" if v == check[3] else "  (expected %s)" % check[3]))
    detail = "  |  ".join(actions)
    _log.info("%s active (%s): %s", label, how, detail)
    return True, f"[OK] {label} active ({info}).  " + ("; ".join(notes) + "\n  " if notes else "\n  ") + detail


def enable_ultimate_performance() -> tuple[bool, str]:
    return _enable(NAME_ULT, "Windows Ultimate Performance, kept by DWUT", _TUNE_ULTIMATE, "Ultimate Performance",
                   ("SUB_PROCESSOR", "PROCTHROTTLEMIN", "CPU minimum state %", 100))


def enable_extreme_performance() -> tuple[bool, str]:
    return _enable(NAME_EXT, "Ultimate Performance + CPU pinned at 100%, USB/PCIe power saving off (DWUT)", _TUNE_EXTREME,
                   "Extreme Performance", ("SUB_USB", "USBSELECTSUSPEND", "USB selective suspend (0 = off)", 0))


def revert_to_balanced() -> tuple[bool, str]:
    """Switch back to Balanced AND restore GPU settings to defaults."""
    target = None
    for g, n in _schemes():
        if g == _PLAN_BALANCED or n.lower() in ("balanced", "equilibrado", "ausgeglichen", "équilibré"):
            target = g
            break
    if not target:
        target = _dup(_PLAN_BALANCED)               # recreate the built-in if it was deleted
        if target:
            _run(["powercfg", "/changename", target, "Balanced"])
    if not target:
        return False, "Balanced power plan not found on this PC."
    ok, info = _activate_verified(target)
    if not ok:
        return False, f"Could not switch back to Balanced - {info}"
    _restore_graphics_defaults()
    return True, f"[OK] Back on {info}. GPU settings restored to Windows defaults."

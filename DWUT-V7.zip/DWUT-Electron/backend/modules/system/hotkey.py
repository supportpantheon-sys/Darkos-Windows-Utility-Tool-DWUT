"""
modules/system/hotkey.py - Ctrl+Shift+Esc opens the DWUT Task Manager and Win+R opens the DWUT Run window
instead of the Windows ones.

Windows reserves Ctrl+Shift+Esc, so RegisterHotKey / Electron's globalShortcut usually lose it to the OS.
A low-level keyboard hook (WH_KEYBOARD_LL) runs BEFORE that handling: we recognise the combination, swallow it
so the Windows Task Manager never starts, and tell Electron to open ours. It works whenever DWUT is running,
including while the window is minimised or hidden in the tray.

Limits (Windows rules): the hook only sees keystrokes sent to windows of equal or lower integrity, so DWUT
must be running as Administrator to catch the shortcut while an elevated app is in the foreground. Ctrl+Alt+Del
is a secure attention sequence and can't be hooked by anything.
"""
from __future__ import annotations

import ctypes
import sys
import threading
import time
from ctypes import wintypes
from typing import Callable

from core.logger import get_logger

_log = get_logger("hotkey")

_WH_KEYBOARD_LL = 13
_WM_KEYDOWN, _WM_SYSKEYDOWN = 0x0100, 0x0104
_VK_ESCAPE, _VK_CONTROL, _VK_SHIFT, _VK_MENU = 0x1B, 0x11, 0x10, 0x12
_VK_R, _VK_LWIN, _VK_RWIN, _WM_KEYUP, _WM_SYSKEYUP = 0x52, 0x5B, 0x5C, 0x0101, 0x0105
_VK_MASK = 0xE8                    # unassigned key: tapped after swallowing Win+R so Windows does not open Start when Win is released
_LLKHF_INJECTED = 0x10

_state = {"started": False, "hook": None, "proc": None, "last": 0.0, "fire": None, "enabled": lambda: True,
          "run_fire": None, "run_enabled": lambda: True, "run_last": 0.0, "run_down": False}


class _KBD(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]


def start(on_trigger: Callable[[], None], enabled: Callable[[], bool] = lambda: True,
          on_run: Callable[[], None] | None = None, run_enabled: Callable[[], bool] = lambda: True) -> bool:
    """Install the hook on its own thread. Returns False when not on Windows or already running."""
    if sys.platform != "win32" or _state["started"]:
        return False
    _state["started"] = True
    _state["fire"] = on_trigger
    _state["enabled"] = enabled
    _state["run_fire"] = on_run
    _state["run_enabled"] = run_enabled
    threading.Thread(target=_run, daemon=True, name="taskmgr-hotkey").start()
    return True


def _run() -> None:
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    LRESULT = ctypes.c_ssize_t
    HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = wintypes.HHOOK
    user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = LRESULT
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
    user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE

    def _fire_run():
        try:                                                        # cancel the pending "Win alone" -> Start menu
            user32.keybd_event(_VK_MASK, 0, 0, 0)
            user32.keybd_event(_VK_MASK, 0, 2, 0)
        except Exception:
            pass
        try:
            _state["run_fire"]()
        except Exception:
            pass

    def proc(n_code, w_param, l_param):
        try:
            if n_code == 0 and _state["run_fire"] and _state["run_enabled"]():
                k = ctypes.cast(l_param, ctypes.POINTER(_KBD)).contents
                if k.vkCode == _VK_R and not (k.flags & _LLKHF_INJECTED):
                    if w_param in (_WM_KEYUP, _WM_SYSKEYUP):
                        if _state["run_down"]:
                            _state["run_down"] = False
                            return 1
                    elif w_param in (_WM_KEYDOWN, _WM_SYSKEYDOWN):
                        win = (user32.GetAsyncKeyState(_VK_LWIN) | user32.GetAsyncKeyState(_VK_RWIN)) & 0x8000
                        ctrl = user32.GetAsyncKeyState(_VK_CONTROL) & 0x8000
                        shift = user32.GetAsyncKeyState(_VK_SHIFT) & 0x8000
                        alt = user32.GetAsyncKeyState(_VK_MENU) & 0x8000
                        if win and not (ctrl or shift or alt):
                            _state["run_down"] = True
                            now = time.monotonic()
                            if now - _state["run_last"] > 0.4:
                                _state["run_last"] = now
                                threading.Thread(target=_fire_run, daemon=True).start()
                            return 1                                # swallow: the Windows Run box never opens
            if n_code == 0 and _state["enabled"]():
                k = ctypes.cast(l_param, ctypes.POINTER(_KBD)).contents
                if k.vkCode == _VK_ESCAPE and not (k.flags & _LLKHF_INJECTED):
                    ctrl = user32.GetAsyncKeyState(_VK_CONTROL) & 0x8000
                    shift = user32.GetAsyncKeyState(_VK_SHIFT) & 0x8000
                    alt = user32.GetAsyncKeyState(_VK_MENU) & 0x8000
                    if ctrl and shift and not alt:
                        if w_param in (_WM_KEYDOWN, _WM_SYSKEYDOWN):
                            now = time.monotonic()
                            if now - _state["last"] > 0.4:          # ignore key-repeat
                                _state["last"] = now
                                threading.Thread(target=_state["fire"], daemon=True).start()
                        return 1                                    # swallow: the Windows Task Manager never sees it
        except Exception:
            pass                                                    # never break the user's keyboard
        return user32.CallNextHookEx(None, n_code, w_param, l_param)

    _state["proc"] = HOOKPROC(proc)                                 # keep a reference or it gets garbage-collected
    _state["hook"] = user32.SetWindowsHookExW(_WH_KEYBOARD_LL, _state["proc"], kernel32.GetModuleHandleW(None), 0)
    if not _state["hook"]:
        _log.warning("Could not install the Ctrl+Shift+Esc hook (error %s)", ctypes.get_last_error())
        _state["started"] = False
        return
    _log.info("Ctrl+Shift+Esc now opens the DWUT Task Manager")
    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:    # a hook needs a message pump on its thread
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))

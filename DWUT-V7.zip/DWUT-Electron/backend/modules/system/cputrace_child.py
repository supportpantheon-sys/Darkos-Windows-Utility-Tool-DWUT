"""
modules/system/cputrace_child.py - helper process: which thread ran on which logical CPU, measured by the Windows kernel.

Runs the kernel context-switch trace (ETW "NT Kernel Logger") while its parent keeps stdin open and prints one JSON line a second:
    {"win": 1.0, "events": 41000, "cpus": {"0": [[tid, run_100ns, switches], ...], ...}}
run_100ns = how long that thread really ran on that CPU in the window (tid 0 = the idle thread).
If tracing is not allowed (not elevated / another tool owns the kernel logger) it prints {"err": "..."} and exits; the Task Manager
then falls back to an estimate.  It is a separate process so it can never disturb the app itself.
"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import threading
import time
from collections import defaultdict
from ctypes import POINTER, Structure, byref, c_longlong, c_ubyte, c_ulonglong, c_ushort, c_void_p, sizeof

c_ulong = ctypes.c_uint32          # Windows DWORD / ULONG is always 32-bit
c_long = ctypes.c_int32

LOGGER = "NT Kernel Logger"
ENABLE_CSWITCH = 0x00000010
REAL_TIME = 0x00000100
TRACED_GUID = 0x00020000
PM_REALTIME_RECORD = 0x00000100 | 0x10000000      # PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD
STOP, QUERY = 1, 0
THREAD_GUID_DATA1 = 0x3D6FA8D1
OP_CSWITCH = 36


class GUID(Structure):
    _fields_ = [("Data1", c_ulong), ("Data2", c_ushort), ("Data3", c_ushort), ("Data4", c_ubyte * 8)]


class WNODE_HEADER(Structure):
    _fields_ = [("BufferSize", c_ulong), ("ProviderId", c_ulong), ("HistoricalContext", c_ulonglong), ("TimeStamp", c_longlong),
                ("Guid", GUID), ("ClientContext", c_ulong), ("Flags", c_ulong)]


class EVENT_TRACE_PROPERTIES(Structure):
    _fields_ = [("Wnode", WNODE_HEADER), ("BufferSize", c_ulong), ("MinimumBuffers", c_ulong), ("MaximumBuffers", c_ulong),
                ("MaximumFileSize", c_ulong), ("LogFileMode", c_ulong), ("FlushTimer", c_ulong), ("EnableFlags", c_ulong),
                ("AgeLimit", c_long), ("NumberOfBuffers", c_ulong), ("FreeBuffers", c_ulong), ("EventsLost", c_ulong),
                ("BuffersWritten", c_ulong), ("LogBuffersLost", c_ulong), ("RealTimeBuffersLost", c_ulong),
                ("LoggerThreadId", c_void_p), ("LogFileNameOffset", c_ulong), ("LoggerNameOffset", c_ulong)]


class EVENT_DESCRIPTOR(Structure):
    _fields_ = [("Id", c_ushort), ("Version", c_ubyte), ("Channel", c_ubyte), ("Level", c_ubyte), ("Opcode", c_ubyte),
                ("Task", c_ushort), ("Keyword", c_ulonglong)]


class EVENT_HEADER(Structure):
    _fields_ = [("Size", c_ushort), ("HeaderType", c_ushort), ("Flags", c_ushort), ("EventProperty", c_ushort),
                ("ThreadId", c_ulong), ("ProcessId", c_ulong), ("TimeStamp", c_longlong), ("ProviderId", GUID),
                ("EventDescriptor", EVENT_DESCRIPTOR), ("ProcessorTime", c_ulonglong), ("ActivityId", GUID)]


class ETW_BUFFER_CONTEXT(Structure):
    _fields_ = [("ProcessorNumber", c_ubyte), ("Alignment", c_ubyte), ("LoggerId", c_ushort)]


class EVENT_RECORD(Structure):
    _fields_ = [("EventHeader", EVENT_HEADER), ("BufferContext", ETW_BUFFER_CONTEXT), ("ExtendedDataCount", c_ushort),
                ("UserDataLength", c_ushort), ("ExtendedData", c_void_p), ("UserData", c_void_p), ("UserContext", c_void_p)]


class EVENT_TRACE_HEADER(Structure):
    _fields_ = [("Size", c_ushort), ("FieldTypeFlags", c_ushort), ("Version", c_ulong), ("ThreadId", c_ulong), ("ProcessId", c_ulong),
                ("TimeStamp", c_longlong), ("Guid", GUID), ("ClientContext", c_ulong), ("Flags", c_ulong)]


class EVENT_TRACE(Structure):
    _fields_ = [("Header", EVENT_TRACE_HEADER), ("InstanceId", c_ulong), ("ParentInstanceId", c_ulong), ("ParentGuid", GUID),
                ("MofData", c_void_p), ("MofLength", c_ulong), ("ClientContext", c_ulong)]


class SYSTEMTIME(Structure):
    _fields_ = [("w", c_ushort * 8)]


class TIME_ZONE_INFORMATION(Structure):
    _fields_ = [("Bias", c_long), ("StandardName", c_ushort * 32), ("StandardDate", SYSTEMTIME), ("StandardBias", c_long),
                ("DaylightName", c_ushort * 32), ("DaylightDate", SYSTEMTIME), ("DaylightBias", c_long)]


class TRACE_LOGFILE_HEADER(Structure):
    _fields_ = [("BufferSize", c_ulong), ("Version", c_ulong), ("ProviderVersion", c_ulong), ("NumberOfProcessors", c_ulong),
                ("EndTime", c_longlong), ("TimerResolution", c_ulong), ("MaximumFileSize", c_ulong), ("LogFileMode", c_ulong),
                ("BuffersWritten", c_ulong), ("LogInstanceGuid", GUID), ("LoggerName", ctypes.c_wchar_p), ("LogFileName", ctypes.c_wchar_p),
                ("TimeZone", TIME_ZONE_INFORMATION), ("BootTime", c_longlong), ("PerfFreq", c_longlong), ("StartTime", c_longlong),
                ("ReservedFlags", c_ulong), ("BuffersLost", c_ulong)]


class EVENT_TRACE_LOGFILEW(Structure):
    _fields_ = [("LogFileName", ctypes.c_wchar_p), ("LoggerName", ctypes.c_wchar_p), ("CurrentTime", c_longlong), ("BuffersRead", c_ulong),
                ("ProcessTraceMode", c_ulong), ("CurrentEvent", EVENT_TRACE), ("LogfileHeader", TRACE_LOGFILE_HEADER),
                ("BufferCallback", c_void_p), ("BufferSize", c_ulong), ("Filled", c_ulong), ("EventsLost", c_ulong),
                ("EventRecordCallback", c_void_p), ("IsKernelTrace", c_ulong), ("Context", c_void_p)]


_FUNC = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)
EVENT_RECORD_CALLBACK = _FUNC(None, POINTER(EVENT_RECORD))


def _say(obj) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def _props(enable: int):
    n = os.cpu_count() or 4
    size = sizeof(EVENT_TRACE_PROPERTIES) + (len(LOGGER) + 1) * 2
    buf = ctypes.create_string_buffer(size)
    p = EVENT_TRACE_PROPERTIES.from_buffer(buf)
    p.Wnode.BufferSize = size
    p.Wnode.Flags = TRACED_GUID
    p.Wnode.ClientContext = 2                       # timestamps in 100 ns units
    g = p.Wnode.Guid                                # SystemTraceControlGuid {9E814AAD-3204-11D2-9A82-006008A86939}
    g.Data1, g.Data2, g.Data3 = 0x9E814AAD, 0x3204, 0x11D2
    for i, b in enumerate((0x9A, 0x82, 0x00, 0x60, 0x08, 0xA8, 0x69, 0x39)):
        g.Data4[i] = b
    p.BufferSize = 64
    p.MinimumBuffers = n * 2
    p.MaximumBuffers = n * 2 + 32
    p.LogFileMode = REAL_TIME
    p.EnableFlags = enable
    p.LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES)
    return buf


def _enable_privilege(name: str) -> None:
    try:
        from ctypes import wintypes as wt
        k32, adv = ctypes.WinDLL("kernel32"), ctypes.WinDLL("advapi32")

        class LUID(Structure):
            _fields_ = [("lo", wt.DWORD), ("hi", c_long)]

        class TP(Structure):
            _fields_ = [("n", wt.DWORD), ("luid", LUID), ("attr", wt.DWORD)]
        k32.GetCurrentProcess.restype = c_void_p
        tok = c_void_p()
        adv.OpenProcessToken(c_void_p(k32.GetCurrentProcess()), 0x28, byref(tok))
        luid = LUID()
        adv.LookupPrivilegeValueW(None, name, byref(luid))
        adv.AdjustTokenPrivileges(tok, False, byref(TP(1, luid, 2)), 0, None, None)
        k32.CloseHandle(tok)
    except Exception:
        pass


def main() -> int:
    if sys.platform != "win32":
        _say({"err": "Windows only"})
        return 1
    adv = ctypes.WinDLL("advapi32", use_last_error=True)
    adv.StartTraceW.argtypes = [POINTER(c_ulonglong), ctypes.c_wchar_p, c_void_p]
    adv.ControlTraceW.argtypes = [c_ulonglong, ctypes.c_wchar_p, c_void_p, c_ulong]
    adv.OpenTraceW.argtypes = [c_void_p]
    adv.OpenTraceW.restype = c_ulonglong
    adv.ProcessTrace.argtypes = [POINTER(c_ulonglong), c_ulong, c_void_p, c_void_p]
    adv.CloseTrace.argtypes = [c_ulonglong]
    _enable_privilege("SeSystemProfilePrivilege")

    handle = c_ulonglong(0)
    buf = _props(ENABLE_CSWITCH)
    err = adv.StartTraceW(byref(handle), LOGGER, buf)
    if err == 183:                                   # already exists: take it over only if it is a leftover of ours (cswitch only)
        qb = _props(0)
        if adv.ControlTraceW(0, LOGGER, qb, QUERY) == 0 and EVENT_TRACE_PROPERTIES.from_buffer(qb).EnableFlags == ENABLE_CSWITCH:
            adv.ControlTraceW(0, LOGGER, _props(0), STOP)
            time.sleep(0.3)
            buf = _props(ENABLE_CSWITCH)
            err = adv.StartTraceW(byref(handle), LOGGER, buf)
    if err != 0:
        _say({"err": {5: "access denied (run DWUT as administrator)", 183: "another tool is using the Windows kernel trace"}.get(err, f"StartTrace error {err}")})
        return 2

    lock = threading.Lock()
    run = defaultdict(lambda: defaultdict(int))      # cpu -> tid -> 100 ns on that cpu
    sw = defaultdict(lambda: defaultdict(int))       # cpu -> tid -> times scheduled in
    last: dict = {}                                  # cpu -> (tid, ts)
    stat = {"events": 0}

    def on_event(rec):
        try:
            r = rec.contents
            h = r.EventHeader
            if h.EventDescriptor.Opcode != OP_CSWITCH or h.ProviderId.Data1 != THREAD_GUID_DATA1 or r.UserDataLength < 8:
                return
            cpu = r.BufferContext.ProcessorNumber
            tid = c_ulong.from_address(r.UserData).value        # NewThreadId
            ts = h.TimeStamp
            with lock:
                prev = last.get(cpu)
                if prev and ts > prev[1]:
                    run[cpu][prev[0]] += ts - prev[1]
                last[cpu] = (tid, ts)
                sw[cpu][tid] += 1
                stat["events"] += 1
        except Exception:
            pass

    cb = EVENT_RECORD_CALLBACK(on_event)             # keep a reference while tracing
    lf = EVENT_TRACE_LOGFILEW()
    lf.LoggerName = LOGGER
    lf.ProcessTraceMode = PM_REALTIME_RECORD
    lf.EventRecordCallback = ctypes.cast(cb, c_void_p).value
    th = adv.OpenTraceW(byref(lf))
    if th in (0, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFF):
        adv.ControlTraceW(handle, None, _props(0), STOP)
        _say({"err": "OpenTrace failed"})
        return 3
    arr = (c_ulonglong * 1)(th)
    done, stop = threading.Event(), threading.Event()

    def pump():
        adv.ProcessTrace(arr, 1, None, None)         # blocks until the session is stopped
        done.set()
    threading.Thread(target=pump, daemon=True).start()

    def watch_parent():                              # parent closes our stdin (or dies) -> stop tracing
        try:
            sys.stdin.read()
        except Exception:
            pass
        stop.set()
    threading.Thread(target=watch_parent, daemon=True).start()

    t0 = time.time()
    try:
        while not stop.is_set() and not done.is_set():
            stop.wait(1.0)
            now = time.time()
            with lock:
                snap = {c: sorted(((t, v, sw[c].get(t, 0)) for t, v in d.items()), key=lambda x: -x[1])[:14] for c, d in run.items()}
                n = stat["events"]
                run.clear(); sw.clear(); stat["events"] = 0
            _say({"win": round(now - t0, 3), "events": n, "cpus": {str(c): [list(r) for r in rows] for c, rows in snap.items()}})
            t0 = now
    finally:
        adv.ControlTraceW(handle, None, _props(0), STOP)
        try:
            adv.CloseTrace(th)
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        try:
            _say({"err": f"{exc.__class__.__name__}: {exc}"})
        except Exception:
            pass
        sys.exit(9)

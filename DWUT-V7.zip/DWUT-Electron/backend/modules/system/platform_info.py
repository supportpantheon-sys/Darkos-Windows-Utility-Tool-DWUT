"""
modules/system/platform_info.py - reliable Windows 10 / 11 detection and system facts.

Windows 10 and 11 both report "10.0" through the classic APIs, and the registry ProductName still says
"Windows 10 ..." on Windows 11. The only dependable signal is the BUILD NUMBER (Windows 11 starts at
22000). We read it with RtlGetVersion (never shimmed or lied about, unlike GetVersionEx) and cross-check
the registry, then add edition / version / architecture / feature facts used to tailor the app.
"""

from __future__ import annotations

import os
import platform
import shutil
import sys
from functools import lru_cache

_WIN11_BUILD_CUTOFF = 22000

# Build -> marketing name for the feature updates DWUT users are likely to be on.
_BUILD_NAMES = {
    10240: "1507", 10586: "1511", 14393: "1607", 15063: "1703", 16299: "1709", 17134: "1803", 17763: "1809",
    18362: "1903", 18363: "1909", 19041: "2004", 19042: "20H2", 19043: "21H1", 19044: "21H2", 19045: "22H2",
    22000: "21H2", 22621: "22H2", 22631: "23H2", 26100: "24H2", 26200: "25H2",
}


def _rtl_build() -> tuple[int, int]:
    """(major, build) straight from ntdll.RtlGetVersion."""
    try:
        import ctypes

        class _OSVI(ctypes.Structure):
            _fields_ = [("size", ctypes.c_ulong), ("major", ctypes.c_ulong), ("minor", ctypes.c_ulong),
                        ("build", ctypes.c_ulong), ("platform", ctypes.c_ulong), ("csd", ctypes.c_wchar * 128)]
        v = _OSVI()
        v.size = ctypes.sizeof(v)
        if ctypes.windll.ntdll.RtlGetVersion(ctypes.byref(v)) == 0:
            return int(v.major), int(v.build)
    except Exception:
        pass
    return 0, 0


def _reg(name: str, default=""):
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", 0,
                           winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
        v = winreg.QueryValueEx(k, name)[0]
        winreg.CloseKey(k)
        return v
    except Exception:
        return default


@lru_cache(maxsize=1)
def get_build_number() -> int:
    """Current Windows build number, or 0 if not on Windows / unreadable."""
    if sys.platform != "win32":
        return 0
    major, build = _rtl_build()
    if build and major >= 10:
        return build
    try:
        return int(sys.getwindowsversion().build)
    except Exception:
        pass
    try:
        return int(_reg("CurrentBuildNumber", _reg("CurrentBuild", 0)) or 0)
    except Exception:
        return 0


@lru_cache(maxsize=1)
def is_windows_11() -> bool:
    return get_build_number() >= _WIN11_BUILD_CUTOFF


@lru_cache(maxsize=1)
def is_windows_10() -> bool:
    b = get_build_number()
    return 10000 <= b < _WIN11_BUILD_CUTOFF


@lru_cache(maxsize=1)
def windows_display_name() -> str:
    if is_windows_11():
        return "Windows 11"
    if is_windows_10():
        return "Windows 10"
    return "Windows (unknown version)" if sys.platform == "win32" else "Non-Windows"


def os_family() -> str:
    """'win11' | 'win10' | 'other' - the value the UI uses to show/hide OS-specific options."""
    return "win11" if is_windows_11() else "win10" if is_windows_10() else "other"


@lru_cache(maxsize=1)
def get_os_info() -> dict:
    """Everything the app needs to know about this Windows install (cached for the session)."""
    build = get_build_number()
    edition_id = str(_reg("EditionID", ""))
    install_type = str(_reg("InstallationType", "Client"))
    prod = str(_reg("ProductName", "")) or windows_display_name()
    if is_windows_11():
        prod = prod.replace("Windows 10", "Windows 11")        # the registry keeps the old "Windows 10" text
    display_ver = str(_reg("DisplayVersion", "")) or str(_reg("ReleaseId", "")) or _BUILD_NAMES.get(build, "")
    if not display_ver:                                         # unknown newer build: fall back to the closest known one
        known = [b for b in _BUILD_NAMES if b <= build]
        display_ver = _BUILD_NAMES[max(known)] if known else ""
    ubr = int(_reg("UBR", 0) or 0)
    arch_raw = (os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE") or platform.machine() or "").upper()
    arch = {"AMD64": "x64", "X86_64": "x64", "ARM64": "ARM64", "X86": "x86", "IA64": "IA64"}.get(arch_raw, arch_raw or "unknown")
    ed_low = edition_id.lower()
    is_server = install_type.lower() == "server" or "server" in prod.lower()
    is_ltsc = "enterprises" in ed_low or "iotenterprises" in ed_low or "ltsc" in prod.lower() or "ltsb" in prod.lower()
    is_home = ed_low in ("core", "coren", "coresinglelanguage", "corecountryspecific")
    family = os_family()
    marketing = " ".join(x for x in (windows_display_name() if family != "other" else prod, ) if x)
    return {
        "family": family,                              # win11 | win10 | other
        "is_win11": family == "win11", "is_win10": family == "win10",
        "name": windows_display_name(),
        "product_name": prod, "edition_id": edition_id, "edition": prod.replace("Windows 11 ", "").replace("Windows 10 ", "").strip(),
        "version": display_ver,                         # 22H2 / 23H2 / 24H2 ...
        "build": build, "ubr": ubr, "build_full": f"{build}.{ubr}" if ubr else str(build),
        "arch": arch, "is_arm": arch == "ARM64", "is_64bit": arch in ("x64", "ARM64"),
        "is_server": is_server, "is_ltsc": is_ltsc, "is_home": is_home,
        "label": f"{marketing} {display_ver}".strip() + f" (build {build}.{ubr})" if ubr else f"{marketing} {display_ver}".strip() + f" (build {build})",
        "win10_end_of_support": is_windows_10() and build < 99999,       # Windows 10 reached end of support on 14 Oct 2025
        "features": {
            "winget": bool(shutil.which("winget")),
            "windows_terminal": bool(shutil.which("wt")),
            "powershell7": bool(shutil.which("pwsh")),
            "hyperv_capable": not is_home and arch != "x86",
            "recall_capable": is_windows_11() and build >= 26100,
            "wsl": bool(shutil.which("wsl")),
        },
    }

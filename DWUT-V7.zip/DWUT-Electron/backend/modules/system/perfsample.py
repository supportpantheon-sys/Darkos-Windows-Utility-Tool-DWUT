"""
modules/system/perfsample.py - ONE sampler for CPU / GPU load, shared by the Task Manager and the Dashboard.

Why: Windows performance counters are rates - a value only means something over the interval between two reads of the SAME
query.  The old code read the same counters from several places on different timers (process list, performance tab, dashboard),
so each read covered a random, often tiny interval and the numbers jumped around / disagreed with each other.  Here a single
background thread reads once a second and everybody else just takes the latest value.

Definitions match Windows Task Manager:
  CPU total / per thread   "% Processor Utility" (frequency-aware, what Task Manager shows), capped at 100.
  CPU frequency            base frequency x "% Processor Performance"  (real current clock, not the nominal one).
  GPU (per process)        the BUSIEST engine of that process (Task Manager: "highest utilization across all engines"), not the sum.
  GPU (adapter)            the busiest engine of the adapter.
  GPU engine rows          the busiest engine of each type (3D / Copy / Video Decode ...), not a sum of all instances.
"""
from __future__ import annotations

import re
import sys
import threading
import time
from typing import Optional

from core.logger import get_logger

_log = get_logger("perfsample")

_GPU_RE = re.compile(r"pid_(\d+)_luid_(0x[0-9a-fA-F]+_0x[0-9a-fA-F]+)_phys_(\d+)_eng_(\d+)_engtype_(.+)$")


def _engine_class(raw: str) -> str:
    r = raw.lower()
    if "3d" in r:
        return "3D"
    if "copy" in r:
        return "Copy"
    if "decode" in r:
        return "Video Decode"
    if "encode" in r or "processing" in r:
        return "Video Processing"
    if "compute" in r or "vr" in r:
        return "Compute"
    return "3D"


def parse_gpu(items: dict) -> dict:
    """items: {counter instance name: utilization %}  ->  per-process / per-adapter / per-engine-type figures (pure function)."""
    eng_total: dict = {}            # (luid, phys, eng) -> summed % over processes
    eng_type: dict = {}             # (luid, phys, eng) -> engine class
    per_pid_eng: dict = {}          # pid -> {(luid,phys,eng): %}
    for inst, val in items.items():
        m = _GPU_RE.match(inst)
        if not m or val is None or val <= 0:
            continue
        pid, luid, phys, eng, typ = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        key = (luid, phys, eng)
        eng_total[key] = eng_total.get(key, 0.0) + float(val)
        eng_type[key] = _engine_class(typ)
        d = per_pid_eng.setdefault(pid, {})
        d[key] = d.get(key, 0.0) + float(val)
    adapters: dict = {}
    for key, v in eng_total.items():
        a = adapters.setdefault(key[0], {"total": 0.0, "engines": {}})
        v = min(100.0, v)
        a["total"] = max(a["total"], v)
        t = eng_type[key]
        a["engines"][t] = max(a["engines"].get(t, 0.0), v)
    per_pid = {pid: round(min(100.0, max(d.values())), 1) for pid, d in per_pid_eng.items()}
    return {"adapters": adapters, "per_pid": per_pid}


class _Pdh:
    """Minimal ctypes PDH wrapper (no pywin32 needed)."""

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ct, self.wt = ctypes, wintypes
        self.pdh = ctypes.windll.pdh
        self.pdh.PdhOpenQueryW.argtypes = [ctypes.c_wchar_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_void_p)]
        self.pdh.PdhAddEnglishCounterW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_void_p)]
        self.pdh.PdhCollectQueryData.argtypes = [ctypes.c_void_p]
        self.pdh.PdhCloseQuery.argtypes = [ctypes.c_void_p]
        self.pdh.PdhGetFormattedCounterArrayW.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                                                          ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
        self.pdh.PdhGetFormattedCounterValue.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]

        class _FMT(ctypes.Structure):
            _fields_ = [("CStatus", wintypes.DWORD), ("v", ctypes.c_double)]

        class _ITEM(ctypes.Structure):
            _fields_ = [("name", ctypes.c_wchar_p), ("val", _FMT)]
        self.FMT, self.ITEM = _FMT, _ITEM

    def open(self, paths: list):
        ct = self.ct
        q = ct.c_void_p()
        if self.pdh.PdhOpenQueryW(None, 0, ct.byref(q)) != 0:
            return None, []
        cs = []
        for p in paths:
            c = ct.c_void_p()
            cs.append(c if self.pdh.PdhAddEnglishCounterW(q, p, 0, ct.byref(c)) == 0 else None)
        self.pdh.PdhCollectQueryData(q)
        return q, cs

    def close(self, q) -> None:
        try:
            self.pdh.PdhCloseQuery(q)
        except Exception:
            pass

    def collect(self, q) -> bool:
        return self.pdh.PdhCollectQueryData(q) == 0

    def array(self, c) -> dict:
        ct, wt = self.ct, self.wt
        FMT = 0x200 | 0x8000                                  # DOUBLE | NOCAP100
        size, count = wt.DWORD(0), wt.DWORD(0)
        r = self.pdh.PdhGetFormattedCounterArrayW(c, FMT, ct.byref(size), ct.byref(count), None)
        if (r & 0xFFFFFFFF) != 0x800007D2 or not size.value:  # PDH_MORE_DATA
            return {}
        buf = ct.create_string_buffer(size.value)
        if self.pdh.PdhGetFormattedCounterArrayW(c, FMT, ct.byref(size), ct.byref(count), buf) != 0:
            return {}
        items = ct.cast(buf, ct.POINTER(self.ITEM))
        out = {}
        for i in range(count.value):
            it = items[i]
            if it.val.CStatus in (0, 1) and it.name:
                out[it.name] = float(it.val.v)
        return out

    def single(self, c) -> Optional[float]:
        ct, wt = self.ct, self.wt
        v = self.FMT()
        if self.pdh.PdhGetFormattedCounterValue(c, 0x200 | 0x8000, ct.byref(wt.DWORD()), ct.byref(v)) != 0 or v.CStatus not in (0, 1):
            return None
        return float(v.v)


class PerfSampler:
    def __init__(self):
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._cpu: dict = {}
        self._gpu: dict = {}
        self._primary = ""
        self._vram_total = 0.0
        self._name = ""

    def start(self) -> None:
        if sys.platform != "win32" or (self._thread and self._thread.is_alive()):
            return
        self._thread = threading.Thread(target=self._run, daemon=True, name="perfsample")
        self._thread.start()

    def cpu(self) -> dict:
        self.start()
        with self._lock:
            return dict(self._cpu)

    def gpu(self) -> dict:
        self.start()
        with self._lock:
            return dict(self._gpu)

    # ── sampling thread ──────────────────────────────────────────────────────
    def _run(self) -> None:
        try:
            pdh = _Pdh()
        except Exception as exc:
            _log.warning("PDH unavailable: %s", exc)
            return
        cq, cc = pdh.open([r"\Processor Information(*)\% Processor Utility",
                           r"\Processor Information(_Total)\% Processor Performance",
                           r"\Processor Information(_Total)\Processor Frequency",
                           r"\Process V2(*)\% Processor Utility"])
        gq = gc = None
        gopened = 0.0
        while True:
            t0 = time.time()
            try:
                self._sample_cpu(pdh, cq, cc)
            except Exception as exc:
                _log.debug("cpu sample: %s", exc)
            try:
                if gq is None or t0 - gopened > 90:           # re-open now and then so new / exited GPU instances stay in step
                    if gq is not None:
                        pdh.close(gq)
                    gq, gc = pdh.open([r"\GPU Engine(*)\Utilization Percentage", r"\GPU Adapter Memory(*)\Dedicated Usage"])
                    gopened = t0
                else:
                    self._sample_gpu(pdh, gq, gc)
            except Exception as exc:
                _log.debug("gpu sample: %s", exc)
            time.sleep(max(0.2, 1.0 - (time.time() - t0)))

    def _sample_cpu(self, pdh, q, cs) -> None:
        if not q or not pdh.collect(q) or not cs[0]:
            return
        items = pdh.array(cs[0])
        per, total = {}, None
        for nm, v in items.items():
            if nm == "_Total":
                total = v
            elif re.fullmatch(r"\d+,\d+", nm):
                g, i = nm.split(",")
                per[(int(g), int(i))] = v
        if not per:
            return
        perf = pdh.single(cs[1]) if cs[1] else None
        base = pdh.single(cs[2]) if cs[2] else None
        freq = round(base * perf / 100.0) if base and perf else None
        procs, div = {}, 1.0
        try:
            if len(cs) > 3 and cs[3]:                       # per-process utility (Windows 10 21H2+ / 11); older systems fall back to CPU-time deltas
                S = 0.0
                for nm, v in pdh.array(cs[3]).items():
                    base, _, pid = nm.rpartition(":")
                    if not pid.isdigit() or not base:
                        continue
                    pid = int(pid)
                    if pid == 0 or base.lower() in ("idle", "system idle process", "_total"):
                        continue
                    procs[pid] = procs.get(pid, 0.0) + max(0.0, v)
                    S += max(0.0, v)
                n = max(1, len(per))
                tot = total if total is not None else sum(per.values()) / n
                # the counter is on a "per logical CPU" scale on some builds and "whole machine" on others: pick the scale whose
                # sum over all processes matches the machine total
                if tot > 1.0 and S > 0:
                    div = float(n) if S / tot > n ** 0.5 else 1.0
        except Exception:
            procs = {}
        d = {"procs": {pid: round(min(100.0, v / div), 1) for pid, v in procs.items()},
             "per": [round(max(0.0, min(100.0, per[k])), 1) for k in sorted(per)],
             "total": round(max(0.0, min(100.0, total)), 1) if total is not None else None,
             "freq_mhz": freq, "base_mhz": round(base) if base else None, "ts": time.time()}
        with self._lock:
            self._cpu = d

    def _sample_gpu(self, pdh, q, cs) -> None:
        if not q or not pdh.collect(q) or not cs[0]:
            return
        parsed = parse_gpu(pdh.array(cs[0]))
        ads = parsed["adapters"]
        mem = pdh.array(cs[1]) if cs[1] else {}
        vram = {}
        for nm, v in mem.items():                              # e.g. luid_0x00000000_0x0000F3B2_phys_0
            m = re.match(r"luid_(0x[0-9a-fA-F]+_0x[0-9a-fA-F]+)_phys", nm)
            if m:
                vram[m.group(1)] = vram.get(m.group(1), 0.0) + v / 1048576.0
        for luid in vram:
            ads.setdefault(luid, {"total": 0.0, "engines": {}})
        if not ads:
            with self._lock:
                self._gpu = {"total": 0.0, "engines": {}, "per_pid": {}, "vram_mb": 0.0, "adapters": 0, "ts": time.time()}
            return
        cur = ads.get(self._primary)
        best = max(ads, key=lambda k: (ads[k]["total"], vram.get(k, 0.0)))
        if not cur or ads[best]["total"] > ads[self._primary]["total"] + 3.0:   # switch only on a clear difference (no flapping)
            self._primary = best
        a = ads[self._primary]
        eng = {k: round(v, 1) for k, v in a["engines"].items()}
        with self._lock:
            self._gpu = {"total": round(a["total"], 1), "engines": eng, "per_pid": parsed["per_pid"],
                         "vram_mb": round(vram.get(self._primary, 0.0), 1), "adapters": len(ads), "ts": time.time()}


perf = PerfSampler()


def vram_total_mb() -> float:
    """Dedicated video memory of the primary adapter (registry qwMemorySize - works for NVIDIA / AMD / Intel)."""
    if perf._vram_total:
        return perf._vram_total
    try:
        import winreg
        best = 0.0
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base)
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(k, i)
            except OSError:
                break
            i += 1
            try:
                sk = winreg.OpenKey(k, sub)
                val, typ = winreg.QueryValueEx(sk, "HardwareInformation.qwMemorySize")
                if isinstance(val, bytes):
                    val = int.from_bytes(val[:8], "little")
                mb = float(val) / 1048576.0
                if mb > best:
                    best = mb
                    try:
                        perf._name = str(winreg.QueryValueEx(sk, "DriverDesc")[0])
                    except OSError:
                        pass
            except OSError:
                continue
        perf._vram_total = best
    except Exception:
        pass
    return perf._vram_total


def gpu_name() -> str:
    vram_total_mb()
    return perf._name

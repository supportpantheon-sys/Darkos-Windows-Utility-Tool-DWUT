r"""
modules/system/disk_cleanup.py

Real disk cleanup — measures actual bytes before deleting.

Categories:
  temp_user      — %TEMP% and %LOCALAPPDATA%\Temp
  temp_system    — C:\Windows\Temp
  prefetch       — C:\Windows\Prefetch
  inet_cache     — IE/Edge internet cache
  thumbnail_cache— Explorer thumbnail DB
  update_cache   — Windows Update SoftwareDistribution\Download
  recycle_bin    — per-drive recycle bins
  event_logs     — clear Windows Event Logs (optional/aggressive)
  crash_dumps    — minidump files

Each category returns real byte counts — no fake numbers anywhere.
"""

from __future__ import annotations

import ctypes
import os
import shutil
import stat
import subprocess
import threading
import time
import winreg
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.events import Events, bus
from core.logger import get_logger

_log = get_logger(__name__)


@dataclass
class CleanCategory:
    key: str
    name: str
    description: str
    paths: list[str]     # can contain env vars
    aggressive: bool = False  # needs extra confirmation
    estimated_mb: Optional[float] = None  # filled in after scan
    actual_bytes: int = 0


@dataclass
class DiskScanResult:
    categories: list[CleanCategory]
    total_bytes: int
    scan_duration_s: float

    @property
    def total_mb(self) -> float:
        return self.total_bytes / (1024 * 1024)

    @property
    def total_gb(self) -> float:
        return self.total_bytes / (1024 ** 3)


@dataclass
class DiskCleanResult:
    category_results: dict[str, int]   # key → bytes_freed
    total_bytes_freed: int
    files_deleted: int
    errors: list[str]
    duration_s: float

    @property
    def total_mb_freed(self) -> float:
        return self.total_bytes_freed / (1024 * 1024)


# ──────────────────────────────────────────────────────────────────────────────
# Category definitions
# ──────────────────────────────────────────────────────────────────────────────

def _make_categories() -> list[CleanCategory]:
    return [
        CleanCategory(
            key="temp_user",
            name="User Temp Files",
            description="Temporary files in %TEMP% and %LOCALAPPDATA%\\Temp",
            paths=[
                os.path.expandvars(r"%TEMP%"),
                os.path.expandvars(r"%LOCALAPPDATA%\Temp"),
            ],
        ),
        CleanCategory(
            key="temp_system",
            name="Windows Temp Files",
            description="Temporary files in C:/Windows/Temp",
            paths=[os.path.expandvars(r"%SystemRoot%\Temp")],
        ),
        CleanCategory(
            key="prefetch",
            name="Prefetch Cache",
            description="Application prefetch data (safe to delete; Windows rebuilds it)",
            paths=[os.path.expandvars(r"%SystemRoot%\Prefetch")],
        ),
        CleanCategory(
            key="inet_cache",
            name="Browser / Internet Cache",
            description="Internet Explorer and Edge legacy cache",
            paths=[
                os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Windows\INetCache"),
                os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Windows\INetCookies"),
            ],
        ),
        CleanCategory(
            key="thumbnail_cache",
            name="Thumbnail Cache",
            description="Explorer thumbnail database files (rebuilt automatically)",
            paths=[
                os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Windows\Explorer"),
            ],
        ),
        CleanCategory(
            key="crash_dumps",
            name="Crash Dumps / Minidumps",
            description="Windows crash report files in Minidump",
            paths=[
                os.path.expandvars(r"%SystemRoot%\Minidump"),
                os.path.expandvars(r"%LOCALAPPDATA%\CrashDumps"),
            ],
        ),
        CleanCategory(
            key="update_cache",
            name="Windows Update Cache",
            description="Downloaded Windows Update packages (safe after updates are installed)",
            paths=[os.path.expandvars(r"%SystemRoot%\SoftwareDistribution\Download")],
            aggressive=False,
        ),
        CleanCategory(
            key="event_logs",
            name="Windows Event Logs",
            description="Clears all Windows event log files (aggressive — loses log history)",
            paths=[],  # handled separately via wevtutil
            aggressive=True,
        ),
    ]


# ──────────────────────────────────────────────────────────────────────────────
# Low-level helpers
# ──────────────────────────────────────────────────────────────────────────────

_FILE_ATTRIBUTE_REPARSE_POINT = 0x400
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _lp(path: str) -> str:
    """Long-path (\\\\?\\) form so deep temp trees over 260 chars can be deleted."""
    if os.name != "nt":
        return path
    path = os.path.abspath(path)
    if path.startswith("\\\\?\\"):
        return path
    if path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + path[2:]
    return "\\\\?\\" + path


def _is_reparse(st: os.stat_result) -> bool:
    return bool(getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT)


def _unique_paths(paths: list[str]) -> list[str]:
    """Drop duplicates (e.g. %TEMP% and %LOCALAPPDATA%\\Temp are usually identical)."""
    seen: set[str] = set()
    out: list[str] = []
    for p in paths:
        if not p:
            continue
        try:
            key = os.path.normcase(os.path.realpath(p))
        except Exception:
            key = os.path.normcase(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def _dir_size(path: str) -> int:
    """Return total bytes of all real files under `path` (junctions not followed). Never throws."""
    total = 0
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(_lp(cur)) as it:
                for e in it:
                    try:
                        st = e.stat(follow_symlinks=False)
                        if e.is_dir(follow_symlinks=False):
                            if not _is_reparse(st):
                                stack.append(e.path)
                        else:
                            total += st.st_size
                    except OSError:
                        pass
        except OSError:
            pass
    return total


def _event_log_size() -> int:
    """Return total size of .evtx log files."""
    log_dir = Path(os.path.expandvars(r"%SystemRoot%\System32\winevt\Logs"))
    total = 0
    try:
        if log_dir.exists():
            for f in log_dir.glob("*.evtx"):
                try:
                    total += f.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return total


def _force_remove_file(path: str) -> bool:
    """Delete one file, clearing the read-only attribute first if needed."""
    lp = _lp(path)
    try:
        os.unlink(lp)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        pass
    try:
        os.chmod(lp, stat.S_IWRITE | stat.S_IREAD)
        os.unlink(lp)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False


def _take_ownership(path: str) -> None:
    """Admin-only last resort for ACL-locked items (takeown + icacls)."""
    try:
        subprocess.run(["takeown", "/f", path, "/r", "/d", "y"],
                       capture_output=True, timeout=45, creationflags=_NO_WINDOW)
        subprocess.run(["icacls", path, "/grant", "*S-1-5-32-544:(OI)(CI)F", "/t", "/c", "/q"],
                       capture_output=True, timeout=45, creationflags=_NO_WINDOW)
    except Exception:
        pass


def _purge_tree(path: str, remove_root: bool) -> tuple[int, int, int]:
    """
    Recursively delete `path`.  Returns (bytes_freed, items_deleted, items_skipped).

    * Bytes are counted ONLY for files that were really deleted.
    * Junctions / symlinks are unlinked, never followed.
    * Read-only files are made writable first.
    * Files that are in use are skipped and counted, not silently ignored.
    """
    freed = deleted = skipped = 0
    try:
        with os.scandir(_lp(path)) as it:
            entries = list(it)
    except OSError:
        return 0, 0, 1

    for e in entries:
        try:
            st = e.stat(follow_symlinks=False)
        except OSError:
            skipped += 1
            continue

        if e.is_dir(follow_symlinks=False) and not _is_reparse(st):
            f, d, s = _purge_tree(e.path, remove_root=True)
            freed += f; deleted += d; skipped += s
            continue

        if e.is_dir(follow_symlinks=False):          # junction / dir symlink
            try:
                os.rmdir(_lp(e.path))
                deleted += 1
            except OSError:
                skipped += 1
            continue

        size = st.st_size
        if _force_remove_file(e.path):
            freed += size
            deleted += 1
        else:
            skipped += 1

    if remove_root:
        try:
            os.rmdir(_lp(path))
            deleted += 1
        except OSError:
            pass
    return freed, deleted, skipped


# ──────────────────────────────────────────────────────────────────────────────
# Scan
# ──────────────────────────────────────────────────────────────────────────────

def _category_size(cat: CleanCategory) -> int:
    if cat.key == "event_logs":
        return _event_log_size()
    if cat.key == "thumbnail_cache":
        return sum(f.stat().st_size for p in _unique_paths(cat.paths) for f in _thumb_files(p) if f.exists())
    return sum(_dir_size(p) for p in _unique_paths(cat.paths))


def _thumb_files(folder: str) -> list[Path]:
    out: list[Path] = []
    try:
        d = Path(folder)
        if d.exists():
            for pat in ("thumbcache_*.db", "iconcache_*.db", "*.etl"):
                out.extend(d.glob(pat))
    except OSError:
        pass
    return out


def scan_disk_categories() -> DiskScanResult:
    """
    Measure size of each cleanup category without deleting anything.
    Publishes progress. Returns DiskScanResult with real byte counts.
    """
    t0 = time.monotonic()
    categories = _make_categories()
    total = 0

    for cat in categories:
        bus.publish(Events.CLEANUP_PROGRESS, f"Measuring: {cat.name}…")
        try:
            size = _category_size(cat)
        except Exception as exc:                       # never let one category kill the scan
            _log.debug("scan %s failed: %s", cat.key, exc)
            size = 0

        cat.actual_bytes = size
        cat.estimated_mb = size / (1024 * 1024)
        total += size

        bus.publish(Events.CLEANUP_PROGRESS, f"  {cat.name}: {cat.estimated_mb:.1f} MB")

    duration = time.monotonic() - t0
    _log.info("Disk scan complete: %.1f MB total in %.1fs", total / (1024 * 1024), duration)

    return DiskScanResult(categories=categories, total_bytes=total, scan_duration_s=duration)


# ──────────────────────────────────────────────────────────────────────────────
# Clean
# ──────────────────────────────────────────────────────────────────────────────

def _delete_dir_contents(path: str) -> tuple[int, int, list[str]]:
    """
    Delete all contents of a directory (not the directory itself).
    Returns (bytes_freed, items_deleted, errors).  Bytes are real, not estimated.
    """
    if not os.path.isdir(path):
        return 0, 0, []

    freed, deleted, skipped = _purge_tree(path, remove_root=False)

    # Anything left?  Try once more after taking ownership (needs admin; harmless otherwise).
    if skipped:
        try:
            leftovers = [os.path.join(path, n) for n in os.listdir(path)]
        except OSError:
            leftovers = []
        if leftovers and _is_admin():
            for item in leftovers[:200]:
                if os.path.isdir(item):
                    _take_ownership(item)
                    f, d, s = _purge_tree(item, remove_root=True)
                else:
                    _take_ownership(item)
                    ok = _force_remove_file(item)
                    f, d, s = (0, 1, 0) if ok else (0, 0, 1)
                freed += f; deleted += d
                skipped = max(0, skipped - d)

    errors: list[str] = []
    if skipped:
        errors.append(f"{path}: {skipped} item(s) in use or protected — skipped")
    return freed, deleted, errors


def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _clear_thumbnail_cache(paths: list[str]) -> tuple[int, int, list[str]]:
    freed = deleted = 0
    locked = 0
    for folder in _unique_paths(paths):
        for f in _thumb_files(folder):
            try:
                size = f.stat().st_size
            except OSError:
                continue
            if _force_remove_file(str(f)):
                freed += size
                deleted += 1
            else:
                locked += 1
    errs = [f"thumbnail cache: {locked} file(s) locked by Explorer — skipped"] if locked else []
    return freed, deleted, errs


def _list_event_logs() -> list[str]:
    names: list[str] = []
    try:
        r = subprocess.run(["wevtutil", "el"], capture_output=True, text=True,
                           timeout=60, creationflags=_NO_WINDOW, errors="replace")
        names = [l.strip() for l in r.stdout.splitlines() if l.strip()]
    except Exception as exc:
        _log.debug("wevtutil el failed: %s", exc)
    if not names:
        try:
            ps = ("[System.Diagnostics.Eventing.Reader.EventLogSession]::GlobalSession.GetLogNames()"
                  " | ForEach-Object { $_ }")
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                               capture_output=True, text=True, timeout=60,
                               creationflags=_NO_WINDOW, errors="replace")
            names = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        except Exception as exc:
            _log.debug("PowerShell log enumeration failed: %s", exc)
    return names


def _clear_event_logs() -> tuple[int, int, list[str]]:
    """
    Clear EVERY Windows event log channel (the old version stopped after the first
    50 of ~1000+ channels, which is why nothing visibly shrank).  Runs in parallel.
    """
    errors: list[str] = []
    if not _is_admin():
        errors.append("Event logs: administrator rights are required to clear them")

    before = _event_log_size()
    names = _list_event_logs()
    if not names:
        errors.append("Event logs: could not enumerate log channels")
        return 0, 0, errors

    cleared = 0
    lock = threading.Lock()

    def _clear(name: str) -> None:
        nonlocal cleared
        try:
            r = subprocess.run(["wevtutil", "cl", name], capture_output=True,
                               timeout=45, creationflags=_NO_WINDOW)
            if r.returncode == 0:
                with lock:
                    cleared += 1
        except Exception:
            pass

    # Big/important logs first so they are cleared even if the user cancels early
    priority = [n for n in names if n in ("Application", "System", "Security", "Setup")]
    rest = [n for n in names if n not in priority]
    for n in priority:
        _clear(n)
    with ThreadPoolExecutor(max_workers=16) as pool:
        list(pool.map(_clear, rest))

    after = _event_log_size()
    freed = max(0, before - after)
    bus.publish(Events.CLEANUP_PROGRESS, f"  Cleared {cleared} of {len(names)} event log channels")
    return freed, cleared, errors


def _service_action(action: str, *svcs: str) -> None:
    for svc in svcs:
        try:
            subprocess.run(["net", action, svc, "/y"] if action == "stop" else ["net", action, svc],
                           capture_output=True, timeout=60, creationflags=_NO_WINDOW)
        except Exception:
            pass


def _stop_wu_services() -> None:
    _service_action("stop", "wuauserv", "bits", "dosvc")


def _start_wu_services() -> None:
    _service_action("start", "wuauserv", "bits")


def clean_categories(
    category_keys: list[str],
) -> DiskCleanResult:
    """
    Clean the selected categories.
    Returns real byte counts — nothing is faked.
    Publishes Events.CLEANUP_PROGRESS throughout.
    """
    t0 = time.monotonic()
    categories = {cat.key: cat for cat in _make_categories()}

    category_results: dict[str, int] = {}
    total_bytes = 0
    total_files = 0
    all_errors: list[str] = []

    needs_wu_stop = "update_cache" in category_keys
    if needs_wu_stop:
        bus.publish(Events.CLEANUP_PROGRESS, "Stopping Windows Update services…")
        _stop_wu_services()

    try:
        for key in category_keys:
            cat = categories.get(key)
            if not cat:
                continue

            bus.publish(Events.CLEANUP_PROGRESS, f"Cleaning: {cat.name}…")
            cat_bytes = 0
            cat_files = 0
            cat_errors: list[str] = []

            try:
                if key == "event_logs":
                    cat_bytes, cat_files, cat_errors = _clear_event_logs()
                elif key == "thumbnail_cache":
                    cat_bytes, cat_files, cat_errors = _clear_thumbnail_cache(cat.paths)
                else:
                    for path in _unique_paths(cat.paths):
                        freed, files, errors = _delete_dir_contents(path)
                        cat_bytes += freed
                        cat_files += files
                        cat_errors.extend(errors)
            except Exception as exc:
                cat_errors.append(f"{cat.name}: {exc}")

            all_errors.extend(cat_errors)
            category_results[key] = cat_bytes
            total_bytes += cat_bytes
            total_files += cat_files

            note = f", {len(cat_errors)} note(s)" if cat_errors else ""
            bus.publish(Events.CLEANUP_PROGRESS,
                        f"  [OK] {cat.name}: {cat_bytes / (1024*1024):.1f} MB freed "
                        f"({cat_files} items{note})")
            for e in cat_errors[:3]:
                bus.publish(Events.CLEANUP_PROGRESS, f"      {e}")
    finally:
        if needs_wu_stop:
            bus.publish(Events.CLEANUP_PROGRESS, "Restarting Windows Update services…")
            _start_wu_services()

    duration = time.monotonic() - t0
    _log.info("Disk cleanup: %.1f MB freed, %d files in %.1fs",
              total_bytes / (1024 * 1024), total_files, duration)

    result = DiskCleanResult(
        category_results=category_results,
        total_bytes_freed=total_bytes,
        files_deleted=total_files,
        errors=all_errors,
        duration_s=duration,
    )
    bus.publish(Events.CLEANUP_DONE, result)
    return result


# ──────────────────────────────────────────────────────────────────────────────
# Free space info
# ──────────────────────────────────────────────────────────────────────────────

def get_drive_info(drive: str = "C:\\") -> dict:
    """Return total/free/used GB for a drive."""
    try:
        total, used, free = shutil.disk_usage(drive)
        return {
            "drive": drive,
            "total_gb": total / (1024 ** 3),
            "used_gb": used / (1024 ** 3),
            "free_gb": free / (1024 ** 3),
            "used_pct": used / total * 100 if total else 0,
        }
    except Exception:
        return {"drive": drive, "total_gb": 0, "used_gb": 0, "free_gb": 0, "used_pct": 0}

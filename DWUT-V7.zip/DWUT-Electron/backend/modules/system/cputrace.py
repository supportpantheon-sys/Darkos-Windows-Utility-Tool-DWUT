"""
modules/system/cputrace.py - "what is actually running on logical CPU Tn" for the Task Manager's Performance tab.

  trace     the Windows kernel context-switch trace (cputrace_child.py): exactly which threads ran on that CPU in the last
            second, for how long, and how often they were scheduled there.
  estimate  only when the trace is not allowed (not elevated / another tool owns the kernel trace): threads that used CPU in
            the last moments AND whose scheduler "ideal processor" is that CPU.  Labelled as an estimate in the UI.

The helper only runs while the drill-down is being looked at (it stops ~10 s after the last request).
"""
from __future__ import annotations

import ctypes
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

from core.logger import get_logger
from core.mask import clean

_log = get_logger("cputrace")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_CHILD = Path(__file__).with_name("cputrace_child.py")
_IDLE_AFTER = 10.0


def _pyexe() -> str:
    exe = Path(sys.executable)
    w = exe.with_name("python.exe")                    # not pythonw: stdout pipes must work
    return str(w if w.exists() else exe)


class CpuTrace:
    def __init__(self):
        self._lock = threading.Lock()
        self._proc: Optional[subprocess.Popen] = None
        self._latest: dict = {}
        self._err = ""
        self._blocked_until = 0.0
        self._last_req = 0.0
        self._tid_owner: dict = {}
        self._tid_refreshed = 0.0
        self._prev_threads: dict = {}
        self._watch: Optional[threading.Thread] = None

    def _start(self) -> None:
        if (self._proc and self._proc.poll() is None) or sys.platform != "win32" or time.time() < self._blocked_until:
            return
        try:
            self._proc = subprocess.Popen([_pyexe(), "-I", str(_CHILD)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=subprocess.DEVNULL, creationflags=_NO_WIN, text=True, bufsize=1)
        except Exception as exc:
            self._err = str(exc)
            self._blocked_until = time.time() + 300
            return
        self._latest, self._err = {}, ""
        threading.Thread(target=self._read, args=(self._proc,), daemon=True, name="cputrace-reader").start()
        if not self._watch or not self._watch.is_alive():
            self._watch = threading.Thread(target=self._idle_watch, daemon=True, name="cputrace-idle")
            self._watch.start()

    def _read(self, proc: subprocess.Popen) -> None:
        try:
            for line in proc.stdout:
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if "err" in d:
                    self._err = str(d["err"])
                    self._blocked_until = time.time() + 300      # a trace that is not allowed is not retried every second
                    break
                d["ts"] = time.time()
                with self._lock:
                    self._latest = d
        except Exception:
            pass
        finally:
            try:
                proc.kill()
            except Exception:
                pass

    def _idle_watch(self) -> None:
        while True:
            time.sleep(2.0)
            p = self._proc
            if not p or p.poll() is not None:
                return
            if time.time() - self._last_req > _IDLE_AFTER:
                self.stop()
                return

    def stop(self) -> None:
        p, self._proc = self._proc, None
        if not p:
            return
        try:
            p.stdin.close()                    # closing stdin tells the helper to stop the kernel trace
        except Exception:
            pass
        try:
            p.wait(timeout=3)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass

    def _owners(self, tids: set) -> dict:
        if [t for t in tids if t and t not in self._tid_owner] and time.time() - self._tid_refreshed > 3.0:
            self._tid_refreshed = time.time()
            try:
                import psutil
                m = {}
                for p in psutil.process_iter(["pid", "name"]):
                    try:
                        for t in p.threads():
                            m[t.id] = (p.info["pid"], p.info["name"] or "")
                    except Exception:
                        continue
                self._tid_owner = m
            except Exception as exc:
                _log.debug("tid map: %s", exc)
        return self._tid_owner

    @staticmethod
    def _proc_info(pid: int, procs: list) -> dict:
        for p in procs:
            if p.get("pid") == pid:
                return p
        return {}

    def breakdown(self, idx: int, procs: list) -> dict:
        self._last_req = time.time()
        self._start()
        with self._lock:
            snap = dict(self._latest)
        if snap and time.time() - snap.get("ts", 0) < 6:
            return self._from_trace(idx, snap, procs)
        if self._proc and self._proc.poll() is None and not self._err:
            return {"cpu": idx, "source": "trace", "rows": [], "starting": True, "usage": None, "idle_pct": None,
                    "note": "Starting the kernel scheduler trace…"}
        return self._estimate(idx, procs)

    def _from_trace(self, idx: int, snap: dict, procs: list) -> dict:
        raw = snap.get("cpus", {}).get(str(idx), [])
        win = max(1.0, float(snap.get("win", 1.0)) * 1e7)                  # window length in 100 ns units
        owners = self._owners({r[0] for r in raw})
        idle = sum(r[1] for r in raw if r[0] == 0)
        busy = sum(r[1] for r in raw if r[0] != 0)
        rows = []
        for tid, run, k in raw:
            if tid == 0:
                continue
            pid, nm = owners.get(tid, (0, ""))
            pi = self._proc_info(pid, procs)
            rows.append({"tid": tid, "pid": pid, "name": pi.get("name") or clean(nm) or "(thread exited)", "icon": pi.get("icon", ""),
                         "signer": pi.get("signer", ""), "exe": pi.get("exe", ""), "run_ms": round(run / 1e4, 1),
                         "share": round(100.0 * run / win, 1), "switches": k, "state": "Ran on this CPU"})
        rows.sort(key=lambda r: -r["run_ms"])
        return {"cpu": idx, "source": "trace", "window_ms": round(win / 1e4), "usage": round(min(100.0, 100.0 * busy / win), 1),
                "idle_pct": round(min(100.0, 100.0 * idle / win), 1), "events": snap.get("events", 0), "rows": rows[:60]}

    @staticmethod
    def _ideal_cpu(k32, tid: int) -> Optional[int]:
        try:
            class PN(ctypes.Structure):
                _fields_ = [("Group", ctypes.c_ushort), ("Number", ctypes.c_ubyte), ("Reserved", ctypes.c_ubyte)]
            k32.OpenThread.restype = ctypes.c_void_p
            h = k32.OpenThread(0x0800, False, tid)                           # THREAD_QUERY_LIMITED_INFORMATION
            if not h:
                return None
            pn = PN()
            ok = k32.GetThreadIdealProcessorEx(ctypes.c_void_p(h), ctypes.byref(pn))
            k32.CloseHandle(ctypes.c_void_p(h))
            return pn.Group * 64 + pn.Number if ok else None
        except Exception:
            return None

    def _estimate(self, idx: int, procs: list) -> dict:
        import psutil
        k32 = ctypes.windll.kernel32 if sys.platform == "win32" else None
        now = time.time()
        cur = {}
        for p in sorted(procs, key=lambda p: -(p.get("cpu") or 0))[:40]:
            try:
                for t in psutil.Process(p["pid"]).threads():
                    cur[(p["pid"], t.id)] = (t.user_time + t.system_time, p)
            except Exception:
                continue
        prev, self._prev_threads = self._prev_threads, {k: (v[0], now) for k, v in cur.items()}
        rows, window = [], 0.0
        for key, (cpu_s, p) in cur.items():
            old = prev.get(key)
            if not old:
                continue
            dt, delta = now - old[1], cpu_s - old[0]
            window = max(window, dt)
            if delta <= 0.004 or dt <= 0:
                continue
            if k32 is not None and self._ideal_cpu(k32, key[1]) != idx:
                continue
            rows.append({"tid": key[1], "pid": key[0], "name": p.get("name", ""), "icon": p.get("icon", ""), "signer": p.get("signer", ""),
                         "exe": p.get("exe", ""), "run_ms": round(delta * 1000, 1), "share": round(100.0 * delta / dt, 1),
                         "switches": None, "state": "Scheduled here (ideal CPU)"})
        rows.sort(key=lambda r: -r["run_ms"])
        why = f" ({self._err})" if self._err else ""
        return {"cpu": idx, "source": "estimate", "window_ms": round(window * 1000), "usage": None, "idle_pct": None, "rows": rows[:60],
                "starting": not prev,
                "note": "Estimate: the exact kernel trace is not available" + why + ". Showing active threads whose scheduler-assigned CPU is this one."}


cpu_trace = CpuTrace()

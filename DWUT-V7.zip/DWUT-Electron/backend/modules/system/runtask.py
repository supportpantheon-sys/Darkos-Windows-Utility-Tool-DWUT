"""
modules/system/runtask.py - the engine behind the Task Manager's "Run task" dialog (Windows Run, Win+R).

Behaves like the real thing:
  * environment variables are expanded (%windir%\\system32\\cmd.exe)
  * a quoted path, an unquoted path containing spaces, or a bare name from PATH / "App Paths" all work
  * folders, documents, URLs, mailto:, ms-settings:, shell:..., ::{CLSID}, .msc / .cpl / .lnk / .bat open normally
  * the working directory is the user's profile folder
  * the same error wording Windows uses when something can't be found
  * "Create this task with administrative privileges" -> elevated ("runas"); unticked -> started as the normal
    desktop user even though DWUT itself runs elevated (just like Win+R from a non-elevated Explorer)
"""
from __future__ import annotations

import ctypes
import os
import re
import shutil
import subprocess
import sys
from typing import Optional

from core.logger import get_logger

_log = get_logger("runtask")

_PROTOCOL = re.compile(r"^(?:[a-zA-Z][a-zA-Z0-9+.\-]+:|::\{)")      # 2+ letters before ":" (a single letter is a drive)
_NOT_FOUND = "Windows cannot find '{t}'. Make sure you typed the name correctly, and then try again."


def _is_protocol(s: str) -> bool:
    """http:, mailto:, ms-settings:, shell:..., ::{GUID} - but not a drive path like C:\\x."""
    return bool(_PROTOCOL.match(s))


def split_command(cmd: str) -> tuple[str, str]:
    """-> (target, parameters). Mirrors how Run decides where the program name ends."""
    cmd = cmd.strip()
    if cmd.startswith('"'):
        end = cmd.find('"', 1)
        if end > 0:
            return cmd[1:end], cmd[end + 1:].strip()
    if _is_protocol(cmd) or os.path.exists(cmd):
        return cmd, ""
    parts = cmd.split(" ")
    for i in range(len(parts), 0, -1):                       # longest prefix that is a real file/folder/command wins
        head = " ".join(parts[:i])
        if os.path.exists(head) or shutil.which(head):
            return head, " ".join(parts[i:]).strip()
    return parts[0], " ".join(parts[1:]).strip()


# ── starting things ──────────────────────────────────────────────────────────

def _is_elevated() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _shell_execute(verb: Optional[str], target: str, params: str, cwd: str) -> int:
    shell32 = ctypes.windll.shell32
    shell32.ShellExecuteW.restype = ctypes.c_void_p
    shell32.ShellExecuteW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_wchar_p,
                                      ctypes.c_wchar_p, ctypes.c_int]
    r = shell32.ShellExecuteW(None, verb, target, params or None, cwd, 1)
    return int(r or 0)


def _explorer_token():
    """A primary token of the logged-in desktop user (explorer.exe), i.e. NON-elevated."""
    import psutil
    k32, adv = ctypes.windll.kernel32, ctypes.windll.advapi32
    me = ctypes.c_ulong()
    k32.ProcessIdToSessionId(os.getpid(), ctypes.byref(me))
    for p in psutil.process_iter(["name", "pid"]):
        if (p.info["name"] or "").lower() != "explorer.exe":
            continue
        sid = ctypes.c_ulong()
        k32.ProcessIdToSessionId(p.info["pid"], ctypes.byref(sid))
        if sid.value != me.value:
            continue
        PROCESS_QUERY_INFORMATION, TOKEN_ALL = 0x0400, 0xF01FF
        h = k32.OpenProcess(PROCESS_QUERY_INFORMATION, False, p.info["pid"])
        if not h:
            continue
        tok = ctypes.c_void_p()
        ok = adv.OpenProcessToken(ctypes.c_void_p(h), 0x0002 | 0x0001 | 0x0008, ctypes.byref(tok))    # DUPLICATE | ASSIGN_PRIMARY | QUERY
        k32.CloseHandle(ctypes.c_void_p(h))
        if not ok:
            continue
        dup = ctypes.c_void_p()
        adv.DuplicateTokenEx(tok, TOKEN_ALL, None, 2, 1, ctypes.byref(dup))                            # impersonation level 2, primary token
        k32.CloseHandle(tok)
        if dup:
            return dup
    return None


def _launch_unelevated(exe: str, params: str, cwd: str, tok=None) -> bool:
    """Start an executable with the desktop user's (non-elevated) token (grabbed now, or passed in)."""
    from ctypes import wintypes
    adv, k32 = ctypes.windll.advapi32, ctypes.windll.kernel32
    own = tok is None
    tok = tok or _explorer_token()
    if not tok:
        return False

    class SI(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("lpReserved", wintypes.LPWSTR), ("lpDesktop", wintypes.LPWSTR),
                    ("lpTitle", wintypes.LPWSTR), ("dwX", wintypes.DWORD), ("dwY", wintypes.DWORD),
                    ("dwXSize", wintypes.DWORD), ("dwYSize", wintypes.DWORD), ("dwXCountChars", wintypes.DWORD),
                    ("dwYCountChars", wintypes.DWORD), ("dwFillAttribute", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("wShowWindow", wintypes.WORD), ("cbReserved2", wintypes.WORD), ("lpReserved2", ctypes.c_void_p),
                    ("hStdInput", wintypes.HANDLE), ("hStdOutput", wintypes.HANDLE), ("hStdError", wintypes.HANDLE)]

    class PI(ctypes.Structure):
        _fields_ = [("hProcess", wintypes.HANDLE), ("hThread", wintypes.HANDLE), ("dwProcessId", wintypes.DWORD), ("dwThreadId", wintypes.DWORD)]
    si = SI()
    si.cb = ctypes.sizeof(si)
    si.lpDesktop = "winsta0\\default"
    pi = PI()
    cmdline = f'"{exe}"' + (f" {params}" if params else "")
    adv.CreateProcessWithTokenW.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD,
                                            ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(SI), ctypes.POINTER(PI)]
    ok = adv.CreateProcessWithTokenW(tok, 1, None, ctypes.create_unicode_buffer(cmdline), 0x00000010,    # LOGON_WITH_PROFILE, CREATE_NEW_CONSOLE
                                     None, cwd, ctypes.byref(si), ctypes.byref(pi))
    if own:
        k32.CloseHandle(tok)
    if ok:
        k32.CloseHandle(pi.hProcess)
        k32.CloseHandle(pi.hThread)
    return bool(ok)


def _resolve_exe(target: str) -> Optional[str]:
    """Full path when the target is a real .exe/.com (so it can be started with the user token), else None."""
    cand = target if os.path.isfile(target) else shutil.which(target)
    if cand and cand.lower().endswith((".exe", ".com")):
        return os.path.abspath(cand)
    return None


def run(command: str, admin: bool = False) -> dict:
    """Run `command` like Win+R. -> {"ok": bool, "error": str, "note": str}."""
    if sys.platform != "win32":
        return {"ok": False, "error": "Run is only available on Windows."}
    raw = (command or "").strip()
    if not raw:
        return {"ok": False, "error": "Type the name of a program, folder, document, or Internet resource."}
    expanded = os.path.expandvars(raw)
    cwd = os.path.expanduser("~")
    target, params = split_command(expanded)
    target = os.path.expandvars(target)
    try:
        if admin:
            code = _shell_execute("runas", target, params, cwd)
            if code <= 32:
                return _error(code, target, admin=True)
            return {"ok": True}
        # Normal user: DWUT is elevated, so hand the job to the desktop user's token like Explorer would.
        if _is_elevated():
            exe = _resolve_exe(target)
            if exe and _launch_unelevated(exe, params, cwd):
                return {"ok": True}
            if not exe and not _is_protocol(target) and not os.path.exists(target) and not shutil.which(target):
                code = _shell_execute("open", target, params, cwd)          # App Paths names (e.g. "chrome", "winword")
                return {"ok": True} if code > 32 else _error(code, target)
            if not exe:
                # documents, folders, URLs, .msc/.cpl/.bat ...: Explorer opens them as the normal desktop user
                arg = target if not params else f'{target} {params}'
                if _launch_unelevated(os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "explorer.exe"), f'"{arg}"' if " " in arg and not arg.startswith('"') else arg, cwd):
                    return {"ok": True}
            code = _shell_execute("open", target, params, cwd)              # last resort: same privileges as DWUT
            return ({"ok": True, "note": "Started with the same privileges as DWUT."} if code > 32 else _error(code, target))
        code = _shell_execute("open", target, params, cwd)
        return {"ok": True} if code > 32 else _error(code, target)
    except Exception as exc:
        _log.warning("run failed: %s", exc)
        return {"ok": False, "error": f"Could not start '{raw}': {exc}"}


def _error(code: int, target: str, admin: bool = False) -> dict:
    if code in (2, 3):                                  # file / path not found
        return {"ok": False, "error": _NOT_FOUND.format(t=target)}
    if code == 5:
        return {"ok": False, "error": "The operation was cancelled." if admin else f"Access to '{target}' was denied."}
    if code == 31:
        return {"ok": False, "error": f"There is no program associated with '{target}'."}
    if code == 8:
        return {"ok": False, "error": "There is not enough memory to start this program."}
    return {"ok": False, "error": f"Windows could not open '{target}' (error {code})."}


# ── used by Task Manager "Restart task" ─────────────────────────────────────

def relaunch(exe: str, params: str, cwd: str, elevated: bool) -> bool:
    """Start `exe` again with the privilege level the old process had."""
    if sys.platform != "win32":
        return False
    cwd = cwd if cwd and os.path.isdir(cwd) else os.path.dirname(exe) or os.path.expanduser("~")
    if elevated or not _is_elevated():
        return _shell_execute("open", exe, params, cwd) > 32
    return _launch_unelevated(exe, params, cwd)


def process_elevated(pid: int) -> Optional[bool]:
    """True/False if the process runs elevated (UAC 'as administrator'); None when it can't be read."""
    try:
        k32, adv = ctypes.windll.kernel32, ctypes.windll.advapi32
        k32.OpenProcess.restype = ctypes.c_void_p
        k32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        adv.OpenProcessToken.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_void_p)]
        adv.GetTokenInformation.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
        h = k32.OpenProcess(0x1000, 0, pid)                      # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return None
        tok = ctypes.c_void_p()
        ok = adv.OpenProcessToken(h, 0x0008, ctypes.byref(tok))  # TOKEN_QUERY
        k32.CloseHandle(h)
        if not ok:
            return None
        val, ret = ctypes.c_ulong(0), ctypes.c_ulong(0)
        ok = adv.GetTokenInformation(tok, 20, ctypes.byref(val), ctypes.sizeof(val), ctypes.byref(ret))   # TokenElevation
        k32.CloseHandle(tok)
        return bool(val.value) if ok else None
    except Exception:
        return None


def restart_explorer() -> bool:
    """Restart the Windows shell (taskbar, desktop, File Explorer) as the normal desktop user."""
    import time
    import psutil
    tok = _explorer_token()                                      # must be taken BEFORE explorer is closed
    me = ctypes.c_ulong()
    ctypes.windll.kernel32.ProcessIdToSessionId(os.getpid(), ctypes.byref(me))
    for p in psutil.process_iter(["name", "pid"]):
        try:
            if (p.info["name"] or "").lower() == "explorer.exe":
                sid = ctypes.c_ulong()
                ctypes.windll.kernel32.ProcessIdToSessionId(p.info["pid"], ctypes.byref(sid))
                if sid.value == me.value:
                    p.kill()
        except Exception:
            continue
    time.sleep(0.9)
    explorer = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "explorer.exe")
    if tok and _launch_unelevated(explorer, "", os.environ.get("WINDIR", r"C:\Windows"), tok):
        ctypes.windll.kernel32.CloseHandle(tok)
        return True
    subprocess.Popen([explorer], creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))   # last resort
    return True

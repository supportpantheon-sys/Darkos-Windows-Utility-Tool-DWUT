"""
modules/vm/engine.py — build a ready-to-install virtual machine.

VirtualBox (recommended) is fully automatic: download + silent install, create the VM with the chosen specs, and for ISOs VirtualBox
can install unattended (Windows 10/11, Ubuntu, Debian, Fedora, ...) the OS installs itself.  VMware Workstation cannot be downloaded
without a Broadcom login, so for it DWUT downloads the ISO and gives an exact click-by-click guide with the chosen specs.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import threading
from pathlib import Path
from typing import Callable, Optional

import psutil

from core.logger import get_logger
from modules.usb import catalog
from modules.usb import engine as ue
from modules.usb.engine import CACHE, FlashError, ps, run

_log = get_logger(__name__)
VM_TOOLS = CACHE.parent / "vm"

# id -> (VirtualBox ostype, cpus, ram_gb, disk_gb, vram_mb, efi, tpm)
VBOX = {
    "win11": ("Windows11_64", 4, 8, 80, 128, True, True), "win10": ("Windows10_64", 2, 4, 60, 128, False, False),
    "ubuntu": ("Ubuntu_64", 2, 4, 40, 128, False, False), "mint": ("Ubuntu_64", 2, 4, 40, 128, False, False), "mint_xfce": ("Ubuntu_64", 2, 4, 40, 128, False, False),
    "fedora": ("Fedora_64", 2, 4, 40, 128, False, False), "debian": ("Debian_64", 2, 4, 40, 128, False, False),
    "arch": ("ArchLinux_64", 2, 4, 30, 64, False, False), "opensuse": ("openSUSE_64", 2, 4, 40, 128, False, False), "alpine": ("Linux26_64", 1, 1, 10, 16, False, False),
    "kali": ("Debian_64", 2, 4, 50, 128, False, False), "kali_purple": ("Debian_64", 2, 4, 60, 128, False, False),
    "parrot_sec": ("Debian_64", 2, 4, 50, 128, False, False), "parrot_home": ("Debian_64", 2, 4, 40, 128, False, False),
    "blackarch": ("ArchLinux_64", 2, 4, 60, 64, False, False), "qubes": ("Linux26_64", 4, 16, 100, 64, False, False),
    "tails": ("Debian_64", 2, 4, 8, 64, False, False), "templeos": ("Other_64", 1, 1, 4, 16, False, False), "hbcd": ("Windows10_64", 2, 4, 20, 64, False, False),
}
OSTYPE_CHOICES = {"Windows 11": "Windows11_64", "Windows 10": "Windows10_64", "Linux (64-bit)": "Linux26_64", "Other (64-bit)": "Other_64"}


def host_info() -> dict:
    code, out = ps("$p=Get-CimInstance Win32_Processor | Select-Object -First 1; $c=Get-CimInstance Win32_ComputerSystem; "
                   "ConvertTo-Json -Compress @{virt=[bool]$p.VirtualizationFirmwareEnabled; hyperv=[bool]$c.HypervisorPresent}", 30)
    d = {}
    try:
        d = json.loads(out.strip().splitlines()[-1])
    except Exception:
        pass
    return {"cores": psutil.cpu_count(logical=True) or 2, "ram_gb": round(psutil.virtual_memory().total / 1024 ** 3, 1),
            "virt_enabled": d.get("virt", True), "hyperv": d.get("hyperv", False)}


def list_drives() -> list[dict]:
    code, out = ps("$v=@(Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.Size -gt 0 } | ForEach-Object { "
                   "[pscustomobject]@{letter=\"$($_.DriveLetter)\"; label=$_.FileSystemLabel; fs=$_.FileSystem; size=[int64]$_.Size; free=[int64]$_.SizeRemaining} }); "
                   "ConvertTo-Json -InputObject @($v) -Compress", 40)
    try:
        d = json.loads(out.strip().splitlines()[-1])
        return d if isinstance(d, list) else [d]
    except Exception:
        return []


def defaults(os_id: str) -> dict:
    t = VBOX.get(os_id, ("Other_64", 2, 4, 30, 64, False, False))
    h = host_info()
    cpus = min(t[1], max(1, h["cores"] // 2 or 1))
    ram = min(t[2], max(1, int(h["ram_gb"] // 2)))
    return {"ostype": t[0], "cpus": cpus, "ram_gb": ram, "disk_gb": t[3], "vram_mb": t[4], "efi": t[5], "tpm": t[6], "host": h}


# ── VirtualBox ────────────────────────────────────────────────────────────────

def vbox_exe() -> Optional[Path]:
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramW6432", r"C:\Program Files")):
        p = Path(root) / "Oracle" / "VirtualBox" / "VBoxManage.exe"
        if p.exists():
            return p
    return None


def ensure_virtualbox(log, on_dl, cancel: threading.Event) -> Path:
    exe = vbox_exe()
    if exe:
        log("VirtualBox is already installed.")
        return exe
    ver = ue.http_text("https://download.virtualbox.org/virtualbox/LATEST-STABLE.TXT", 30).strip().splitlines()[0].strip()
    base = f"https://download.virtualbox.org/virtualbox/{ver}/"
    names = [n for n in ue.list_dir(base) if re.fullmatch(rf"VirtualBox-{re.escape(ver)}-\d+-Win\.exe", n)]
    if not names:
        raise FlashError(f"VirtualBox {ver} installer not found on download.virtualbox.org")
    name = names[0]
    VM_TOOLS.mkdir(parents=True, exist_ok=True)
    dest = VM_TOOLS / name
    sha = None
    try:
        sha = ue.parse_checksum(ue.http_text(base + "SHA256SUMS", 30), name)
    except FlashError:
        pass
    log(f"Downloading VirtualBox {ver}…")
    ue.download([base + name], dest, on_dl, cancel, log)
    if sha and ue.sha256_file(dest, lambda f: None, cancel) != sha:
        dest.unlink(missing_ok=True)
        raise FlashError("VirtualBox download failed its checksum - please try again.")
    code, out = ps(f"$s=Get-AuthenticodeSignature -LiteralPath '{dest}'; \"$($s.Status)|$($s.SignerCertificate.Subject)\"", 40)
    if not (out.startswith("Valid") and "oracle" in out.lower()):
        dest.unlink(missing_ok=True)
        raise FlashError("VirtualBox installer signature check failed.")
    log("Installing VirtualBox (about a minute; your network may blink once)…")
    code, out = run([str(dest), "--silent", "--ignore-reboot"], 900)
    exe = vbox_exe()
    if not exe:
        raise FlashError(f"VirtualBox installation failed (code {code}). Try running the installer manually: {dest}")
    return exe


def _vb(exe: Path, args: list[str], timeout: int = 600, strict: bool = True) -> str:
    code, out = run([str(exe), *args], timeout)
    if code != 0 and strict:
        raise FlashError(f"VBoxManage {' '.join(args[:2])} failed: {out.strip()[-300:]}")
    return out


def _unique_name(exe: Path, name: str) -> str:
    out = _vb(exe, ["list", "vms"], 60, strict=False)
    taken = set(re.findall(r'^"(.*?)"', out, re.M))
    n, cand = 1, name
    while cand in taken:
        n += 1
        cand = f"{name} ({n})"
    return cand


def build_vbox(exe: Path, spec: dict, iso: Path, drive: str, log) -> dict:
    name = _unique_name(exe, re.sub(r'[\\/:*?"<>|]', "", spec["name"]).strip() or "DWUT VM")
    base = Path(f"{drive}:\\DWUT-VMs")
    base.mkdir(parents=True, exist_ok=True)
    unattended = False
    if spec.get("unattended"):
        out = _vb(exe, ["unattended", "detect", f"--iso={iso}", "--machine-readable"], 120, strict=False)
        unattended = re.search(r'UnattendedInstallationSupported="?true', out, re.I) is not None
        log("Unattended install " + ("supported by this ISO - the OS will install itself." if unattended else "not supported by this ISO - you will run its installer."))
    log(f"Creating VM '{name}' on {drive}:…")
    _vb(exe, ["createvm", "--name", name, "--ostype", spec["ostype"], "--register", "--basefolder", str(base)])
    mod = ["modifyvm", name, "--memory", str(int(spec["ram_gb"] * 1024)), "--cpus", str(spec["cpus"]), "--vram", str(spec["vram_mb"]),
           "--graphicscontroller", "vboxsvga" if "Windows" in spec["ostype"] else "vmsvga", "--nic1", "nat", "--boot1", "dvd", "--boot2", "disk", "--boot3", "none", "--ioapic", "on"]
    if spec.get("efi"):
        mod += ["--firmware", "efi"]
    _vb(exe, mod)
    if spec.get("tpm"):
        _vb(exe, ["modifyvm", name, "--tpm-type", "2.0"], 60, strict=False)
    if spec.get("accel3d"):
        _vb(exe, ["modifyvm", name, "--accelerate-3d", "on"], 60, strict=False)
    for opt in (["--audio-enabled", "on", "--audio-driver", "default", "--audio-controller", "hda"], ["--clipboard-mode", "bidirectional"], ["--drag-and-drop", "bidirectional"]):
        _vb(exe, ["modifyvm", name, *opt], 60, strict=False)          # optional niceties: older VirtualBox may not know them
    vdi = base / name / f"{name}.vdi"
    _vb(exe, ["createmedium", "disk", "--filename", str(vdi), "--size", str(int(spec["disk_gb"] * 1024)), "--format", "VDI"], 900)
    _vb(exe, ["storagectl", name, "--name", "SATA", "--add", "sata", "--controller", "IntelAhci", "--portcount", "2"])
    _vb(exe, ["storageattach", name, "--storagectl", "SATA", "--port", "0", "--device", "0", "--type", "hdd", "--medium", str(vdi)])
    _vb(exe, ["storageattach", name, "--storagectl", "SATA", "--port", "1", "--device", "0", "--type", "dvddrive", "--medium", "emptydrive" if unattended else str(iso)])
    if unattended:
        user = re.sub(r"[^A-Za-z0-9_.-]", "", spec.get("user") or "user") or "user"
        _vb(exe, ["unattended", "install", name, f"--iso={iso}", f"--user={user}", f"--password={spec.get('password') or 'changeme'}",
                  f"--full-user-name={user}", "--install-additions", "--locale=en_US", "--start-vm=gui"], 300)
    else:
        _vb(exe, ["startvm", name, "--type", "gui"], 120)
    return {"name": name, "unattended": unattended, "folder": str(base / name), "user": spec.get("user"), "password": spec.get("password")}


# ── guides ────────────────────────────────────────────────────────────────────

def specs_lines(spec: dict, drive: str) -> list[str]:
    return [f"Name: {spec['name']}", f"CPU cores: {spec['cpus']}", f"Memory: {spec['ram_gb']} GB ({int(spec['ram_gb'] * 1024)} MB)", f"Disk: {spec['disk_gb']} GB (stored on {drive}:)",
            f"Video memory: {spec['vram_mb']} MB", f"Firmware: {'UEFI (EFI)' if spec.get('efi') else 'BIOS'}", f"TPM 2.0: {'yes' if spec.get('tpm') else 'no'}"]


def guide_virtualbox(res: dict, spec: dict) -> dict:
    if res["unattended"]:
        steps = [f"The VM '{res['name']}' is running and is installing the operating system BY ITSELF - you do not need to click through setup.",
                 "Leave the VM window open. The install takes roughly 15-40 minutes and the VM restarts a few times.",
                 f"When it reaches the desktop, sign in with  user: {res['user'] or 'user'}  /  password: {res['password'] or 'changeme'}  (change this password afterwards).",
                 "Guest Additions (better resolution, shared clipboard, drag-and-drop) are installed automatically.",
                 "Tip: to leave the VM, press the Right Ctrl key. Close the window and choose 'Save the machine state' to pause it."]
    else:
        steps = [f"The VM '{res['name']}' was created and started, with the ISO already inserted - this ISO cannot be installed unattended, so run its installer yourself.",
                 "Click inside the VM window and press Enter (or pick 'Install') at the boot menu. If the screen stays black for a minute, give it a moment.",
                 "When the installer asks where to install, choose the virtual disk (it is empty and shows the size you chose).",
                 "After the install finishes the VM restarts - if it boots the installer again, use the VM's Devices > Optical Drives > 'Remove disk from virtual drive'.",
                 "Then in the VM menu choose Devices > Insert Guest Additions CD image and run it for proper resolution and shared clipboard.",
                 "Tip: press the Right Ctrl key to release your mouse from the VM."]
    return {"title": "Your virtual machine", "steps": steps, "specs": specs_lines(spec, "?"), "software": "VirtualBox", "folder": res["folder"]}


def guide_vmware(iso: Path, spec: dict, drive: str, os_name: str) -> dict:
    steps = ["VMware Workstation Pro is free for personal use now, but Broadcom only offers it after you create a free account, so DWUT cannot download it for you. Click 'Open VMware download page' below, sign in/register, and install it (accept the defaults).",
             f"Your operating system image is already downloaded: {iso}",
             "Open VMware Workstation and choose File > New Virtual Machine… > Typical > Next.",
             f"Choose 'Installer disc image file (iso)' and browse to the file above. Next.",
             f"Pick the guest OS ({os_name}); Name: {spec['name']}; Location: {drive}:\\DWUT-VMs\\{spec['name']}",
             f"Maximum disk size: {spec['disk_gb']} GB. Choose 'Store virtual disk as a single file'. Next.",
             f"Click 'Customize Hardware…' and set Memory = {int(spec['ram_gb'] * 1024)} MB and Processors = {spec['cpus']} cores. Close, then Finish."]
    if spec.get("efi"):
        steps.append("This OS needs UEFI: select the VM > VM > Settings > Options > Advanced > Firmware type: UEFI (tick 'Enable secure boot' for Windows 11).")
    if spec.get("tpm"):
        steps.append("Windows 11 also needs a TPM: VM > Settings > Options > Access Control > Encrypt (set a password) > then Hardware > Add > Trusted Platform Module.")
    steps += ["Power on the VM and follow the OS installer.", "After installing, choose VM > Install VMware Tools for better resolution and shared clipboard."]
    return {"title": "Set up your VMware VM", "steps": steps, "specs": specs_lines(spec, drive), "software": "VMware", "folder": str(iso.parent),
            "url": "https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion"}

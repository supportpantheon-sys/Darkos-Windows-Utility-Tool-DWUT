@echo off
rem ===========================================================================
rem  DWUT - Repair Internet.  Double-click if you ever lose internet after using
rem  VPN mode (e.g. DWUT crashed while the kill switch was on).
rem  Removes: firewall kill-switch/DNS rules, Windows + WinHTTP proxy settings,
rem  browser WebRTC/QUIC policies and Store-app loopback exemptions DWUT added.
rem ===========================================================================
net session >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo Removing DWUT VPN firewall rules...
for %%R in ("DWUT-VPN-KillSwitch-v4" "DWUT-VPN-KillSwitch-v6" "DWUT-VPN-DNS-Block" "DWUT-VPN-DNS-Block-tcp") do netsh advfirewall firewall delete rule name=%%R >nul 2>&1
echo Resetting proxy settings...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f >nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyServer /f >nul 2>&1
netsh winhttp reset proxy >nul
echo Removing browser leak-protection policies...
for %%K in ("HKLM\SOFTWARE\Policies\Google\Chrome" "HKLM\SOFTWARE\Policies\Microsoft\Edge" "HKLM\SOFTWARE\Policies\BraveSoftware\Brave") do (
  reg delete %%K /v WebRtcIPHandling /f >nul 2>&1
  reg delete %%K /v QuicAllowed /f >nul 2>&1
)
if exist "%LOCALAPPDATA%\DWUT\vpn_state.json" (
  powershell -NoProfile -Command "$s=Get-Content \"$env:LOCALAPPDATA\DWUT\vpn_state.json\" -Raw | ConvertFrom-Json; foreach($f in $s.store_added){ CheckNetIsolation LoopbackExempt -d -n=$f | Out-Null }"
  del "%LOCALAPPDATA%\DWUT\vpn_state.json" >nul 2>&1
)
del "%LOCALAPPDATA%\DWUT\relay_port.txt" >nul 2>&1
echo.
echo Done - your internet connection settings are back to normal.
pause

"""
app/updater.py — DWUT auto-updater.

Checks GitHub for a newer release tag on startup (background thread),
and shows an update-available banner in the UI if one is found.

Designed to be completely non-blocking and safe to skip on network error.

Usage
-----
    from app.updater import check_for_update_async

    # Call once from main() after the main window is ready:
    check_for_update_async(callback=lambda info: bus.publish(Events.UPDATE_AVAILABLE, info))

The callback receives a dict:
    {
        "version":  "v1.2.3",
        "url":      "https://github.com/.../releases/tag/v1.2.3",
        "notes":    "Release notes text (first 512 chars)",
        "download": "https://.../DWUT_v1.2.3.zip",   # or "" if not found
    }

If no update or a network error occurs the callback is never called.
"""

from __future__ import annotations

import threading
from typing import Callable, Optional

from core.logger import get_logger

_log = get_logger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────

# Set these to point at your actual GitHub repo.
GITHUB_OWNER  = "YourUser"
GITHUB_REPO   = "DWUT"

# Current version — bump this string on each release.
CURRENT_VERSION = "v3.7.0"

_API_URL = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/latest"


def _parse_version(tag: str) -> tuple[int, ...]:
    """'v1.2.3' -> (1, 2, 3).  Non-numeric segments become 0."""
    clean = tag.lstrip("vV").split("-")[0]  # strip pre-release suffix for comparison
    parts = []
    for seg in clean.split("."):
        try:
            parts.append(int(seg))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _do_check() -> Optional[dict]:
    """Blocking check — runs on a background thread."""
    try:
        import requests
        resp = requests.get(
            _API_URL,
            headers={"Accept": "application/vnd.github+json"},
            timeout=8,
        )
        if resp.status_code != 200:
            return None
        data = resp.json()

        latest_tag = data.get("tag_name", "")
        if not latest_tag:
            return None

        if _parse_version(latest_tag) <= _parse_version(CURRENT_VERSION):
            return None   # already up to date

        # Find zip download URL (asset or zipball)
        download_url = ""
        for asset in data.get("assets", []):
            name: str = asset.get("name", "")
            if name.lower().endswith(".zip"):
                download_url = asset.get("browser_download_url", "")
                break
        if not download_url:
            download_url = data.get("zipball_url", "")

        notes_raw = (data.get("body") or "").strip()
        notes = notes_raw[:512] + ("…" if len(notes_raw) > 512 else "")

        return {
            "version":  latest_tag,
            "url":      data.get("html_url", ""),
            "notes":    notes,
            "download": download_url,
        }
    except Exception as exc:
        _log.debug("Update check failed (non-fatal): %s", exc)
        return None


def check_for_update_async(
    callback: Callable[[dict], None],
    delay_s: float = 5.0,
) -> None:
    """
    Spin up a daemon thread to check for updates.

    Parameters
    ----------
    callback   : called on the background thread when a newer version is
                 found — you must marshal it to the main thread yourself
                 (e.g. frame.after(0, callback, info)).
    delay_s    : wait this many seconds before hitting the network so
                 the app has fully started before any extra I/O begins.
    """
    def _run() -> None:
        import time
        time.sleep(delay_s)
        info = _do_check()
        if info:
            _log.info("Update available: %s", info["version"])
            try:
                callback(info)
            except Exception as e:
                _log.debug("Update callback error: %s", e)

    t = threading.Thread(target=_run, daemon=True, name="dwut-updater")
    t.start()

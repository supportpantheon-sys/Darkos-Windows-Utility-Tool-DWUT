"""
ui/widgets/smooth_scroll.py - drop-in CTkScrollableFrame fix.
"""
from __future__ import annotations
import tkinter as tk
import customtkinter as ctk
from ui.theme import TOKENS


class SmoothScrollFrame(ctk.CTkScrollableFrame):
    """
    CTkScrollableFrame with two layers of scroll-jank fixed.

    Problem 1 — scrollregion recompute causes visual smush while panning
    -----------------------------------------------------------------------
    CTkScrollableFrame calls canvas.configure(scrollregion=...) synchronously
    on every <Configure> event on its interior frame.  On Windows the canvas
    view changing can itself trigger <Configure> on the interior frame mid-scroll,
    so every wheel tick fires a scrollregion recalculate — which momentarily
    changes the canvas's own layout math while the view is in motion.  Cards
    visibly squish and re-expand on every tick.

    Fix: debounce the recompute behind a 16 ms after(), and if the wheel is
    actively spinning, hold the recompute entirely until 120 ms after the last
    wheel event (the "settle" window), instead of applying the 16 ms debounce
    indiscriminately.

    Problem 2 — mousewheel events captured by child widgets don't reach canvas
    ---------------------------------------------------------------------------
    On Windows, CTkScrollableFrame binds <MouseWheel> to its canvas, but any
    child widget (label, button, frame, etc.) that has focus or is hovered
    captures the event first — Tk's event propagation doesn't automatically
    reroute wheel events to the containing scroll canvas.  The result: hovering
    over a card inside the scroll area and spinning the wheel does nothing.

    Fix: after every pack()/grid()/place() call that adds content we recursively
    bind <MouseWheel> (and the Linux Button-4/5 equivalents) on every descendant
    widget, redirecting all of them to the scroll canvas's yview_scroll call.
    A single public method `bind_children()` is exposed so callers can re-trigger
    this after adding content dynamically.

    Problem 3 — super-fast scrolling causes the view to jump erratically
    -----------------------------------------------------------------------
    When the user scrolls extremely fast (trackpad flick or fast mouse wheel),
    many <MouseWheel> events arrive in rapid succession.  Each one calls
    yview_scroll(units, "units") — but "units" means one scroll unit per call,
    so very fast scrolling sends many single-unit calls faster than Tk can
    repaint.  This causes the content to visually "stutter" and the scrollregion
    to get out of sync.

    Fix: accumulate delta across a 16ms window and fire a single batched
    yview_scroll() call instead of one per event.  This is the same technique
    browsers use for smooth wheel handling.
    """

    _BATCH_MS = 16    # batch window in ms — one repaint frame at 60fps

    def __init__(self, parent, **kwargs) -> None:
        super().__init__(parent, **kwargs)
        self._scroll_update_id: str | None = None
        self._scrolling_settle_id: str | None = None
        self._is_scrolling = False
        self._pending_scroll_units: float = 0.0   # accumulated delta (batching)
        self._scroll_batch_id: str | None = None  # after() id for the batch flush

        # Resolve the internal canvas regardless of ctk version
        self._scroll_canvas: tk.Canvas | None = (
            getattr(self, "_parent_canvas", None)
            or getattr(self, "_canvas", None)
        )

        try:
            if self._scroll_canvas:
                self._patch_configure(self._scroll_canvas)
        except Exception:
            pass

        # bind_children() is NOT called automatically here any more.
        # Calling it on a half-built widget tree (which is what the 50ms
        # after() was doing for the Tweaks tab's async batch build) walks
        # hundreds of not-yet-existing widgets and then misses all the ones
        # added after it fires.  Callers that want scroll binding must call
        # bind_children() explicitly once their content is fully built.
        # For non-async tabs, _switch_tab_with_overlay calls it after
        # do_switch() completes.  For async builds, the final batch callback
        # calls it directly before signalling _hide_tab_overlay().

    # ── Problem-1 fix: debounced / settle-aware scrollregion recompute ──

    def _patch_configure(self, canvas: tk.Canvas) -> None:
        try:
            child = getattr(self, "_parent_frame", None)
            if child:
                child.unbind("<Configure>")
                child.bind("<Configure>", self._debounced_configure, add=False)
        except Exception:
            pass

    def _debounced_configure(self, event=None) -> None:
        if self._scroll_update_id:
            self.after_cancel(self._scroll_update_id)
        if self._is_scrolling:
            self._scroll_update_id = "pending"
            return
        self._scroll_update_id = self.after(16, self._update_region)

    def _update_region(self) -> None:
        self._scroll_update_id = None
        try:
            if self._scroll_canvas:
                self._scroll_canvas.configure(
                    scrollregion=self._scroll_canvas.bbox("all")
                )
        except Exception:
            pass

    def _on_scroll_settled(self) -> None:
        self._scrolling_settle_id = None
        self._is_scrolling = False
        if self._scroll_update_id is not None:
            self._update_region()

    # ── Problem-2 fix: redirect child widget wheel events to canvas ──────

    def _scroll_handler(self, event: tk.Event) -> str:
        """
        Route a wheel event from any descendant to this scroll canvas.

        Problem 3 fix: instead of calling yview_scroll immediately for each
        event, we accumulate the delta and flush it in a single batched call
        every _BATCH_MS ms.  This prevents rapid-fire events from queueing
        dozens of single-unit scroll calls that overwhelm Tk's repaint loop
        and cause erratic jumping when the user scrolls super fast.
        """
        if self._scroll_canvas is None:
            return "continue"

        # Mark active scroll for the settle timer
        self._is_scrolling = True
        if self._scrolling_settle_id:
            self.after_cancel(self._scrolling_settle_id)
        self._scrolling_settle_id = self.after(120, self._on_scroll_settled)

        # Accumulate delta
        if event.num == 4:       # Linux scroll up
            self._pending_scroll_units -= 1
        elif event.num == 5:     # Linux scroll down
            self._pending_scroll_units += 1
        else:
            # Windows / macOS: event.delta is ±120 per notch
            # Use fractional accumulation so a quick flick (multiple notches
            # in one event, delta = ±240 or ±360) is handled correctly.
            self._pending_scroll_units += -event.delta / 120

        # Schedule a single flush if not already scheduled
        if self._scroll_batch_id is None:
            self._scroll_batch_id = self.after(self._BATCH_MS, self._flush_scroll)

        return "break"  # prevent the event bubbling further

    def _flush_scroll(self) -> None:
        """Apply all accumulated scroll units in a single call."""
        self._scroll_batch_id = None
        if not self._pending_scroll_units or self._scroll_canvas is None:
            self._pending_scroll_units = 0.0
            return
        units = round(self._pending_scroll_units)
        if units:
            try:
                self._scroll_canvas.yview_scroll(units, "units")
            except Exception:
                pass
        self._pending_scroll_units = 0.0

    def bind_children(self) -> None:
        """
        Recursively bind all descendant widgets so their wheel events
        are routed to this scroll canvas.  Call this after adding
        content dynamically (the 50ms after() in __init__ handles
        the common static-content case automatically).
        """
        self._bind_tree(self)

    def _bind_tree(self, widget: tk.Widget) -> None:
        try:
            widget.bind("<MouseWheel>", self._scroll_handler, add=True)
            widget.bind("<Button-4>",   self._scroll_handler, add=True)
            widget.bind("<Button-5>",   self._scroll_handler, add=True)
        except Exception:
            pass
        try:
            for child in widget.winfo_children():
                self._bind_tree(child)
        except Exception:
            pass

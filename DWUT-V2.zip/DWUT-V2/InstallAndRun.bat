@echo off
setlocal EnableDelayedExpansion

:: ============================================================
::  DWUT — InstallAndRun.bat
::  Installs Python dependencies and launches DWUT.
::  Requires Python 3.10+ to already be installed.
:: ============================================================

title DWUT Installer

:: -- Check for admin rights ----------------------------------
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [DWUT] Requesting administrator privileges...
    powershell -NoProfile -Command ^
        "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo  =========================================
echo   Darko's Windows Utility Tool — Installer
echo  =========================================
echo.

:: -- Python check --------------------------------------------
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Python not found. Install Python 3.10+ from https://python.org
    echo         Make sure to tick "Add Python to PATH" during install.
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PY_VER=%%v
echo [OK] Python %PY_VER% found.

:: -- pip upgrade (silent) ------------------------------------
echo [....] Upgrading pip...
python -m pip install --upgrade pip --quiet
echo [OK] pip ready.

:: -- Install/upgrade requirements ----------------------------
echo [....] Installing dependencies...
pip install --upgrade ^
    customtkinter ^
    pillow ^
    psutil ^
    pywin32 ^
    pymem ^
    requests ^
    --quiet

if %errorLevel% neq 0 (
    echo [WARN] Some packages may not have installed cleanly.
    echo        Run:  pip install customtkinter pillow psutil pywin32 pymem requests
)

echo [OK] Dependencies installed.

:: -- Optional: OpenHardwareMonitor notice --------------------
echo.
echo [INFO] For GPU stats on the Dashboard, install and run OpenHardwareMonitor
echo        (free, open source) from: https://openhardwaremonitor.org/
echo        DWUT will work fine without it.
echo.

:: -- Launch --------------------------------------------------
echo [....] Launching DWUT...
cd /d "%~dp0"
python dmurt\run.py

if %errorLevel% neq 0 (
    echo.
    echo [ERROR] DWUT exited with an error (code %errorLevel%).
    pause
)

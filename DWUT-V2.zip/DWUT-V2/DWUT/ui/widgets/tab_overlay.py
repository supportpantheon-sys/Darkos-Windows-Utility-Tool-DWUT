"""
ui/widgets/tab_overlay.py — Loading overlay mixin for tab-based pages.

Pages that have an internal tab bar (optimizer, proxy, tools, debloat) can
inherit TabOverlayMixin to get the same "Loading…" screen that the main
window shows when navigating between top-level pages.

Usage — synchronous build (cheap tabs):
    class MyPage(TabOverlayMixin):
        def _switch_tab(self, tab):
            self._switch_tab_with_overlay(tab, self._do_switch_tab, self._built_tabs)

Usage — async build (heavy tabs like Tweaks with 70+ cards):
    class MyPage(TabOverlayMixin):
        def _switch_tab(self, tab):
            self._switch_tab_with_overlay(tab, self._do_switch_tab, self._built_tabs)

        def _do_switch_tab(self, tab):
            if tab == "Tweaks" and tab not in self._built_tabs:
                self._built_tabs.add(tab)
                self._build_tweaks_tab_async()   # calls _hide_tab_overlay() when done
                return   # do NOT pack the frame yet — async builder does it
            # normal sync path for all other tabs...
"""
from __future__ import annotations
import time
import customtkinter as ctk
from ui.theme import TOKENS, get_font


class TabOverlayMixin:
    """
    Mixin that adds a "Loading…" overlay to in-page tab switches.

    Two modes:

    SYNC  — overlay shows, do_switch() runs synchronously, overlay hides
            after a minimum visible time. Fine for tabs that build fast.

    ASYNC — overlay shows, do_switch() kicks off an async job and returns
            immediately. The async job calls self._hide_tab_overlay() when
            it's actually finished. Use this for tabs that build 50+ widgets
            so the overlay stays up the whole time without freezing the UI.

    To use async mode, in do_switch() detect the heavy tab, kick off the
    async builder, and return WITHOUT calling _built_tabs.add() or packing
    the frame — the async builder does both. Pass async_tab=tab to
    _switch_tab_with_overlay so the mixin knows NOT to auto-hide.
    """

    # ── Public API ────────────────────────────────────────────────────────

    def _init_tab_overlay(self, content_parent: ctk.CTkFrame) -> None:
        """
        Call once after the tab content area is created.
        content_parent is the frame whose area the overlay should cover.
        """
        self._tab_overlay_parent = content_parent
        self._tab_overlay = ctk.CTkFrame(
            content_parent, fg_color=TOKENS["bg_base"], corner_radius=0,
        )
        ctk.CTkLabel(
            self._tab_overlay,
            text="Loading…",
            font=get_font(13),
            text_color=TOKENS["text_secondary"],
        ).place(relx=0.5, rely=0.5, anchor="center")
        self._tab_overlay_async = False   # True while an async builder is running
        # Not placed yet — shown on demand.

    def _show_tab_overlay(self) -> None:
        """Place the overlay and force-paint it. Call before heavy work."""
        if not hasattr(self, "_tab_overlay"):
            return
        self._tab_overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._tab_overlay.lift()
        try:
            root = self._tab_overlay.winfo_toplevel()
            root.update()   # full paint flush, not just geometry
        except Exception:
            pass

    def _hide_tab_overlay(self, min_ms_remaining: int = 0) -> None:
        """
        Hide the overlay after at least min_ms_remaining more ms.
        Safe to call from an after() callback (async build completion).
        """
        if not hasattr(self, "_tab_overlay"):
            return
        self._tab_overlay_async = False
        try:
            self._tab_overlay.after(
                max(0, int(min_ms_remaining)),
                self._tab_overlay.place_forget,
            )
        except Exception:
            try:
                self._tab_overlay.place_forget()
            except Exception:
                pass

    def _switch_tab_with_overlay(
        self,
        tab: str,
        do_switch: "Callable[[str], None]",
        built_tabs: "set[str]",
        min_ms: int = 120,
        async_tab: "str | None" = None,
    ) -> None:
        """
        Wrap do_switch(tab) with a loading overlay shown on EVERY switch.

        For ASYNC builds: pass async_tab=tab when the tab's builder is
        asynchronous (fires after() batches internally). The mixin will
        show the overlay and call do_switch(), but will NOT auto-hide —
        the async builder must call self._hide_tab_overlay() itself when
        all batches are done.

        For SYNC builds: overlay auto-hides after do_switch() returns,
        with a minimum visible time of min_ms (first build) or min_ms//2
        (revisit).

        Parameters
        ----------
        tab       : tab name to switch to
        do_switch : callable that performs the actual switch
        built_tabs: set tracking which tabs are already built
        min_ms    : minimum overlay visible time for a first build (ms)
        async_tab : if this == tab, the build is async; don't auto-hide
        """
        if not hasattr(self, "_tab_overlay"):
            do_switch(tab)
            return

        first_build = tab not in built_tabs
        is_async = (async_tab == tab)
        effective_min_ms = min_ms if first_build else min_ms // 2

        # ── 1. Show overlay BEFORE any work ──────────────────────────────
        self._show_tab_overlay()
        t_start = time.monotonic()

        if is_async:
            self._tab_overlay_async = True

        # ── 2. Do the actual tab work ─────────────────────────────────────
        do_switch(tab)

        # ── 3. Re-lift overlay: do_switch may have packed/lifted frames on
        #       top of it — same issue window.py had with page frames ───────
        try:
            self._tab_overlay.lift()
        except Exception:
            pass

        # ── 4. For async builds, the builder calls _hide_tab_overlay()
        #       itself when done. For sync builds, auto-hide now. ──────────
        if not is_async:
            elapsed_ms = (time.monotonic() - t_start) * 1000
            remaining_ms = max(0, effective_min_ms - elapsed_ms)
            try:
                self._tab_overlay.after(
                    int(remaining_ms), self._tab_overlay.place_forget
                )
            except Exception:
                self._tab_overlay.place_forget()

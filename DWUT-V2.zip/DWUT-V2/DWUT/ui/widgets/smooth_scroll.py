"""
ui/widgets/smooth_scroll.py — drop-in replacement for CTkScrollableFrame.

Fixes four real problems seen in production:

  1. scrollbar_width / unknown kwargs crash
     CTkScrollableFrame's accepted kwargs vary by version.  We strip any kwarg
     that CTkScrollableFrame.__init__ doesn't accept before calling super(),
     so SmoothScrollFrame("scrollbar_width=6") never crashes regardless of ctk
     version.

  2. Scroll wheel events eaten by child widgets (Windows)
     On Windows, <MouseWheel> is captured by whichever widget is under the
     cursor, not the canvas.  Result: hovering over a label/button inside the
     scroll area and spinning the wheel does nothing.
     Fix: bind_children() recursively redirects every descendant's wheel event
     to our own _scroll_handler.

  3. Scroll too slow / feels unresponsive
     CTk's default unit multiplier is 1 per notch.  Windows sends delta=120 per
     notch — but even with delta/120=1 unit, one "unit" in Tk's canvas scroll is
     tiny.  Fix: multiply by _UNITS_PER_NOTCH (default 3) so a single wheel
     click moves a meaningful amount.

  4. Visual glitches / content squish during fast scrolling
     Two sub-problems:
     a) CTkScrollableFrame fires scrollregion recalculate on every <Configure>
        event on the interior frame, which itself triggers during scroll →
        content visibly squishes.  Fix: debounce behind 16 ms; hold recompute
        entirely while wheel is active, flush 80 ms after last event.
     b) Many rapid events queueing dozens of canvas calls faster than Tk can
        repaint → erratic jumps.  Fix: accumulate delta across a 16 ms batch
        window and issue a single yview_scroll() per frame instead of one per
        event.  Fractional remainder carries over so no scroll distance is lost.
"""

from __future__ import annotations

import inspect
import tkinter as tk
import customtkinter as ctk

# ── Constants ──────────────────────────────────────────────────────────────────
_UNITS_PER_NOTCH = 3    # canvas scroll units per wheel notch — feel free to tune
_BATCH_MS        = 14   # accumulation window in ms (~1 frame at 70 fps)
_SETTLE_MS       = 80   # ms after last wheel event before scrollregion is allowed
                        # to recompute (prevents squish while actively scrolling)


# ── Helper: figure out which kwargs CTkScrollableFrame actually accepts ────────
_CTK_SCROLL_PARAMS: set[str] | None = None

def _ctk_scroll_params() -> set[str]:
    global _CTK_SCROLL_PARAMS
    if _CTK_SCROLL_PARAMS is None:
        try:
            sig = inspect.signature(ctk.CTkScrollableFrame.__init__)
            _CTK_SCROLL_PARAMS = set(sig.parameters.keys()) - {"self"}
        except Exception:
            _CTK_SCROLL_PARAMS = set()
    return _CTK_SCROLL_PARAMS


class SmoothScrollFrame(ctk.CTkScrollableFrame):
    """Drop-in CTkScrollableFrame with all four scroll bugs fixed."""

    def __init__(self, parent, **kwargs) -> None:
        # ── Fix 1: strip unsupported kwargs ───────────────────────────────
        accepted = _ctk_scroll_params()
        if accepted:
            bad = [k for k in kwargs if k not in accepted]
            for k in bad:
                kwargs.pop(k)

        super().__init__(parent, **kwargs)

        # ── Internal state ─────────────────────────────────────────────────
        self._pending_units: float = 0.0       # accumulated scroll delta
        self._batch_id:      str | None = None  # after() id for batch flush
        self._settle_id:     str | None = None  # after() id for settle timer
        self._region_id:     str | None = None  # after() id for region recompute
        self._is_scrolling:  bool = False

        # Resolve the internal Tk canvas (attribute name varies by ctk version)
        self._scroll_canvas: tk.Canvas | None = (
            getattr(self, "_parent_canvas", None) or
            getattr(self, "_canvas",        None)
        )

        # ── Fix 4a: patch scrollregion recompute ──────────────────────────
        if self._scroll_canvas:
            inner = getattr(self, "_parent_frame", None)
            if inner:
                try:
                    inner.unbind("<Configure>")
                    inner.bind("<Configure>", self._on_inner_configure, add=False)
                except Exception:
                    pass

    # ── Scrollregion debounce (fix 4a) ────────────────────────────────────

    def _on_inner_configure(self, _event=None) -> None:
        """Debounced scrollregion update — held off while wheel is active."""
        if self._region_id:
            try:
                self.after_cancel(self._region_id)
            except Exception:
                pass
        if self._is_scrolling:
            # Don't recompute while actively scrolling; _settle fires it.
            self._region_id = "deferred"
            return
        self._region_id = self.after(16, self._do_update_region)

    def _do_update_region(self) -> None:
        self._region_id = None
        try:
            if self._scroll_canvas:
                self._scroll_canvas.configure(
                    scrollregion=self._scroll_canvas.bbox("all")
                )
        except Exception:
            pass

    def _on_settle(self) -> None:
        """Called 80 ms after the last wheel event — safe to recompute region."""
        self._settle_id   = None
        self._is_scrolling = False
        # Flush any held-off region recompute
        if self._region_id == "deferred":
            self._region_id = None
            self._do_update_region()

    # ── Wheel event handler (fixes 2, 3, 4b) ─────────────────────────────

    def _scroll_handler(self, event: tk.Event) -> str:
        if self._scroll_canvas is None:
            return "continue"

        # Mark as actively scrolling → suppress region recompute (fix 4a)
        self._is_scrolling = True
        if self._settle_id:
            try:
                self.after_cancel(self._settle_id)
            except Exception:
                pass
        self._settle_id = self.after(_SETTLE_MS, self._on_settle)

        # Accumulate delta (fix 4b / fix 3)
        if event.num == 4:          # Linux up
            self._pending_units -= _UNITS_PER_NOTCH
        elif event.num == 5:        # Linux down
            self._pending_units += _UNITS_PER_NOTCH
        else:
            # Windows/macOS: delta is ±120 per notch (sometimes ±240 for
            # high-resolution wheels or fast flicks)
            notches = event.delta / 120
            self._pending_units -= notches * _UNITS_PER_NOTCH

        # Schedule a single flush for this batch window (fix 4b)
        if self._batch_id is None:
            self._batch_id = self.after(_BATCH_MS, self._flush_scroll)

        return "break"      # stop the event reaching any other widget

    def _flush_scroll(self) -> None:
        """Apply accumulated units in a single canvas call."""
        self._batch_id = None
        if self._scroll_canvas is None or not self._pending_units:
            self._pending_units = 0.0
            return
        # Round toward the larger magnitude so small flicks still register
        units = int(self._pending_units)
        if units == 0:
            units = 1 if self._pending_units > 0 else -1
        # Carry fractional remainder to the next batch
        self._pending_units -= units
        try:
            self._scroll_canvas.yview_scroll(units, "units")
        except Exception:
            pass

    # ── Recursive wheel-event redirect (fix 2) ────────────────────────────

    def bind_children(self) -> None:
        """
        Redirect wheel events from every descendant widget to this scroll frame.
        Call once after all content is added.  Safe to call multiple times.
        """
        self._bind_tree(self)

    def _bind_tree(self, widget: tk.Widget) -> None:
        try:
            widget.bind("<MouseWheel>", self._scroll_handler, add=True)
            widget.bind("<Button-4>",   self._scroll_handler, add=True)
            widget.bind("<Button-5>",   self._scroll_handler, add=True)
        except Exception:
            pass
        try:
            for child in widget.winfo_children():
                self._bind_tree(child)
        except Exception:
            pass

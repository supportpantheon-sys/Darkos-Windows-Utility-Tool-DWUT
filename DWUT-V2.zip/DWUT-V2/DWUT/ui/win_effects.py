"""
ui/win_effects.py

Windows 11 rounds top-level window corners automatically via its own
window manager — but ONLY for normally-decorated windows. Both the splash
and the main window use overrideredirect(True) (no native titlebar), which
opts them out of that automatic rounding, leaving hard square corners.

This restores it explicitly via the DWM API (DwmSetWindowAttribute with
DWMWA_WINDOW_CORNER_PREFERENCE), which is the same mechanism Windows 11
itself uses. No-ops harmlessly on Windows 10 or older (the attribute is
simply rejected) and on any non-Windows platform.

Alt-Tab / Taskbar
-----------------
The "ghost owner" trick is the only approach that works reliably across
all Windows 10/11 configurations for overrideredirect windows.

How it works: Windows decides whether a window appears in the taskbar/
Alt-Tab based on whether it has a *visible* owner window. A window with
no owner that has WS_EX_APPWINDOW set should appear — but the style
write often gets silently discarded when the window is first mapped,
because Tk creates overrideredirect windows as WS_EX_TOOLWINDOW before
your Python code can intercept them, and some Windows versions treat
TOOLWINDOW as permanent at creation time.

The ghost approach creates one small hidden Tk Toplevel (no
overrideredirect, fully decorated, but never visible) and makes the main
window an *owned* window of that ghost via SetWindowLong(GWL_HWNDPARENT).
Windows then shows the main window in the taskbar because its owner is
a real WS_EX_APPWINDOW window, bypassing the TOOLWINDOW classification
entirely.  Minimize works naturally too — iconify() on the main window
hides both, and the taskbar entry stays the ghost's entry so it never
disappears.
"""

from __future__ import annotations

import sys

_ghost_window = None   # module-level singleton; created once, reused


def _get_ghost(root) -> object | None:
    """Return (creating if needed) the hidden owner Toplevel."""
    global _ghost_window
    if not sys.platform == "win32":
        return None
    try:
        import tkinter as tk
        if _ghost_window is None or not _ghost_window.winfo_exists():
            _ghost_window = tk.Toplevel(root)
            _ghost_window.withdraw()          # never visible
            _ghost_window.title("dwut_ghost") # invisible but sets app name
            _ghost_window.overrideredirect(False)
        return _ghost_window
    except Exception:
        return None


def round_window_corners(root) -> None:
    """Apply Windows 11's rounded-corner window style to a Tk root.
    Call after the window has an HWND (i.e. after it's been created —
    winfo_id() is valid immediately after widget construction, no need
    to wait for it to be mapped/visible)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        hwnd = root.winfo_id()
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        value = ctypes.c_int(DWMWCP_ROUND)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            ctypes.c_void_p(hwnd),
            ctypes.c_int(DWMWA_WINDOW_CORNER_PREFERENCE),
            ctypes.byref(value),
            ctypes.sizeof(value),
        )
    except Exception:
        pass   # Windows 10 or older, or the call just isn't available — fine either way


def enable_taskbar_and_alt_tab(root) -> None:
    """
    Make an overrideredirect(True) window appear in the taskbar and Alt-Tab.

    Uses the "ghost owner" approach: a hidden real window is made the GWL_HWNDPARENT
    owner of the main window so Windows classifies it as a real app regardless of
    whatever extended style Tk initially set on it.

    Falls back to the SetWindowLong WS_EX_APPWINDOW approach if the ghost creation
    fails, so there's always at least an attempt on older Tk builds.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32

        hwnd = root.winfo_id()

        # ── Primary: ghost owner trick ──────────────────────────────────
        ghost = _get_ghost(root)
        if ghost is not None:
            ghost_hwnd = ghost.winfo_id()
            GWL_HWNDPARENT = -8
            user32.SetWindowLongW(ctypes.c_void_p(hwnd), GWL_HWNDPARENT, ghost_hwnd)
        # ────────────────────────────────────────────────────────────────

        # ── Belt-and-suspenders: also set WS_EX_APPWINDOW explicitly ───
        GWL_EXSTYLE     = -20
        WS_EX_APPWINDOW = 0x00040000
        WS_EX_TOOLWINDOW = 0x00000080

        style = user32.GetWindowLongW(ctypes.c_void_p(hwnd), GWL_EXSTYLE)
        style &= ~WS_EX_TOOLWINDOW
        style |= WS_EX_APPWINDOW
        user32.SetWindowLongW(ctypes.c_void_p(hwnd), GWL_EXSTYLE, style)
        # ────────────────────────────────────────────────────────────────

        # Flush the style change so it takes effect immediately.
        SWP_NOMOVE      = 0x0002
        SWP_NOSIZE      = 0x0001
        SWP_NOZORDER    = 0x0004
        SWP_FRAMECHANGED = 0x0020
        user32.SetWindowPos(
            ctypes.c_void_p(hwnd), None, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
        )
    except Exception:
        pass

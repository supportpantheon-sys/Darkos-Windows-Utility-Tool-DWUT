"""
modules/system/power_modes.py

Two persistent, toggleable power modes on top of Windows' own power plans.

Ultimate Performance
────────────────────
  • Unhides and activates Windows' built-in "Ultimate Performance" plan.
  • Removes background throttling / idle timers.
  • ALSO sets the hardware-accelerated GPU scheduling (HAGS) registry flag
    and all GPU-related power settings (adaptive power save off, prefer
    max performance) so the graphics card actually runs flat-out rather
    than clocking down when the power plan changes.

Extreme Performance
───────────────────
  • Everything in Ultimate Performance, plus:
    – CPU minimum state pinned to 100% (cores never downclock)
    – USB selective suspend disabled
    – PCI Express ASPM disabled
  • GPU settings pushed further: graphics power plan set to the Microsoft
    "High Performance" GPU preference (Windows 11) or the NVIDIA/AMD
    control-panel equivalent via registry.

Both switch the active power plan AND apply GPU/graphics settings
atomically — toggling one off reverts everything (Balanced plan +
GPU settings restored to Windows defaults).
"""

from __future__ import annotations

import subprocess
import winreg
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)

_PLAN_ULTIMATE_PERF = "e9a42b02-d5df-448d-aa00-03f14749eb61"
_PLAN_BALANCED       = "381b4222-f694-41f0-9685-ff5bb260df2e"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _run(args: list[str], timeout: int = 10) -> tuple[bool, str]:
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return False, str(exc)


def _find_scheme_guid(name_fragment: str) -> Optional[str]:
    ok, out = _run(["powercfg", "/list"])
    if not ok:
        return None
    for line in out.splitlines():
        if name_fragment.lower() in line.lower():
            for part in line.split():
                if len(part) == 36 and part.count("-") == 4:
                    return part
    return None


def _reg_set(hive, path: str, name: str, value, val_type=winreg.REG_DWORD) -> bool:
    try:
        key = winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, val_type, value)
        winreg.CloseKey(key)
        return True
    except Exception as exc:
        _log.debug("Registry write failed %s\\%s: %s", path, name, exc)
        return False


def _reg_delete(hive, path: str, name: str) -> bool:
    """Delete a registry value, ignoring 'not found' errors."""
    try:
        key = winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return True     # already gone — fine
    except Exception as exc:
        _log.debug("Registry delete failed %s\\%s: %s", path, name, exc)
        return False


# ── GPU / Graphics settings ────────────────────────────────────────────────────

# Windows 11 Graphics preference keys live under:
#   HKCU\Software\Microsoft\DirectX\UserGpuPreferences
# Each app's preference is stored as a string value whose name is the full
# exe path.  Setting "__NV_OPTIMUS" (special key used system-wide) to
# "GpuPreference=2;" enables "High performance" for all apps by default.
_HKCU_GPU_PREF = r"Software\Microsoft\DirectX\UserGpuPreferences"

# HAGS (Hardware-Accelerated GPU Scheduling) — Win10 2004+
_HKLM_HAGS_PATH = r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers"

# NVIDIA power mode via registry (applies when NVCP isn't running)
_HKLM_NV_BASE = r"SYSTEM\CurrentControlSet\Control\Video"


def _set_graphics_max_performance() -> list[str]:
    """
    Apply all GPU/graphics power settings for Maximum Performance.
    Returns a list of human-readable actions taken.
    """
    actions: list[str] = []

    # 1. HAGS on
    ok = _reg_set(winreg.HKEY_LOCAL_MACHINE, _HKLM_HAGS_PATH,
                  "HwSchMode", 2)
    if ok:
        actions.append("Hardware-Accelerated GPU Scheduling: Enabled")

    # 2. Windows 11 / 10 per-GPU power policy via DirectX key
    #    GpuPreference=2 → High Performance
    ok = _reg_set(
        winreg.HKEY_CURRENT_USER, _HKCU_GPU_PREF,
        "DefaultGpuPreference", "GpuPreference=2;",
        val_type=winreg.REG_SZ,
    )
    if ok:
        actions.append("GPU Graphics Preference: High Performance")

    # 3. Power plan GPU sub-group — prefer max performance on all schemes
    #    Subgroup: GPU Preference Policy (GUID for "Prefer Maximum Performance")
    #    This affects the active plan's GPU preference setting visible in
    #    advanced power plan settings → "Graphics settings" on Win11.
    gpu_subgroup = "5fb4938d-1ee8-4b0f-9a3c-5036b0ab995c"   # Graphics settings
    gpu_setting  = "dd848b2a-8a5d-4451-9ae2-39cd41658f6c"   # GPU preference policy
    # 2 = Prefer Maximum Performance
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "2"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "2"])
    actions.append("Power Plan GPU Preference: Prefer Maximum Performance")

    # 4. Adaptive power save feature (NVIDIA) via powercfg
    #    Subgroup: PCI Express / Link State Power Management (turn off)
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "0"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "0"])
    actions.append("PCI Express ASPM (Link State Power Mgmt): Off")

    # 5. Apply the changes to the current scheme
    _run(["powercfg", "/setactive", "SCHEME_CURRENT"])

    return actions


def _restore_graphics_defaults() -> list[str]:
    """
    Revert GPU/graphics settings back to Windows defaults.
    """
    actions: list[str] = []

    # HAGS back to default (auto = 0 means OS chooses)
    _reg_delete(winreg.HKEY_LOCAL_MACHINE, _HKLM_HAGS_PATH, "HwSchMode")
    actions.append("HAGS: Restored to Windows default")

    # Remove the per-user GPU preference override
    _reg_delete(winreg.HKEY_CURRENT_USER, _HKCU_GPU_PREF, "DefaultGpuPreference")
    actions.append("GPU Graphics Preference: Restored to Windows default")

    # GPU sub-group in power plan back to "balanced" (0 = adaptive)
    gpu_subgroup = "5fb4938d-1ee8-4b0f-9a3c-5036b0ab995c"
    gpu_setting  = "dd848b2a-8a5d-4451-9ae2-39cd41658f6c"
    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "0"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", gpu_subgroup, gpu_setting, "0"])
    actions.append("Power Plan GPU Preference: Balanced")

    _run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "1"])
    _run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_PCIEXPRESS", "ASPM", "1"])
    _run(["powercfg", "/setactive", "SCHEME_CURRENT"])

    return actions


# ── Power plan setup ───────────────────────────────────────────────────────────

def _ensure_ultimate_scheme() -> Optional[str]:
    existing = _find_scheme_guid("Ultimate Performance")
    if existing:
        return existing
    ok, out = _run(["powercfg", "/duplicatescheme", _PLAN_ULTIMATE_PERF])
    if not ok:
        return None
    for part in out.split():
        if len(part) == 36 and part.count("-") == 4:
            return part
    return _find_scheme_guid("Ultimate Performance")


def _ensure_extreme_scheme() -> Optional[str]:
    existing = _find_scheme_guid("Extreme Performance")
    if existing:
        return existing

    base = _ensure_ultimate_scheme()
    if not base:
        return None

    ok, out = _run(["powercfg", "/duplicatescheme", base])
    if not ok:
        return None
    new_guid = None
    for part in out.split():
        if len(part) == 36 and part.count("-") == 4:
            new_guid = part
            break
    if not new_guid:
        return None

    _run(["powercfg", "/changename", new_guid, "Extreme Performance",
          "Maximum performance — disables USB/PCIe power saving and pins CPU to 100% min state."])

    # CPU minimum state → 100% (cores never downclock)
    _run(["powercfg", "/setacvalueindex", new_guid, "SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"])
    _run(["powercfg", "/setdcvalueindex", new_guid, "SUB_PROCESSOR", "PROCTHROTTLEMIN", "100"])
    # USB selective suspend off
    _run(["powercfg", "/setacvalueindex", new_guid, "SUB_USB", "USBSELECTSUSPEND", "0"])
    _run(["powercfg", "/setdcvalueindex", new_guid, "SUB_USB", "USBSELECTSUSPEND", "0"])
    # PCI Express ASPM off
    _run(["powercfg", "/setacvalueindex", new_guid, "SUB_PCIEXPRESS", "ASPM", "0"])
    _run(["powercfg", "/setdcvalueindex", new_guid, "SUB_PCIEXPRESS", "ASPM", "0"])

    return new_guid


# ── Public API ─────────────────────────────────────────────────────────────────

def is_ultimate_performance_active() -> bool:
    ok, out = _run(["powercfg", "/getactivescheme"])
    return ok and "ultimate performance" in out.lower()


def is_extreme_performance_active() -> bool:
    ok, out = _run(["powercfg", "/getactivescheme"])
    return ok and "extreme performance" in out.lower()


def enable_ultimate_performance() -> tuple[bool, str]:
    """Activate Ultimate Performance power plan AND set all GPU settings to max."""
    guid = _ensure_ultimate_scheme()
    if not guid:
        return False, "Could not create the Ultimate Performance power plan."

    ok, out = _run(["powercfg", "/setactive", guid])
    if not ok:
        return False, out or "Failed to activate Ultimate Performance."

    gpu_actions = _set_graphics_max_performance()
    detail = "  |  ".join(gpu_actions) if gpu_actions else "(no GPU changes)"
    _log.info("Activated Ultimate Performance — GPU: %s", detail)
    return True, f"✓ Ultimate Performance active.  GPU settings set to max.\n  {detail}"


def enable_extreme_performance() -> tuple[bool, str]:
    """Activate Extreme Performance power plan AND set all GPU settings to max."""
    guid = _ensure_extreme_scheme()
    if not guid:
        return False, "Could not create the Extreme Performance power plan."

    ok, out = _run(["powercfg", "/setactive", guid])
    if not ok:
        return False, out or "Failed to activate Extreme Performance."

    gpu_actions = _set_graphics_max_performance()
    detail = "  |  ".join(gpu_actions) if gpu_actions else "(no GPU changes)"
    _log.info("Activated Extreme Performance — GPU: %s", detail)
    return True, f"✓ Extreme Performance active.  GPU + CPU settings maxed.\n  {detail}"


def revert_to_balanced() -> tuple[bool, str]:
    """Switch back to Balanced power plan AND restore GPU settings to defaults."""
    ok, out = _run(["powercfg", "/setactive", _PLAN_BALANCED])
    if not ok:
        return False, out or "Failed to switch power plan."

    gpu_actions = _restore_graphics_defaults()
    detail = "  |  ".join(gpu_actions) if gpu_actions else ""
    _log.info("Reverted to Balanced — GPU: %s", detail)
    return True, f"Reverted to Balanced power plan.  GPU settings restored.\n  {detail}"

"""
modules/system/platform_info.py

Windows 10 and Windows 11 report the same major version (10) through most
of the classic Win32 APIs — the only reliable way to tell them apart is
the build number: Microsoft's own cutoff is build 22000 (Windows 11's
first RTM build). A lot of this app's tweaks and features (Recall,
several newer Settings-app toggles, some Explorer behaviors) only exist
on Windows 11, so anything that isn't there on Windows 10 should check
is_windows_11() before showing itself rather than just failing silently
(or worse, "succeeding" a registry write for a setting that does nothing
on that OS).
"""

from __future__ import annotations

import sys
from functools import lru_cache

_WIN11_BUILD_CUTOFF = 22000


@lru_cache(maxsize=1)
def get_build_number() -> int:
    """Current Windows build number, or 0 if not on Windows / unreadable."""
    if sys.platform != "win32":
        return 0
    try:
        import sys as _sys
        return _sys.getwindowsversion().build
    except Exception:
        return 0


@lru_cache(maxsize=1)
def is_windows_11() -> bool:
    return get_build_number() >= _WIN11_BUILD_CUTOFF


@lru_cache(maxsize=1)
def is_windows_10() -> bool:
    build = get_build_number()
    return 0 < build < _WIN11_BUILD_CUTOFF


@lru_cache(maxsize=1)
def windows_display_name() -> str:
    if is_windows_11():
        return "Windows 11"
    if is_windows_10():
        return "Windows 10"
    return "Windows (unknown version)" if sys.platform == "win32" else "Non-Windows"

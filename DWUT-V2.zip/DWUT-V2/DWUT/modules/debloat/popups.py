"""
modules/debloat/popups.py — Registry-based popup / watermark suppression.

All functions return bool: True = success, False = failure.
Every disable has a matching re-enable for full reversibility.
"""

from __future__ import annotations

import subprocess
import winreg

from core.logger import get_logger

_log = get_logger(__name__)


def _reg_set(hive, path: str, name: str, value, val_type=winreg.REG_DWORD) -> bool:
    try:
        key = winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, val_type, value)
        winreg.CloseKey(key)
        return True
    except Exception as exc:
        _log.warning("reg_set failed %s: %s", name, exc)
        return False


def _reg_delete(hive, path: str, name: str) -> bool:
    try:
        key = winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return True
    except Exception as exc:
        _log.warning("reg_delete failed %s: %s", name, exc)
        return False


def _schtask(action: str, task: str) -> bool:
    """Enable or disable a scheduled task."""
    try:
        result = subprocess.run(
            ["schtasks", f"/{action}", "/TN", task],
            capture_output=True, text=True, timeout=8,
        )
        return result.returncode == 0
    except Exception as exc:
        _log.warning("schtask %s %s: %s", action, task, exc)
        return False


# ── 1. Activate Windows watermark ─────────────────────────────────────────────

def _disable_activation_watermark() -> bool:
    """
    Remove the 'Activate Windows' desktop watermark and suppress the
    Settings nag.  Works on Windows 10 and 11.

    PaintDesktopVersion=0 → DWM stops painting the build/watermark overlay.
    NoActivationUI=1      → Suppresses the Settings activation page nag.
    FlightingBranchName   → Prevents "Insider Preview" style watermarks.
    """
    ok1 = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
        "PaintDesktopVersion", 0,
    )
    ok2 = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform\Activation",
        "NoActivationUI", 1,
    )
    # Also suppress the action center / Settings nag badge
    ok3 = _reg_set(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",
        "Start_NotifyNewApps", 0,
    )
    _log.info("Disabled Activate Windows watermark: %s %s %s", ok1, ok2, ok3)
    return ok1 or ok2  # ok3 is a bonus; don't count it as a failure


def _enable_activation_watermark() -> bool:
    """Restore the Activate Windows watermark (re-enable DWM overlay)."""
    ok1 = _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
        "PaintDesktopVersion",
    )
    ok2 = _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform\Activation",
        "NoActivationUI",
    )
    return ok1 or ok2


# ── 2. License expiry notification ────────────────────────────────────────────

# Scheduled tasks responsible for the notification
_ACTIVATION_TASKS = [
    r"\Microsoft\Windows\License Manager\TempSignedLicenseExchange",
    r"\Microsoft\Windows\SoftwareProtectionPlatform\SvcRestartTaskLogon",
    r"\Microsoft\Windows\SoftwareProtectionPlatform\SvcRestartTaskNetwork",
]


def _disable_license_expiry_notification() -> bool:
    results = []
    for task in _ACTIVATION_TASKS:
        results.append(_schtask("Disable", task))
    # Also kill the notification agent registry entry
    ok = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Notifications\Data",
        "918ABB48", 0,
    )
    results.append(ok)
    _log.info("Disabled license expiry notifications: %s", results)
    return any(results)


def _enable_license_expiry_notification() -> bool:
    results = []
    for task in _ACTIVATION_TASKS:
        results.append(_schtask("Enable", task))
    _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Notifications\Data",
        "918ABB48",
    )
    return any(results)


# ── 3. OOBE / "Personalize your PC" nag ──────────────────────────────────────

def _disable_oobe_nag() -> bool:
    """
    Suppress "Let's finish setting up your PC" and the personalization nag.
    Uses ContentDeliveryManager flags (the same ones that kill Spotlight
    and suggested apps) and the OemPreInstallation disable flag.
    """
    cdm_path = r"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
    flags = [
        ("ContentDeliveryAllowed",        0),
        ("OemPreInstalledAppsEnabled",    0),
        ("PreInstalledAppsEnabled",       0),
        ("PreInstalledAppsEverEnabled",   0),
        ("SilentInstalledAppsEnabled",    0),
        ("SubscribedContentEnabled",      0),
        ("SystemPaneSuggestionsEnabled",  0),
    ]
    ok = False
    for name, val in flags:
        if _reg_set(winreg.HKEY_CURRENT_USER, cdm_path, name, val):
            ok = True

    # Suppress the OOBE nag run key
    _reg_set(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement",
        "ScoobeSystemSettingEnabled", 0,
    )

    _log.info("Disabled OOBE/personalize nag")
    return ok


def _enable_oobe_nag() -> bool:
    cdm_path = r"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
    flags = [
        "ContentDeliveryAllowed",
        "OemPreInstalledAppsEnabled",
        "PreInstalledAppsEnabled",
        "PreInstalledAppsEverEnabled",
        "SilentInstalledAppsEnabled",
        "SubscribedContentEnabled",
        "SystemPaneSuggestionsEnabled",
    ]
    ok = False
    for name in flags:
        if _reg_delete(winreg.HKEY_CURRENT_USER, cdm_path, name):
            ok = True
    _reg_delete(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement",
        "ScoobeSystemSettingEnabled",
    )
    return ok


# ── 4. Windows 11 Settings activation banner ─────────────────────────────────

def _disable_settings_activation_banner() -> bool:
    """
    Hide the orange 'Activate Windows' banner in Settings on Windows 11.
    Only applies to Windows 11; safe no-op on Windows 10.
    """
    ok = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\WindowsRuntime\ActivationBanner",
        "HideBanner", 1,
    )
    # Additional Win11 Settings telemetry nag suppression
    _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\OOBE",
        "SetupDisplayedProductKeyPage", 1,
    )
    _log.info("Disabled Win11 Settings activation banner: %s", ok)
    return ok


def _enable_settings_activation_banner() -> bool:
    ok = _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\WindowsRuntime\ActivationBanner",
        "HideBanner",
    )
    _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\OOBE",
        "SetupDisplayedProductKeyPage",
    )
    return ok


# ── 5. Get Genuine Windows / SmartScreen activation alert ────────────────────

def _disable_get_genuine_windows() -> bool:
    """
    Suppress 'Get Genuine Windows' overlay and SmartScreen activation alert.
    """
    ok1 = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform",
        "NoActivationUI", 1,
    )
    # Disable the GenuineCenter scheduled task (exists on some Win10 editions)
    _schtask("Disable", r"\Microsoft\Windows\Application Experience\ProgramDataUpdater")
    # Disable the LUA activation prompt flag
    ok2 = _reg_set(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Software Protection Platform",
        "NoGenTicket", 1,
    )
    _log.info("Disabled Get Genuine Windows: %s %s", ok1, ok2)
    return ok1 or ok2


def _enable_get_genuine_windows() -> bool:
    _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform",
        "NoActivationUI",
    )
    _schtask("Enable", r"\Microsoft\Windows\Application Experience\ProgramDataUpdater")
    _reg_delete(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Software Protection Platform",
        "NoGenTicket",
    )
    return True
